create database softpad_trz1_0170;
use softpad_trz1_0170;

/*-----------------------------------------------------------------------------------------------------------------------*/
/* TABLA DE CLIENTE DE TRANZABILIDAD
/*-----------------------------------------------------------------------------------------------------------------------*/
CREATE TABLE IF NOT EXISTS clientes(
id            int(5)  not null auto_increment,
ruc           char(11) not null,
nombre_cli    varchar(120) not null,
clave         char(6) not null,
PRIMARY KEY(id),
UNIQUE KEY uq_cliente_ruc (ruc),                     
UNIQUE KEY uq_cliente_nombre_cli (nombre_cli),                     
UNIQUE KEY uq_cliente_clave (clave))
ENGINE=InnoDB DEFAULT CHARSET=latin1;      
CREATE INDEX cliente_1 ON clientes(ruc);                                                                     

/*-----------------------------------------------------------------------------------------------------------------------*/
/* TABLA DE USUARIOS DE LA ORDEN
/*-----------------------------------------------------------------------------------------------------------------------*/
CREATE TABLE IF NOT EXISTS usuarios(
id           int(11)  not null auto_increment,
cod_user     char(3)  not null,                               /*REGISTRO UNICO */
nombre_user  varchar(80) not null,
PRIMARY KEY(id),
UNIQUE KEY  uq_usuarios_cod_user (cod_user),
UNIQUE KEY  uq_usuarios (nombre_user)) ENGINE=InnoDB DEFAULT CHARSET=latin1;
CREATE INDEX usuarios_1 ON usuarios(cod_user);                                                                     


/* TABLA DEL LISTADO DE TODAS LAS ORDENES */
/*-----------------------------------------------------------------------------------------------------------------------*/
CREATE TABLE IF NOT EXISTS cabecera(
id            int(11)  not null auto_increment,
ano_orden     int(4) not null,
n_orden       char(6) not null,        /*REGISTRO UNICO */
tiporeg       char(2) not null,      /*REGIMEN -DGA*/       
c_aduana      char(3) not null,      /*ADUANA -DGA*/    
cliente_id    int(5) not null,      /*ID DEL CLIENTE */
numblguia     char(25)  default "",      /*DOCUMENTO DE TRANSPORTE -SEA*/
nombre_d      varchar(50) default "",      /*DESCRIPCION DE ALMACEN -DGA*/   
nomtransp     varchar(40) default "",      /*NOMBRE DE TRANSPORTE -DGA*/     
tipo_aforo    char(1) default "",      /*CANAL -DGA*/            
fob_dol       decimal(15,3) default 0.000,   /*VALOR FOB */ 
tdder         decimal(15,3) default 0.000,   /*TOTAL DERECHOS */   
percepcion    decimal(15,3) default 0.000,   /*PERCEPCION */             
kne           decimal(14,3) default 0.000,   /*TOTAL KILOS NETOS -DGA */   
kbr           decimal(14,3) default 0.000,   /*TOTAL KILOS BRUTOS -DGA */ 
t_bultos      decimal(15,3) default 0.000,   /*TOTAL BULTOS -DGA */             
n_declar      char(6) default "",      /*NUMERACION -DGA*/             
ref_clie      varchar(200) default "",      /*REFERENCIA DE LA ORDEN -APE*/ 
cont1         varchar(75) default "",      /*CONTENIDO -DGA*/ 
fech_crea     datetime,                    /*Fecha de creacion */
fech_env      datetime,                    /*Fecha de Envio de la Orden */
fech_numer    datetime,                    /*Fecha de Numeracion */
fech_canc     datetime,                    /*Fecha de Cancelacion */
fech_aforo    datetime,                    /*Fecha de Aforo */
fech_levan    datetime,                    /*Fecha de Levante */
fech_regul    datetime,                    /*Fecha de Regularizacion */
fech_retir    datetime,                    /*Fecha de retiro */
fech_entreg   datetime,                    /*Fecha de entrega */
fech_fact     datetime,                    /*Fecha de Facturacion */
pRIMARY KEY(id),
UNIQUE KEY  uq_cabecera (ano_orden,n_orden,tiporeg,c_aduana),
CONSTRAINT fk_cabecera_cliente FOREIGN KEY (cliente_id) REFERENCES clientes (id)) ENGINE=InnoDB DEFAULT CHARSET=latin1;
CREATE INDEX cabecera_1 ON cabecera(ano_orden,n_orden,tiporeg,c_aduana);                                                                     

/*-----------------------------------------------------------------------------------------------------------------------*/
/* TABLA DE INCIDENCIA DE LA ORDEN
/*-----------------------------------------------------------------------------------------------------------------------*/
CREATE TABLE IF NOT EXISTS detalle(
id            int(11)  not null auto_increment,
cabecera_id   int(11)  not null,                                     	           
fecha_inc     datetime,                                       /*FECHA Y HORA */
estado        char(2)  not null,
incidencia    varchar(80) not null,
usuario_id    int(11) not null,
PRIMARY KEY(id,cabecera_id),
CONSTRAINT fk_detalle_cabecera FOREIGN KEY (cabecera_id) REFERENCES cabecera (id),
CONSTRAINT fk_detalle_usuarios FOREIGN KEY (usuario_id) REFERENCES usuarios (id)) ENGINE=InnoDB DEFAULT CHARSET=latin1;
