create user 'carlos'@'localhost' identified by 'Hola' ; 
show grants for 'carlos'@'localhost';
grant select on softpad_sad1_0170.ape to 'carlos'@'localhost';

show grants for 'carlos'@'localhost';

grant select on softpad_sad1_0170.* to 'carlos'@'localhost';
grant delete on softpad_sad1_0170.* to 'carlos'@'localhost';
grant insert, update on softpad_sad1_0170.* to 'carlos'@'localhost';

create user 'Trazabilidad2'@'localhost' identified by 'Trazabilidad707293';
show grants for 'Trazabilidad2'@'localhost';
grant select, insert, update, delete on softpad_trz1_1800.* to 'Trazabilidad2'@'localhost';
grant select, insert, update, delete on softpad_trz1_1220.* to 'Trazabilidad2'@'localhost';
grant select, insert, update, delete on softpad_trz1_0170.* to 'Trazabilidad2'@'localhost';
grant select on softpad_trz_tablas.* to 'Trazabilidad2'@'localhost';