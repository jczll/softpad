﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using Tranzabilidad.AccesoDatos;
using Trazabilidad.Interfaz;

namespace Trazabilidad.Web
{
    public partial class FrmIngresoUsuario : System.Web.UI.Page
    {
        IUnidadDeTrabajo unidadDeTrabajo = new UnidadDeTrabajo(ConfigurationManager.ConnectionStrings["TrzConexion"].ConnectionString);

        protected void Page_Load(object sender, EventArgs e)
        {
            //if (Request.QueryString["cod_inter"] == "0170")
            //    Img0170.Visible = true;
            //if (Request.QueryString["cod_inter"] == "1220")
            //    Img1220.Visible = true;
            //else
            //    Img1800.Visible = true;
            switch (Request.QueryString["cod_inter"])
            {
                case "0170":
                    Img0170.Visible = true;
                    break;
                case "1220":
                    Img1220.Visible = true;
                    break;
                default:
                    Img1800.Visible = true;
                    break;
            }
        }
        protected void BtnLogin_Click(object sender, EventArgs e)
        {
            Ingresar();
        }
        private void Ingresar()
        {
            Application["cod_inter"] = Convert.ToString(Request.QueryString["cod_inter"]);
            if (ValidaUsuario())
            {
                FormsAuthenticationTicket tkt;
                string cookieStr;
                HttpCookie httpCookie;
                tkt = new FormsAuthenticationTicket(
                          1,
                          TxtRuc.Text.Trim(),
                          DateTime.Now,
                          DateTime.Now.AddMinutes(220),
                          false,
                          ""
                          );
                cookieStr = FormsAuthentication.Encrypt(tkt);
                httpCookie = new HttpCookie(FormsAuthentication.FormsCookieName, cookieStr);

                Response.Cookies.Add(httpCookie);
                Response.Redirect("~/default.aspx", true);
            }
        }
        private bool ValidaUsuario()
        {
            var scod_inter = Application["cod_inter"].ToString();

            var Cliente = unidadDeTrabajo.RepositorioClientes.ObtenerClientePorRucyClave(TxtRuc.Text.Trim(), TxtPassword.Text.Trim(), scod_inter);
            if (Cliente.Count > 0)
            {
                foreach (var item in Cliente)
                {
                    Application["Cliente_id"] = item.id;
                    Application["Nombre_cli"] = item.nombre_cli.Trim();
                }
                DarDeBajarOrdenes(scod_inter);
                return true;
            }
            else
                Response.Write("<script>alert('No se ha podido Autenticar el ingreso de dicho Cliente ')</script>");
            return false;
        }
        private void DarDeBajarOrdenes(string scod_inter)
        {
            int iCabeceraId;
            int iClienteId;
            //Obtenemos la lista de Ordenes que van a darse de Baja
            var ListaClientes = unidadDeTrabajo.RepositorioClientes.ConsultarClienteParaBaja(scod_inter);
            //Obtenemos la lista de los Clientes que van a darse de Baja
            var ListaCabecera = unidadDeTrabajo.RepositorioCabecera.ConsultarOrdenesParaBaja(scod_inter);
            if (ListaCabecera.Count > 0)
            {
                foreach (var item in ListaCabecera)
                {
                    iCabeceraId= item.id;
                    ////Buscamos el registo que tenga los datos de insercion anterior
                    var iBorroDetalle = unidadDeTrabajo.RepositorioDetalle.BorraDetalleDeBaja(iCabeceraId, scod_inter);
                    if (iBorroDetalle > 0)
                    {
                        var iBorroCabecera = unidadDeTrabajo.RepositorioCabecera.BorraCabeceraDeBaja(iCabeceraId, scod_inter);
                    }
                }
            }
            if (ListaClientes.Count > 0)
            {
                foreach (var item in ListaClientes)
                {
                    iClienteId = item.id;
                }
            }
        }
    }
}