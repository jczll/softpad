﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using Tranzabilidad.AccesoDatos;
using Trazabilidad.Interfaz;

namespace Trazabilidad.Web
{
    public partial class FrmIngresoUsuario : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void BtnLogin_Click(object sender, EventArgs e)
        {
            Ingresar();
        }
        private void Ingresar()
        {
            if (ValidaUsuario())
            {
                FormsAuthenticationTicket tkt;
                string cookieStr;
                HttpCookie httpCookie;
                tkt = new FormsAuthenticationTicket(
                          1,
                          TxtRuc.Text.Trim(),
                          DateTime.Now,
                          DateTime.Now.AddMinutes(220),
                          false,
                          ""
                          );
                cookieStr = FormsAuthentication.Encrypt(tkt);
                httpCookie = new HttpCookie(FormsAuthentication.FormsCookieName, cookieStr);

                Response.Cookies.Add(httpCookie);
                Response.Redirect("~/default.aspx", true);
            }
        }
        private bool ValidaUsuario()
        {
            IUnidadDeTrabajo unidadDeTrabajo = new UnidadDeTrabajo(ConfigurationManager.ConnectionStrings["TrzConexion"].ConnectionString);

            var Cliente = unidadDeTrabajo.RepositorioClientes.ObtenerClientePorRucyClave(TxtRuc.Text.Trim(), TxtPassword.Text.Trim());
            if (Cliente.Count > 0)
            {
                foreach (var item in Cliente)
                {
                    Application["Cliente_id"] = item.id;
                    Application["Nombre_cli"] = item.nombre_cli.Trim();
                }
                return true;
            }
            else
                Response.Write("<script>alert('No se ha podido Autenticar el ingreso de dicho Cliente ')</script>");
            return false;
        }
    }
}