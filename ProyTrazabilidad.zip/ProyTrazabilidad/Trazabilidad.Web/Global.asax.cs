﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Optimization;
using System.Web.Routing;
using System.Web.Security;
using System.Web.SessionState;
using Tranzabilidad.AccesoDatos;
using Trazabilidad.Interfaz;

namespace Trazabilidad.Web
{
    public class Global : HttpApplication
    {
        void Application_Start(object sender, EventArgs e)
        {
            // Código que se ejecuta al iniciar la aplicación
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            BundleConfig.RegisterBundles(BundleTable.Bundles);
        }
        void Session_Start(object sender, EventArgs e)
        {
            //Si el Usuario esta ya autenticado que tome el codigo para buscar su nombre de usuario       
            if (HttpContext.Current.User.Identity.IsAuthenticated)
            {
                BuscaClienteIngresado(HttpContext.Current.User.Identity.Name);
            }
        }
        private void BuscaClienteIngresado(string sRuc)
        {
            IUnidadDeTrabajo unidadDeTrabajo = new UnidadDeTrabajo(ConfigurationManager.ConnectionStrings["TrzConexion"].ConnectionString);

            var Cliente = unidadDeTrabajo.RepositorioClientes.ObtenerClientePorRuc(sRuc);
            if (Cliente.Count > 0)
            {
                foreach (var item in Cliente)
                {
                    Application["Cliente_id"] = item.id;
                    Application["Nombre_cli"] = item.nombre_cli.Trim();
                }
            }
        }
    }
}