﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using Tranzabilidad.AccesoDatos;
using Trazabilidad.Interfaz;

namespace Trazabilidad.Web
{
    public class PaginaBase : System.Web.UI.Page
    {
        protected readonly IUnidadDeTrabajo unidadDeTrabajo;
        public PaginaBase()
        {
            unidadDeTrabajo = new UnidadDeTrabajo(ConfigurationManager.ConnectionStrings["TrzConexion"].ConnectionString);
        }
        protected void IsAutenticate()
        {
            //Verificando si el usuario esta autenticado a la aplicacion

            var sCod_inter = Application["cod_inter"].ToString();

            if (!HttpContext.Current.User.Identity.IsAuthenticated)
            {
                RedirectToLogin(sCod_inter);
            }
        }
        private void RedirectToLogin(string sCod_inter)
        {
            Response.Redirect("~/FrmIngresoUsuario.aspx?cod_inter="+sCod_inter);
        }
    }
}