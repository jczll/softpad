﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Trazabilidad.Web
{
    public partial class _Default : PaginaBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            base.IsAutenticate();
            if (!Page.IsPostBack)
            {
                ConsultarTrazabilidad();
            }
        }
        private void ConsultarTrazabilidad()
        {
            string scliente_id = Application["Cliente_id"].ToString();
            int icliente_id = Convert.ToInt32(scliente_id);
            var data = unidadDeTrabajo.RepositorioCabecera.ObtenerCabeceraPorCliente(icliente_id);
            GrdTablas.DataSource = data;
            GrdTablas.DataBind();
        }
        private string ObtenerNombreCliente(int iId)
        {
            var objetoBD = unidadDeTrabajo.clientes.Get((int)iId);
            return objetoBD.nombre_cli;
        }

        protected void BtnConsultar_Click(object sender, EventArgs e)
        {
            ConsultarTrazabilidadxReferenciaNumblguiaRegimen(TxtRef_clie.Text, Txnumblguia.Text, CmbTipoReg.Text);
        }
        private void ConsultarTrazabilidadxReferenciaNumblguiaRegimen(string sRef_clie, string sNumblguia, string sTiporeg)
        {
            var data = unidadDeTrabajo.RepositorioCabecera.ObtenerCabeceraPorReferenciaRegimenBl(sRef_clie,sNumblguia,sTiporeg);
            GrdTablas.DataSource = data;
            GrdTablas.DataBind();
        }
    }
}