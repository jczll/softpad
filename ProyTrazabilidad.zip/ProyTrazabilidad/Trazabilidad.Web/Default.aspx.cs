﻿using Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Trazabilidad.Web
{
    public partial class _Default : PaginaBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!String.IsNullOrWhiteSpace(Request.QueryString["cod_inter"]))
            {
                Application["cod_inter"] = Convert.ToString(Request.QueryString["cod_inter"]);
            }
            base.IsAutenticate();
            if (!Page.IsPostBack)
            {                
                Txtcod_inter.Text = Application["cod_inter"].ToString();
                Session["Trazabilidad"] = null;
                ConsultarTrazabilidad(TxtRef_clie.Text, Txnumblguia.Text, CmbTipoReg.Text);
            }
        }

        protected void BtnConsultar_Click(object sender, EventArgs e)
        {
            Session["Trazabilidad"] = null;
            ConsultarTrazabilidad(TxtRef_clie.Text, Txnumblguia.Text, CmbTipoReg.Text);
        }

        protected void GrdTablas_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            Session["Trazabilidad"] = null;
            GrdTablas.PageIndex = e.NewPageIndex;
            ConsultarTrazabilidad(TxtRef_clie.Text, Txnumblguia.Text, CmbTipoReg.Text);
        }

        private void ConsultarTrazabilidad(string sRef_clie, string sNumblguia, string sTiporeg)
        {
            dynamic data = null;
            if (Session["Trazabilidad"] == null)
            {
                string scliente_id = Application["Cliente_id"].ToString();
                int iCliente_Id = Convert.ToInt32(scliente_id);
                data = unidadDeTrabajo.RepositorioCabecera.ConsultarTrazabilidad(iCliente_Id, sRef_clie, sNumblguia, sTiporeg, Txtcod_inter.Text);
                Session["Trazabilidad"] = data;
            }
            else
            {
                data = Session["Trazabilidad"] as cabecera[];
            }
            GrdTablas.DataSource = data;
            GrdTablas.DataBind();
        }
    }
}