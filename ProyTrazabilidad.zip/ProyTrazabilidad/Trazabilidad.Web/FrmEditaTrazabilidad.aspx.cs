﻿using Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Trazabilidad.Web
{
    public partial class FrmEditaTrazabilidad : PaginaBase
    {
        public FrmEditaTrazabilidad()
        {
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            base.IsAutenticate();
            if (!Page.IsPostBack)
            {
                ObtenerCabeceraxId();
            }
        }
        private void ObtenerCabeceraxId()
        {
            if (String.IsNullOrWhiteSpace(Request.QueryString["id"]))
            {
                return;
            }
            else
            {
                var scod_inter = Application["cod_inter"].ToString();
                var id = Convert.ToInt32(Request.QueryString["id"]);
                var ListaCabecera = unidadDeTrabajo.RepositorioCabecera.ObtenerCabeceraCompletaPorId(id, scod_inter);
                foreach (var item in ListaCabecera)
                {
                    Txtn_orden.Text = item.ano_orden.ToString()+"-"+ item.n_orden.ToString();
                    Txtreg_aduana.Text = item.reg_aduana;
                    Txtaduana.Text = item.aduana;
                    TxtNumblguia.Text = item.numblguia;
                    TxtNombre_d.Text = item.nombre_d;
                    Txtnomtransp.Text = item.nomtransp;
                    Txtaforo.Text = item.aforo;
                    Txtfob_dol.Text = item.fob_dol.ToString();
                    Txttdder.Text = item.tdder.ToString();
                    TxtPercepcion.Text = item.percepcion.ToString();
                    Txtkne.Text = item.kne.ToString();
                    TxtKbr.Text = item.kbr.ToString();
                    Txtt_bultos.Text = item.t_bultos.ToString();
                    TxtN_declar.Text = item.n_declar;
                    Txtref_clie.Text = item.ref_clie;
                    TxtCont1.Text = item.cont1;
                }
                var data = unidadDeTrabajo.RepositorioDetalle.ObtenerDetallePorCabecera_Id(id, scod_inter);
                GrdIncidencias.DataSource = data;
                GrdIncidencias.DataBind();
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Session["Trazabilidad"] = null;
            Response.Redirect("default.aspx");
        }
    }
}