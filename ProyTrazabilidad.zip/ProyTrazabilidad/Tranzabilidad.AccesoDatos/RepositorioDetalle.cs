﻿using Dapper;
using Entidades;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Trazabilidad.Interfaz;

namespace Tranzabilidad.AccesoDatos
{
    public class RepositorioDetalle : Repositorio<Detalle>, IRepositorioDetalle
    {
        public RepositorioDetalle(string connectionString) : base(connectionString)
        {
        }

        public List<Detalle_completo> ObtenerDetallePorCabecera_Id(int iCabecera_Id, string sCod_inter)
        {
            var sSql = " select usuarios.id,fecha_inc,incidencia,nombre_user ";
                sSql = sSql + " from softpad_trz1_"+sCod_inter+".detalle ";
                sSql = sSql + "      left join softpad_trz1_" + sCod_inter + ".usuarios on usuarios.id=detalle.usuario_id ";
                sSql = sSql + " where cabecera_id=@FiltroCabecera_id order by fecha_inc desc";

            using (var connection = new MySqlConnection(_connectionString))
            {
                var result = connection.Query<Detalle_completo>(sSql, new { FiltroCabecera_id = iCabecera_Id }).ToList();
                return result;
            }
        }
        public int BorraDetalleDeBaja(int iCabecera_Id, string sCod_inter)
        {
            var sSql= "delete from softpad_trz1_" + sCod_inter + ".detalle ";
                sSql = sSql + " where cabecera_id=@FiltroCabecera_id";

            using (var connection = new MySqlConnection(_connectionString))
            {
                var result = connection.Execute(sSql, new { FiltroCabecera_id = iCabecera_Id });
                return result;
            }
        }
    }
}
