﻿using Dapper;
using Entidades;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Trazabilidad.Interfaz;

namespace Tranzabilidad.AccesoDatos
{
    public class RepositorioDetalle : Repositorio<Detalle>, IRepositorioDetalle
    {
        public RepositorioDetalle(string connectionString) : base(connectionString)
        {
        }

        public List<Detalle_completo> ObtenerDetallePorCabecera_Id(int iCabecera_Id)
        {
            var sSql = @"
                select usuarios.id,fecha_inc,incidencia,nombre_user 
                       from detalle
                            left join usuarios on usuarios.id=detalle.usuario_id 
                       where cabecera_id=@FiltroCabecera_id";

            using (var connection = new MySqlConnection(_connectionString))
            {
                var result = connection.Query<Detalle_completo>(sSql, new { FiltroCabecera_id = iCabecera_Id }).ToList();
                return result;
            }
        }
    }
}
