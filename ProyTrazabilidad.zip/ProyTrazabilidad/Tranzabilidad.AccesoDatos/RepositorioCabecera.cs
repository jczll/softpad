﻿using Dapper;
using Entidades;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Trazabilidad.Interfaz;

namespace Tranzabilidad.AccesoDatos
{
    public class RepositorioCabecera : Repositorio<cabecera>, IRepositorioCabecera
    {
        public RepositorioCabecera(string connectionString) : base(connectionString)
        {
        }
        public List<cabecera> ConsultarTrazabilidad(int iCliente_Id, string sRef_clie, string sNumblguia, string sTiporeg, string sCod_inter)
        {
            var sSql = "Select * from softpad_trz1_" + sCod_inter + ".cabecera ";
            var sWhere = "where cliente_id="+ iCliente_Id+" ";
            if (!string.IsNullOrWhiteSpace(sRef_clie))
                sWhere = sWhere + "and ref_clie like '%"+ sRef_clie.Trim()+"%'";
            if (!string.IsNullOrWhiteSpace(sNumblguia))
                sWhere = sWhere + " and numblguia like '%"+ sNumblguia.Trim()+"%'";
            if (!string.IsNullOrWhiteSpace(sTiporeg))
                sWhere = sWhere + " and tiporeg = '"+ sTiporeg.Trim()+"'";
            sSql = sSql + sWhere + " order by fech_crea desc";

            using (var connection = new MySqlConnection(_connectionString))
            {
                var result = connection.Query<cabecera>(sSql).ToList();
                return result;
            }
        }
        public List<cabecera_completa> ObtenerCabeceraCompletaPorId(int iId, string sCod_inter)
        {
            var sSql = "select ano_orden,n_orden,ta1.aduana,ta15.reg_aduana,numblguia,nombre_d,nomtransp,aforo,fob_dol,tdder,kbr,kne,t_bultos,n_declar,ref_clie,cont1 ";
                sSql = sSql + "from softpad_trz1_"+ sCod_inter + ".cabecera ";
                sSql = sSql + "     left join softpad_trz_tablas.ta1 ta1 on ta1.cod = cabecera.c_aduana ";
                sSql = sSql + "     left join softpad_trz_tablas.ta15 ta15 on ta15.cod = cabecera.tiporeg ";
                sSql = sSql + "     left join softpad_trz_tablas.ta18 ta18 on ta18.cod = cabecera.tipo_aforo ";
                sSql = sSql + "where id= @FiltroiId";

            using (var connection = new MySqlConnection(_connectionString))
            {
                //var result = connection.QueryFirst(sSql, new { FiltroiId = iId }).ToList();
                var result = connection.Query<cabecera_completa>(sSql, new { FiltroiId = iId }).ToList();
                return result;
            }
        }
        public List<cabecera> ConsultarOrdenesParaBaja(string sCod_inter)
        {
            var sSql = "Select * from softpad_trz1_" + sCod_inter + ".cabecera where curdate() > adddate(fech_crea, interval 90 day)";
            using (var connection = new MySqlConnection(_connectionString))
            {
                var result = connection.Query<cabecera>(sSql).ToList();
                return result;
            }
        }
        public int BorraCabeceraDeBaja(int iId, string sCod_inter)
        {
            var sSql = "delete from softpad_trz1_" + sCod_inter + ".cabecera where id=@Filtroid";

            using (var connection = new MySqlConnection(_connectionString))
            {
                var result = connection.Execute(sSql, new { Filtroid = iId });
                return result;
            }
        }
    }
}
