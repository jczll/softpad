﻿using Dapper;
using Entidades;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Trazabilidad.Interfaz;

namespace Tranzabilidad.AccesoDatos
{
    public class RepositorioCabecera : Repositorio<cabecera>, IRepositorioCabecera
    {
        public RepositorioCabecera(string connectionString) : base(connectionString)
        {
        }
        public List<cabecera> ObtenerCabeceraPorCliente(int iCliente_Id)
        {
            var sSql = "Select * from cabecera where cliente_id=@FiltroCliente_id ";
            using (var connection = new MySqlConnection(_connectionString))
            {
                var result = connection.Query<cabecera>(sSql, new { FiltroCliente_id = iCliente_Id }).ToList();
                return result;
            }
        }
        public List<cabecera> ObtenerCabeceraPorReferenciaRegimenBl(string sRef_clie, string sNumblguia, string sTiporeg)
        {
            var sSql = "Select * from cabecera ";
            var sWhere = "";
            if (!string.IsNullOrWhiteSpace(sRef_clie))
                sWhere = "where ref_clie = @FiltroRef_clie ";                
            if (!string.IsNullOrWhiteSpace(sNumblguia))
            {
                if (string.IsNullOrEmpty(sWhere))
                   sWhere = sWhere + "where numblguia = @FiltroNumblguia ";
                else
                   sWhere = sWhere + " and numblguia = @FiltroNumblguia ";
            }
            if (!string.IsNullOrWhiteSpace(sTiporeg))
            {
                if (string.IsNullOrEmpty(sWhere))
                    sWhere = sWhere + "where tiporeg = @FiltroTiporeg ";
                else
                    sWhere = sWhere + " and tiporeg = @FiltroTiporeg ";
            }
            sSql = sSql + sWhere;

            using (var connection = new MySqlConnection(_connectionString))
            {
                var result = connection.Query<cabecera>(sSql, new { FiltroRef_clie = sRef_clie, FiltroNumblguia = sNumblguia, FiltroTiporeg = sTiporeg }).ToList();
                return result;
            }
        }
        //public List<cabecera> ObtenerCabeceraPorReferenciaRegimenBl(string sRef_clie, string sNumblguia, string sTiporeg)
        //{
        //    var sSql = "Select * from cabecera ";
        //    var sWhere = "";
        //    if (!string.IsNullOrWhiteSpace(sRef_clie))
        //        sWhere = "where ref_clie = @FiltroRef_clie ";
        //    if (!string.IsNullOrWhiteSpace(sNumblguia))
        //    {
        //        if (string.IsNullOrEmpty(sWhere))
        //            sWhere = sWhere + "where numblguia = @FiltroNumblguia ";
        //        else
        //            sWhere = sWhere + " and numblguia = @FiltroNumblguia ";
        //    }
        //    if (!string.IsNullOrWhiteSpace(sTiporeg))
        //    {
        //        if (string.IsNullOrEmpty(sWhere))
        //            sWhere = sWhere + "where tiporeg = @FiltroTiporeg ";
        //        else
        //            sWhere = sWhere + " and tiporeg = @FiltroTiporeg ";
        //    }
        //    sSql = sSql + sWhere;

        //    using (var connection = new MySqlConnection(_connectionString))
        //    {
        //        if (!string.IsNullOrWhiteSpace(sRef_clie) && !string.IsNullOrWhiteSpace(sNumblguia) && !string.IsNullOrWhiteSpace(sTiporeg))
        //        {
        //            var result = connection.Query<cabecera>(sSql, new { FiltroRef_clie = sRef_clie, FiltroNumblguia = sNumblguia, FiltroTiporeg = sTiporeg }).ToList();
        //        }
        //        else
        //        {
        //            if (!string.IsNullOrWhiteSpace(sRef_clie) && !string.IsNullOrWhiteSpace(sNumblguia))
        //            {
        //                var result = connection.Query<cabecera>(sSql, new { FiltroRef_clie = sRef_clie, FiltroNumblguia = sNumblguia }).ToList();
        //            }
        //            else
        //            {
        //                if (!string.IsNullOrWhiteSpace(sRef_clie) && !string.IsNullOrWhiteSpace(sTiporeg))
        //                {
        //                    var result = connection.Query<cabecera>(sSql, new { FiltroRef_clie = sRef_clie, FiltroTiporeg = sTiporeg }).ToList();
        //                }
        //                else
        //                {
        //                    if (!string.IsNullOrWhiteSpace(sNumblguia) && !string.IsNullOrWhiteSpace(sTiporeg))
        //                    {
        //                        var result = connection.Query<cabecera>(sSql, new { FiltroNumblguia = sNumblguia, FiltroTiporeg = sTiporeg }).ToList();
        //                    }
        //                    else
        //                    {
        //                        if (!string.IsNullOrWhiteSpace(sRef_clie))
        //                        {
        //                            var result = connection.Query<cabecera>(sSql, new { FiltroRef_clie = sRef_clie }).ToList();
        //                        }
        //                        else
        //                        {
        //                            if (!string.IsNullOrWhiteSpace(sNumblguia))
        //                            {
        //                                var result = connection.Query<cabecera>(sSql, new { FiltroNumblguia = sNumblguia }).ToList();
        //                            }
        //                            else
        //                            {
        //                                if (!string.IsNullOrWhiteSpace(sTiporeg))
        //                                {
        //                                    var result = connection.Query<cabecera>(sSql, new { FiltroTiporeg = sTiporeg }).ToList();
        //                                }
        //                            }
        //                        }
        //                    }
        //                }
        //            }
        //        }
        //        return result;
        //    }
        //}
        public List<cabecera_completa> ObtenerCabeceraCompletaPorId(int iId)
        {
            var sSql = @"
            select ano_orden,n_orden,ta1.aduana,ta15.reg_aduana,numblguia,nombre_d,nomtransp,aforo,fob_dol,tdder,kbr,kne,t_bultos,n_declar,ref_clie,cont1
                   from cabecera
                        left join softpad_trz_tablas.ta1 ta1 on ta1.cod = cabecera.c_aduana
                        left join softpad_trz_tablas.ta15 ta15 on ta15.cod = cabecera.tiporeg
                        left join softpad_trz_tablas.ta18 ta18 on ta18.cod = cabecera.tipo_aforo 
                   where id= @FiltroiId";

            using (var connection = new MySqlConnection(_connectionString))
            {
                //var result = connection.QueryFirst(sSql, new { FiltroiId = iId }).ToList();
                var result = connection.Query<cabecera_completa>(sSql, new { FiltroiId = iId }).ToList();
                return result;
            }
        }
    }
}
