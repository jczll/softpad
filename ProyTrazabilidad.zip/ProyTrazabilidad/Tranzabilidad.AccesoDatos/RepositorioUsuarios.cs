﻿using Dapper;
using Entidades;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Trazabilidad.Interfaz;

namespace Tranzabilidad.AccesoDatos
{
    public class RepositorioUsuarios : Repositorio<Usuarios>, IRepositorioUsuarios
    {
        public RepositorioUsuarios(string connectionString) : base(connectionString)
        {
        }
        public List<Usuarios> ConsultarUsuariosParaBaja(string sCod_inter)
        {
            var sSql = "Select usuario_id from softpad_trz1_" + sCod_inter + ".detalle as detalle ";
                sSql = sSql + "left join softpad_trz1_" + sCod_inter + ".cabecera cabecera on cabecera.id = detalle.cabecera_id ";
                sSql = sSql + "where curdate() > adddate(cabecera.fech_crea, interval 15 day) ";
                sSql = sSql + "group by usuario_id";

            using (var connection = new MySqlConnection(_connectionString))
            {
                var result = connection.Query<Usuarios>(sSql).ToList();
                return result;
            }
        }
        public int BorraUsuarioDeBaja(int iUsuario_Id, string sCod_inter)
        {
            var sSql = "delete from softpad_trz1_" + sCod_inter + ".usuarios ";
            sSql = sSql + " where id=@FiltroUsuario_id";

            using (var connection = new MySqlConnection(_connectionString))
            {
                var result = connection.Execute(sSql, new { FiltroUsuario_id = iUsuario_Id });
                return result;
            }
        }
    }
}
