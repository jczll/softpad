﻿using Dapper;
using Entidades;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Trazabilidad.Interfaz;

namespace Tranzabilidad.AccesoDatos
{
    public class RepositorioClientes : Repositorio<Clientes>, IRepositorioClientes
    {
        public RepositorioClientes(string connectionString) : base(connectionString)
        {
        }

        public List<Clientes> ObtenerClientePorRuc(string sRuc, string sCod_inter)
        {
            var sSql = "Select * from softpad_trz1_" + sCod_inter + ".clientes where ruc=@FiltroRuc ";
            using (var connection = new MySqlConnection(_connectionString))
            {
                var result = connection.Query<Clientes>(sSql, new { FiltroRuc = sRuc }).ToList();
                return result;
            }
        }

        public List<Clientes> ObtenerClientePorRucyClave(string sRuc, string sClave, string sCod_inter)
        {
            var sSql = "Select * from softpad_trz1_"+ sCod_inter + ".clientes where ruc=@FiltroRuc and clave=@FiltroClave ";
            using (var connection = new MySqlConnection(_connectionString))
            {
                //var parameters = new { FirstName = "Maria", LastName = "Apellido" };
                var result = connection.Query<Clientes>(sSql, new { FiltroRuc = sRuc, FiltroClave = sClave }).ToList();
                return result;
            }
        }
    }
}
