﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidades;
using Trazabilidad.Interfaz;

namespace Tranzabilidad.AccesoDatos
{
    public class UnidadDeTrabajo : IUnidadDeTrabajo
    {
        public IRepositorio<cabecera> cabecera { get; private set; }
        public IRepositorio<Detalle> detalle { get; private set; }
        public IRepositorio<Clientes> clientes { get; private set; }
        public IRepositorio<Usuarios> usuarios { get; private set; }
        public IRepositorioClientes RepositorioClientes { get; private set; }
        public IRepositorioCabecera RepositorioCabecera { get; private set; }
        public IRepositorioDetalle RepositorioDetalle { get; private set; }

        public UnidadDeTrabajo(string connectionString)
        {
            cabecera = new Repositorio<cabecera>(connectionString);
            clientes = new Repositorio<Clientes>(connectionString);
            usuarios = new Repositorio<Usuarios>(connectionString);
            RepositorioClientes = new RepositorioClientes(connectionString);
            RepositorioCabecera = new RepositorioCabecera(connectionString);
            RepositorioDetalle = new RepositorioDetalle(connectionString);
        }
    }
}
