﻿using System.Configuration;
using System.Linq;
using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Tranzabilidad.AccesoDatos;
using Trazabilidad.Interfaz;
using Entidades;

namespace Trazabilidad.Prueba
{
    [TestClass]
    public class UnitTest1
    {
        private readonly IUnidadDeTrabajo unidadDeTrabajo;

        public UnitTest1()
        {
            unidadDeTrabajo = new UnidadDeTrabajo(ConfigurationManager.ConnectionStrings["TrzConexion"].ConnectionString);
        }

        [TestMethod]
        public void ObtenerTodoTest()
        {
            //Preparacion y Configuracion
            //var data = unidadDeTrabajo.actualizacion.GetList();
            var data = unidadDeTrabajo.cabecera.GetList();
            //Ejecucion : Obtener Data
            //Comprobacion
            Assert.AreEqual(true, data.Count > 0);
        }
        [TestMethod]
        public void InsertarTest()
        {
            var clientes = new Clientes()
            {
                ruc = "20500826527",
                nombre_cli = "TRAFERITO TOURS",
                clave = "T2027R"
            };
            var NuevoId = unidadDeTrabajo.clientes.Insert(clientes);
            //Obtener el objeto insertado para hacer la comprabacion
            var objetoBD = unidadDeTrabajo.clientes.Get((int)NuevoId);

            Assert.AreEqual(clientes.ruc, objetoBD.ruc);
        }
        [TestMethod]
        public void InsertarTestUsuario()
        {
            var usuarios = new Usuarios()
            {
                cod_user = "003",
                nombre_user = "ORLANDO MENDEZ GUERRERO"
            };
            var NuevoId = unidadDeTrabajo.usuarios.Insert(usuarios);
            //Obtener el objeto insertado para hacer la comprabacion
            var objetoBD = unidadDeTrabajo.usuarios.Get((int)NuevoId);

            Assert.AreEqual(usuarios.cod_user, objetoBD.cod_user);
        }
    }
}
