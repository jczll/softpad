﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Clientes
    {
        public int id { get; set; }
        [StringLength(11)]
        public string ruc { get; set; }
        public string nombre_cli { get; set; }
        [StringLength(6)]
        public string clave { get; set; }
    }
}
