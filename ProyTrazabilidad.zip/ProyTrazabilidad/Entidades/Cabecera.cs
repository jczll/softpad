﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class cabecera
    {
        public int id { get; set; }
        public int ano_orden { get; set; }
        public string n_orden { get; set; }
        public string tiporeg { get; set; }
        public string c_aduana { get; set; }
        public int cliente_id { get; set; }
        public string numblguia { get; set; }
        public string nombre_d { get; set; }
        public string nomtransp { get; set; }
        public string tipo_aforo { get; set; }
        public decimal fob_dol { get; set; }
        public decimal tdder { get; set; }
        public decimal percepcion { get; set; }
        public decimal kne { get; set; }
        public decimal kbr { get; set; }
        public int t_bultos { get; set; }
        public string n_declar { get; set; }
        public string ref_clie { get; set; }
        public string cont1 { get; set; }
        public DateTime? fech_crea { get; set; }
        public DateTime? fech_env { get; set; }
        public DateTime? fech_numer { get; set; }
        public DateTime? fech_canc { get; set; }
        public DateTime? fech_aforo { get; set; }
        public DateTime? fech_levan { get; set; }
        public DateTime? fech_regul { get; set; }
        public DateTime? fech_retir { get; set; }
        public DateTime? fech_entreg { get; set; }
        public DateTime? fech_fact { get; set; }
    }
    public class cabecera_completa
    {
        public int id { get; set; }
        public int ano_orden { get; set; }
        public string n_orden { get; set; }
        public string reg_aduana { get; set; }
        public string aduana { get; set; }
        public string numblguia { get; set; }
        public string nombre_d { get; set; }
        public string nomtransp { get; set; }
        public string aforo { get; set; }
        public decimal fob_dol { get; set; }
        public decimal tdder { get; set; }
        public decimal percepcion { get; set; }
        public decimal kne { get; set; }
        public decimal kbr { get; set; }
        public int t_bultos { get; set; }
        public string n_declar { get; set; }
        public string ref_clie { get; set; }
        public string cont1 { get; set; }
    }
}
