﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Usuarios
    {
        public int id { get; set; }
        [StringLength(3)]
        public string cod_user { get; set; }
        [StringLength(80)]
        public string nombre_user { get; set; }
    }
}
