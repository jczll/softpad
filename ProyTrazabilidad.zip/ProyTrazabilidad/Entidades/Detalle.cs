﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Detalle
    {
        public int id { get; set; }
        public string cabecera_id { get; set; }
        public DateTime fecha_inc { get; set; }
        public string estado { get; set; }
        public string incidencia { get; set; }
        public string usuario_id { get; set; }
    }
    public class Detalle_completo
    {
        public int id { get; set; }
        public DateTime fecha_inc { get; set; }
        public string incidencia { get; set; }
        public string nombre_user { get; set; }
    }
}
