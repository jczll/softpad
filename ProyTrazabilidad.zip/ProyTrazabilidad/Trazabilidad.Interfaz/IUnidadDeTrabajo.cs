﻿using Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Trazabilidad.Interfaz
{
    public interface IUnidadDeTrabajo
    {
        IRepositorio<cabecera> cabecera { get; }
        IRepositorio<Detalle> detalle { get; }
        IRepositorio<Clientes> clientes { get; }
        IRepositorio<Usuarios> usuarios { get; }
        IRepositorioClientes RepositorioClientes { get; }
        IRepositorioCabecera RepositorioCabecera { get; }
        IRepositorioDetalle RepositorioDetalle { get; }
    }
}
