﻿using Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Trazabilidad.Interfaz
{
    public interface IRepositorioClientes : IRepositorio<Clientes>
    {
        List<Clientes> ObtenerClientePorRucyClave(string sRuc, string sClave, string sCod_inter);
        List<Clientes> ObtenerClientePorRuc(string sRuc, string sCod_inter);
        List<Clientes> ConsultarClienteParaBaja(string sCod_inter);
        int BorraClienteDeBaja(int iCabecera_Id, string sCod_inter);
    }
}
