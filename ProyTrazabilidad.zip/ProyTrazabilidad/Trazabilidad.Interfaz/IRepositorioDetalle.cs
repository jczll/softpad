﻿using Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Trazabilidad.Interfaz
{
    public interface IRepositorioDetalle : IRepositorio<Detalle>
    {
        List<Detalle_completo> ObtenerDetallePorCabecera_Id(int iCabecera_Id);
    }
}
