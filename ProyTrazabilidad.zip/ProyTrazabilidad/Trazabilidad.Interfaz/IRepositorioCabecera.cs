﻿using Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Trazabilidad.Interfaz
{
    public interface IRepositorioCabecera : IRepositorio<cabecera>
    {
        List<cabecera> ObtenerCabeceraPorCliente(int iCliente_Id);
        List<cabecera_completa> ObtenerCabeceraCompletaPorId(int iId);
    }
}
