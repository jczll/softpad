﻿using Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Trazabilidad.Interfaz
{
    public interface IRepositorioCabecera : IRepositorio<cabecera>
    {
        List<cabecera> ConsultarTrazabilidad(int iCliente_Id, string sRef_clie, string sNumblguia, string sTiporeg, string sCod_inter);
        List<cabecera_completa> ObtenerCabeceraCompletaPorId(int iId, string sCod_inter);
        List<cabecera> ConsultarOrdenesParaBaja(string sCod_inter);
        int BorraCabeceraDeBaja(int iId, string sCod_inter);
    }
}
