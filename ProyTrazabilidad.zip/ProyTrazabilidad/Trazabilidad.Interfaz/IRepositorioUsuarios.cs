﻿using Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Trazabilidad.Interfaz
{
    public interface IRepositorioUsuarios : IRepositorio<Usuarios>
    {
        List<Usuarios> ConsultarUsuariosParaBaja(string sCod_inter);
        int BorraUsuarioDeBaja(int iUsuario_Id, string sCod_inter);
    }
}
