/********************************************************************************************/
/*            CREACION DE VISTAS EN LA BASE DE DATOS SOFTPAD_SAD1_1800                      */
/********************************************************************************************/
/********************************************************************************************/
/* Vista para el 1CPV para la edicion de clientes relacionados al proveedor */
create view Vista1Cpv as 
select cpv.COD_PROV, Cpv.VINCULAC, Cpv.INFL_VINCU, Cpv.PVATR12B,
       Cpv.PRECE1, Cpv.PCONMCIA, Cpv.PDECOND, Cpv.SPAG_INDIR, Cpv.PDESRET,
       Cpv.SDER_LICEN, Cpv.VENT_CONDI, Cpv.CONTMCIA, Cpv.CONTSUMI, Cpv.CLAUREVI,
       Cpv.INTIMPCLI, Cpv.DIFVALASI, Cpv.COND16, Cpv.COND17, Cpv.COND18, Cpv.COND19,
       Cpv.COND20, Cpv.CARACESTIM, Cpv.COD_CLIEN, Cpv.COD_INTERM, Itr.NOM_INTER,Cli.nombre
from cpv 
left join itr ON Cpv.COD_INTERM = Itr.CODIGO
left join cli ON Cpv.COD_CLIEN = Cli.CODIGO;

/********************************************************************************************/

/* Vista para el DJA para la declaracion Jurada en el ingreso de despachos del B */
create view VistaDja as 
SELECT Dja.NUME_SECUP, Pra.NOM_FABR, Dja.COD_PROV, Dja.N_ORDEN,
  Dja.NATURALEZA, Dja.TERM1, Dja.TERM2, Dja.FORM_ENVIO, Dja.NUME_ENVIO,
  Dja.VINCULAC, Dja.INFL_VINCU, Dja.PVATR12B, Dja.PRECE1, Dja.PCONMCIA,
  Dja.PDECOND, Dja.SPAG_INDIR, Dja.PDESRET, Dja.SDER_LICEN, Dja.VENT_CONDI,
  Dja.CONTMCIA, Dja.CONTSUMI, Dja.CLAUREVI, Dja.INTIMPCLI, Dja.DIFVALASI,
  Dja.COND16, Dja.COND17, Dja.COND18, Dja.COND19, Dja.COND20, Dja.CANT_FACTU,
  Dja.PRED_FACT, Dja.VTA_SUCESI, Dja.FLETE_FACT, Dja.SEGUR_FACT, Dja.DGASTO1,
  Dja.DGASTO2, Dja.DGASTO3, Dja.DGASTO4, Dja.DGASTO5, Dja.DADIC1, Dja.DADIC2,
  Dja.DADIC3, Dja.DADIC4, Dja.DADIC5, Dja.DADIC6, Dja.DADIC7, Dja.DADIC8,
  Dja.DADIC9, Dja.DDEDUC1, Dja.DDEDUC2, Dja.DDEDUC3, Dja.DDEDUC4, Dja.DDEDUC5,
  Dja.DFLETE2, Dja.COD_P_ADQ, Dja.CANT_DAV, Dja.FOB_FACT, Dja.CARACESTIM,
  Dja.CONT_OTRO, Dja.NUM_CONTRA, Dja.FCH_CONTRA, Dja.OTRODOC, Dja.FORMAPAGO,
  Dja.OTROFORMA, Dja.MEDIOPAGO, Dja.OTROMEDIO, Dja.OTRONATURA,
  Dja.COD_RESTRI, Dja.COD_CONDI, Dja.OTR_CONDI, Dja.COD_VINC, Dja.C_DOCORI,
  Dja.T_DOCORI, Dja.N_DOCORI, Dja.D_DOCORI, Dja.COD_INTERM, Dja.PAIS_PROV,
  Dja.CANT_ITEMS, Dja.PRE_FACT, Dja.AJUSTE, Dja.TOT_DEDUC, Dja.TERM3,
  Dja.NIVEL_COM, Dja.OTR_NIVC, Dja.CONDI_PRO, Dja.OTR_CONDP, Dja.TPROVIS,
  Dja.NUME_ENVP
 FROM DJA 
 LEFT JOIN PRA ON Dja.COD_PROV = Pra.CODIGO;

/********************************************************************************************/

/* Vista para el INC para las Incidencias del Despacho */
create view VistaInc as  
SELECT Inc.*, Usu.USUARIO, Dsp.NOMBRE 
 FROM inc 
 LEFT JOIN USU ON USU.CODIGO = INC.COD_USER 
 LEFT JOIN DSP ON DSP.CODIGO = INC.COD_RESPON ;

/********************************************************************************************/

/* Vista para el DED Derechos Definitivos en Numeracion y Cancelacion */
create view VistaDED as  
SELECT Dea.N_ORDEN, Dea.TIPO_DERE, Softpad_sistema.Ts35.derechos,Dea.CODIGO,Dea.DERE_LIQUI,Dea.DERE_PAGAR
 FROM dea
 LEFT JOIN softpad_sistema.ts35 ON Softpad_sistema.Ts35.codigo=Dea.CODIGO 
 WHERE tipo_dere="D";

/********************************************************************************************/
/* Vista para el DEL Liquidacion de Cobranzas en Numeracion y Cancelacion */
create view VistaDEL as  
SELECT Del.N_ORDEN,del.correl,Del.CODIGO,Softpad_sistema.Ts35.derechos,Del.NUMERO_LC,Del.FECHA_LC,Del.MONEDA,Del.T_CAMBIO,Del.DERE_DOLAR,Del.DERE_SOLES 
 FROM Del 
 LEFT JOIN softpad_sistema.ts35 ON Softpad_sistema.Ts35.codigo=Del.CODIGO ;

/********************************************************************************************/
/* Vista para el DDP Derechos Definitivos para la Proforma */
create view VistaDPD as  
SELECT Drp.N_PROF, Drp.TIPO_DERE, Drp.CODIGO,Softpad_sistema.Ts35.derechos AS derechos,Drp.DERE_LIQUI,Drp.DERE_PAGAR 
 FROM drp 
 LEFT JOIN softpad_sistema.ts35 ON Softpad_sistema.Ts35.codigo=DRP.CODIGO 
 WHERE tipo_dere="D";

/********************************************************************************************/
/* Vista para el CNT Listado de Contenedores */
create view VistaCNT as  
SELECT Cnt.N_ORDEN, Cnt.ORDEN, Cnt.TIPO_CNT, Cnt.TRANSPORTE, Cnt.NUME_CNT,
  Cnt.PESO_BRUTO, Cnt.TARA, Cnt.N_PRE_ADUA, Cnt.N_PRE_OTRO, Cnt.TAMANO,
  Cnt.TAMANOCON, Cnt.TIPO_INGRE, Cnt.INGRESO, Cnt.CODI_CONDI, Cnt.CONDICION,
  Cnt.DESC_MERC, Cnt.C_ADUANA, Cnt.TIPOREG, Cnt.NUMMANIF, Cnt.COD_CLIEN,
  Cnt.N_DUA, Cnt.FCH_DUA, Cnt.NAVE, Cnt.AUTORIZAC, Cnt.DESTINO, Cnt.AD_DOCASOC,
  Cnt.PAIS_DESTI, Cnt.COD_ANULA, Cnt.ELEGIDO, Cnt.MOTIVO_ANUL, Cli.nombre
 FROM Cnt 
 LEFT JOIN CLI ON Cnt.COD_CLIEN = Cli.CODIGO;

/*********************************************************************************/
/***********      VISTA PARA LOS ARCHIVOS ANEXOS DE LA TABLA DE CLIENTES    ******/
/*********************************************************************************/

/* Vista para el CPV para la edici�n de clientes relacionados al proveedor */
create view VistaCpv as 
SELECT Cpv.*, Pra.NOM_FABR, Pra.DIR1, Itr.NOM_INTER 
FROM cpv
LEFT JOIN pra ON Cpv.COD_PROV = Pra.CODIGO 
LEFT JOIN itr ON Cpv.COD_INTERM = Itr.CODIGO;

/*==================================================================================================*/

/* Vista para Las Comisiones por Cliente CLM  */
create view VistaCLM as  
SELECT Clm.COD_CLIEN,Clm.CORREL, Clm.TIPO_ADUAN,Softpad_sistema.Ts371.descripcio AS desc_aduan,Clm.TIPO_REGIM,Softpad_sistema.Ts372.descripcio AS desc_regim, Clm.PORC_COMIS,
       Clm.TIPO_FINAN,Softpad_sistema.Ts505.descripcio AS desc_finan,Clm.TIPO_BASE, Softpad_sistema.Ts98.descripcio AS desc_base,Clm.COMIS_MIN, Clm.COMIS_MAX, Clm.TIPO_COMIS,
       Softpad_sistema.Ts6.descripcio AS desc_comis,Clm.MONEDA 
 FROM CLM 
 LEFT JOIN softpad_sistema.ts371 ON Clm.TIPO_ADUAN=Softpad_sistema.Ts371.codigo 
 LEFT JOIN softpad_sistema.ts372 ON Clm.TIPO_REGIM=Softpad_sistema.Ts372.codigo 
 LEFT JOIN softpad_sistema.ts505 ON Clm.TIPO_FINAN=Softpad_sistema.Ts505.codigo 
 LEFT JOIN softpad_sistema.ts6   ON Clm.TIPO_COMIS=Softpad_sistema.Ts6.cod
 LEFT JOIN softpad_sistema.ts98  ON Clm.TIPO_BASE =Softpad_sistema.Ts98.cod;

/*==================================================================================================*/

/* Vista para Las Gastos Fijos x cliente CLG  */
create view VistaCLG as  
SELECT Clg.COD_CLIEN,Clg.CORREL,Clg.TIPO_ADUAN,Softpad_sistema.Ts371.descripcio AS desc_aduan,Clg.TIPO_REGIM,Softpad_sistema.Ts372.descripcio AS desc_regim, 
       Clg.COD_GASTO,Tgf.GASTOS,Clg.DGASTO,Clg.SGASTO,Clg.TIPO_OPER 
 FROM Clg 
 LEFT JOIN Tgf ON Clg.COD_GASTO = Tgf.CODIGO
 LEFT JOIN softpad_sistema.ts371 Ts371 ON Clg.TIPO_ADUAN=Softpad_sistema.Ts371.codigo 
 LEFT JOIN softpad_sistema.ts372 Ts372 ON Clg.TIPO_REGIM=Softpad_sistema.Ts372.codigo ;

/*==================================================================================================*/

/* Vista para los parientes del cliente para la SBS UIF  */
create view VistaUF2 as  
SELECT Uf2.COD_CLIEN, Uf2.TIPO_PERS, Uf2.CORREL, Uf2.NOMBRE, Uf2.APELLIDOS,
  Uf2.RAZ_SOCIAL, Uf2.TIPO_DOC, Uf2.DOCUMENTO, Uf2.OCUPACION, Uf2.COD_PARENT 
 FROM UF2
 WHERE TIPO_PERS="N";

/* Vista para las personas Juridicas x cliente para la SBS UIF  */
create view VistaUF3 as  
SELECT Uf2.COD_CLIEN, Uf2.TIPO_PERS, Uf2.CORREL, Uf2.NOMBRE, Uf2.APELLIDOS,
  Uf2.RAZ_SOCIAL, Uf2.TIPO_DOC, Uf2.DOCUMENTO, Uf2.OCUPACION, Uf2.COD_PARENT 
 FROM UF2 
 WHERE TIPO_PERS="J";

/*********************************************************************************/
/***********      VISTA PARA EL ENVIO DE ENTREGA RAPITA         ******************/
/*********************************************************************************/
/* Vista para el Envio de Entrega Rapida EER para Regimen 04 DGS  */
create view VistaDGS as 
SELECT dug.N_ORDEN,Dug.ORDEN_SIMP,Dug.N_SERIE,Ape.COD_CLIEN,Cli.NOMBRE,Ape.TIPOREG,Ape.REF_CLIE,
       Dga.C_ADUAN_S,Dga.FCH_OR_EMB,Dga.FCHLLE,Dga.CODMODALI,Dga.FFAC_VTASU,Dga.FOB,Dga.FLETE,Dga.COD_CENVIO,Dga.SEGURO,Dga.T_BULTOS,Dga.TOTUFIS,Dga.TOTUCOM,Dga.KNE,Dga.KBR,
       Sea.N_SERIE as N_SERIE1,Sea.NUMBLGUIA,Sea.COD_P_PRO,Sea.TIPOUFIS,Sea.CLAS_COMER,Sea.NUM_FACT1,Sea.FCH_FACT1,Sea.DES1,Sea.DES2,Sea.DES3,Sea.DES4,Sea.DES5,Sea.COD_PRODUC 
 FROM dug 
 LEFT JOIN ape ON Dug.ORDEN_SIMP = Ape.N_ORDEN 
 LEFT JOIN cli ON Ape.COD_CLIEN  = Cli.CODIGO   
 LEFT JOIN dga ON Dug.ORDEN_SIMP = Dga.N_ORDEN 
 LEFT JOIN sea ON Dug.ORDEN_SIMP = Sea.N_ORDEN
 WHERE Dug.ORDEN_SIMP <> ( "" );

/*WHERE Dug.ORDEN_SIMP <> ( "" ) GROUP BY Dug.ORDEN_SIMP*/

/*==================================================================================================*/

/* Vista para el Envio de Entrega Rapida EER para Regimen 04 DGT  */
create function fDgt() returns char(11)DETERMINISTIC NO SQL return @porden; 
/*==================================================================================================*/
create view VistaDGT as 
SELECT dug.N_ORDEN,Dug.ORDEN_SIMP,Dug.N_SERIE,Ape.COD_CLIEN,Cli.NOMBRE,Ape.TIPOREG,Ape.REF_CLIE,
       Dga.C_ADUAN_S,Dga.FCH_OR_EMB,Dga.FCHLLE,Dga.CODMODALI,Dga.FFAC_VTASU,Dga.FOB,Dga.FLETE,Dga.COD_CENVIO,Dga.SEGURO,Dga.T_BULTOS,Dga.TOTUFIS,Dga.TOTUCOM,Dga.KNE 
 FROM  Dug  
 LEFT JOIN ape ON Dug.ORDEN_SIMP = Ape.N_ORDEN
 LEFT JOIN cli ON Ape.COD_CLIEN  = Cli.CODIGO
 LEFT JOIN dga ON Dug.ORDEN_SIMP = Dga.N_ORDEN
 WHERE Dug.ORDEN_SIMP <> ( "" ) AND DUG.N_ORDEN=fDgt() GROUP BY Dug.ORDEN_SIMP;

/*==================================================================================================*/

/* Vista para el Envio de Entrega Rapida EER para Regimen 04 SEX  */
create view VistaSEX as
SELECT Sea.N_ORDEN, Sea.N_SERIE, Sea.REGI_PROCE, Sea.REGI_PROC1,
  Sea.APL_ULTRA, Sea.OTROPUERTO, Sea.FCH_EMB, Sea.COD_P_EMB, Sea.NUMBLGUIA,
  Sea.NUMDET, Sea.CERT_ORIG, Sea.FCERT_ORI, Sea.UNI_COMER, Sea.CLAS_COMER,
  Sea.CEXOCER, Sea.NUMBULTOS, Sea.CLASEBULTO, Sea.KNSER, Sea.KBSER,
  Sea.UFISICAS, Sea.TIPOUFIS, Sea.CANT_EQUIV, Sea.TIPO_EQUIV, Sea.NUME_SERPR,
  Sea.PARTIDA, Sea.PAN, Sea.PART_NABAN, Sea.COD_LIB, Sea.TRATO_PREF,
  Sea.TIPO_MARGE, Sea.COD_P_PRO, Sea.COD_P_ADQ, Sea.REGI_APLIC, Sea.FOBSER,
  Sea.FOBSDOL, Sea.FOBGSER, Sea.FOBGDOL, Sea.AJUSTE, Sea.VTA_SUCESI,
  Sea.FLESER, Sea.FLESDOL, Sea.SEGSER, Sea.SEGSDOL, Sea.TIPO_SEG, Sea.TNAN,
  Sea.CIFSER, Sea.CIFSDOL, Sea.DES1, Sea.DES2, Sea.DES3, Sea.DES4, Sea.DES5,
  Sea.PORCENTAJE, Sea.CEXPODUMP, Sea.CPROD, Sea.TPROD, Sea.CODIDE, Sea.ANOAUT,
  Sea.NUMAUT, Sea.CODLUG, Sea.FOB_PNETO, Sea.CPROH, Sea.CEXCNAN, Sea.CCUOEXP,
  Sea.UBIGEO, Sea.FEEMIAUT, Sea.FEVENAUT, Sea.CZONFRA, Sea.DZONFRA,
  Sea.FOB_FACT, Sea.CCODDOC, Sea.FACT_COMER, Sea.MPO, Sea.ESTADO,
  Sea.DOC_CANCEL, Sea.ADVALSER, Sea.ADVDOL, Sea.LADVDOL, Sea.SOBRETSER,
  Sea.SB10DOL, Sea.LSB10DOL, Sea.D_ESP, Sea.DS16DOL, Sea.LDS16DOL, Sea.ISCSER,
  Sea.VAISCSER, Sea.PRESOLISC, Sea.ISCDOL, Sea.LISCDOL, Sea.IGVSER,
  Sea.VAIGVSER, Sea.IGVDOL, Sea.LIGVDOL, Sea.IPMSER, Sea.VAIPMSER, Sea.IPMDOL,
  Sea.LIPMDOL, Sea.ANTIDOL, Sea.FACTSEG, Sea.NUMDECPRO, Sea.SERITEM,
  Sea.FECHINIREG, Sea.FCHVCTOPRO, Sea.NUM_FACT1, Sea.FCH_FACT1, Sea.D6,
  Sea.INFORMAC1, Sea.INFORMAC2, Sea.INFORMAC3, Sea.INFORMAC4, Sea.INFORMAC5,
  Sea.NUME_ITEMB, Sea.QUNIISC, Sea.TUNIISC, Sea.PIGVDOL, Sea.AADV_DOL,
  Sea.ASB10DOL, Sea.FLAG_BASE, Sea.NUME_FFCO, Sea.KBSERANT, Sea.TIPOCODLIB,
  Sea.TIPOCODLI1, Sea.F_ROTULADO, Sea.ROTULADO, Sea.PRORR_PESO,
  Sea.FLAGKBRKNE, Sea.TIPO_CONO, Sea.CONO_MAST, Sea.CONSIGNA, Sea.RIESGOSAN,
  Sea.TIP_CERTOR, Sea.TIP_EMICER, Sea.NOM_EMICER, Sea.FEC_IEMBCE,
  Sea.FEC_FEMBCE, Sea.CRI_ORIGEN, Sea.IND_TRANS, Sea.FEC_EMBPTR,
  Sea.NUM_EMBAR, Sea.N_PARTE, Sea.COD_PRODUC, Sea.FLAG_DIGPA, Sea.NUMAUTOEXP,
  Sea.NOM_PRODUC, Sea.PEMB_ORIG, Sea.CNT_GUIAS, Sea.COD_CENVIO,
  Sea.VAL_ESTIMA, Sea.tiporeg_s, Sea.fchnumer_s, Sea.ANULADA, Sea.REVISION,
  Sea.IND_PARTES 
 FROM Sea;


/*********************************************************************************/
/***********      VISTA PARA LA GUIA DE REMISION                ******************/
/*********************************************************************************/

create view VistaGre as 
SELECT Gre.N_DOC, Gre.FECHOPE, Gre.N_ORDEN, Gre.COD_CLIEN, Gre.MOTIVO_TRA,
  Gre.DES_MOTIVO, Gre.COD_TRANSP, Gre.SOL_TRANSP, Gre.COD_CODUCT,
  Gre.MATR_VEHIC, Gre.FCHINITRAS, Gre.CERTINSCRI, Gre.FECH_EMIS,
  Gre.FECH_VENC, Gre.MARC_NUM1, Gre.MARC_NUM2, Gre.MARC_NUM3, Gre.MARC_NUM4,
  Gre.MARC_NUM5, Gre.MARC_NUM6, Gre.MARC_NUM7, Gre.CONT1, Gre.CONT2, Gre.CONT3,
  Gre.CONT4, Gre.CONT5, Gre.CONT6, Gre.CONT7, Gre.CONT8, Gre.CONT9, Gre.CONT10,
  Gre.CONT11, Gre.CONT12, Gre.CONT13, Gre.CONT14, Gre.CONT15, Gre.CONT16,
  Gre.CONT17, Gre.CONT18, Gre.CONT19, Gre.OBSVE1, Gre.OBSVE2, Gre.OBSVE3,
  Gre.OBSVE4, Gre.OBSVE5, Gre.OBSVE6, Gre.OBSVE7, Gre.OBSVE8, Gre.OBSVE9,
  Gre.OBSVE10, Gre.OBSVE11, Gre.OBSVE12, Gre.OBSVE13, Gre.OBSVE14, Gre.OBSVE15,
  Gre.OBSVE16, Gre.OBSVE17, Gre.PP_CODIGO, Gre.PP_DOMICIL, Gre.PP_DIRECC,
  Gre.PP_VIATIPO, Gre.PP_VIANOMB, Gre.PP_NUMERO, Gre.PP_INTER, Gre.PP_ZONA,
  Gre.PP_DIST, Gre.PP_PROV, Gre.PP_DPTO, Gre.LL_CODIGO, Gre.LL_DIRECC,
  Gre.LL_VIATIPO, Gre.LL_VIANOMB, Gre.LL_NUMERO, Gre.LL_INTER, Gre.LL_ZONA,
  Gre.LL_DIST, Gre.LL_PROV, Gre.LL_DPTO, Gre.FLETE_MERC, Gre.PESO, Gre.BULTOS,
  Gre.CLASEBULTO, Gre.COD_USER, Gre.ANULADA, Cli.nombre as nombre_dest, Trs.NOMBRE as des_transp,
  Gre.OBSER1, Gre.CONT20, Gre.CONT21, Gre.CONT22, Gre.CONT23, Gre.CONT24,
  Gre.CONT25, Gre.pp_ruc, CODI_DEST 
 FROM gre 
 LEFT JOIN cli ON  Gre.COD_CLIEN = Cli.CODIGO 
 LEFT JOIN trs ON  Gre.COD_TRANSP = Trs.CODIGO;

/*********************************************************************************/
/***********      VISTA PARA LOS REQUERIMIENTOS                 ******************/
/*********************************************************************************/

/* Vista para el Envio de Entrega Rapida EER para Regimen 04 DGT  */
create view VistaReq as 
 SELECT Req.N_REQUER, Req.FCH_DIGIT, Req.COD_USER, Req.CONCEPTO, Req.OBS1,Req.OBS2, Req.OBS3, Req.OBS4, Req.OBS5, Req.OBS6, Req.OBS7, Req.OBS8, Req.OBS9,
   Req.OBS10, Req.OBS11, Req.OBS12, Req.OBS13, Req.OBS14, Req.OBS15,Req.FCH_ENVIO, Req.FCH_ENTREG, Req.COD_PROG, Usu.USUARIO 
 FROM Req 
 LEFT JOIN USU ON  Req.COD_USER = Usu.CODIGO;

/*********************************************************************************/
/***********      VISTA PARA LA FACTURACION                     ******************/
/*********************************************************************************/

create view VistaDoc as 
SELECT Doc.*, Ape.TIPOREG, Ape.C_ADUANA, Ape.N_DECLAR, Ape.FCHNUMER,Dga.CONT1, Dga.TIPO_AFORO, Pro.MONEDA as moneda1, Pro.DTOT_PROF, Pro.STOT_PROF
   FROM Doc 
   LEFT JOIN Ape ON Doc.N_ORDEN = Ape.N_ORDEN 
   LEFT JOIN Pro ON Doc.N_PROF  = Pro.N_PROF
   LEFT JOIN Dga ON Doc.N_ORDEN = Dga.N_ORDEN;

/*==================================================================================================*/

create view VistaDet as 
SELECT Det.DOC, Det.N_DOC, Det.N_SERIE, Det.FECHGASTO, Det.CODGASTO,
  Det.CONCEPTO, Det.NUMCOMPR, Det.MON, Det.T_CAMBIO, Det.SGASTO, Det.DGASTO,
  Det.AFECTO, Det.OSGASTO, Det.ODGASTO, Det.PSGASTO, Det.PDGASTO,
  Det.SUBNUMDOC, Det.COD_PROV, Det.TIPO_DOCU, Det.CANCE_CLI, Det.OBSERVAC,
  Det.ENLA_CONTA, Det.CANTIDAD, Prc.NOMBRE
 FROM Det
 LEFT JOIN Prc ON Det.COD_PROV = Prc.COD_PROV;

/*==================================================================================================*/

create view VistaInf as  
SELECT Inf.DOC, Inf.N_DOC, Inf.FECHA_INC, Inf.ESTADO, Inf.INCIDENCIA, Inf.AUTOMATICO, Inf.COD_USER, Inf.MARCA, Usu.USUARIO
   FROM Inf 
   LEFT JOIN Usu ON Inf.COD_USER = Usu.CODIGO;
 
/*==================================================================================================*/

create view VistaDfi as 
SELECT Dfi.NUM_FINAN, Dfi.CORREL, Dfi.DOC,Softpad_sistema.Ts31.documento,Dfi.N_DOC,Dfi.DTOT_DOCU,Dfi.STOT_DOCU,Dfi.TIPO_PROF,Dfi.N_PROF,Dfi.REFER 
  FROM Dfi 
  LEFT JOIN softpad_sistema.ts31 ON Softpad_sistema.Ts31.cod=Dfi.DOC ;

/*==================================================================================================*/

create view VistaAbo as 
SELECT Vde.DOC, Vde.N_DOC, Vou.*, Softpad_sistema.Ts638.des_tpago,Softpad_sistema.Ts258.iniciales 
 FROM Vou 
 LEFT JOIN vde ON Vde.N_VOUCHER = Vou.N_VOUCHER AND Vde.TIPO_VOUCH = Vou.TIPO_VOUCH 
 LEFT JOIN softpad_sistema.ts638 ON Softpad_sistema.Ts638.cod_tpago= Vou.T_PAGO 
 LEFT JOIN softpad_sistema.ts258 ON Softpad_sistema.Ts258.codigo= Vou.MONEDA;

/*==================================================================================================*/

create view VistaLde as 
SELECT Lde.NUM_LETRA,Lde.CORREL,Lde.SIMPORTE,Lde.DIMPORTE,Lde.N_ORDEN,Lde.DOC,Softpad_sistema.Ts31.documento AS documento,Lde.N_DOC,
       Lde.FECHA_DOC, Lde.REFER_DATO, Lde.COD_CLIEN, Lde.TCAMBIOCTA 
       FROM Lde 
       LEFT JOIN softpad_sistema.ts31 Ts31 ON Softpad_sistema.Ts31.cod=Lde.DOC ;

/*==================================================================================================*/

create view VistaGas as 
SELECT Gas.*, Prc.NOMBRE, Tgf.GASTOS 
 FROM Gas 
 LEFT JOIN Tgf ON Gas.CODGASTO=Tgf.CODIGO 
 LEFT JOIN Prc ON Gas.COD_PROV = Prc.COD_PROV

/*==================================================================================================*/

create view VistaCjd as 
SELECT Cjd.NUME_CAJA,Cjd.N_ORDEN,Cjd.OBSERVACIO,Cjd.FOLIO,Cjd.NDOC_ASOC,Cjd.NUME_FACTU,Cjd.NUMBLGUIA,Cjd.FECHA_ARCH,
       Ape.C_ADUANA,Ape.TIPOREG,Ape.N_DECLAR,Ape.FCHNUMER,
       Dga.CONT1,Dga.FOB_DOL,Dga.FOB_GTOS,Dga.TIPO_SEG,Dga.NUMPARTIDA,
       Cli.nombre,Cli.TIPO_DOCUM,Cli.DOCUMENTO       
  FROM cjd 
  left join ape on ape.n_orden=cjd.n_orden 
  left join dga on dga.n_orden=cjd.n_orden 
  left join cli on cli.codigo=ape.cod_clien 

/*==================================================================================================*/

create view VistaAdj as 
SELECT Adj.N_ORDEN, Adj.CORREL, Adj.F_DATE, Adj.TIPO_DOC, Adj.N_DOC,Softpad_sistema.Ts217.descripcio, Adj.FECH_ORIG, Adj.FECH_COPIA, Adj.FECH_RECEP, Adj.OBSERVACIO 
  FROM Adj 
  LEFT JOIN softpad_sistema.ts217 Ts217 ON Softpad_sistema.Ts217.cod=Adj.TIPO_DOC 
 
/*==================================================================================================*/

create view VistaOfc as 
SELECT Ofc.*,Ape.F_DATE,Ape.TIPOREG,Ape.C_ADUANA,Ape.N_DECLAR,Ape.FCHNUMER,Dga.NAVE,Sea.NUMBLGUIA,Sea.NUM_FACT1,Cli.nombre,Sea.DES1,
       Dga.FOB_DOLLIQ,Dga.FLE_DOLLIQ,Dga.SEG_DOLLIQ,Dga.CIFDOLLIQ,Dga.KBR,Dga.T_BULTOS 
   FROM Ofc 
   LEFT JOIN Ape ON  Ape.N_ORDEN = Ofc.N_ORDEN AND  Ofc.N_ORDEN <> ( '' ) 
   LEFT JOIN Dga ON  Dga.N_ORDEN = Ape.N_ORDEN 
   LEFT JOIN Cli ON  Cli.CODIGO = Ape.COD_CLIEN 
   LEFT JOIN Sea ON  Sea.N_ORDEN = Ape.N_ORDEN AND n_serie=1 

/*==================================================================================================*/

create view VistaCtd as 
SELECT Ctd.*,Ape.F_DATE,Ape.N_DECLAR,Ape.FCHNUMER
  FROM Ctd LEFT JOIN Ape ON Ctd.N_ORDEN=Ape.N_ORDEN

/*==================================================================================================*/

create view VistaSch as 
SELECT Ape.C_ADUANA, Ape.TIPOREG, Ape.FCHNUMER, Ape.COD_CLIEN,Ape.N_DECLAR, Ape.TDOC_CDA, Ape.DIGI_VERI, Ape.SDOC_CDA,Sch.* 
    FROM Sch 
    LEFT JOIN Ape ON  Sch.N_ORDEN = Ape.N_ORDEN 

/*==================================================================================================*/

create view VistaUti as 
SELECT Uti.N_ORDEN, Uti.NUME_SECUP, Uti.NUME_SECUF, Uti.NUM_ITEM,Uti.COD_NOMBRE, Uti.NOMBRE, Uti.COD_COMPO1, Uti.COMPO1, Uti.COD_COMPO2,
  Uti.COMPO2, Uti.COD_COMPO3, Uti.COMPO3, Uti.COD_COLOR, Uti.COLOR,
  Uti.COD_ACAB, Uti.ACABADO, Uti.DIMENSION, Uti.PESO_VOL, Uti.COD_USO, Uti.USO,
  Uti.COD_PRESEN, Uti.PRESENTAC, Uti.COD_MATEXT, Uti.MATER_EXT,
  Uti.COD_MATINT, Uti.MATER_INT, Uti.COD_TIPO, Uti.TIPO, Uti.COD_DISPO,
  Uti.DISPOSITI, Uti.COD_ACCES, Uti.ACCESORIO, Uti.NRO_PZAS, Uti.OBSERVAC1,
  Uti.VOLUMEN, Uti.ADICIONAL, Uti.TIPO_UTIL, Uti.DIMENSION1, Uti.DIMENSION2,
  Uti.DIMENSION3, Ada.PARTIDA 
 FROM Uti LEFT JOIN ada ON Uti.N_ORDEN= Ada.N_ORDEN AND  Uti.NUME_SECUP= Ada.NUME_SECUP AND Uti.NUME_SECUF = Ada.NUME_SECUF AND Uti.NUM_ITEM = Ada.NUM_ITEM 

/*==================================================================================================*/

create view VistaVde as  
SELECT Vde.N_VOUCHER, Vde.TIPO_VOUCH, Vde.REG_VOUCH, Vde.SIMPORTE,Vde.DIMPORTE, Vde.N_ORDEN, Vde.DOC,
       Softpad_sistema.Ts31.documento AS documento, Vde.N_DOC, Vde.FECHA_DOC,Vde.REFER_DATO, Vde.COD_CLIEN, Vde.TCAMBIOCTA, Vde.CLV_ENLACE 
    FROM Vde LEFT OUTER JOIN softpad_sistema.ts31 ON  Softpad_sistema.Ts31.cod=Vde.DOC 

/*==================================================================================================*/

create view VistaLde as  
SELECT Lde.NUM_LETRA, Lde.CORREL, Lde.SIMPORTE, Lde.DIMPORTE, Lde.N_ORDEN,Lde.DOC, Softpad_sistema.Ts31.documento AS documento, Lde.N_DOC,
  Lde.FECHA_DOC, Lde.REFER_DATO, Lde.COD_CLIEN, Lde.TCAMBIOCTA 
 FROM Lde LEFT JOIN softpad_sistema.ts31 ON Softpad_sistema.Ts31.cod=Lde.DOC

/*==================================================================================================*/

create view VistaTex as  
SELECT Tex.*,Ada.PARTIDA 
 FROM Tex 
    LEFT JOIN ada Ada ON Tex.N_ORDEN = Ada.N_ORDEN  AND  Tex.NUME_SECUP = Ada.NUME_SECUP AND Tex.NUME_SECUF = Ada.NUME_SECUF AND Tex.NUM_ITEM = Ada.NUM_ITEM

/*==================================================================================================*/

create view VistaMdt as  
SELECT Mdt.NUMBLGUIA, Mdt.NUMDET, Mdt.CODI_TERM, Mdt.COD_TRANSP,Mdt.PUER_EMBAR, Mdt.TPESO_RECI, Mdt.CANT_BRECI, Mdt.N_ORDEN
 FROM Mdt 

/*==================================================================================================*/

create view VistaDiarios as  
SELECT Diarios.A�O_DIARIO, Diarios.TIP_DIARIO, Ts12.DESCRIPCIO,Diarios.COD_DIARIO
 FROM DIARIOS 
 LEFT JOIN softpad_sistema.ts12 ON Softpad_sistema.Ts12.codigo=Diarios.TIP_DIARIO
 





