/* TABLAS( MAESTRO DE TABLAS DE ADUANAS )*/                                                   
CREATE TABLE IF NOT EXISTS TABLAS(       
   REGISTRO      CHAR(4) not null,   
   BASE          Char(8)  default "",
   NOMBRE        VarChar(50) default "",
   CLAVE1        varchar(70) default "",
   CLAVE2        varchar(45) default "",
   CLAVE3        varchar(45) default "",
   CLAVE4        varchar(45) default "",
   CLAVE5        varchar(45) default "",
   CLAVE6        varchar(45) default "",
   EDITABLE      CHAR(1) default "",
   PRIMARY KEY(REGISTRO),
   CONSTRAINT UQ_TABLAS_1 UNIQUE(BASE));
CREATE INDEX TABLAS_1 ON TABLAS(REGISTRO);                                                 
CREATE INDEX TABLAS_2 ON TABLAS(BASE);                                              

/* TA0( TABLAS DE CONTROL DE ACTUALIZACIONES )*/                                                   
CREATE TABLE IF NOT EXISTS TA0(                                                 
   NOMBRE     CHAR(12) NOT NULL,                                                
   FECHA      DATE);                                          

/* TA1( TABLAS DE ADUANAS )*/                                                   
CREATE TABLE IF NOT EXISTS TA1(                                                 
   COD         CHAR(3) NOT NULL,                                                
   ADUANA      VARCHAR(30) DEFAULT "",                                          
   T_DESPACHO  CHAR(1) DEFAULT "",                                              
   NOUSO       CHAR(1) DEFAULT "",                                              
   SELVA       CHAR(1) DEFAULT "",                                              
   CODORDEN    CHAR(1) DEFAULT "",                                              
   LOCALIDAD   VARCHAR(20) DEFAULT "",                                          
   CASILLATCI  VARCHAR(20) DEFAULT "",                                          
   FECH_XML10  CHAR(8) DEFAULT "",                                              
   FECH_XML20  CHAR(8) DEFAULT "",                                              
   FECH_XML21  CHAR(8) DEFAULT "",                                              
   FECH_XML30  CHAR(8) DEFAULT "",                                              
   FECH_XML36  CHAR(8) DEFAULT "",                                              
   FECH_XML70  CHAR(8) DEFAULT "",                                              
   FECH_XML80  CHAR(8) DEFAULT "",                                              
   FECH_XML89  CHAR(8) DEFAULT "",                                              
   FECH_XML81  CHAR(8) DEFAULT "",                                              
   PRIMARY KEY(COD));                                                           
CREATE INDEX TA1_1 ON TA1(COD);                                                 
CREATE INDEX TA1_2 ON TA1(ADUANA);                                              
CREATE INDEX TA1_3 ON TA1(CODORDEN);                                            
                                                                                
/* TA2( TABLAS DE ERRORES DE TELEDESPACHO )*/                                   
CREATE TABLE IF NOT EXISTS TA2(                                                 
   COD         CHAR(5) NOT NULL,                                                
   ERROR       VARCHAR(76) DEFAULT "",                                          
   ERROR2      VARCHAR(76) DEFAULT "",                                          
   ERROR3      VARCHAR(76) DEFAULT "",                                          
   PRIMARY KEY(COD));                                                           
CREATE INDEX TA2_1 ON TA2(COD);                                                 
CREATE INDEX TA2_2 ON TA2(ERROR);                                               

/* TA4( TIPO DE ROL DE PARTICIPANTES DEL MNF-XML )*/                                 
CREATE TABLE IF NOT EXISTS TA4(                                                 
   CODIGO         CHAR(2) NOT NULL,                                                
   DESCRIPCIO     VARCHAR(40) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                           
CREATE INDEX TA4_1 ON TA4(CODIGO);                                                 
CREATE INDEX TA4_2 ON TA4(DESCRIPCIO);                                                                                                                              

/* TA7( TABLAS DE FORMA DE PAGO AL EXTERIOR )*/                                 
CREATE TABLE IF NOT EXISTS TA7(                                                 
   COD         CHAR(1) NOT NULL,                                                
   PAGO        VARCHAR(25) DEFAULT "",                                          
   PRIMARY KEY(COD));                                                           
CREATE INDEX TA7_1 ON TA7(COD);                                                 
CREATE INDEX TA7_2 ON TA7(PAGO);                                                                                                                              
                                                                                
/* TA11( TABLAS DE MODALIDAD  TRANSBORDO Y RANCHO DE NAVE )*/                   
CREATE TABLE IF NOT EXISTS TA11(                                                
   COD         CHAR(2) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(90) DEFAULT "",                                          
   TIPOREG     CHAR(2) DEFAULT "",                                              
   PRIMARY KEY(COD,TIPOREG));                                                           
CREATE INDEX TA11_1 ON TA11(COD);                                               
CREATE INDEX TA11_2 ON TA11(DESCRIPCIO);                                        

/* TA12( TABLAS DE EMPRESA DE TRANSPORTE )*/                                    
CREATE TABLE IF NOT EXISTS TA12(                                                
   COD         CHAR(4) NOT NULL,                                                
   TRANSPORTE  VARCHAR(50) DEFAULT "",                                          
   DNOMABREVI  VARCHAR(25) DEFAULT "",                                          
   TDOCUMENTO  CHAR(2) DEFAULT "",                                          
   CDOCUMENTO  CHAR(11) DEFAULT "",                                              
   DIRECCION   VARCHAR(50) DEFAULT "",                                          
   DDISTRITO   VARCHAR(15) DEFAULT "",                                          
   CTELEFONO1  CHAR(7) DEFAULT "",                                              
   CTELEFONO2  CHAR(7) DEFAULT "",                                              
   CFAX        CHAR(7) DEFAULT "",                                              
   CESTADO     CHAR(2) DEFAULT "",                                              
   FCAMBIO     NUMERIC(10,0) DEFAULT 0,                                         
   CUSUARIO    CHAR(7) DEFAULT "",                                              
   FLAG        CHAR(1) DEFAULT "",                                              
   FMOD        NUMERIC(10,0) DEFAULT 0,                                         
   CDIGMOD     CHAR(7) DEFAULT "",                                              
   ESTADO      VARCHAR(12) DEFAULT "",
   TOPERADOR   CHAR(2) DEFAULT "",                                           
   PRIMARY KEY(COD));                                                           
CREATE INDEX TA12_1 ON TA12(COD);                                               
CREATE INDEX TA12_2 ON TA12(TRANSPORTE);                                        
                                                                                
/* TA14( TABLAS DE V�A DE TRANSPORTE )*/                                        
CREATE TABLE IF NOT EXISTS TA14(                                                
   COD         CHAR(1) NOT NULL,                                                
   VIA_TRANSP  VARCHAR(25) DEFAULT "",                                          
   FECHAINI    DATE,                                                            
   FECHAFIN    DATE,                                                            
   ESTADO      CHAR(10) DEFAULT "",                                             
   PRIMARY KEY(COD));                                                           
CREATE INDEX TA14_1 ON TA14(COD);                                               
CREATE INDEX TA14_2 ON TA14(VIA_TRANSP);                                        
                                                                                
/* TA15( TABLAS DE REG�MENES ADUANEROS )*/                                      
CREATE TABLE IF NOT EXISTS TA15(                                                
   COD         CHAR(2) NOT NULL,                                                
   REG_ADUANA  VARCHAR(42) DEFAULT "",                                          
   TIPO        CHAR(1) DEFAULT "",                                              
   FORM01      CHAR(1) DEFAULT "",                                              
   FORM02      CHAR(1) DEFAULT "",                                              
   FORM03      CHAR(1) DEFAULT "",                                              
   FORM04      CHAR(1) DEFAULT "",                                              
   FORM05      CHAR(1) DEFAULT "",                                              
   FORM06      CHAR(1) DEFAULT "",                                              
   FORM07      CHAR(1) DEFAULT "",                                              
   FORM08      CHAR(1) DEFAULT "",                                              
   FORM09      CHAR(1) DEFAULT "",                                              
   FORM10      CHAR(1) DEFAULT "",                                              
   FORM11      CHAR(1) DEFAULT "",                                              
   FORM12      CHAR(1) DEFAULT "",                                              
   FORM13      CHAR(1) DEFAULT "",                                              
   FORM14      CHAR(1) DEFAULT "",                                              
   FORM15      CHAR(1) DEFAULT "",                                              
   FORM16      CHAR(1) DEFAULT "",                                              
   FORM17      CHAR(1) DEFAULT "",                                              
   FORM18      CHAR(1) DEFAULT "",                                              
   FORM19      CHAR(1) DEFAULT "",                                              
   FORM20      CHAR(1) DEFAULT "",                                              
   FORM21      CHAR(1) DEFAULT "",                                              
   FORM22      CHAR(1) DEFAULT "",                                              
   FORM23      CHAR(1) DEFAULT "",                                              
   FORM24      CHAR(1) DEFAULT "",                                              
   FORM25      CHAR(1) DEFAULT "",                                              
   DESCRIPCIO  VARCHAR(15) DEFAULT "",                                          
   TELEDESP    CHAR(1) DEFAULT "",                                              
   DBC         CHAR(3) DEFAULT "",                                              
   SAD         CHAR(1) DEFAULT "",                                              
   DSI         CHAR(1) DEFAULT "",                                              
   DMA         CHAR(1) DEFAULT "",                                              
   RMF         CHAR(1) DEFAULT "",                                              
   PRIMARY KEY(COD));                                                           
CREATE INDEX TA15_1 ON TA15(COD);                                               
CREATE INDEX TA15_2 ON TA15(REG_ADUANA);                                        
                                                                                
/* TA17( TABLAS DE TIPO DE TRATO )*/                                            
CREATE TABLE IF NOT EXISTS TA17(                                                
   COD         CHAR(2) NOT NULL,                                                
   TIPO_TRAT   VARCHAR(26) DEFAULT "",                                          
   PRIMARY KEY(COD));                                                           
CREATE INDEX TA17_1 ON TA17(COD);                                               
CREATE INDEX TA17_2 ON TA17(TIPO_TRAT);                                         
                                                                                
/* TA16( TABLAS DE DEP�SITOS )*/                                                
CREATE TABLE IF NOT EXISTS TA16(                                                
   COD         CHAR(6) NOT NULL,                                                
   DEPOSITO    VARCHAR(60) DEFAULT "",                                          
   DIRECCION   VARCHAR(50) DEFAULT "",                                          
   ABREV       VARCHAR(15) DEFAULT "",                                          
   M           CHAR(1) DEFAULT "",                                              
   JURIDISC    VARCHAR(25) DEFAULT "",                                          
   STATUS      CHAR(10) DEFAULT "",                                             
   RUC         VARCHAR(11) DEFAULT "",                                          
   PRIMARY KEY(COD));                                                           
CREATE INDEX TA16_1 ON TA16(COD);                                               
CREATE INDEX TA16_2 ON TA16(DEPOSITO);                                          
                                                                                
/* TA18( TABLAS DE TIPO DE AFORO )*/                                            
CREATE TABLE IF NOT EXISTS TA18(                                                
   COD         CHAR(1) NOT NULL,                                                
   AFORO       VARCHAR(30) DEFAULT "",                                          
   INI         CHAR(1) DEFAULT "",                                              
   DESCRIPCIO  CHAR(10) DEFAULT "",                                             
   PRIMARY KEY(COD));                                                           
CREATE INDEX TA18_1 ON TA18(COD);                                               
CREATE INDEX TA18_2 ON TA18(AFORO);                                             

/* TA19( TABLAS DE ARANCEL )*/                                                  
CREATE TABLE IF NOT EXISTS TA19(                                                
   PAB         CHAR(10) NOT NULL,                                               
   DES1        VARCHAR(87) DEFAULT "",                                          
   DES2        VARCHAR(153) DEFAULT "",                                         
   FLAG        CHAR(1) DEFAULT "",                                              
   ADV         DECIMAL(8,2) DEFAULT 0.00,                                       
   ISC         DECIMAL(8,2) DEFAULT 0.00,                                       
   IGV         DECIMAL(8,2) DEFAULT 0.00,                                       
   IPM         DECIMAL(8,2) DEFAULT 0.00,                                       
   SOB_TASA    DECIMAL(8,2) DEFAULT 0.00,                                       
   ANTIDUMP    DECIMAL(8,2) DEFAULT 0.00,                                       
   DER_ESPE    CHAR(1) DEFAULT "",                                              
   SEGURO      DECIMAL(13,2) DEFAULT 0.00,                                      
   ITINTEC     CHAR(2) DEFAULT "",                                              
   EXCP        CHAR(1) DEFAULT "",                                              
   UNIDAD      CHAR(10) DEFAULT "",                                             
   CPC         CHAR(3) DEFAULT "",                                              
   COD_PAIS    CHAR(2) DEFAULT "",                                              
   VERIFICAD   NUMERIC(1,0) DEFAULT 0,                                          
   ZOTAC       CHAR(2) DEFAULT "",                                              
   NADV        DECIMAL(8,2) DEFAULT 0.00,                                       
   NSOBTASA    DECIMAL(8,2) DEFAULT 0.00,                                       
   ANEXO       CHAR(1) DEFAULT "",                                              
   M           CHAR(1) DEFAULT "",                                              
   PAIS_SOBTA  CHAR(2) DEFAULT "",                                              
   OMC         CHAR(2) DEFAULT "",                                              
   EXP         CHAR(1) DEFAULT "",                                              
   ANTI        CHAR(1) DEFAULT "",                                              
   SECCION     CHAR(5) DEFAULT "",                                              
   CAPITULO    CHAR(2) DEFAULT "",                                              
   SUBPARTIDA  CHAR(4) DEFAULT "",                                              
   SUBSUBPAB   CHAR(8) DEFAULT "",                                              
   FLAGARAN    CHAR(3) DEFAULT "",                                              
   FCHSOBTASA  DATE,                                                            
   MAQUINAS    CHAR(1) DEFAULT "",                                              
   BASICO1     NUMERIC(3,0) DEFAULT 0,                                          
   BASICO2     NUMERIC(3,0) DEFAULT 0,                                          
   ANEXO3      CHAR(1) DEFAULT "",                                              
   DESCRI1     VARCHAR(250) DEFAULT "",                                         
   PASO        CHAR(1) DEFAULT "",                                              
   TIPO_PROD   CHAR(3) DEFAULT "",                                              
   MINIMAS     CHAR(3) DEFAULT "",                                              
   PABANT      VARCHAR(200) DEFAULT "",                                              
   NUMPART     NUMERIC(2,0) DEFAULT 0,
   ZOFRATACNA  CHAR(1) DEFAULT "",
   SENSIBLES   CHAR(1) DEFAULT "",
   NECROSIS    CHAR(1) DEFAULT "",
   EXCEP_13    CHAR(1) DEFAULT "",
   uif_131014  CHAR(1) DEFAULT "",
   TIPO_CNF    VARCHAR(3) DEFAULT "",
   ADV_ANT     NUMERIC(8,0) DEFAULT 0.00,                                       
   PRIMARY KEY(PAB));                                                           
CREATE INDEX TA19_1 ON TA19(PAB);                                               
CREATE INDEX TA19_2 ON TA19(FLAGARAN,PAB);                                      
CREATE INDEX TA19_3 ON TA19(FLAGARAN,DES1);                                     
CREATE INDEX TA19_4 ON TA19(SECCION,CAPITULO,SUBPARTIDA,PAB);                   


/* TA21( TABLAS DE C�DIGO LIBERATORIO )*/                                       
CREATE TABLE IF NOT EXISTS TA21(                                                
   CODIGO      CHAR(4) NOT NULL,                                                
   BENEFI      VARCHAR(70) DEFAULT "",                                          
   B           CHAR(1) DEFAULT "",                                              
   FECHINIVI   DATE,                                                            
   FECHTERVI   DATE,                                                            
   AV          CHAR(5) DEFAULT "",                                              
   IGV         CHAR(5) DEFAULT "",                                              
   ISC         CHAR(3) DEFAULT "",                                              
   IPM         CHAR(3) DEFAULT "",                                              
   AGR         CHAR(3) DEFAULT "",                                              
   RP          CHAR(3) DEFAULT "",                                              
   M_R         CHAR(3) DEFAULT "",                                              
   SOBTASA     CHAR(3) DEFAULT "",                                              
   NANDINA     VARCHAR(15) DEFAULT "",                                          
   BASE_LEGAL  VARCHAR(80) DEFAULT "",                                          
   TLIB        CHAR(1) DEFAULT "",                                              
   OBSERVACIO  VARCHAR(80) DEFAULT "",                                          
   PRIMARY KEY(CODIGO,TLIB));                                                        
CREATE INDEX TA21_1 ON TA21(CODIGO);                                            
CREATE INDEX TA21_2 ON TA21(BENEFI);                                            
CREATE INDEX TA21_3 ON TA21(B);                                                 
                                                                                
/* TA21AC_I( TABLAS DE ACUERDOS COMERCIALES         - IATA )*/                  
CREATE TABLE IF NOT EXISTS TA21AC_I(                                            
   CODLIB      CHAR(4) DEFAULT "",                                              
   COD         CHAR(2) NOT NULL,                                                
   PARTIDA     CHAR(10) NOT NULL,                                               
   MP          DECIMAL(6,2) DEFAULT 0.00,                                       
   R           CHAR(1) NOT NULL,                                                
   PARTIDA_AN  CHAR(10) DEFAULT "",                                             
   PRIMARY KEY(COD,PARTIDA,R));                                                   
CREATE INDEX TA21AC_I_1 ON TA21AC_I(COD,PARTIDA);                               
CREATE INDEX TA21AC_I_2 ON TA21AC_I(PARTIDA);                                   

/* TA21ACH( TABLAS DE ALADI PER�-CHILE )*/                                      
CREATE TABLE IF NOT EXISTS TA21ACH(                                             
   COD_NANDI   CHAR(10) NOT NULL,                                               
   COD_NALAD   CHAR(10) NOT NULL,                                             
   TIP_PROD    NUMERIC(1,0) DEFAULT 0,                                          
   VERIFICAD   NUMERIC(1,0) DEFAULT 0,                                          
   DEG         CHAR(5) DEFAULT "",                                              
   DEG_DESC1   VARCHAR(60) DEFAULT "",                                          
   DEG_DESC2   VARCHAR(60) DEFAULT "",                                          
   PREFERE     CHAR(5) DEFAULT "",                                              
   PREFE_DES1  VARCHAR(60) DEFAULT "",                                          
   PREFE_MARG  NUMERIC(1,0) DEFAULT 0,                                          
   PARTIDA_AN  CHAR(10) DEFAULT "",                                             
   PRIMARY KEY(COD_NANDI,COD_NALAD,TIP_PROD,VERIFICAD));                                                     
CREATE INDEX TA21ACH_1 ON TA21ACH(COD_NANDI);                                   
CREATE INDEX TA21ACH_2 ON TA21ACH(COD_NANDI,COD_NALAD);                         

                                                                                
/* TA21AL_I( TABLAS DE ALADI                        - IATA )*/                  
CREATE TABLE IF NOT EXISTS TA21AL_I(                                            
   CODLIB      CHAR(4) DEFAULT "",                                              
   COD_NANDI   CHAR(10) NOT NULL,                                               
   COD         CHAR(2) NOT NULL,                                                
   ORIGEN      VARCHAR(20) DEFAULT "",                                          
   COD_NALAD   CHAR(10) DEFAULT "",                                             
   TIP_PROD    CHAR(1) DEFAULT "",                                              
   PAT_HIST    CHAR(3) DEFAULT "",                                              
   MAR_PORCEN  DECIMAL(5,1) DEFAULT 0.0,                                        
   FECH_TER    DATE,                                                            
   DESCRIP1    VARCHAR(70) DEFAULT "",                                          
   DESCRIP2    VARCHAR(70) DEFAULT "",                                          
   DESCRIP3    VARCHAR(70) DEFAULT "",                                          
   DESCRIP4    VARCHAR(70) DEFAULT "",                                          
   OBSERVAC    VARCHAR(70) DEFAULT "",                                          
   OBSERVAC2   VARCHAR(70) DEFAULT "",                                          
   OBSERVAC3   VARCHAR(70) DEFAULT "",                                          
   OBSERVAC4   VARCHAR(70) DEFAULT "",                                          
   OBSERVAC5   VARCHAR(70) DEFAULT "",                                          
   OBSERVAC6   VARCHAR(70) DEFAULT "",                                          
   OBSERVAC7   VARCHAR(70) DEFAULT "",                                          
   VERIFICAD   NUMERIC(1,0) DEFAULT 0,                                          
   M           CHAR(1) DEFAULT "",                                              
   PARTIDA_AN  CHAR(10) DEFAULT "",                                             
   PRIMARY KEY(CODLIB,COD,COD_NANDI,COD_NALAD,TIP_PROD));                                                 
CREATE INDEX TA21AL_I_1 ON TA21AL_I(COD,COD_NANDI);                             
CREATE INDEX TA21AL_I_2 ON TA21AL_I(CODLIB,COD,COD_NANDI,COD_NALAD,TIP_PROD);   
                                                                                
/* TA21EX( TABLAS DE LISTA DE EXCEPCIONES )*/                                   
CREATE TABLE IF NOT EXISTS TA21EX(                                              
   PARTIDA     CHAR(10) NOT NULL,                                               
   PARTIDA_AN  CHAR(10) DEFAULT "",                                             
   PRIMARY KEY(PARTIDA));                                                       
CREATE INDEX TA21EX_1 ON TA21EX(PARTIDA);                                       
                                                                                
/* TA21BOL( TABLAS DE LISTA DE EXCEPCIONES PARA BOLIVIA )*/                     
CREATE TABLE IF NOT EXISTS TA21BOL(                                             
   PARTIDA     CHAR(10) NOT NULL,                                               
   TASA_LIB    CHAR(3) DEFAULT "",                                              
   MPO         DECIMAL(8,3) DEFAULT 0.000,                                      
   PARTIDA_AN  CHAR(10) DEFAULT "",                                             
   PRIMARY KEY(PARTIDA,TASA_LIB));                                                       
CREATE INDEX TA21BOL_1 ON TA21BOL(PARTIDA);                                     
                                                                                
/* TA21BR( TABLAS DE ALADI PER�-BRASIL )*/                                      
CREATE TABLE IF NOT EXISTS TA21BR(                                              
   COD_NANDI   CHAR(10) NOT NULL,                                               
   COD_NALAD   CHAR(10) DEFAULT "",                                             
   MAR_PORCEN  DECIMAL(5,1) DEFAULT 0.0,                                        
   DEG_DESC1   VARCHAR(70) DEFAULT "",                                          
   DEG_DESC2   VARCHAR(70) DEFAULT "",                                          
   OBSERVAC1   VARCHAR(70) DEFAULT "",                                          
   OBSERVAC2   VARCHAR(70) DEFAULT "",                                          
   CERTIF1     VARCHAR(70) DEFAULT "",                                          
   CERTIF2     VARCHAR(70) DEFAULT "",                                          
   CERTIF3     VARCHAR(70) DEFAULT "",                                          
   CERTIF4     VARCHAR(70) DEFAULT "",                                          
   VERIFICAD   NUMERIC(1,0) DEFAULT 0,                                          
   TIPO_MARGE  CHAR(1) DEFAULT "",                                              
   PARTIDA_AN  CHAR(10) DEFAULT "",                                             
   PRIMARY KEY(COD_NANDI,COD_NALAD,TIPO_MARGE));                                                     
CREATE INDEX TA21BR_1 ON TA21BR(COD_NANDI);                                     
CREATE INDEX TA21BR_2 ON TA21BR(COD_NANDI,COD_NALAD,TIPO_MARGE);                

/* TA21PAN( PARTIDAS DEL PACTO ANDINO - IATA )*/                  
CREATE TABLE IF NOT EXISTS TA21PAN(                                                                                         
   PARTIDA    CHAR(10) NOT NULL,                                                
   ANEXO      CHAR(1) DEFAULT "",
   ZLC        CHAR(1) DEFAULT "",
   TM         CHAR(1) DEFAULT "",
   DESCRIP1   VARCHAR(69) DEFAULT "",
   DESCRIP2   VARCHAR(69) DEFAULT "",
   DESCRIP3   VARCHAR(69) DEFAULT "",
   DESCRIP4   VARCHAR(69) DEFAULT "",
   BOLIVIA    VARCHAR(69) DEFAULT "",
   PARTIDA_AN CHAR(10) DEFAULT "",
   PRIMARY KEY(PARTIDA,ANEXO,TM,DESCRIP1,DESCRIP2));                                                           
CREATE INDEX TA21PAN_1 ON TA21PAN(PARTIDA);                                       
                                                 

/* TA21PA_I( TABLAS DE PAISES DEL PACTO ANDINO      - IATA )*/                  
CREATE TABLE IF NOT EXISTS TA21PA_I(                                            
   CODLIB      CHAR(4) DEFAULT "",                                              
   COD         CHAR(2) NOT NULL,                                                
   PRIMARY KEY(COD));                                                           
CREATE INDEX TA21PA_I_1 ON TA21PA_I(COD);                                       
CREATE INDEX TA21PA_I_2 ON TA21PA_I(CODLIB);                                    
                                                                                
/* TA21TO_I( TABLAS DE PAISES DEL PAR-4             - IATA )*/                  
CREATE TABLE IF NOT EXISTS TA21TO_I(                                            
   CODLIB      CHAR(4) DEFAULT "",                                              
   COD         CHAR(2) NOT NULL,                                                
   MP          DECIMAL(6,2) DEFAULT 0.00,                                       
   PRIMARY KEY(COD));                                                           
CREATE INDEX TA21TO_I_1 ON TA21TO_I(COD);                                       
CREATE INDEX TA21TO_I_2 ON TA21TO_I(COD,CODLIB);                                
                                                                                
/* TA22( TABLAS DE CLASE DE BULTOS )*/                                          
CREATE TABLE IF NOT EXISTS TA22(                                                
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRI      VARCHAR(54) DEFAULT "",                                          
   FECHAINI    DATE,                                                            
   FECHAFIN    DATE,                                                            
   ESTADO      VARCHAR(12) DEFAULT "",                                          
   MARCA       CHAR(1) DEFAULT "",                                              
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA22_1 ON TA22(CODIGO);                                            
CREATE INDEX TA22_2 ON TA22(DESCRI);                                            
                                                                              
/* TA28( TABLAS DE FORMA DE PAGO )*/                                            
CREATE TABLE IF NOT EXISTS TA28(                                                
   CODIGO      CHAR(2) NOT NULL,                                                
   FORM_PAGO   VARCHAR(30) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA28_1 ON TA28(CODIGO);                                            
CREATE INDEX TA28_2 ON TA28(FORM_PAGO);                                         
                                                                                
/* TA33( TABLAS DE PROCEDENCIA PRODUCTO )*/                                     
CREATE TABLE IF NOT EXISTS TA33(                                                
   CODIGO      CHAR(2) NOT NULL,                                                
   PROCE_PRO   VARCHAR(40) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA33_1 ON TA33(CODIGO);                                            
CREATE INDEX TA33_2 ON TA33(PROCE_PRO);                                         

/* TA34( TABLAS DE CONDICIONES DEL PROVEEDOR EXTRANJERO )*/                          
CREATE TABLE IF NOT EXISTS TA34(                                               
   COD         CHAR(1) NOT NULL,                                                
   COND_PROVE  VARCHAR(20) DEFAULT "",                                          
   PRIMARY KEY(COD));                                                        
CREATE INDEX TA34_1 ON TA34(COD);                                          
CREATE INDEX TA34_2 ON TA34(COND_PROVE);                                      
         
/* TA36( TABLAS DE EXONERACI�N DEL CERTIFICADO DE INSP. )*/                     
CREATE TABLE IF NOT EXISTS TA36(                                                
   CODIGO      CHAR(2) NOT NULL,                                                
   DESCRI      VARCHAR(50) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA36_1 ON TA36(CODIGO);                                            
CREATE INDEX TA36_2 ON TA36(DESCRI);                                            
                                                                                
/* TA39( TABLAS DE TABLA DE LINEAS AEREAS DEL DMA )*/                           
CREATE TABLE IF NOT EXISTS TA39(                                                
   CODIGO      CHAR(4) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(50) DEFAULT "",                                          
   FECHAINI    DATE,                                                            
   FECHAFIN    DATE,                                                            
   ESTADO      CHAR(10) DEFAULT "",                                             
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA39_1 ON TA39(CODIGO);                                            
CREATE INDEX TA39_2 ON TA39(DESCRIPCIO);                                        
                                                                                
/* TA40( TABLAS DE FORMA EN QUE SE PAGO LOS DERECHOS DE AD )*/                  
CREATE TABLE IF NOT EXISTS TA40(                                                
   CODIGO      CHAR(1) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(55) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA40_1 ON TA40(CODIGO);                                            
CREATE INDEX TA40_2 ON TA40(DESCRIPCIO);                                        
                                                                                
/* TA41( TABLAS DE CODIGOS DE CUOTA DE EXPORTACI�N )*/                          
CREATE TABLE IF NOT EXISTS TA41(                                                
   PARTIDA     CHAR(10) NOT NULL,                                               
   COD_CUOTA   CHAR(2) DEFAULT "",                                              
   CUOTA       NUMERIC(12,0) DEFAULT 0,                                         
   DESCRIPC1   VARCHAR(60) DEFAULT "",                                          
   DESCRIPC2   VARCHAR(60) DEFAULT "",                                          
   FLAG        CHAR(1) DEFAULT "",                                              
   PARTIDA_AN  CHAR(10) DEFAULT "",                                             
   PRIMARY KEY(PARTIDA,COD_CUOTA));                                                       
CREATE INDEX TA41_1 ON TA41(PARTIDA);                                           
CREATE INDEX TA41_2 ON TA41(COD_CUOTA);         
                                
/* TA45 (TABLA DE GASTOS TIPO DE GASTOS DE LA PROFORMA Y LA FACTURA)*/
CREATE TABLE IF NOT EXISTS TA45(
   CODIGO      CHAR(3) not null,         /*codigo de Gasto */   
   GASTOS      VARCHAR(40) DEFAULT "",   /*Detalle del Gasto */
   RUBRO_N     CHAR(2) DEFAULT "",       /*Rubro en el que se va agrupar en el Registro de Ventas */
   FLAG_PRO    CHAR(1) DEFAULT "",       /*Flag que indica que dicho gasto sera para la Proforma */
   FLAG_FAC    CHAR(1) DEFAULT "",       /*Flag que indica que dicho gasto sera para la Factura */	
   FLAG_COB    CHAR(1) DEFAULT "",       /*Flag que indica que dicho gasto sera para la Carta de Cobranza */
   FLAG_NOT    CHAR(1) DEFAULT "",       /*Flag que indica que dicho gasto sera para la Nota de Debito y Credito */
   FLAG_PLA    CHAR(1) DEFAULT "",       /*Flag que indica que dicho gasto sera para la PLanilla de gastos */	
   FLAG_FAT    CHAR(1) DEFAULT "",       /*Flag que indica que dicho gasto sera para la Factura de Transporte */
   CTASDOC     CHAR(8) DEFAULT "",       /*Cuenta Contable en Soles para los Documentos de Venta pasen a contabilidad */
   CTADDOC     CHAR(8) DEFAULT "",       /*Cuenta Contable en Dolares para los Documentos de Venta pasen a contabilidad */
   CTASCOB     CHAR(8) DEFAULT "",       /*Cuenta Contable en Soles para La Carta de Cobranza pasen a contabilidad */	
   CTADCOB     CHAR(8) DEFAULT "",       /*Cuenta Contable en Dolares para la Carta de Cobranza pasen a contabilidad */
   FLAG_REPO   CHAR(1) DEFAULT "",       /*Flag que indica que gastos van a pasar el reporte de gastos */
   DESC_REPO   VARCHAR(10) DEFAULT "",   /*Descripcion resumida del Gasto que pasara el Reporte */
   FLAG_TRANS  CHAR(2) DEFAULT "",       /*Idinca el codigo del gasto que sera de transporte */
   PAGA_ITF    CHAR(1) DEFAULT "",       /*Indica si ese gasto paga ITF (Solo contabilidad) E-ADUANAS */
   REGIMEN     CHAR(1) DEFAULT "",  	 /*Flag que indica que gastos son para Importacion y cuales para exportacion (Solo DHL)*/
   COD_OTRO    CHAR(6) DEFAULT "",       /*codigo de JBA para DHL */
   PRIMARY KEY(CODIGO),
   CONSTRAINT UQ_TA45 UNIQUE(GASTOS));
CREATE INDEX TA45 ON TA45(CODIGO);
                                                                                
/* TA47( TABLAS DE OPERADORES TRANSBORDO O RANCHO DE NAVE )*/                   
CREATE TABLE IF NOT EXISTS TA47(                                                
   COD         CHAR(1) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(40) DEFAULT "",                                          
   PRIMARY KEY(COD));                                                           
CREATE INDEX TA47_1 ON TA47(COD);                                               
CREATE INDEX TA47_2 ON TA47(DESCRIPCIO);                                        
                                                                                
/* TA48( TABLAS DE ENTIDAD DEL CUADRO DE REPOSICION (RPF) )*/                   
CREATE TABLE IF NOT EXISTS TA48(                                                
   COD         CHAR(2) NOT NULL,                                                
   DESCRIP     VARCHAR(50) DEFAULT "",                                          
   PRIMARY KEY(COD));                                                           
CREATE INDEX TA48_1 ON TA48(COD);                                               
                                                                                
/* TA49( TABLAS DE TIPO DE UNIDADES FIS. )*/                                    
CREATE TABLE IF NOT EXISTS TA49(                                                
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRI      VARCHAR(26) DEFAULT "",                                          
   FECHAINI    DATE,                                                            
   FECHAFIN    DATE,                                                            
   ESTADO      VARCHAR(12) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA49_1 ON TA49(CODIGO);                                            
CREATE INDEX TA49_2 ON TA49(DESCRI);                                            
                                                                                
/* TA53( TABLAS DE P.A.EXONERADAS PARA INST.EDUCATIVAS )*/                      
CREATE TABLE IF NOT EXISTS TA53(                                                
   ANEXO       CHAR(1) NOT NULL,                                                
   PARTIDA     CHAR(10) NOT NULL,                                               
   TM          CHAR(1) DEFAULT "",                                              
   DESCRIPC1   VARCHAR(55) DEFAULT "",                                          
   DESCRIPC2   VARCHAR(55) DEFAULT "",                                          
   DESCRIPC3   VARCHAR(55) DEFAULT "",                                          
   DESCRIPC4   VARCHAR(55) DEFAULT "",                                          
   DESCRIPC5   VARCHAR(55) DEFAULT "",                                          
   DESCRIPC6   VARCHAR(55) DEFAULT "",                                          
   PARTIDA_AN  CHAR(10) DEFAULT "",                                             
   PRIMARY KEY(ANEXO,PARTIDA,DESCRIPC1,DESCRIPC2));                                                 
CREATE INDEX TA53_1 ON TA53(ANEXO,PARTIDA);                                     
CREATE INDEX TA53_2 ON TA53(PARTIDA);           

                                                                                
/* TA54( TABLAS DE NATURALEZA TRANSACCI�N )*/                                   
CREATE TABLE IF NOT EXISTS TA54(                                                
   COD         CHAR(2) NOT NULL,                                                
   NAT_TRANS   VARCHAR(100) DEFAULT "",                                         
   DAV         CHAR(2) DEFAULT "",                                              
   CONCEPTO    VARCHAR(90) DEFAULT "",                                          
   PRIMARY KEY(COD));                                                           
CREATE INDEX TA54_1 ON TA54(COD);                                               
CREATE INDEX TA54_2 ON TA54(NAT_TRANS);                                         

/* TA57(TABLA DE PROVEEDORES EXTRANJEROS)*/
CREATE TABLE IF NOT EXISTS TA57(
   CODIGO       CHAR(10) NOT NULL,
   NOM_FABR     VARCHAR(60) DEFAULT '',
   PAIS_PROV    CHAR(2) DEFAULT '',
   DIR1         VARCHAR(55) DEFAULT '',
   CIUDAD       VARCHAR(50) DEFAULT '',
   TLF_PROV     CHAR(15) DEFAULT '',
   FAX_PROV     CHAR(15) DEFAULT '',
   CONDI_PRO    CHAR(1) DEFAULT '',
   VINCULAC     CHAR(1) DEFAULT '',
   PAG_WEB      VARCHAR(60) DEFAULT '',
   EMAIL        VARCHAR(50) DEFAULT '',
   PAIS         CHAR(3) DEFAULT '',
   FLAG_A       CHAR(1) DEFAULT '',
   MESANO       CHAR(4) DEFAULT '',
   OTR_NIVC     VARCHAR(20) DEFAULT '',
   PRIMARY KEY(CODIGO),
   CONSTRAINT UQ_TA57_1 UNIQUE(PAIS_PROV,NOM_FABR,CIUDAD));
CREATE INDEX TA57 ON TA57(CODIGO);
                                                                                
/* TA58( TABLAS DE TIPO DE INTERMEDIARIO )*/                                    
CREATE TABLE IF NOT EXISTS TA58(                                                
   COD         CHAR(1) NOT NULL,                                                
   TIPO_INTER  VARCHAR(25) DEFAULT "",                                          
   PRIMARY KEY(COD));                                                           
CREATE INDEX TA58_1 ON TA58(COD);                                               
CREATE INDEX TA58_2 ON TA58(TIPO_INTER);                                        

                                                                               
/* TA60( TABLAS DE ALMAC�NES )*/                                                
CREATE TABLE IF NOT EXISTS TA60(                                                
   COD         CHAR(6) NOT NULL,                                                
   ALMACEN     VARCHAR(60) DEFAULT "",                                          
   DIRECCION   VARCHAR(50) DEFAULT "",                                          
   ABREV       VARCHAR(15) DEFAULT "",                                          
   JURIDISC    VARCHAR(25) DEFAULT "",                                          
   STATUS      CHAR(10) DEFAULT "",                                             
   PP_VIATIPO  CHAR(10) DEFAULT "",                                             
   PP_VIANOMB  VARCHAR(40) DEFAULT "",                                          
   PP_NUMERO   CHAR(10) DEFAULT "",                                             
   PP_INTER    CHAR(5) DEFAULT "",                                              
   PP_ZONA     CHAR(10) DEFAULT "",                                             
   PP_DIST     VARCHAR(20) DEFAULT "",                                          
   PP_PROV     VARCHAR(15) DEFAULT "",                                          
   PP_DPTO     VARCHAR(15) DEFAULT "",                                          
   RUC         VARCHAR(11) DEFAULT "",                                          
   PRIMARY KEY(COD));                                                           
CREATE INDEX TA60_1 ON TA60(COD);                                               
CREATE INDEX TA60_2 ON TA60(ALMACEN);                                           
                                                                                
/* TA61( TABLAS DE T�RMINO DE ENTREGA )*/                                       
CREATE TABLE IF NOT EXISTS TA61(                                                
   COD_INTERM  CHAR(3) NOT NULL,                                                
   LUGAR_ENTR  VARCHAR(52) DEFAULT "",                                          
   DESCRIPCIO  VARCHAR(120) DEFAULT "",
   PRIMARY KEY(COD_INTERM));                                                    
CREATE INDEX TA61_1 ON TA61(COD_INTERM);                                        
CREATE INDEX TA61_2 ON TA61(LUGAR_ENTR);                                        

/* TA62( TABLAS DE ESTADO DE MERCANC�A )*/                                      
CREATE TABLE IF NOT EXISTS TA62(                                                
   COD         CHAR(2) NOT NULL,                                                
   EST_MERC    VARCHAR(43) DEFAULT "",                                          
   TIPO        CHAR(2) DEFAULT "",                                              
   ANTERIOR    CHAR(2) DEFAULT "",                                              
   FECHAINI    DATE,                                                            
   FECHAFIN    DATE,                                                            
   ESTADO      CHAR(10) DEFAULT "",                                             
   PRIMARY KEY(COD,ESTADO));                                                           
CREATE INDEX TA62_1 ON TA62(COD);                                               
CREATE INDEX TA62_2 ON TA62(EST_MERC);                                          
                                                                                
/* TA64( TABLAS DE PARTIDAS NABANDINA )*/                                       
CREATE TABLE IF NOT EXISTS TA64(                                                
   PARTIDA     CHAR(8) NOT NULL,                                                
   DESCRIP     VARCHAR(48) DEFAULT "",                                          
   VERIFICA    NUMERIC(1,0) DEFAULT 0,                                          
   ADVAL       NUMERIC(3,0) DEFAULT 0,                                          
   IGV         NUMERIC(3,0) DEFAULT 0,                                          
   ISC         NUMERIC(3,0) DEFAULT 0,                                          
   CUODE       NUMERIC(3,0) DEFAULT 0,                                          
   CIIU        NUMERIC(4,0) DEFAULT 0,                                          
   CUCI        CHAR(6) DEFAULT "",                                              
   MERPROHI    CHAR(1) DEFAULT "",                                              
   TASA        CHAR(3) DEFAULT "",                                              
   PRIMARY KEY(PARTIDA,DESCRIP));                                                       
CREATE INDEX TA64_1 ON TA64(PARTIDA);                                           
                              

/* TA65( TABLAS DE EMP.TRANSP. AEREAS )*/                                       
CREATE TABLE IF NOT EXISTS TA65(                                                
   COD         CHAR(4) NOT NULL,                                                
   TRANSPORTE  VARCHAR(55) DEFAULT "",                                          
   DIRECCION   VARCHAR(40) DEFAULT "",                                          
   RUC         CHAR(8) DEFAULT "",                                              
   FECHAINI    DATE,                                                            
   FECHAFIN    DATE,                                                            
   STATUS      CHAR(10) DEFAULT "",                                             
   TDOCUMENTO  CHAR(2) DEFAULT "",                                              
   CDOCUMENTO  VARCHAR(11) DEFAULT "",          
   TOPERADOR   CHAR(2) DEFAULT "",                                
   PRIMARY KEY(COD));                                                           
CREATE INDEX TA65_1 ON TA65(COD);                                               
CREATE INDEX TA65_2 ON TA65(TRANSPORTE);                                        
                                                                                
/* TA66( TABLAS DE NIVEL COMERCIAL DEL IMPORTADOR )*/                           
CREATE TABLE IF NOT EXISTS TA66(                                                
   COD         CHAR(1) NOT NULL,                                                
   NIV_IMPORT  CHAR(10) DEFAULT "",                                             
   COD_DAV     CHAR(2) DEFAULT "",                                              
   NIV_DAV     VARCHAR(20) DEFAULT "",                                          
   PRIMARY KEY(COD));                                                           
CREATE INDEX TA66_1 ON TA66(COD);                                               
CREATE INDEX TA66_2 ON TA66(NIV_IMPORT);                                        
                                                                                
/* TA68( TABLAS DE MODALIDAD IMPORTACI�N SIMPLIFICADA )*/                       
CREATE TABLE IF NOT EXISTS TA68(                                                
   CODIGO      CHAR(2) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(40) DEFAULT "",                                          
   DESCRIPCI2  VARCHAR(40) DEFAULT "",                                             
   REG         CHAR(2) DEFAULT "",
   PRIMARY KEY(CODIGO,REG));                                                        
CREATE INDEX TA68_1 ON TA68(CODIGO);                                            
CREATE INDEX TA68_2 ON TA68(DESCRIPCIO);                                        

/* TA69( TABLAS DE TIPO DE TRATO PARA EXPORTACION TEMP. )*/                     
CREATE TABLE IF NOT EXISTS TA69(                                                
   COD         CHAR(1) NOT NULL,                                                
   TIPO_TRAT   VARCHAR(40) DEFAULT "",                                          
   FECHAINI    DATE,                                                            
   FECHAFIN    DATE,                                                            
   ESTADO      CHAR(10) DEFAULT "",                                             
   PRIMARY KEY(COD));                                                           
CREATE INDEX TA69_1 ON TA69(COD);                                               

/* TA72( TABLAS DE PARTIDAS AFECTAS AL I.S.C. )*/                               
CREATE TABLE IF NOT EXISTS TA72(                                                
   PARTIDA     CHAR(10) NOT NULL,                                               
   COD         CHAR(2) DEFAULT "",                                              
   CORREL      CHAR(2) DEFAULT "",
   TASA        DECIMAL(6,3) DEFAULT 0.000,                                      
   TEXTO       CHAR(3) DEFAULT "",                                              
   PARTIDA_AN  CHAR(10) DEFAULT "",                                             
   OBSERVACIO  VARCHAR(50) DEFAULT "",                                          
   FECH_INICI  DATE, 
   FECH_TERM   DATE,   
   PRIMARY KEY(PARTIDA,COD,CORREL));                                                       
CREATE INDEX TA72_1 ON TA72(PARTIDA);                                           
CREATE INDEX TA72_2 ON TA72(COD);                                               

/* TA73( TABLAS DE TEXTO NORMATIVO DE AFECTOS AL I.S.C. )*/                     
CREATE TABLE IF NOT EXISTS TA73(                                                
   CODIGO      CHAR(3) NOT NULL,                                                
   TEXTO       VARCHAR(70) DEFAULT "",                                          
   TEXTO1      VARCHAR(70) DEFAULT "",                                          
   TEXTO2      VARCHAR(70) DEFAULT "",                                          
   TEXTO3      VARCHAR(70) DEFAULT "",                                          
   TEXTO4      VARCHAR(70) DEFAULT "",                                          
   TEXTO5      VARCHAR(70) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA73_1 ON TA73(CODIGO);                                            
CREATE INDEX TA73_2 ON TA73(TEXTO);                                             
                                                                                
/* TA74( TABLAS DE TIPO DE SEGURO )*/                                           
CREATE TABLE IF NOT EXISTS TA74(                                                
   CODIGO      CHAR(1) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(35) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA74_1 ON TA74(CODIGO);                                            
CREATE INDEX TA74_2 ON TA74(DESCRIPCIO);                                        
                                                                                
/* TA75( TABLAS DE TIPOS DE ENDOSE PARA VEHICULOS )*/                           
CREATE TABLE IF NOT EXISTS TA75(                                                
   CODIGO      CHAR(2) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(65) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA75_1 ON TA75(CODIGO);                                            
CREATE INDEX TA75_2 ON TA75(DESCRIPCIO);                                        
                                                                                
/* TA81( TABLAS DE LIBERACI�N DE I.G.V PARA LOS LIBROS )*/                      
CREATE TABLE IF NOT EXISTS TA81(                                                
   PARTIDA     CHAR(10) NOT NULL,                                               
   COD         CHAR(2) DEFAULT "",                                              
   TASA        NUMERIC(3,0) DEFAULT 0,                                          
   TEXTO       CHAR(3) DEFAULT "",                                              
   PARTIDA_AN  CHAR(10) DEFAULT "",                                             
   PRIMARY KEY(PARTIDA,COD));                                                       
CREATE INDEX TA81_1 ON TA81(PARTIDA);                                           
CREATE INDEX TA81_2 ON TA81(COD);                                               
                                                                                
/* TA82( TABLAS DE FOB REFERENCIAL POR FECHAS )*/                               
CREATE TABLE IF NOT EXISTS TA82(                                                
   FECH_INI    DATE NOT NULL,                                                   
   FECH_TERM   DATE,                                                            
   TRIGO       CHAR(3) DEFAULT "",                                              
   MAIZ        CHAR(3) DEFAULT "",                                              
   ARROZ       CHAR(4) DEFAULT "",                                              
   AZUCAR      CHAR(3) DEFAULT "",                                              
   AZUCAR1     CHAR(3) DEFAULT "",                                              
   FECH_INI2   DATE,                                                            
   FECH_TERM2  DATE,                                                            
   LACTEOS     CHAR(4) DEFAULT "",                                              
   PRIMARY KEY(FECH_INI));                                                      
CREATE INDEX TA82_1 ON TA82(FECH_INI);                                          
CREATE INDEX TA82_2 ON TA82(FECH_INI2);                                         
                                                                                
/* TA83( TABLAS DE PARTIDAS AFECTAS A DERECHO ESPEC�FICO )*/                    
CREATE TABLE IF NOT EXISTS TA83(                                                
   PARTIDA     CHAR(10) NOT NULL,                                               
   CODIGO      CHAR(2) DEFAULT "",                                              
   DESCRIP1    VARCHAR(65) DEFAULT "",                                          
   DESCRIP2    VARCHAR(65) DEFAULT "",                                          
   BASICO1     NUMERIC(3,0) DEFAULT 0,                                          
   BASICO2     NUMERIC(3,0) DEFAULT 0,                                          
   PARTIDA_AN  CHAR(10) DEFAULT "",  
   B           NUMERIC(3,0) DEFAULT 0,
   PRIMARY KEY(PARTIDA));                                                       
CREATE INDEX TA83_1 ON TA83(PARTIDA);                                           
    
/* TA85( TABLAS DE PARTIDAS DEL D.S. 123-97-EF )*/                              
CREATE TABLE IF NOT EXISTS TA85(                                                
   PARTIDA     CHAR(10) NOT NULL,                                               
   DESCRIPC1   VARCHAR(72) DEFAULT "",                                          
   DESCRIPC2   VARCHAR(72) DEFAULT "",                                          
   DESCRIPC3   VARCHAR(72) DEFAULT "",                                          
   DESCRIPC4   VARCHAR(72) DEFAULT "",                                          
   TIPO_MARGE  CHAR(1) DEFAULT "",                                              
   PARTIDA_AN  CHAR(10) DEFAULT "",                                             
   PRIMARY KEY(PARTIDA,DESCRIPC1,DESCRIPC2));                                                       
CREATE INDEX TA85_1 ON TA85(PARTIDA);                                           

                                      
/* TA86( TABLAS DE CRONOGRAMA DE ALADI PER�-CHILE )*/                           
CREATE TABLE IF NOT EXISTS TA86(                                                
   CODIGO      CHAR(5) NOT NULL,                                                
   MPO         DECIMAL(5,1) DEFAULT 0.0,                                        
   FECH_INI    DATE,                                                            
   FECH_TER    DATE,                                                            
   PRIMARY KEY(CODIGO,FECH_INI));                                                        
CREATE INDEX TA86_1 ON TA86(CODIGO);                                            
                                                                                
/* TA87( TABLAS DE LIBERACI�N SEG�N NALADISA(PER�-CHILE) )*/                    
CREATE TABLE IF NOT EXISTS TA87(                                                
   PARTIDA     CHAR(10) NOT NULL,                                               
   MPO         DECIMAL(5,1) DEFAULT 0.0,                                        
   FECH_INI    DATE,                                                            
   FECH_TER    DATE,                                                            
   DESCRIPC1   VARCHAR(25) DEFAULT "",                                          
   CUPO        NUMERIC(8,0) DEFAULT 0,                                          
   PRIMARY KEY(PARTIDA,FECH_INI,CUPO));                                                       
CREATE INDEX TA87_1 ON TA87(PARTIDA);   

/* TA88( TABLAS DE PARTIDAS DE SEMILLAS )*/                                     
CREATE TABLE IF NOT EXISTS TA88(                                                
   PARTIDA     CHAR(10) NOT NULL,                                               
   NALADISA    CHAR(10) DEFAULT "",                                             
   PRODUCTO    VARCHAR(50) DEFAULT "",                                          
   PARTIDA_AN  CHAR(10) DEFAULT "",                                             
   PRIMARY KEY(PARTIDA,NALADISA,PRODUCTO));                                                       
CREATE INDEX TA88_1 ON TA88(PARTIDA);                                           
                                                                                
/* TA89( TABLAS DE PAISES DEL ALADI PARA SEMILLAS )*/                           
CREATE TABLE IF NOT EXISTS TA89(                                                
   PAIS        CHAR(3) NOT NULL,                                                
   NOM_PAIS    VARCHAR(15) DEFAULT "",                                          
   MPO         DECIMAL(6,2) DEFAULT 0.00,                                       
   PRIMARY KEY(PAIS));                                                          
CREATE INDEX TA89_1 ON TA89(PAIS);                                              
                                                                                
/* TA92( TABLAS DE CLASIFICACI�N DE SOFTWARE )*/                                
CREATE TABLE IF NOT EXISTS TA92(                                                
   COD         CHAR(1) NOT NULL,                                                
   DESCRIPC1   VARCHAR(50) DEFAULT "",                                          
   DESCRIPC2   VARCHAR(50) DEFAULT "",                                          
   ESTADO      CHAR(10) DEFAULT "",                                             
   PRIMARY KEY(COD));                                                           
CREATE INDEX TA92_1 ON TA92(COD);                                               

/* TA93(TABLA DE INCIDENCIA DE DESPACHOS)*/
CREATE TABLE IF NOT EXISTS TA93(
    COD         CHAR(2) NOT NULL,        /*Codigo de la Incidencia */
    INCIDENCIA  VARCHAR(55) DEFAULT "",  /*Descripcion de la Indicencia */
    DESCRIPCIO  VARCHAR(11) DEFAULT "",  /*Descripcion Resumida de la Incidencia */
    AUTOMATICO  CHAR(1) DEFAULT "",      /*Flag que indica que la Incidencia es Automatica */
    RUTA_TXTS   VARCHAR(50) DEFAULT "",  /*Ruta donde el sistema generara un Archivo de Texto */
   PRIMARY KEY(COD),
   CONSTRAINT UQ_TA93_1 UNIQUE(COD,INCIDENCIA));
CREATE INDEX TA93 ON TA93(COD);
                                                                                
/* TA94( TABLAS DE CODIGOS DE FERIA )*/                                         
CREATE TABLE IF NOT EXISTS TA94(                                                
   CODIGO      CHAR(4) NOT NULL,                                                
   DESCRIP     VARCHAR(46) DEFAULT "",                                          
   COD_ANT     CHAR(2) DEFAULT "",                                              
   CIUDAD      VARCHAR(11) DEFAULT "",                                          
   FCH_INICIO  DATE,                                                            
   FCH_FIN     DATE,                                                            
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA94_1 ON TA94(CODIGO);                                            
                                                                                
/* TA95( TABLAS DE PARTIDAS DE INSECTICIDAS )*/                                 
CREATE TABLE IF NOT EXISTS TA95(                                                
   PARTIDA     CHAR(10) NOT NULL,                                               
   PARTIDA_AN  CHAR(10) DEFAULT "",                                             
   PRIMARY KEY(PARTIDA));                                                       
CREATE INDEX TA95_1 ON TA95(PARTIDA);                                           
                                                                                
/* TA96( TABLAS DE TIPOS DE FERIA )*/                                           
CREATE TABLE IF NOT EXISTS TA96(                                                
   CODIGO      CHAR(2) NOT NULL,                                                
   DESCRIP     VARCHAR(60) DEFAULT "",                                          
   ESTADO      CHAR(10) DEFAULT "",                                             
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA96_1 ON TA96(CODIGO);                                            
                                                                                
/* TA97( TABLAS DE TIPOS DE TASA PARA 18 )*/                                    
CREATE TABLE IF NOT EXISTS TA97(                                                
   CODIGO      CHAR(2) NOT NULL,                                                
   DESCRIP     VARCHAR(40) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA97_1 ON TA97(CODIGO);                                            
                                                                                
/* TA100( TABLAS DE EXCLUCIONES A RESTITUCION DERECHOS )*/                      
CREATE TABLE IF NOT EXISTS TA100(                                               
   PARTIDA     CHAR(10) NOT NULL,                                               
   DESCRIP1    VARCHAR(70) DEFAULT "",                                          
   DESCRIP2    VARCHAR(70) DEFAULT "",                                          
   PARTIDA_AN  CHAR(10) DEFAULT "",                                             
   PRIMARY KEY(PARTIDA));                                                       
CREATE INDEX TA100_1 ON TA100(PARTIDA);                                         
                                                                                
/* TA101( TABLAS DE TIPOS DE EMPAQUE PARA REEMBARQUE )*/                        
CREATE TABLE IF NOT EXISTS TA101(                                               
   CODIGO      CHAR(1) NOT NULL,                                                
   DESCRIP     VARCHAR(62) DEFAULT "",                                          
   MOD_01      CHAR(1) DEFAULT "",                                              
   MOD_06      CHAR(1) DEFAULT "",                                              
   MOD_OTR     CHAR(1) DEFAULT "",                                              
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA101_1 ON TA101(CODIGO);                                          
                                                                                
/* TA102( TABLAS DE MODALIDAD PARA REEMBARQUE )*/                               
CREATE TABLE IF NOT EXISTS TA102(                                               
   CODIGO      CHAR(2) NOT NULL,                                                
   DESCRIP     VARCHAR(60) DEFAULT "",                                          
   DESCRIP2    VARCHAR(60) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA102_1 ON TA102(CODIGO);                                          
                                                                                
/* TA103( TABLAS DE MODALIDAD PARA TRANSITO )*/                                 
CREATE TABLE IF NOT EXISTS TA103(                                               
   CODIGO      CHAR(2) NOT NULL,                                                
   DESCRIP     VARCHAR(45) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA103_1 ON TA103(CODIGO);                                          
                                                                                
/* TA105( TABLAS DE CODIGOS DE UBIGEO )*/                                       
CREATE TABLE IF NOT EXISTS TA105(                                               
   CODIGO      CHAR(6) NOT NULL,                                                
   DISTRITO    VARCHAR(30) DEFAULT "",                                          
   PROVINCIA   VARCHAR(20) DEFAULT "",                                          
   DPTO        VARCHAR(15) DEFAULT "",                                          
   CREGION     CHAR(3) DEFAULT "",                                              
   CSUBREGION  CHAR(3) DEFAULT "",                                              
   FCAMBIO     NUMERIC(6,0) DEFAULT 0,                                          
   HCAMBIO     CHAR(8) DEFAULT "",                                              
   CUSUARIO    CHAR(7) DEFAULT "",                                              
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA105_1 ON TA105(CODIGO);                                          
CREATE INDEX TA105_2 ON TA105(DISTRITO);                                        
                                                                                
/* TA107( TABLAS DE INDICE DE NORMAS LEGALES )*/                                
CREATE TABLE IF NOT EXISTS TA107(                                               
   FECHA       DATE NOT NULL,                                                   
   CODIGO      CHAR(3) NOT NULL,
   REFERENCIA  VARCHAR(40) NOT NULL,
   DETALLE     VARCHAR(110) DEFAULT "",                                         
   AREA        VARCHAR(30) DEFAULT "",                                          
   DESCRIPC1   VARCHAR(62) DEFAULT "",                                          
   DESCRIPC2   VARCHAR(62) DEFAULT "",                                          
   DESCRIPC3   VARCHAR(62) DEFAULT "",                                          
   DESCRIPC4   VARCHAR(62) DEFAULT "",                                          
   DESCRIPC5   VARCHAR(62) DEFAULT "",                                          
   DESCRIPC6   VARCHAR(62) DEFAULT "",                                          
   DESCRIPC7   VARCHAR(62) DEFAULT "",                                          
   DESCRIPC8   VARCHAR(62) DEFAULT "",                                          
   PAG1        VARCHAR(20) DEFAULT "",                                          
   PAG2        VARCHAR(20) DEFAULT "",                                          
   PAG3        VARCHAR(20) DEFAULT "",                                          
   PAG4        VARCHAR(20) DEFAULT "",                                          
   PAG5        VARCHAR(20) DEFAULT "",                                          
   PAG6        VARCHAR(20) DEFAULT "",                                          
   PAG7        VARCHAR(20) DEFAULT "",                                          
   PAG8        VARCHAR(20) DEFAULT "",                                          
   PAG9        VARCHAR(20) DEFAULT "",                                          
   PAG10       VARCHAR(20) DEFAULT "",                                          
   PAG11       VARCHAR(20) DEFAULT "",                                          
   PAG12       VARCHAR(20) DEFAULT "",                                          
   PAG13       VARCHAR(20) DEFAULT "",                                          
   PAG14       VARCHAR(20) DEFAULT "",                                          
   PAG15       VARCHAR(20) DEFAULT "",                                          
   PAG16       VARCHAR(20) DEFAULT "",                                          
   PAG17       VARCHAR(20) DEFAULT "",                                          
   PAG18       VARCHAR(20) DEFAULT "",                                          
   PAG19       VARCHAR(20) DEFAULT "",                                          
   PAG20       VARCHAR(20) DEFAULT "",                                          
   PAG21       VARCHAR(20) DEFAULT "",                                          
   PAG22       VARCHAR(20) DEFAULT "",                                          
   PAG23       VARCHAR(20) DEFAULT "",                                          
   PAG24       VARCHAR(20) DEFAULT "",                                          
   PAG25       VARCHAR(20) DEFAULT "",                                          
   PAG26       VARCHAR(20) DEFAULT "",                                          
   PAG27       VARCHAR(20) DEFAULT "",                                          
   PAG28       VARCHAR(20) DEFAULT "",                                          
   PAG29       VARCHAR(20) DEFAULT "",                                          
   PAG30       VARCHAR(20) DEFAULT "",                                          
   PAG31       VARCHAR(20) DEFAULT "",                                          
   PAG32       VARCHAR(20) DEFAULT "",                                          
   PAG33       VARCHAR(20) DEFAULT "",                                          
   PAG34       VARCHAR(20) DEFAULT "",                                          
   PAG35       VARCHAR(20) DEFAULT "",                                          
   PAG36       VARCHAR(20) DEFAULT "",                                          
   PAG37       VARCHAR(20) DEFAULT "",                                          
   PAG38       VARCHAR(20) DEFAULT "",                                          
   PAG39       VARCHAR(20) DEFAULT "",                                          
   PAG40       VARCHAR(20) DEFAULT "",                                          
   PAG41       VARCHAR(20) DEFAULT "",                                          
   PAG42       VARCHAR(20) DEFAULT "",                                          
   PAG43       VARCHAR(20) DEFAULT "",                                          
   PAG44       VARCHAR(20) DEFAULT "",                                          
   PAG45       VARCHAR(20) DEFAULT "",                                          
   PAG46       VARCHAR(20) DEFAULT "",                                          
   PAG47       VARCHAR(20) DEFAULT "",                                          
   PAG48       VARCHAR(20) DEFAULT "",                                          
   PAG49       VARCHAR(20) DEFAULT "",                                          
   PAG50       VARCHAR(20) DEFAULT "",                                          
   PAG51       VARCHAR(20) DEFAULT "",                                          
   PAG52       VARCHAR(20) DEFAULT "",                                          
   PAG53       VARCHAR(20) DEFAULT "",                                          
   PAG54       VARCHAR(20) DEFAULT "",                                          
   PAG55       VARCHAR(20) DEFAULT "",                                          
   PAG56       VARCHAR(20) DEFAULT "",                                          
   PAG57       VARCHAR(20) DEFAULT "",                                          
   PAG58       VARCHAR(20) DEFAULT "",                                          
   PAG59       VARCHAR(20) DEFAULT "",                                          
   PAG60       VARCHAR(20) DEFAULT "",                                          
   PAG61       VARCHAR(20) DEFAULT "",                                          
   PAG62       VARCHAR(20) DEFAULT "",                                          
   PAG63       VARCHAR(20) DEFAULT "",                                          
   PAG64       VARCHAR(20) DEFAULT "",                                          
   PAG65       VARCHAR(20) DEFAULT "",                                          
   PAG66       VARCHAR(20) DEFAULT "",                                          
   PAG67       VARCHAR(20) DEFAULT "",                                          
   PAG68       VARCHAR(20) DEFAULT "",                                          
   PAG69       VARCHAR(20) DEFAULT "",                                          
   PAG70       VARCHAR(20) DEFAULT "",                                          
   PAG71       VARCHAR(20) DEFAULT "",                                          
   PAG72       VARCHAR(20) DEFAULT "",                                          
   PAG73       VARCHAR(20) DEFAULT "",                                          
   PAG74       VARCHAR(20) DEFAULT "",                                          
   PAG75       VARCHAR(20) DEFAULT "",                                          
   PAG76       VARCHAR(20) DEFAULT "",                                          
   PAG77       VARCHAR(20) DEFAULT "",                                          
   PAG78       VARCHAR(20) DEFAULT "",                                          
   PAG79       VARCHAR(20) DEFAULT "",                                          
   PAG80       VARCHAR(20) DEFAULT "",                                          
   PAG81       VARCHAR(20) DEFAULT "",                                          
   PAG82       VARCHAR(20) DEFAULT "",                                          
   PAG83       VARCHAR(20) DEFAULT "",                                          
   PAG84       VARCHAR(20) DEFAULT "",                                          
   PAG85       VARCHAR(20) DEFAULT "",                                          
   PAG86       VARCHAR(20) DEFAULT "",                                          
   PAG87       VARCHAR(20) DEFAULT "",                                          
   PAG88       VARCHAR(20) DEFAULT "",                                          
   PAG89       VARCHAR(20) DEFAULT "",                                          
   PAG90       VARCHAR(20) DEFAULT "",                                          
   PAG91       VARCHAR(20) DEFAULT "",                                          
   PAG92       VARCHAR(20) DEFAULT "",                                          
   PAG93       VARCHAR(20) DEFAULT "",                                          
   PAG94       VARCHAR(20) DEFAULT "",                                          
   PAG95       VARCHAR(20) DEFAULT "",                                          
   PRIMARY KEY(FECHA,CODIGO,REFERENCIA,DETALLE));                                                         
CREATE INDEX TA107_1 ON TA107(FECHA);                                           
CREATE INDEX TA107_2 ON TA107(REFERENCIA);                                      
                    
/* TA108( TABLAS DE TEMAS DE NORMAS LEGALES )*/                                 
CREATE TABLE IF NOT EXISTS TA108(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   TEMA        VARCHAR(60) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA108_1 ON TA108(CODIGO);                                          
CREATE INDEX TA108_2 ON TA108(TEMA);                                            
                                                                                
/* TA113( TABLAS DE TIPOS DE ENVIO URGENTE Y ANTICIPADOS )*/                    
CREATE TABLE IF NOT EXISTS TA113(                                               
   COD         CHAR(2) NOT NULL,                                                
   DESCRIPCI1  VARCHAR(60) DEFAULT "",                                          
   DESCRIPCI2  VARCHAR(50) DEFAULT "",                                          
   DESCRIPCI3  VARCHAR(50) DEFAULT "",                                          
   TIPO_DESPA  CHAR(3) DEFAULT "",                                              
   ESTADO      CHAR(10) DEFAULT "",                                             
   CODI_REGI   CHAR(2) DEFAULT "",                                              
   PRIMARY KEY(COD,TIPO_DESPA,CODI_REGI));                                                           
CREATE INDEX TA113_1 ON TA113(COD);                                             

/* TA114( TABLAS DE MARCA DE CIGARRILLOS )*/                                    
CREATE TABLE IF NOT EXISTS TA114(                                               
   COD         CHAR(2) NOT NULL,                                                
   CIGARRO     VARCHAR(15) DEFAULT "",                                          
   PRIMARY KEY(COD));                                                           
CREATE INDEX TA114_1 ON TA114(COD);                                             
CREATE INDEX TA114_2 ON TA114(CIGARRO);                                         
                                                                                
/* TA120( TABLAS DE C�DIGO DE MODALIDAD DE MUA )*/                              
CREATE TABLE IF NOT EXISTS TA120(                                               
   CODIGO      CHAR(2) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(65) DEFAULT "",                                          
   TIPOREG     CHAR(2) DEFAULT "",                                              
   PRIMARY KEY(CODIGO,TIPOREG));                                                        
CREATE INDEX TA120_1 ON TA120(CODIGO);                                          
CREATE INDEX TA120_2 ON TA120(DESCRIPCIO);                                      
          
/* TA121( TABLAS DE C�DIGO DE UNIDADES COMERCIALES )*/                          
CREATE TABLE IF NOT EXISTS TA121(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   UNID_COMER  VARCHAR(50) DEFAULT "",                                          
   FECHAINI    DATE,                                                            
   FECHAFIN    DATE,                                                            
   ESTADO      VARCHAR(12) DEFAULT "",                                          
   MARCA       CHAR(1) DEFAULT "",
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA121_1 ON TA121(CODIGO);                                          
CREATE INDEX TA121_2 ON TA121(UNID_COMER);                                      
                                                                                
/* TA122( TABLAS DE CODIGO DE GASTOS DEL DVA )*/                                
CREATE TABLE IF NOT EXISTS TA122(                                               
   CODIGO      CHAR(4) NOT NULL,                                                
   CONCEPTO    VARCHAR(50) DEFAULT "",                                          
   CONCEPTO1   VARCHAR(90) DEFAULT "",                                          
   TIPO        CHAR(1) DEFAULT "",                                              
   ABREV       CHAR(10) DEFAULT "",                                             
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA122_1 ON TA122(CODIGO);                                          
CREATE INDEX TA122_2 ON TA122(CONCEPTO);                                        
                                                                                
/* TA123( TABLAS DE POSICION FRENTE AL INFORME DE VERIFICAC )*/                 
CREATE TABLE IF NOT EXISTS TA123(                                               
   CODIGO      CHAR(1) NOT NULL,                                                
   CONCEPTO    VARCHAR(64) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA123_1 ON TA123(CODIGO);                                          
CREATE INDEX TA123_2 ON TA123(CONCEPTO);                                        
                                                                                
/* TA125( TABLAS DE MOTIVOS DE VALOR DE AJUSTE )*/                              
CREATE TABLE IF NOT EXISTS TA125(                                               
   CODIGO      CHAR(2) NOT NULL,                                                
   DESCRIPCI1  VARCHAR(60) DEFAULT "",                                          
   DESCRIPCI2  VARCHAR(60) DEFAULT "",                                          
   FECHAINI    DATE,                                                            
   FECHAFIN    DATE,                                                            
   ESTADO      CHAR(10) DEFAULT "",                                             
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA125_1 ON TA125(CODIGO);                                          
CREATE INDEX TA125_2 ON TA125(DESCRIPCI1);                                      
                                                                                
/* TA126( TABLAS DE ENTIDAD AUTOR.DE MERC.RESTRINGIDA )*/                       
CREATE TABLE IF NOT EXISTS TA126(                                               
   CODIGO      CHAR(2) NOT NULL,                                                
   DESCRIPCI1  VARCHAR(60) DEFAULT "",                                          
   DESCRIPCI2  VARCHAR(60) DEFAULT "",                                          
   FECHAINI    DATE,                                                            
   FECHAFIN    DATE,                                                            
   ESTADO      CHAR(10) DEFAULT "",                                             
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA126_1 ON TA126(CODIGO);                                          
CREATE INDEX TA126_2 ON TA126(DESCRIPCI1);                                      
                                                                                
/* TA128( TABLAS DE TIPO DE DOC.DE AUTOR.MER.RESTRINGIDA )*/                    
CREATE TABLE IF NOT EXISTS TA128(                                               
   CODIGO      CHAR(2) NOT NULL,                                                
   DESCRIPC1   VARCHAR(65) DEFAULT "",                                          
   SUBENTIDAD  CHAR(4) DEFAULT "",                                          
   FECHAINI    DATE,                                                            
   FECHAFIN    DATE,                                                            
   ESTADO      CHAR(10) DEFAULT "",                                             
   PRIMARY KEY(SUBENTIDAD,CODIGO));                                                        
CREATE INDEX TA128_1 ON TA128(SUBENTIDAD,CODIGO);                                          
CREATE INDEX TA128_2 ON TA128(DESCRIPC1);                                       

/* TA130( Anexo I y II de Convenio de Aceleraci�n )*/           
CREATE TABLE IF NOT EXISTS TA130(                                               
   PARTIDA     CHAR(10) NOT NULL,                                                
   ANEXO       CHAR(1) DEFAULT "",                                          
   PARTIDA_AN  VARCHAR(10) DEFAULT "",                                          
   PRIMARY KEY(PARTIDA));                                                        
CREATE INDEX TA130_1 ON TA130(PARTIDA);                                          
                                                                                
/* TA133( TABLAS DE INCISOS DE ART.2 DEL D.S.N� 071-98-EF PARA 18 )*/           
CREATE TABLE IF NOT EXISTS TA133(                                               
   INCISO      CHAR(1) NOT NULL,                                                
   DESCRIP1    VARCHAR(56) DEFAULT "",                                          
   DESCRIP2    VARCHAR(56) DEFAULT "",                                          
   DESCRIP3    VARCHAR(56) DEFAULT "",                                          
   DESCRIP4    VARCHAR(56) DEFAULT "",                                          
   DESCRIP5    VARCHAR(56) DEFAULT "",                                          
   PRIMARY KEY(INCISO));                                                        
CREATE INDEX TA133_1 ON TA133(INCISO);                                          
                                                                                
/* TA134( TABLAS DE PARTIDAS PARA DISCAPACITADOS )*/                            
CREATE TABLE IF NOT EXISTS TA134(                                               
   PARTIDA     CHAR(10) NOT NULL,                                               
   PARTIDA_AN  CHAR(10) DEFAULT "",                                             
   PRIMARY KEY(PARTIDA));                                                       
CREATE INDEX TA134_1 ON TA134(PARTIDA);                                         
                                                                                
/* TA138( TABLAS DE MERCANC�A RESTRINGIDA )*/                                   
CREATE TABLE IF NOT EXISTS TA138(                                               
   ANEXO       NUMERIC(2,0) NOT NULL,                                           
   SUB_ANEXO   CHAR(2) NOT NULL,                                                
   PARTIDA     CHAR(10) NOT NULL,                                               
   DES1        VARCHAR(73) DEFAULT "",                                          
   DES2        VARCHAR(71) DEFAULT "",                                          
   DES3        VARCHAR(71) DEFAULT "",                                          
   DES4        VARCHAR(71) DEFAULT "",                                          
   DES5        VARCHAR(70) DEFAULT "",                                          
   DES6        VARCHAR(70) DEFAULT "",                                          
   DES7        VARCHAR(70) DEFAULT "",                                          
   DES8        VARCHAR(70) DEFAULT "",                                          
   DES9        VARCHAR(70) DEFAULT "",                                          
   USO         VARCHAR(70) DEFAULT "",                                          
   PARTIDA_AN  CHAR(10) DEFAULT "",                                             
   RIESGO      CHAR(1) DEFAULT "",                                              
   PRIMARY KEY(PARTIDA,ANEXO,SUB_ANEXO,DES1,DES2,DES3,DES4,DES5,DES6,USO,PARTIDA_AN));                                       
CREATE INDEX TA138_1 ON TA138(PARTIDA,ANEXO,SUB_ANEXO);                         

/* TA139( TABLAS DE TIPOS DE AUTORIZACI�N )*/                                   
CREATE TABLE IF NOT EXISTS TA139(                                               
   ANEXO       NUMERIC(2,0) NOT NULL,                                           
   SUB_ANEXO   CHAR(2) NOT NULL,                                                
   PRODUCTO    VARCHAR(230) DEFAULT "",                                         
   CODENTIDAD  CHAR(2) DEFAULT "",                                              
   AUTORIZAC   VARCHAR(230) DEFAULT "",                                         
   BASELEGAL   VARCHAR(230) DEFAULT "",                                         
   NOTA1       VARCHAR(230) DEFAULT "",                                         
   NOTA2       VARCHAR(230) DEFAULT "",                                         
   DS          VARCHAR(125) DEFAULT "",                                         
   PRIMARY KEY(ANEXO,SUB_ANEXO));                                               
CREATE INDEX TA139_1 ON TA139(ANEXO,SUB_ANEXO);                                 
                                                                                
/* TA140( TABLAS DE PUERTOS                      - IATA )*/                     
CREATE TABLE IF NOT EXISTS TA140(                                               
   CODIGO      CHAR(5) NOT NULL,                                                
   DESCRI      VARCHAR(33) DEFAULT "",                                          
   DPAIS       VARCHAR(50) DEFAULT "",                                          
   P_CODIGO    CHAR(6) DEFAULT "",                                              
   FECHAINI    DATE,                                                            
   FECHAFIN    DATE,                                                            
   ESTADO      CHAR(10) DEFAULT "",                                             
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA140_1 ON TA140(CODIGO);                                          
CREATE INDEX TA140_2 ON TA140(DESCRI);                                          
                                                                                
/* TA141( TABLAS DE PAISES                       - IATA )*/                     
CREATE TABLE IF NOT EXISTS TA141(                                               
   CODIGO      CHAR(2) NOT NULL,                                                
   DESCRI      VARCHAR(55) DEFAULT "",                                          
   DESCRI1     VARCHAR(50) DEFAULT "",                                          
   ANTIGUO     CHAR(3) DEFAULT "",                                              
   FECHAINI    DATE,                                                            
   FECHAFIN    DATE,                                                            
   ESTADO      CHAR(10) DEFAULT "",                                             
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA141_1 ON TA141(CODIGO);                                          
CREATE INDEX TA141_2 ON TA141(DESCRI);                                          
                                                                                
/* TA142( TABLAS DE MONEDAS                      - IATA )*/                     
CREATE TABLE IF NOT EXISTS TA142(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DPAIS1      VARCHAR(30) DEFAULT "",                                          
   DESCRI      VARCHAR(30) DEFAULT "",                                          
   FACTOR      DECIMAL(12,10) DEFAULT 0.0000000000,                             
   DPAIS       VARCHAR(55) DEFAULT "",                                          
   CPAIS       CHAR(2) DEFAULT "",                                              
   FECHA_ACT   DATE,                                                            
   FECHAINI    DATE,                                                            
   FECHAFIN    DATE,                                                            
   ESTADO      CHAR(10) DEFAULT "",                                             
   MARCA       CHAR(1) DEFAULT "",
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA142_1 ON TA142(CODIGO);                                          
CREATE INDEX TA142_2 ON TA142(DPAIS1);                                          
                                  
/* TA143( TABLAS DE PARTIDAS CON ANTIDUMPING     - IATA )*/                     
CREATE TABLE IF NOT EXISTS TA143(                                               
   PARTIDA     CHAR(10) NOT NULL,                                               
   PAIS        CHAR(2) NOT NULL,                                                
   CPROD       CHAR(2) NOT NULL,                                                
   DESCRIPC    VARCHAR(50) DEFAULT "",                                          
   DESCRIPC2   VARCHAR(35) DEFAULT "",                                          
   TASA        DECIMAL(7,2) DEFAULT 0.00,                                       
   TEXTO       CHAR(3) DEFAULT "",                                              
   TIPO_BASE   CHAR(3) DEFAULT "",                                              
   TIPO_CALC   CHAR(2) DEFAULT "",                                              
   TABANT      CHAR(8) DEFAULT "",                                              
   EMP_EXON1   VARCHAR(25) DEFAULT "",                                          
   CIFDOL      DECIMAL(6,2) DEFAULT 0.00,                                       
   PARTIDA_AN  CHAR(10) DEFAULT "",
   PRIMARY KEY(PAIS,CPROD,PARTIDA,DESCRIPC));                                            
CREATE INDEX TA143_1 ON TA143(PAIS,CPROD,PARTIDA);                              
CREATE INDEX TA143_2 ON TA143(PAIS,PARTIDA);                                    
CREATE INDEX TA143_3 ON TA143(PARTIDA);                                         
                                                                                
/* TA144( TABLAS DE ANTIDUMPING PROV.EXTRANJERO  - IATA )*/                     
CREATE TABLE IF NOT EXISTS TA144(                                               
   PARTIDA     CHAR(10) NOT NULL,                                               
   PAIS        CHAR(2) NOT NULL,                                                
   CPROD       CHAR(2) NOT NULL,                                                
   CEXPODUMP   CHAR(4) NOT NULL,                                                
   NOMB_EMPR   VARCHAR(50) DEFAULT "",                                          
   ANTIDUMP    DECIMAL(6,2) DEFAULT 0.00,                                       
   DESCRIP1    VARCHAR(75) DEFAULT "",                                          
   DESCRIP2    VARCHAR(75) DEFAULT "",                                          
   NOMB_EMPR1  VARCHAR(130) DEFAULT "",                                         
   TIPO_CALC   CHAR(2) DEFAULT "",                                              
   PARTIDA_AN  CHAR(10) DEFAULT "",                                             
   FCHINICIO   DATE,                                                            
   FCHTERMINO  DATE,                                                            
   TIPO_BASE   CHAR(3) DEFAULT "",                                              
   PRIMARY KEY(PARTIDA,PAIS,CPROD,CEXPODUMP,NOMB_EMPR,DESCRIP1));                                  
CREATE INDEX TA144_1 ON TA144(PARTIDA,PAIS,CPROD,CEXPODUMP);                    
CREATE INDEX TA144_2 ON TA144(NOMB_EMPR);                                       
CREATE INDEX TA144_3 ON TA144(PARTIDA,CPROD,CEXPODUMP);                         
                                                     
/* TA145( TABLAS DE ANTIDUMPING DEFINIT.  CHINA  - IATA )*/                     
CREATE TABLE IF NOT EXISTS TA145(                                               
   PAIS        CHAR(2) NOT NULL,                                                
   PARTIDA     CHAR(10) NOT NULL,                                               
   MINIMO      DECIMAL(10,3) DEFAULT 0.000,                                     
   MAXIMO      DECIMAL(10,3) DEFAULT 0.000,                                     
   ANTI        DECIMAL(10,2) DEFAULT 0.00,                                      
   CPROD       CHAR(2) NOT NULL,                                                
   TEXTO       CHAR(3) DEFAULT "",                                              
   TIPO_BASE   CHAR(3) DEFAULT "",                                              
   TIPO_CALC   CHAR(2) DEFAULT "",                                              
   TABANT      CHAR(8) DEFAULT "",                                              
   MENOS       CHAR(1) DEFAULT "",                                              
   PARTIDA_AN  CHAR(10) DEFAULT "",                                             
   EMP_EXON1   VARCHAR(65) DEFAULT "",                                          
   CEXPODUMP   CHAR(4) DEFAULT "",                                              
   NOMB_EMPR   VARCHAR(50) DEFAULT "",                                          
   ORDEN       CHAR(2) NOT NULL,                                          
   PRIMARY KEY(PAIS,CPROD,PARTIDA,ORDEN));                                            
CREATE INDEX TA145_1 ON TA145(PAIS,CPROD,PARTIDA);                             
CREATE INDEX TA145_2 ON TA145(PAIS,PARTIDA);                                    
CREATE INDEX TA145_3 ON TA145(PARTIDA);

/* TA146( TABLAS DE PAISES ALADI PARA SEMILLAS   - IATA )*/                     
CREATE TABLE IF NOT EXISTS TA146(                                               
   PAIS        CHAR(2) NOT NULL,                                                
   NOM_PAIS    VARCHAR(15) DEFAULT "",                                          
   MPO         DECIMAL(6,2) DEFAULT 0.00,                                       
   PRIMARY KEY(PAIS));                                                          
CREATE INDEX TA146_1 ON TA146(PAIS);                                            
                                                                                
/* TA147( TABLAS DE CRONOGRAMA PACTO ANDINO      - IATA )*/                     
CREATE TABLE IF NOT EXISTS TA147(                                               
   ANEXO       CHAR(1) NOT NULL,                                                
   FECHA       DATE,                                                            
   FECH_TER    DATE,                                                            
   MPO         NUMERIC(8,0) DEFAULT 0,                                          
   AUTORIZ     CHAR(1) DEFAULT "",                                              
   PAIS1       CHAR(2) DEFAULT "",                                              
   PAIS2       CHAR(2) DEFAULT "",                                              
   PAIS3       CHAR(2) DEFAULT "",                                              
   PAIS4       CHAR(2) DEFAULT "",                                              
   ORDEN       CHAR(1) NOT NULL,
   PRIMARY KEY(ANEXO,ORDEN));                                                         
CREATE INDEX TA147_1 ON TA147(ANEXO);                                           

/* TA148( TABLAS DE EXONERAC. DEL PACTO ANDINO   - IATA )*/                     
CREATE TABLE IF NOT EXISTS TA148(                                               
   PARTIDA     CHAR(10) NOT NULL,                                               
   PAIS        CHAR(2) NOT NULL,                                                
   PARTIDA_AN  CHAR(10) DEFAULT "",                                             
   PRIMARY KEY(PAIS,PARTIDA));                                                  
CREATE INDEX TA148_1 ON TA148(PAIS,PARTIDA);                                    
                                                                                
/* TA149( TABLAS DE ANTIDUMPING RUSIA Y UCRANIA  - IATA )*/                     
CREATE TABLE IF NOT EXISTS TA149(                                               
   PARTIDA     CHAR(10) NOT NULL,                                               
   COD_PAIS    CHAR(2) NOT NULL,                                                
   TASA        DECIMAL(6,2) DEFAULT 0.00,                                       
   CPROD       CHAR(2) DEFAULT "",                                              
   PARTIDA_AN  CHAR(10) DEFAULT "",                                             
   PRIMARY KEY(PARTIDA,COD_PAIS));                                              
CREATE INDEX TA149_1 ON TA149(PARTIDA,COD_PAIS);                                
                                                                                
/* TA150( TABLAS DE CRONOGRAMA CONV.ACELERACI�N  - IATA )*/                     
CREATE TABLE IF NOT EXISTS TA150(                                               
   ANEXO       CHAR(1) NOT NULL,                                                
   FECHA       DATE,                                                            
   FECH_TER    DATE,                                                            
   MPO         NUMERIC(8,0) DEFAULT 0,                                          
   AUTORIZ     CHAR(1) DEFAULT "",                                              
   PAIS1       CHAR(2) DEFAULT "",                                              
   DEC_414     CHAR(1) DEFAULT "",                                              
   ORDEN       CHAR(1) NOT NULL,
   PRIMARY KEY(ANEXO,ORDEN));                                                         
CREATE INDEX TA150_1 ON TA150(ANEXO);                                           
                          
/* TA151( TABLAS DE MODALIDAD DE REEXPORTACI�N )*/                              
CREATE TABLE IF NOT EXISTS TA151(                                               
   COD         CHAR(1) NOT NULL,                                                
   DESCRIP1    VARCHAR(32) DEFAULT "",                                          
   PRIMARY KEY(COD));                                                           
CREATE INDEX TA151_1 ON TA151(COD);                                             
                         
/* TA152( TABLAS DE CODIGOS DE ULTRACTIVIDAD )*/                                
CREATE TABLE IF NOT EXISTS TA152(                                               
   CODIGO      CHAR(2) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(50) DEFAULT "",                                          
   DESCRIPCI1  VARCHAR(50) DEFAULT "",                                          
   FECHAINI    DATE,                                                            
   FECHAFIN    DATE,                                                            
   ESTADO      CHAR(10) DEFAULT "",                                             
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA152_1 ON TA152(CODIGO);                                          
CREATE INDEX TA152_2 ON TA152(DESCRIPCIO);                                      
                                                                                
/* TA160( TABLAS DE BANCOS PARA OPERACIONES )*/                                 
CREATE TABLE IF NOT EXISTS TA160(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   BANCO       VARCHAR(58) DEFAULT "",                                          
   INICIALES   VARCHAR(20) DEFAULT "",                                          
   FECHAINI    DATE,                                                            
   FECHAFIN    DATE,                                                            
   ESTADO      CHAR(10) DEFAULT "",                                             
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA160_1 ON TA160(CODIGO);                                          
CREATE INDEX TA160_2 ON TA160(BANCO);                                           
                                                                                
/* TA161( TABLAS DE EMPRESAS DE TRANSPORTE TERRESTRE )*/                        
CREATE TABLE IF NOT EXISTS TA161(                                               
   CODIGO      CHAR(4) NOT NULL,                                                
   DESCRIPC    VARCHAR(63) DEFAULT "",                                          
   DIRECC      VARCHAR(50) DEFAULT "",                                          
   TELF1       VARCHAR(15) DEFAULT "",                                          
   TELF2       VARCHAR(15) DEFAULT "",                                          
   ESTADO      VARCHAR(12) DEFAULT "",                                          
   TDOCUMENTO  CHAR(2) DEFAULT "",                                              
   CDOCUMENTO  VARCHAR(11) DEFAULT "",                                          
   TOPERADOR   CHAR(2) DEFAULT "",
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA161_1 ON TA161(CODIGO);                                          
CREATE INDEX TA161_2 ON TA161(DESCRIPC);                                        

/* TA163(Nacionalizaci�n Excedente de Admisi�n    )*/                         
CREATE TABLE IF NOT EXISTS TA163(                                               
   COD         CHAR(1) NOT NULL,                                                
   DESCRIPC    VARCHAR(40) DEFAULT "",                                          
   PRIMARY KEY(COD));                                                        
CREATE INDEX TA163_1 ON TA163(COD);                                          
CREATE INDEX TA163_2 ON TA163(DESCRIPC);                                      

                                                                                
/* TA164( TABLAS DE OPERADORES DE COMERCIO EXTERIOR )*/                         
CREATE TABLE IF NOT EXISTS TA164(                                               
   CODIGO      CHAR(1) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(50) DEFAULT "",                                          
   WEBSERVICE  CHAR(1) DEFAULT "",                                              
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA164_1 ON TA164(CODIGO);                                          
CREATE INDEX TA164_2 ON TA164(DESCRIPCIO);                                      
                                                                                
/* TA165( TABLAS DE TRIBUTOS PARA AUTOLIQUIDACION DE ADEUDO )*/                 
CREATE TABLE IF NOT EXISTS TA165(                                               
   CODIGO      CHAR(4) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(55) DEFAULT "",                                          
   TIPO        CHAR(1) DEFAULT "",                                              
   COD_SAD     CHAR(2) DEFAULT "",                                              
   PRIMARY KEY(CODIGO,TIPO));                                                        
CREATE INDEX TA165_1 ON TA165(CODIGO);                                          
CREATE INDEX TA165_2 ON TA165(DESCRIPCIO);                                      

/* TA166( TABLAS DE SANCIONES PARA AUTOLIQUIDACION DE ADEUD )*/                 
CREATE TABLE IF NOT EXISTS TA166(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(170) DEFAULT "",                                         
   BASE_LEGAL  VARCHAR(33) DEFAULT "",                                          
   FECHINI     DATE,                                                            
   FECHTERM    DATE,                                                            
   PORC_UIT    DECIMAL(12,3) DEFAULT 0.000,                                     
   ESTADO      CHAR(10) DEFAULT "",                                             
   LEY         VARCHAR(11) DEFAULT "",                                          
   ART         VARCHAR(33) DEFAULT "",                                          
   ARTICULO    VARCHAR(20) DEFAULT "",                                          
   INCISO      VARCHAR(33) DEFAULT "",                                          
   MULTA       VARCHAR(50) DEFAULT "",                                          
   REGLAM      CHAR(7) DEFAULT "",                                              
   INCENTIVO   CHAR(1) DEFAULT "",                                              
   GRADUALIDA  CHAR(1) DEFAULT "",                                              
   MON_MULTA   CHAR(1) DEFAULT "",                                              
   SEACOGEINC  CHAR(1) DEFAULT "",                                              
   GRADUALI2   CHAR(1) DEFAULT "",                                              
   COND_EXONE  CHAR(45) DEFAULT "",
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA166_1 ON TA166(CODIGO);                                          
CREATE INDEX TA166_2 ON TA166(DESCRIPCIO);                                      

/* TA167( TABLAS DE MODALIDADES DE AUTOLIQUIDACION DE ADEUD )*/                 
CREATE TABLE IF NOT EXISTS TA167(                                               
   CODIGO      CHAR(4) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(80) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA167_1 ON TA167(CODIGO);                                          
CREATE INDEX TA167_2 ON TA167(DESCRIPCIO);                                      

/* TA168( TABLAS DE INDICADOR DE INCENTIVOS AUT.ADEUDOS )*/                     
CREATE TABLE IF NOT EXISTS TA168(                                               
   CODIGO      CHAR(1) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(50) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA168_1 ON TA168(CODIGO);                                          
CREATE INDEX TA168_2 ON TA168(DESCRIPCIO);                                      
                                                                                
/* TA169( TABLAS DE PORCENTAJE DE INCENTIVOS AUT.ADEUDOS )*/                    
CREATE TABLE IF NOT EXISTS TA169(                                               
   CODIGO      CHAR(1) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(15) DEFAULT "",                                          
   DESCRIPC1   VARCHAR(30) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA169_1 ON TA169(CODIGO);                                          
CREATE INDEX TA169_2 ON TA169(DESCRIPCIO);                                      
                                                                                
/* TA175( TABLAS DE MOTIVO DE TRASLADO DE GU�AS DE REMISI�N )*/                 
CREATE TABLE IF NOT EXISTS TA175(                                               
   CODIGO      CHAR(2) NOT NULL,                                                
   DESCRIPC    VARCHAR(55) DEFAULT "",                                          
   COD_ANT     CHAR(2) DEFAULT "",                                              
   ESTADO      CHAR(10) DEFAULT "",                                             
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA175_1 ON TA175(CODIGO);                                          
CREATE INDEX TA175_2 ON TA175(DESCRIPC);                                        
                                                                                
/* TA176( TABLAS DE TIPO DE PROCEDIMIENTO APLICADO (OCS) )*/                    
CREATE TABLE IF NOT EXISTS TA176(                                               
   CODIGO      CHAR(1) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(55) DEFAULT "",                                          
   REG_10      CHAR(1) DEFAULT "",                                              
   REG_18      CHAR(1) DEFAULT "",                                              
   REG_20      CHAR(1) DEFAULT "",                                              
   REG_21      CHAR(1) DEFAULT "",                                              
   REG_30      CHAR(1) DEFAULT "",                                              
   REG_70      CHAR(1) DEFAULT "",                                              
   REG_78      CHAR(1) DEFAULT "",                                              
   REG_80      CHAR(1) DEFAULT "",                                              
   REG_89      CHAR(1) DEFAULT "",                                              
   PRIMARY KEY(CODIGO,DESCRIPCIO));                                                        
CREATE INDEX TA176_1 ON TA176(CODIGO);                                          
CREATE INDEX TA176_2 ON TA176(DESCRIPCIO);                                      
   
/* TA177( TABLAS DE TIPO DE DOC. ASOCIADO AL DESPACHO (OCS) )*/                 
CREATE TABLE IF NOT EXISTS TA177(                                               
   CODIGO      CHAR(2) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(55) DEFAULT "",                                          
   REG_10      CHAR(1) DEFAULT "",                                              
   REG_18      CHAR(1) DEFAULT "",                                              
   REG_20      CHAR(1) DEFAULT "",                                              
   REG_21      CHAR(1) DEFAULT "",                                              
   REG_30      CHAR(1) DEFAULT "",                                              
   REG_70      CHAR(1) DEFAULT "",                                              
   REG_78      CHAR(1) DEFAULT "",                                              
   REG_80      CHAR(1) DEFAULT "",                                              
   REG_89      CHAR(1) DEFAULT "",                                              
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA177_1 ON TA177(CODIGO);                                          
CREATE INDEX TA177_2 ON TA177(DESCRIPCIO);                                      
                                                                                
/* TA184( TABLAS DE ANTIDUMPING PARA CUBIERTOS DE CHINA )*/                     
CREATE TABLE IF NOT EXISTS TA184(                                               
   PARTIDA     CHAR(10) NOT NULL,                                               
   PAIS        CHAR(2) NOT NULL,                                                
   CPROD       CHAR(2) NOT NULL,                                                
   DESCRIPC    VARCHAR(50) DEFAULT "",                                          
   MINIMO      DECIMAL(10,3) DEFAULT 0.000,                                     
   MAXIMO      DECIMAL(10,3) DEFAULT 0.000,                                     
   ANTI        DECIMAL(10,2) DEFAULT 0.00,                                      
   TEXTO       CHAR(3) DEFAULT "",                                              
   TIPO_APLIC  CHAR(3) DEFAULT "",                                              
   TABANT      CHAR(8) DEFAULT "",                                              
   PARTIDA_AN  CHAR(10) DEFAULT "",                                             
   PRIMARY KEY(PAIS,CPROD,PARTIDA));                                            
CREATE INDEX TA184_1 ON TA184(PAIS,CPROD,PARTIDA);                              
CREATE INDEX TA184_2 ON TA184(PAIS,PARTIDA);                                    
                                                                                
/* TA186( TABLAS DE TABLA DEL TAMEX )*/                                         
CREATE TABLE IF NOT EXISTS TA186(                                               
   FECH_TAM    DATE NOT NULL,                                                   
   TAMEX       DECIMAL(11,6) DEFAULT 0.000000,                                  
   TIC         DECIMAL(11,6) DEFAULT 0.000000,                                  
   PRIMARY KEY(FECH_TAM));                                                      
CREATE INDEX TA186_1 ON TA186(FECH_TAM);                                        
                                                                                
/* TA188( TABLAS DE P.A. EXCLUIDAS DE REST.DERECHOS (13) )*/                    
CREATE TABLE IF NOT EXISTS TA188(                                               
   PARTIDA     CHAR(10) NOT NULL,                                               
   DESCRIP     VARCHAR(70) DEFAULT "",                                          
   DESCRIP1    VARCHAR(70) DEFAULT "",                                          
   EXCEPTUADA  VARCHAR(70) DEFAULT "",                                          
   EXCEPTUAD1  VARCHAR(70) DEFAULT "",                                          
   PARTIDA_AN  CHAR(10) DEFAULT "",                                             
   PRIMARY KEY(PARTIDA,DESCRIP,DESCRIP1,EXCEPTUADA));                                                       
CREATE INDEX TA188_1 ON TA188(PARTIDA);                                         
                                       
/* TA189( TABLAS DE TIPO DE DEUDOR EN LA AUTOLIQUIDACION )*/                    
CREATE TABLE IF NOT EXISTS TA189(                                               
   CODIGO      CHAR(1) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(50) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA189_1 ON TA189(CODIGO);                                          
CREATE INDEX TA189_2 ON TA189(DESCRIPCIO);                                      
                                                                                
/* TA190( TABLAS DE NOMBRE COMERCIAL DE VEHICULOS )*/                           
CREATE TABLE IF NOT EXISTS TA190(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(25) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA190_1 ON TA190(CODIGO);                                          
CREATE INDEX TA190_2 ON TA190(DESCRIPCIO);                                      
                                                                           
/* TA193( TABLAS DE COLOR DE VEHICULOS )*/                                      
CREATE TABLE IF NOT EXISTS TA193(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(25) DEFAULT "",                                          
   FECHAINI    DATE,                                                            
   FECHAFIN    DATE,                                                            
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA193_1 ON TA193(CODIGO);                                          
CREATE INDEX TA193_2 ON TA193(DESCRIPCIO);                                      
                                                                                
/* TA194( TABLAS DE TIPO DE TRANSMISION DE VEHICULOS )*/                        
CREATE TABLE IF NOT EXISTS TA194(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(30) DEFAULT "",                                          
   DEFINIC1    VARCHAR(70) DEFAULT "",                                          
   DEFINIC2    VARCHAR(70) DEFAULT "",                                          
   DEFINIC3    VARCHAR(70) DEFAULT "",                                          
   DEFINIC4    VARCHAR(70) DEFAULT "",                                          
   DEFINIC5    VARCHAR(70) DEFAULT "",                                          
   DEFINIC6    VARCHAR(70) DEFAULT "",                                          
   DEFINIC7    VARCHAR(70) DEFAULT "",                                          
   DEFINIC8    VARCHAR(70) DEFAULT "",                                          
   DEFINIC9    VARCHAR(70) DEFAULT "",                                          
   DEFINIC10   VARCHAR(70) DEFAULT "",                                          
   FECHAINI    DATE,                                                            
   FECHAFIN    DATE,                                                            
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA194_1 ON TA194(CODIGO);                                          
CREATE INDEX TA194_2 ON TA194(DESCRIPCIO);                                      
                                                                                
/* TA195( TABLAS DE TIPO DE COMBUSTIBLE DE VEHICULOS )*/                        
CREATE TABLE IF NOT EXISTS TA195(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(29) DEFAULT "",                                          
   DEFINIC1    VARCHAR(70) DEFAULT "",                                          
   DEFINIC2    VARCHAR(70) DEFAULT "",                                          
   DEFINIC3    VARCHAR(70) DEFAULT "",                                          
   DEFINIC4    VARCHAR(70) DEFAULT "",                                          
   DEFINIC5    VARCHAR(70) DEFAULT "",                                          
   DEFINIC6    VARCHAR(70) DEFAULT "",                                          
   DEFINIC7    VARCHAR(70) DEFAULT "",                                          
   DEFINIC8    VARCHAR(70) DEFAULT "",                                          
   DEFINIC9    VARCHAR(70) DEFAULT "",                                          
   FECHAINI    DATE,                                                            
   FECHAFIN    DATE,                                                            
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA195_1 ON TA195(CODIGO);                                          
CREATE INDEX TA195_2 ON TA195(DESCRIPCIO);                                      
                                                                                
/* TA196( TABLAS DE TIPO DE TRACCI�N DE VEHICULOS )*/                           
CREATE TABLE IF NOT EXISTS TA196(                                               
   CODIGO      CHAR(4) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(15) DEFAULT "",                                          
   FECHAINI    DATE,                                                            
   FECHAFIN    DATE,                                                            
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA196_1 ON TA196(CODIGO);                                          
CREATE INDEX TA196_2 ON TA196(DESCRIPCIO);                                      
   
/* TA197( TABLAS DE ACCESORIOS DE VEHICULOS )*/                                 
CREATE TABLE IF NOT EXISTS TA197(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(55) DEFAULT "",                                          
   FECHAINI    DATE,                                                            
   FECHAFIN    DATE,                                                            
   NENVIO      CHAR(3) DEFAULT "",
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA197_1 ON TA197(CODIGO);                                          
CREATE INDEX TA197_2 ON TA197(DESCRIPCIO);                                      
                                                                                
/* TA198( TABLAS DE MEDICAMENTOS PARA TRAT.ONCOLOGICO Y VIH )*/                 
CREATE TABLE IF NOT EXISTS TA198(                                               
   PARTIDA     CHAR(10) NOT NULL,                                               
   DESCRIPCIO  VARCHAR(35) NOT NULL,                                            
   TIPO        CHAR(1) DEFAULT "",                                              
   PARTIDA_AN  CHAR(10) DEFAULT "",                                             
   PRIMARY KEY(PARTIDA,DESCRIPCIO));                                            
CREATE INDEX TA198_1 ON TA198(PARTIDA,DESCRIPCIO);                              
                                                                                
/* TA199( TABLAS DE VEHICULOS USADOS - D.U. N� 140-2001 )*/                     
CREATE TABLE IF NOT EXISTS TA199(                                               
   PARTIDA     CHAR(10) NOT NULL,                                               
   TIPO        CHAR(2) DEFAULT "",                                              
   PARTES      CHAR(1) DEFAULT "",                                              
   C30032006   CHAR(1) DEFAULT "",                                              
   PARTIDA_AN  CHAR(10) DEFAULT "",                                             
   C03032006   CHAR(1) DEFAULT "",                                              
   ANEXO       CHAR(1) DEFAULT "",                                              
   CATEGORIA   CHAR(2) DEFAULT "",                                              
   CATEGORIA1  CHAR(2) DEFAULT "",                                              
   CETICOS     CHAR(1) DEFAULT "",                                              
   COLECCION   CHAR(1) DEFAULT "",                                              
   DESCRIPCIO  VARCHAR(100) DEFAULT "",                                         
   OBS_300306  VARCHAR(45) DEFAULT "",                                          
   PRIMARY KEY(PARTIDA,ANEXO));                                                       
CREATE INDEX TA199_1 ON TA199(PARTIDA);                                         
                         
/* TA200( TABLAS DE PRODUCTOS DE IMPORTACI�N PROHIBIDA )*/                      
CREATE TABLE IF NOT EXISTS TA200(                                               
   PARTIDA     CHAR(10) NOT NULL,                                               
   TEXTO       VARCHAR(65) DEFAULT "",                                          
   TEXTO1      VARCHAR(68) DEFAULT "",                                          
   TPROD       CHAR(2) DEFAULT "",                                              
   PARTIDA_AN  CHAR(10) DEFAULT "",                                             
   PRIMARY KEY(PARTIDA,TEXTO,TPROD));                                                       
CREATE INDEX TA200_1 ON TA200(PARTIDA);                                         
   
/* TA201( TABLAS DE DENOMINACI�N DE CALZADO )*/                                 
CREATE TABLE IF NOT EXISTS TA201(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPC    VARCHAR(50) DEFAULT "",                                          
   NENVIO      CHAR(3) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA201_1 ON TA201(CODIGO);                                          
CREATE INDEX TA201_2 ON TA201(DESCRIPC);                                        
                                                                                
/* TA202( TABLAS DE MATERIAS DE PARTE SUPERIOR DE CALZADO )*/                   
CREATE TABLE IF NOT EXISTS TA202(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPC    VARCHAR(45) DEFAULT "",                                          
   NENVIO      CHAR(3) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                    
CREATE INDEX TA202_1 ON TA202(CODIGO);                                          
CREATE INDEX TA202_2 ON TA202(DESCRIPC);                                        
                                                                                
/* TA203( TABLAS DE ORIGEN DE CUERO DE CALZADO )*/                              
CREATE TABLE IF NOT EXISTS TA203(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPC    VARCHAR(40) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA203_1 ON TA203(CODIGO);                                          
CREATE INDEX TA203_2 ON TA203(DESCRIPC);                                        
                                                                                
/* TA204( TABLAS DE PARTE SUP.EN ACABADO DE CUERO DE CALZAD )*/                 
CREATE TABLE IF NOT EXISTS TA204(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPC    VARCHAR(30) DEFAULT "",                                          
   NENVIO      CHAR(3) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA204_1 ON TA204(CODIGO);                                          
CREATE INDEX TA204_2 ON TA204(DESCRIPC);                                        
                                                                                
/* TA205( TABLAS DE PARTE SUP.ORIGEN SINTETICO,PLASTICO )*/                     
CREATE TABLE IF NOT EXISTS TA205(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPC    VARCHAR(40) DEFAULT "",                                      
   NENVIO      CHAR(3) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA205_1 ON TA205(CODIGO);                                          
CREATE INDEX TA205_2 ON TA205(DESCRIPC);                                        
                                                                                
/* TA206( TABLAS DE TIPOS DE TEJIDO EN PARTE SUP.DE CALZADO )*/                 
CREATE TABLE IF NOT EXISTS TA206(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPC    VARCHAR(40) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA206_1 ON TA206(CODIGO);                                          
CREATE INDEX TA206_2 ON TA206(DESCRIPC);                                        
                                                                                
/* TA207( TABLAS DE COMPOSICI�N DE SUELA DE CALZADO )*/                         
CREATE TABLE IF NOT EXISTS TA207(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPC    VARCHAR(45) DEFAULT "",                                          
   NENVIO      CHAR(3) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA207_1 ON TA207(CODIGO);                                          
CREATE INDEX TA207_2 ON TA207(DESCRIPC);                                        
                                                                                
/* TA208( TABLAS DE COMPOSICI�N DEL FORRO DE CALZADO )*/                        
CREATE TABLE IF NOT EXISTS TA208(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPC    VARCHAR(46) DEFAULT "",                    
   NENVIO      CHAR(3) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA208_1 ON TA208(CODIGO);                                          
CREATE INDEX TA208_2 ON TA208(DESCRIPC);                                        
                                                                                
/* TA209( TABLAS DE USUARIOS DEL CALZADO )*/                                    
CREATE TABLE IF NOT EXISTS TA209(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPC    VARCHAR(30) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA209_1 ON TA209(CODIGO);                                          
CREATE INDEX TA209_2 ON TA209(DESCRIPC);                                        
                                                                                
/* TA210( TABLAS DE NOMBRE COMERCIAL DE PARTES DE CIERRES )*/                   
CREATE TABLE IF NOT EXISTS TA210(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPC    VARCHAR(30) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA210_1 ON TA210(CODIGO);                                          
CREATE INDEX TA210_2 ON TA210(DESCRIPC);                                        
                                                                                
/* TA211( TABLAS DE COMPOSICION DE LA CINTA )*/                                 
CREATE TABLE IF NOT EXISTS TA211(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPC    VARCHAR(30) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA211_1 ON TA211(CODIGO);                                          
CREATE INDEX TA211_2 ON TA211(DESCRIPC);                                        
                                                                                
/* TA212( TABLAS DE MATERIAL DE DIENTE DE CREMALLERA Y LLAV )*/                 
CREATE TABLE IF NOT EXISTS TA212(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPC    VARCHAR(30) DEFAULT "",                                          
   NENVIO      CHAR(3) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA212_1 ON TA212(CODIGO);                                          
CREATE INDEX TA212_2 ON TA212(DESCRIPC);                                        
                                                                                
/* TA213( TABLAS DE TIPO DE LLAVE )*/                                           
CREATE TABLE IF NOT EXISTS TA213(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPC    VARCHAR(30) DEFAULT "",                                          
   NENVIO      CHAR(3) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA213_1 ON TA213(CODIGO);                                          
CREATE INDEX TA213_2 ON TA213(DESCRIPC);                                        
                                                                                
/* TA214( TABLAS DE TIPO DE CIERRE )*/                                          
CREATE TABLE IF NOT EXISTS TA214(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPC    VARCHAR(30) DEFAULT "",                                          
   NENVIO      CHAR(3) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA214_1 ON TA214(CODIGO);                                          
CREATE INDEX TA214_2 ON TA214(DESCRIPC);                                        
                                                                                
/* TA215( TABLAS DE PRESENTACI�N DE LA CINTA )*/                                
CREATE TABLE IF NOT EXISTS TA215(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPC    VARCHAR(30) DEFAULT "",                                          
   NENVIO      CHAR(3) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA215_1 ON TA215(CODIGO);                                          
CREATE INDEX TA215_2 ON TA215(DESCRIPC);                                        
                                                                              
/* TA218( TABLAS DE CONDICI�N DE LA CARGA (DUIM) )*/                            
CREATE TABLE IF NOT EXISTS TA218(                                               
   CODIGO      CHAR(4) NOT NULL,                                                
   DESCRI      VARCHAR(50) DEFAULT "",                                          
   FECHAINI    DATE,
   FECHAFIN    DATE,
   ESTADO      CHAR(10) NOT NULL,
   PRIMARY KEY(CODIGO),
   CONSTRAINT UQ_TA218_1 UNIQUE(DESCRI));
CREATE INDEX TA218_1 ON TA218(CODIGO);                                          
CREATE INDEX TA218_2 ON TA218(DESCRI);                                                                                                                         
                                                                               
/* TA219( TABLAS DE CONDICI�N DE LA CARGA (DUIM) )*/                            
CREATE TABLE IF NOT EXISTS TA219(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIP     VARCHAR(30) DEFAULT "",                                          
   TIPO        CHAR(1) NOT NULL,
   PRIMARY KEY(CODIGO,TIPO));                                                        
CREATE INDEX TA219_1 ON TA219(CODIGO);                                          
CREATE INDEX TA219_2 ON TA219(DESCRIP);                                         
                                                                                
/* TA220( TABLAS DE TIPO DE CARGA (DUIM) )*/                                    
CREATE TABLE IF NOT EXISTS TA220(                                               
   CODIGO      CHAR(1) NOT NULL,                                                
   DESCRIP     VARCHAR(20) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA220_1 ON TA220(CODIGO);                                          
CREATE INDEX TA220_2 ON TA220(DESCRIP);                                         
                                                                                
/* TA221( TABLAS DE NOMBRE COMERCIAL (LENTES,MONTURAS,GAFAS )*/                 
CREATE TABLE IF NOT EXISTS TA221(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPC    VARCHAR(30) DEFAULT "",                                          
   PARTIDA     CHAR(10) NOT NULL,  
   PARTIDA_AN  CHAR(10) DEFAULT "",
   PRIMARY KEY(CODIGO,PARTIDA));                                                        
CREATE INDEX TA221_1 ON TA221(CODIGO);                                          
CREATE INDEX TA221_2 ON TA221(DESCRIPC);                                        
CREATE INDEX TA221_3 ON TA221(PARTIDA);                                         
                             
/* TA222( TABLAS DE MATERIAL (LENTES,MONTURAS,GAFAS) )*/                        
CREATE TABLE IF NOT EXISTS TA222(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPC    VARCHAR(40) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA222_1 ON TA222(CODIGO);                                          
CREATE INDEX TA222_2 ON TA222(DESCRIPC);                                        
                                                                                
/* TA223( TABLAS DE NUMERO DE FOCOS (LENTES,MONTURAS,GAFAS) )*/                 
CREATE TABLE IF NOT EXISTS TA223(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPC    VARCHAR(40) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA223_1 ON TA223(CODIGO);                                          
CREATE INDEX TA223_2 ON TA223(DESCRIPC);                                        
                                                                                
/* TA224( TABLAS DE COLOR ANTEOJOS (LENTES,MONTURAS,GAFAS) )*/                  
CREATE TABLE IF NOT EXISTS TA224(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPC    VARCHAR(30) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA224_1 ON TA224(CODIGO);                                          
CREATE INDEX TA224_2 ON TA224(DESCRIPC);                                        
                                                                                
/* TA225( TABLAS DE ACABADO (LENTES,MONTURAS,GAFAS) )*/                         
CREATE TABLE IF NOT EXISTS TA225(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPC    VARCHAR(40) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA225_1 ON TA225(CODIGO);                                          
CREATE INDEX TA225_2 ON TA225(DESCRIPC);                                        
                                                                                
/* TA226( TABLAS DE TIPO DE LENTES DE CONTACTO )*/                              
CREATE TABLE IF NOT EXISTS TA226(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPC    VARCHAR(30) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA226_1 ON TA226(CODIGO);                                          
CREATE INDEX TA226_2 ON TA226(DESCRIPC);                                        
                                                                                
/* TA227( TABLAS DE SERIES DE MEDIDA )*/                                        
CREATE TABLE IF NOT EXISTS TA227(                                               
   CODIGO      CHAR(2) NOT NULL,                                                
   DESCRIPC    VARCHAR(30) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA227_1 ON TA227(CODIGO);                                          
CREATE INDEX TA227_2 ON TA227(DESCRIPC);                                        
                                                                                
/* TA228( TABLAS DE USO DE LENTES DE CONTACTO BLANDOS )*/                       
CREATE TABLE IF NOT EXISTS TA228(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPC    VARCHAR(30) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA228_1 ON TA228(CODIGO);                                          
CREATE INDEX TA228_2 ON TA228(DESCRIPC);                                        
                                                                                
/* TA229( TABLAS DE TIPO DE LENTES MONOFOCALES )*/                              
CREATE TABLE IF NOT EXISTS TA229(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPC    VARCHAR(30) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA229_1 ON TA229(CODIGO);                                          
CREATE INDEX TA229_2 ON TA229(DESCRIPC);                                        
                                                                                
/* TA230( TABLAS DE TRATAMIENTO DE LENTES CORRECTORES )*/                       
CREATE TABLE IF NOT EXISTS TA230(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPC    VARCHAR(45) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA230_1 ON TA230(CODIGO);                                          
CREATE INDEX TA230_2 ON TA230(DESCRIPC);                                        
                                                                                
/* TA231( TABLAS DE AGENCIAS DE CARGA PARA LA DUIM )*/                          
CREATE TABLE IF NOT EXISTS TA231(                                               
   CODIGO      CHAR(4) NOT NULL,                                                
   DESCRIPC    VARCHAR(60) DEFAULT "",                                          
   ADUANA      VARCHAR(19) DEFAULT "",                                          
   ESTADO      CHAR(10) DEFAULT "",                                             
   CLAVE       CHAR(4) DEFAULT "",                                              
   PRIMARY KEY(CODIGO,ADUANA));                                                        
CREATE INDEX TA231_1 ON TA231(CODIGO);                                          
CREATE INDEX TA231_2 ON TA231(DESCRIPC);                                        

/* TA232( TABLAS DE PARTIDAS CON AD-VALOREM ADICIONAL )*/                       
CREATE TABLE IF NOT EXISTS TA232(                                               
   PARTIDA     CHAR(10) NOT NULL,                                               
   PAIS        CHAR(2) NOT NULL,                                                
   FCH_EMBARQ  DATE,                                                            
   HASTA       DATE,                                                            
   FCH_PUBLIC  DATE,                                                            
   TASA        NUMERIC(2,0) DEFAULT 0,                                          
   TM          CHAR(1) DEFAULT "",                                              
   DESCRIPC    VARCHAR(75) DEFAULT "",                                          
   DESCRIPC1   VARCHAR(75) DEFAULT "",                                          
   DESCRIPC2   VARCHAR(75) DEFAULT "",                                          
   PARTIDA_AN  CHAR(10) DEFAULT "",                                             
   PRIMARY KEY(PARTIDA,PAIS,TM));                                                  
CREATE INDEX TA232_1 ON TA232(PARTIDA,PAIS);                                    

/* TA233( TABLAS DE COMPONENTES (PLASTICOS) )*/                                 
CREATE TABLE IF NOT EXISTS TA233(                                               
   CODIGO      CHAR(2) NOT NULL,                                                
   DESCRIPC    VARCHAR(29) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA233_1 ON TA233(CODIGO);                                          
CREATE INDEX TA233_2 ON TA233(DESCRIPC);                                        
                                                                                
/* TA234( TABLAS DE GRADO DE ELABORACI�N DEL PLASTICO )*/                       
CREATE TABLE IF NOT EXISTS TA234(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPC    VARCHAR(29) DEFAULT "",                                          
   NENVIO      CHAR(3) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA234_1 ON TA234(CODIGO);                                          
CREATE INDEX TA234_2 ON TA234(DESCRIPC);                                        
   
/* TA235( TABLAS DE TIPO DE SOPORTE (PLASTICOS) )*/                             
CREATE TABLE IF NOT EXISTS TA235(                                               
   CODIGO      CHAR(2) NOT NULL,                                                
   DESCRIPC    VARCHAR(29) DEFAULT "",                                          
   NENVIO      CHAR(3) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA235_1 ON TA235(CODIGO);                                          
CREATE INDEX TA235_2 ON TA235(DESCRIPC);                                        
                                                                                
/* TA236( TABLAS DE COMP.TEJIDO Y NO TEJIDO (PLASTICOS) )*/                     
CREATE TABLE IF NOT EXISTS TA236(                                               
   CODIGO      CHAR(2) NOT NULL,                                                
   DESCRIPC    VARCHAR(29) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA236_1 ON TA236(CODIGO);                                          
CREATE INDEX TA236_2 ON TA236(DESCRIPC);                                        
                                                                                
/* TA237( TABLAS DE GRADO ELABORACION DEL SOPORTE (PLASTICO) )*/                
CREATE TABLE IF NOT EXISTS TA237(                                               
   CODIGO      CHAR(2) NOT NULL,                                                
   DESCRIPC    VARCHAR(29) DEFAULT "",                                          
   NENVIO      CHAR(3) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA237_1 ON TA237(CODIGO);                                          
CREATE INDEX TA237_2 ON TA237(DESCRIPC);                                        
                                                                                
/* TA238( TABLAS DE ACABADO (PLASTICOS) )*/                                     
CREATE TABLE IF NOT EXISTS TA238(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPC    VARCHAR(29) DEFAULT "",                                          
   NENVIO      CHAR(3) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA238_1 ON TA238(CODIGO);                                      
CREATE INDEX TA238_2 ON TA238(DESCRIPC);                                        
                                                                                
/* TA239( TABLAS DE COLORES (PLASTICOS) )*/                                     
CREATE TABLE IF NOT EXISTS TA239(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPC    VARCHAR(20) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA239_1 ON TA239(CODIGO);                                          
CREATE INDEX TA239_2 ON TA239(DESCRIPC);                                        
                                                                                
/* TA240( TABLAS DE CALIDAD (PLASTICOS) )*/                                     
CREATE TABLE IF NOT EXISTS TA240(                                               
   CODIGO      CHAR(2) NOT NULL,                                                
   DESCRIPC    VARCHAR(29) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA240_1 ON TA240(CODIGO);                                          
CREATE INDEX TA240_2 ON TA240(DESCRIPC);                                        
                                                                                
/* TA241( TABLAS DE USO COMERCIAL (NEUMATICOS) )*/                              
CREATE TABLE IF NOT EXISTS TA241(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPC    VARCHAR(65) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA241_1 ON TA241(CODIGO);                                          
CREATE INDEX TA241_2 ON TA241(DESCRIPC);                                        
                                                                                
/* TA242( TABLAS DE MATERIAL DE CARCASA (NEUMATICOS) )*/                        
CREATE TABLE IF NOT EXISTS TA242(                                               
   CODIGO      CHAR(2) NOT NULL,                                                
   DESCRIPC    CHAR(10) DEFAULT "",                                             
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA242_1 ON TA242(CODIGO);                                          
CREATE INDEX TA242_2 ON TA242(DESCRIPC);                                        
                                                                                
/* TA243( TABLAS DE TIPO DE NOMENCLATURA (NEUMATICOS) )*/                       
CREATE TABLE IF NOT EXISTS TA243(                                               
   CODIGO      CHAR(2) NOT NULL,                                                
   DESCRIPC    VARCHAR(12) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA243_1 ON TA243(CODIGO);                                          
CREATE INDEX TA243_2 ON TA243(DESCRIPC);                                        
                                                                                
/* TA244( TABLAS DE TIPO DE CONSTRUCCION (NEUMATICOS) )*/                       
CREATE TABLE IF NOT EXISTS TA244(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPC    VARCHAR(23) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA244_1 ON TA244(CODIGO);                                          
CREATE INDEX TA244_2 ON TA244(DESCRIPC);                                        
                                                                            
/* TA245( TABLAS DE INDICE DE CARGA X LLANTA )*/                                
CREATE TABLE IF NOT EXISTS TA245(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   CARGA       VARCHAR(20) DEFAULT "",                                          
   NENVIO      CHAR(3) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA245_1 ON TA245(CODIGO);                                          
CREATE INDEX TA245_2 ON TA245(CARGA);                                           
                                                                               
/* TA246( TABLAS DE CODIGO DE LIMITE DE VELOCIDAD )*/                           
CREATE TABLE IF NOT EXISTS TA246(                                               
   CODIGO      CHAR(1) NOT NULL,                                                
   LIMITE      VARCHAR(11) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA246_1 ON TA246(CODIGO);                                          
CREATE INDEX TA246_2 ON TA246(LIMITE);                                          
                                                                                
/* TA247( TABLAS DE CODIGO DE EXONERACION DEL VIN )*/                           
CREATE TABLE IF NOT EXISTS TA247(                                               
   CODIGO      CHAR(2) NOT NULL,                                                
   DESCRIPC1   VARCHAR(60) DEFAULT "",                                          
   DESCRIPC2   VARCHAR(60) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA247_1 ON TA247(CODIGO);                                          
CREATE INDEX TA247_2 ON TA247(DESCRIPC1);                                       
                                                                                
/* TA249( TABLAS DE ANTID. CALZADO DE INDONESIA - PAYLESS )*/                   
CREATE TABLE IF NOT EXISTS TA249(                                               
   PAIS        CHAR(2) NOT NULL,                                                
   PARTIDA     CHAR(10) NOT NULL,                                               
   MINIMO      DECIMAL(10,3) DEFAULT 0.000,                                     
   MAXIMO      DECIMAL(10,3) DEFAULT 0.000,                                     
   ANTI        DECIMAL(10,2) DEFAULT 0.00,                                      
   CPROD       CHAR(2) NOT NULL,                                                
   TEXTO       CHAR(3) DEFAULT "",                                              
   PARTIDA_AN  CHAR(10) DEFAULT "",                                             
   PRIMARY KEY(PAIS,CPROD,PARTIDA));                                            
CREATE INDEX TA249_1 ON TA249(PAIS,CPROD,PARTIDA);                              
CREATE INDEX TA249_2 ON TA249(PAIS,PARTIDA);                                    
                                                                                
/* TA250( TABLAS DE PARTIDAS DEL SGPC )*/                                       
CREATE TABLE IF NOT EXISTS TA250(                                               
   PARTIDA     CHAR(10) NOT NULL,                                               
   MARGEN      DECIMAL(5,2) DEFAULT 0.00,                                       
   PARTIDA_AN  CHAR(10) DEFAULT "",                                             
   PRIMARY KEY(PARTIDA));                                                       
CREATE INDEX TA250_1 ON TA250(PARTIDA);                                         
                                                                                
/* TA251( TABLAS DE PAISES DEL SGPC )*/                                         
CREATE TABLE IF NOT EXISTS TA251(                                               
   CODIGO      CHAR(2) NOT NULL,                                                
   DESCRI      VARCHAR(55) DEFAULT "",                                          
   DESCRI1     VARCHAR(50) DEFAULT "",                                          
   ANTIGUO     CHAR(3) DEFAULT "",                                              
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA251_1 ON TA251(CODIGO);                                          
                                                                                
/* TA255( TABLAS DE PARTIDAS EXCLUIDAS EXONERACION IGV )*/                      
CREATE TABLE IF NOT EXISTS TA255(                                               
   PAB         CHAR(10) NOT NULL,                                               
   PARTIDA_AN  CHAR(10) DEFAULT "",                                             
   PRIMARY KEY(PAB));                                                           
CREATE INDEX TA255_1 ON TA255(PAB);                                             
                                                                                
/* TA256( TABLAS DE PORCENTAJES DE PERCEPCION DE IGV )*/                        
CREATE TABLE IF NOT EXISTS TA256(                                               
   COD         CHAR(1) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(25) DEFAULT "",                                          
   PORCENTAJE  DECIMAL(5,2) DEFAULT 0.00,                                       
   PRIMARY KEY(COD));                                                           
CREATE INDEX TA256_1 ON TA256(COD);                                             
                                                                                
/* TA257( TABLAS DE CLASIFICACI�N DE VEHICULOS )*/                              
CREATE TABLE IF NOT EXISTS TA257(                                               
   CODIGO      CHAR(4) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(70) DEFAULT "",                                          
   DESCRIPC2   VARCHAR(70) DEFAULT "",                                          
   DESCRIPC3   VARCHAR(70) DEFAULT "",                                          
   DESCRIPC4   VARCHAR(70) DEFAULT "",                                          
   DESCRIPC5   VARCHAR(70) DEFAULT "",                                          
   TIPO        CHAR(1) DEFAULT "",                                              
   ENC_CHISPA  DECIMAL(10,3) DEFAULT 0.000,                                     
   ENC_COMPRE  DECIMAL(10,3) DEFAULT 0.000, 
   TIPO_CATEG  CHAR(2) NOT NULL,                                      
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA257_1 ON TA257(CODIGO);                                          
CREATE INDEX TA257_2 ON TA257(DESCRIPCIO);                                      
                                                                                
/* TA259( TABLAS DE CORRELACION/MODELOS DE VEHICULOS )*/                        
CREATE TABLE IF NOT EXISTS TA259(                                               
   MODELO      CHAR(3) NOT NULL,                                                
   DES_MODELO  VARCHAR(29) DEFAULT "",                                          
   CATEGORIA   CHAR(2) NOT NULL,
   MARCA       CHAR(3) NOT NULL,
   CARROC      CHAR(3) NOT NULL,
   VERSION     CHAR(10) DEFAULT "",                                             
   FECHAINI    DATE,                                                            
   FECHAFIN    DATE,       
   PRIMARY KEY(MODELO,CATEGORIA,MARCA,CARROC),
   CONSTRAINT FK_TA259_TA257 FOREIGN KEY(CATEGORIA) REFERENCES TA257(CODIGO),
   CONSTRAINT FK_TA259_TA734 FOREIGN KEY(MARCA) REFERENCES TA734(CODIGO),
   CONSTRAINT FK_TA259_TA735 FOREIGN KEY(CARROC) REFERENCES TA735(CODIGO));                                                        
CREATE INDEX TA259_1 ON TA259(MODELO);                                          
CREATE INDEX TA259_2 ON TA259(DES_MODELO);                                      
CREATE INDEX TA259_3 ON TA259(MARCA,CATEGORIA);                                 
CREATE INDEX TA259_4 ON TA259(CARROC,MODELO);                                   

/* TA261( TABLAS DE SALVAGUARDA PARA PRODUCTOS DE CHINA )*/                     
CREATE TABLE IF NOT EXISTS TA261(                                               
   PARTIDA     CHAR(10) NOT NULL,                                               
   TASA        DECIMAL(5,2) DEFAULT 0.00,                                       
   PARTIDA_AN  CHAR(10) DEFAULT "",                                             
   PRIMARY KEY(PARTIDA));                                                       
CREATE INDEX TA261_1 ON TA261(PARTIDA);                                         

/* TA262( TABLAS DE TIPO DE ENVIO A ADUANAS )*/                                 
CREATE TABLE IF NOT EXISTS TA262(                                               
   CODIGO      CHAR(1) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(45) DEFAULT "",                                          
   NSIGAD      CHAR(2) DEFAULT "",                                              
   TIPO        CHAR(1) DEFAULT "",	
   PRIMARY KEY(CODIGO,TIPO));                                                        
CREATE INDEX TA262_1 ON TA262(CODIGO);                                          
CREATE INDEX TA262_2 ON TA262(DESCRIPCIO);                                      
                                                                                
/* TA263( TABLAS DE SOLICITUD DE AFORO )*/                                      
CREATE TABLE IF NOT EXISTS TA263(                                               
   CODIGO      CHAR(1) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(50) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA263_1 ON TA263(CODIGO);                                          
CREATE INDEX TA263_2 ON TA263(DESCRIPCIO);                                      
                                                                                
/* TA264( TABLAS DE INDICADOR DE PAGO ELECTRONICO )*/                           
CREATE TABLE IF NOT EXISTS TA264(                                               
   CODIGO      CHAR(1) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(50) DEFAULT "",                                          
   REGIMEN     CHAR(2) DEFAULT "",                                          
   PRIMARY KEY(CODIGO,REGIMEN));                                                        
CREATE INDEX TA264_1 ON TA264(CODIGO);                                          
CREATE INDEX TA264_2 ON TA264(DESCRIPCIO);                                      

/* TA265( TABLAS DE TIPO DE PLAZO )*/                                           
CREATE TABLE IF NOT EXISTS TA265(                                               
   CODIGO      CHAR(1) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(15) DEFAULT "",                                          
   TIPO        CHAR(1)  NOT NULL,                                                
   PRIMARY KEY(CODIGO,TIPO));                                                        
CREATE INDEX TA265_1 ON TA265(CODIGO);                                          
CREATE INDEX TA265_2 ON TA265(DESCRIPCIO);                                      
                                      
/* TA266( TABLAS DE ZONA FRANCA )*/                                             
CREATE TABLE IF NOT EXISTS TA266(                                               
   CODIGO      CHAR(1) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(35) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA266_1 ON TA266(CODIGO);                                          
CREATE INDEX TA266_2 ON TA266(DESCRIPCIO);                                      
                                                                                
/* TA267( TABLAS DE FORMA DE ENVIO (FORMATO B) )*/                              
CREATE TABLE IF NOT EXISTS TA267(                                               
   CODIGO      CHAR(1) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(20) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA267_1 ON TA267(CODIGO);                                          
CREATE INDEX TA267_2 ON TA267(DESCRIPCIO);                                      
                                                                                
/* TA269( TABLAS DE DEDUCCIONES DISTINGUIDAS (FORMATO B) )*/                    
CREATE TABLE IF NOT EXISTS TA269(                                               
   CODIGO      CHAR(1) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(35) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA269_1 ON TA269(CODIGO);                                          
CREATE INDEX TA269_2 ON TA269(DESCRIPCIO);                                      
                                                                                
/* TA270( TABLAS DE TIPO DE VALOR (FORMATO B) )*/                               
CREATE TABLE IF NOT EXISTS TA270(                                               
   CODIGO      CHAR(1) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(20) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA270_1 ON TA270(CODIGO);                                          
CREATE INDEX TA270_2 ON TA270(DESCRIPCIO);                                      
                                                                                
/* TA271( TABLAS DE FACTURA POR TERCEROS ( PARA EXPORTACION) )*/                
CREATE TABLE IF NOT EXISTS TA271(                                               
   CODIGO      CHAR(2) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(60) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA271_1 ON TA271(CODIGO);                                          
CREATE INDEX TA271_2 ON TA271(DESCRIPCIO);                                      
                                                                                
/* TA272( TABLAS DE TIPO DE DESPACHO DE EXPORTACION )*/                         
CREATE TABLE IF NOT EXISTS TA272(                                               
   CODIGO      CHAR(2) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(45) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA272_1 ON TA272(CODIGO);                                          
CREATE INDEX TA272_2 ON TA272(DESCRIPCIO);                                      
                                                                                
/* TA275( TABLAS DE TIPO DE MODALIDAD SWAP )*/                                  
CREATE TABLE IF NOT EXISTS TA275(                                               
   CODIGO      CHAR(1) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(32) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA275_1 ON TA275(CODIGO);                                          
CREATE INDEX TA275_2 ON TA275(DESCRIPCIO);                                      
                                                                                
/* TA276( TABLAS DE ANEXO 1 PARA LA ORDEN DE EMBARQUE )*/                       
CREATE TABLE IF NOT EXISTS TA276(                                               
   CODIGO      CHAR(1) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(30) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA276_1 ON TA276(CODIGO);                                          
CREATE INDEX TA276_2 ON TA276(DESCRIPCIO);                                      
                                                                                
/* TA277( TABLAS DE SI TIENE O NO RANCHO DE NAVE )*/                            
CREATE TABLE IF NOT EXISTS TA277(                                               
   CODIGO      CHAR(2) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(85) DEFAULT "",                                          
   STATUS      CHAR(10) DEFAULT "",                                             
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA277_1 ON TA277(CODIGO);                                          
CREATE INDEX TA277_2 ON TA277(DESCRIPCIO);                                      
                                                                                
/* TA278( TABLAS DE TIPO DE ENVIO DE SIMPLIFICADA )*/                           
CREATE TABLE IF NOT EXISTS TA278(                                               
   CODIGO      CHAR(1) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(20) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA278_1 ON TA278(CODIGO);                                          
CREATE INDEX TA278_2 ON TA278(DESCRIPCIO);                                      
                                                                               
                                                                                
/* TA280( TABLAS DE TIPO DE REGIMEN PARA METERIAL DE GUERRA )*/                 
CREATE TABLE IF NOT EXISTS TA280(                                               
   CODIGO      CHAR(1) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(12) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA280_1 ON TA280(CODIGO);                                          
CREATE INDEX TA280_2 ON TA280(DESCRIPCIO);                                      
                                                                                
/* TA281( TABLAS DE BIENES DE MATERIAL PARA USO AERON�UTICO )*/                 
CREATE TABLE IF NOT EXISTS TA281(                                               
   CODIGO      CHAR(10) NOT NULL,                                               
   DES1        VARCHAR(65) DEFAULT "",                                          
   DES2        VARCHAR(65) DEFAULT "",                                          
   DES3        VARCHAR(65) DEFAULT "",                                          
   DES4        VARCHAR(65) DEFAULT "",                                          
   DES5        VARCHAR(65) DEFAULT "",                                          
   DES6        VARCHAR(65) DEFAULT "",                                          
   ANEXO_1_C   CHAR(10) DEFAULT "",                                             
   STATUS     CHAR(10) default '',
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA281_1 ON TA281(CODIGO);                                          
CREATE INDEX TA281_2 ON TA281(DES1);                                            
 
/* TA282( TABLAS DE TIPO DE MODALIDADNVIO PARA EL TRANSBORDO )*/                
CREATE TABLE IF NOT EXISTS TA282(                                               
    CODIGO      CHAR(2) NOT NULL,                                                
    DESCRIPCIO  VARCHAR(60) DEFAULT "",  
    XML         CHAR(2) DEFAULT "",                                 
    POSICION    CHAR(1) DEFAULT "",                                          
    PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA282_1 ON TA282(CODIGO);                                          
CREATE INDEX TA282_2 ON TA282(DESCRIPCIO);       
    
/* TA283( TABLAS DE TIPO DE EMBARQUE PARA EL TRANSBORDO )*/                     
CREATE TABLE IF NOT EXISTS TA283(                                               
   CODIGO      CHAR(1) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(20) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA283_1 ON TA283(CODIGO);                                          
CREATE INDEX TA283_2 ON TA283(DESCRIPCIO);                                      
                                                                                
/* TA284( TABLAS DE PAISES EXCLUIDOS DE LA SALVAGUARDA )*/                      
CREATE TABLE IF NOT EXISTS TA284(                                               
   CODIGO      CHAR(2) NOT NULL,                                                
   DESCRI      VARCHAR(55) DEFAULT "",                                          
   DESCRI1     VARCHAR(50) DEFAULT "",                                          
   ANTIGUO     CHAR(3) DEFAULT "",                                              
   FECHAINI    DATE,                                                            
   FECHAFIN    DATE,                                                            
   ESTADO      CHAR(10) DEFAULT "",                                             
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA284_1 ON TA284(CODIGO);                                          
CREATE INDEX TA284_2 ON TA284(DESCRI);                                          
                                                                                
/* TA285( TABLAS DE PARTIDAS EXCLUIDAS DE SALVAGUARDA X PAIS )*/                
CREATE TABLE IF NOT EXISTS TA285(                                               
   PARTIDA     CHAR(10) NOT NULL,                                               
   PAIS        CHAR(2) NOT NULL,                                                
   PARTIDA_AN  CHAR(10) DEFAULT "",                                             
   PRIMARY KEY(PARTIDA,PAIS));                                                  
CREATE INDEX TA285_1 ON TA285(PARTIDA,PAIS);                                    
                                                                                
/* TA286( TABLAS DE TIPO DE PILAS Y BATERIAS DE PILAS )*/                       
CREATE TABLE IF NOT EXISTS TA286(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRI      VARCHAR(55) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA286_1 ON TA286(CODIGO);                                          
CREATE INDEX TA286_2 ON TA286(DESCRI);                                          
                                                                                
/* TA287( TABLAS DE FORMA DE PILAS Y BATERIAS DE PILAS )*/                      
CREATE TABLE IF NOT EXISTS TA287(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRI      VARCHAR(55) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA287_1 ON TA287(CODIGO);                                          
CREATE INDEX TA287_2 ON TA287(DESCRI);                                          
                                                                                
/* TA288( TABLAS DE DIMENSIONES DE PILAS Y BATERIAS DE PILAS )*/                
CREATE TABLE IF NOT EXISTS TA288(                                               
   CODIGO      CHAR(4) NOT NULL,                                                
   DESCRI      CHAR(7) DEFAULT "",                                              
   DIAMETRO    VARCHAR(25) DEFAULT "",                                          
   NORMA_IEC   CHAR(10) DEFAULT "",                                             
   NENVIO      CHAR(3) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA288_1 ON TA288(CODIGO);                                          
CREATE INDEX TA288_2 ON TA288(DESCRI);                                          
                                                                                
/* TA289( TABLAS DE UNIDADES DE OJETES )*/                                      
CREATE TABLE IF NOT EXISTS TA289(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRI      CHAR(10) DEFAULT "",                                             
   ESTADO      CHAR(10) DEFAULT "",                                             
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA289_1 ON TA289(CODIGO);                                          
CREATE INDEX TA289_2 ON TA289(DESCRI);                                          
                                                                                
/* TA290( TABLAS DE TIPO DE ANILLOS DE OJETES )*/                               
CREATE TABLE IF NOT EXISTS TA290(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRI      VARCHAR(55) DEFAULT "", 
   NENVIO      CHAR(3) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA290_1 ON TA290(CODIGO);                                          
CREATE INDEX TA290_2 ON TA290(DESCRI);                                          
                                                                                
/* TA291( TABLAS DE MATERIALES DE FABRICACI�N DE OJETES )*/                     
CREATE TABLE IF NOT EXISTS TA291(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRI      VARCHAR(55) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA291_1 ON TA291(CODIGO);                                          
CREATE INDEX TA291_2 ON TA291(DESCRI);                                          
                                                                                
/* TA292( TABLAS DE ACABADO DE OJETES )*/                                       
CREATE TABLE IF NOT EXISTS TA292(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRI      VARCHAR(55) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA292_1 ON TA292(CODIGO);                                          
CREATE INDEX TA292_2 ON TA292(DESCRI);                                          
                                                                                
/* TA293( TABLAS DE USO AL QUE SE DESTINAN LOS OJETES )*/                       
CREATE TABLE IF NOT EXISTS TA293(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRI      VARCHAR(55) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA293_1 ON TA293(CODIGO);                                          
CREATE INDEX TA293_2 ON TA293(DESCRI);                                          
                                                                                
/* TA295( TABLAS DE PRESENTACION DE GARANTIA (RESTITUCION 13 )*/                
CREATE TABLE IF NOT EXISTS TA295(                                               
   CODIGO      CHAR(1) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(40) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA295_1 ON TA295(CODIGO);                                          
CREATE INDEX TA295_2 ON TA295(DESCRIPCIO);                                      
                                                                                
/* TA296( TABLAS DE CARTA PODER (RESTITUCION 13) )*/                            
CREATE TABLE IF NOT EXISTS TA296(                                               
   CODIGO      CHAR(1) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(40) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA296_1 ON TA296(CODIGO);                                          
CREATE INDEX TA296_2 ON TA296(DESCRIPCIO);                                      
                                                                                
/* TA297( TABLAS DE TIPO DE COMPRA (RESTITUCION 13) )*/                         
CREATE TABLE IF NOT EXISTS TA297(                                               
   CODIGO      CHAR(1) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(60) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA297_1 ON TA297(CODIGO);                                          
CREATE INDEX TA297_2 ON TA297(DESCRIPCIO);                                      
                                                                                
/* TA298( TABLAS DE CONSTRUCCION DE CALZADO )*/                                 
CREATE TABLE IF NOT EXISTS TA298(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(20) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA298_1 ON TA298(CODIGO);                                          
CREATE INDEX TA298_2 ON TA298(DESCRIPCIO);                                      
                                                                                
/* TA299( TABLAS DE MODALIDAD DEL DUTY FREE )*/                                 
CREATE TABLE IF NOT EXISTS TA299(                                               
   CODIGO      CHAR(2) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(55) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA299_1 ON TA299(CODIGO);                                          
CREATE INDEX TA299_2 ON TA299(DESCRIPCIO);                                      
                                                                                
/* TA300( TABLAS DE MODALIDAD DE TRASLADO DE DUTY FREE )*/                      
CREATE TABLE IF NOT EXISTS TA300(                                               
   CODIGO      CHAR(2) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(55) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA300_1 ON TA300(CODIGO);                                          
CREATE INDEX TA300_2 ON TA300(DESCRIPCIO);                                      
                                                                                
/* TA301( TABLAS DE TIPO DE DESTINO PARA TRANSITO )*/                           
CREATE TABLE IF NOT EXISTS TA301(                                               
   CODIGO      CHAR(1) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(20) DEFAULT "",                                          

   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA301_1 ON TA301(CODIGO);                                          
CREATE INDEX TA301_2 ON TA301(DESCRIPCIO);                                      
                                                                                
/* TA303( TABLAS DE TIPOS DE ENVIO DE MANIFIESTO )*/                            
CREATE TABLE IF NOT EXISTS TA303(                                               
   CODIGO      CHAR(1) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(70) DEFAULT "",   
   T_OPERADOR  CHAR(1) DEFAULT "",       
   FLAG_REGIM  CHAR(1) DEFAULT "",                                      
   PRIMARY KEY(CODIGO,T_OPERADOR,FLAG_REGIM));                                                        
CREATE INDEX TA303_1 ON TA303(CODIGO);                                          
CREATE INDEX TA303_2 ON TA303(DESCRIPCIO);                                      
              
/* TA307( TABLAS DE INDICARDOR DE VARIACION DE MANIFIESTO )*/                   
CREATE TABLE IF NOT EXISTS TA307(                                               
   CODIGO      NUMERIC(1,0) NOT NULL,                                           
   DESCRIPCIO  VARCHAR(25) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA307_1 ON TA307(CODIGO);                                          
CREATE INDEX TA307_2 ON TA307(DESCRIPCIO);                                      
                                                                                
/* TA308( TABLAS DE ESTADO DEL MANIFIESTO )*/                                   
CREATE TABLE IF NOT EXISTS TA308(                                               
   CODIGO      CHAR(1) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(15) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA308_1 ON TA308(CODIGO);                                          
CREATE INDEX TA308_2 ON TA308(DESCRIPCIO);                                      
                                                                                
/* TA309( TABLAS DE TIPO DE INFORMACION DEL MANIFIESTO )*/                      
CREATE TABLE IF NOT EXISTS TA309(                                               
   CODIGO      CHAR(2) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(15) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA309_1 ON TA309(CODIGO);                                          
CREATE INDEX TA309_2 ON TA309(DESCRIPCIO);                                      
                                                                                
/* TA311( TABLAS DE TIPO DE ACTA DE INVENTARIO )*/                              
CREATE TABLE IF NOT EXISTS TA311(                                               
   CODIGO      CHAR(1) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(30) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA311_1 ON TA311(CODIGO);                                          
CREATE INDEX TA311_2 ON TA311(DESCRIPCIO);                                      
                                                                                
/* TA312( TABLAS DE TIPO DE PRECINTO VIOLENTADO )*/                             
CREATE TABLE IF NOT EXISTS TA312(                                               
   CODIGO      CHAR(1) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(16) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA312_1 ON TA312(CODIGO);                                          
CREATE INDEX TA312_2 ON TA312(DESCRIPCIO);                                      
                                                                                
/* TA315( TABLAS DE TIPOS DE PRODUCTOS A NACIONALIZAR (20,21 )*/                
CREATE TABLE IF NOT EXISTS TA315(                                               
   COD         CHAR(1) NOT NULL,                                                
   DESCRIP     VARCHAR(15) DEFAULT "",                                          
   PRIMARY KEY(COD));                                                           
CREATE INDEX TA315_1 ON TA315(COD);                                             
CREATE INDEX TA315_2 ON TA315(DESCRIP);                                         
                                                                              
/* TA318( TABLAS DE PARTIDAS CON ROTULADOS )*/                                  
CREATE TABLE IF NOT EXISTS TA318(                                               
   PARTIDA     CHAR(10) NOT NULL,                                               
   DES1        VARCHAR(80) DEFAULT "",                                          
   DES2        VARCHAR(80) DEFAULT "",                                          
   DES3        VARCHAR(80) DEFAULT "",                                          
   EXPLIC1     VARCHAR(80) DEFAULT "",                                          
   EXPLIC2     VARCHAR(80) DEFAULT "",                                          
   EXPLIC3     VARCHAR(80) DEFAULT "",                                          
   EXPLIC4     CHAR(10) DEFAULT "",                                             
   PARTIDA_AN  CHAR(10) DEFAULT "",                                             
   PRIMARY KEY(PARTIDA,DES1));                                                       
CREATE INDEX TA318_1 ON TA318(PARTIDA);                                         
                           
/* TA319( TABLAS DE CODIFICACI�N DE COMPUTADORAS, COMPONENTE )*/                
CREATE TABLE IF NOT EXISTS TA319(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(55) DEFAULT "",                                          
   PARTIDA     CHAR(10) NOT NULL,                                                
   PARTIDA_AN  CHAR(10) DEFAULT "",                                             
   TIPO_COD    CHAR(3) DEFAULT "",                                              
   PRIMARY KEY(CODIGO,PARTIDA));                                                        
CREATE INDEX TA319_1 ON TA319(CODIGO);                                          
CREATE INDEX TA319_2 ON TA319(DESCRIPCIO);                                      
CREATE INDEX TA319_3 ON TA319(PARTIDA);                                         
                                                         
/* TA320( TABLAS DE MARCA COMERCIAL DE COMPUTADORAS )*/                         
CREATE TABLE IF NOT EXISTS TA320(                                               
   CODIGO      CHAR(4) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(20) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA320_1 ON TA320(CODIGO);                                          
CREATE INDEX TA320_2 ON TA320(DESCRIPCIO);                                      
                                                                                
/* TA321( TABLAS DE TIPOS DE COMPUTADORAS )*/                                   
CREATE TABLE IF NOT EXISTS TA321(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(27) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA321_1 ON TA321(CODIGO);                                          
CREATE INDEX TA321_2 ON TA321(DESCRIPCIO);                                      
                                                                                
/* TA322( TABLAS DE TIPOS DE PROCESADOR )*/                                     
CREATE TABLE IF NOT EXISTS TA322(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(15) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA322_1 ON TA322(CODIGO);                                          
CREATE INDEX TA322_2 ON TA322(DESCRIPCIO);                                      
                                                                                
/* TA323( TABLAS DE VELOCIDAD DEL PROCESADOR )*/                                
CREATE TABLE IF NOT EXISTS TA323(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(20) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA323_1 ON TA323(CODIGO);                                          
CREATE INDEX TA323_2 ON TA323(DESCRIPCIO);                                      
                                                                                
/* TA324( TABLAS DE TIPO DE MEMORIA )*/                                         
CREATE TABLE IF NOT EXISTS TA324(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(17) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA324_1 ON TA324(CODIGO);                                          
CREATE INDEX TA324_2 ON TA324(DESCRIPCIO);                                      
                                                                                
/* TA325( TABLAS DE TIPO DE MEMORIA RAM )*/                                     
CREATE TABLE IF NOT EXISTS TA325(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(45) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA325_1 ON TA325(CODIGO);                                          
CREATE INDEX TA325_2 ON TA325(DESCRIPCIO);                                      
                                                                                
/* TA326( TABLAS DE MODULO DE MEMORIA )*/                                       
CREATE TABLE IF NOT EXISTS TA326(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(35) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA326_1 ON TA326(CODIGO);                                          
CREATE INDEX TA326_2 ON TA326(DESCRIPCIO);                                      
                                                                                
/* TA327( TABLAS DE VELOCIDAD DE BUS )*/                                        
CREATE TABLE IF NOT EXISTS TA327(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(17) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA327_1 ON TA327(CODIGO);                                          
CREATE INDEX TA327_2 ON TA327(DESCRIPCIO);                                      
                                                                                
/* TA328( TABLAS DE CAPACIDAD DE MEMORIA / DISQUETERA )*/                       
CREATE TABLE IF NOT EXISTS TA328(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(14) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA328_1 ON TA328(CODIGO);                                          
CREATE INDEX TA328_2 ON TA328(DESCRIPCIO);                                      
                                                                                
/* TA329( TABLAS DE TIPOS DE IMPRESORA )*/                                      
CREATE TABLE IF NOT EXISTS TA329(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(18) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA329_1 ON TA329(CODIGO);                                          
CREATE INDEX TA329_2 ON TA329(DESCRIPCIO);                                      
                                                                                
/* TA330( TABLAS DE VELOCIDAD DE IMPRESI�N )*/                                  
CREATE TABLE IF NOT EXISTS TA330(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(16) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA330_1 ON TA330(CODIGO);                                          
CREATE INDEX TA330_2 ON TA330(DESCRIPCIO);                                      
                                                                                
/* TA331( TABLAS DE PINES DE IMPRESORA MATRICIAL )*/                            
CREATE TABLE IF NOT EXISTS TA331(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(20) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA331_1 ON TA331(CODIGO);                                          
CREATE INDEX TA331_2 ON TA331(DESCRIPCIO);                                      
                                                                                
/* TA332( TABLAS DE COLUMNAS DE IMPRESI�N )*/                                   
CREATE TABLE IF NOT EXISTS TA332(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(22) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA332_1 ON TA332(CODIGO);                                          
CREATE INDEX TA332_2 ON TA332(DESCRIPCIO);                                      
                                                                                
/* TA333( TABLAS DE VELOCIDAD DE IMPRESI�N )*/                                  
CREATE TABLE IF NOT EXISTS TA333(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(17) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA333_1 ON TA333(CODIGO);                                          
CREATE INDEX TA333_2 ON TA333(DESCRIPCIO);                                      
                                                                                
/* TA334( TABLAS DE COLOR DEL MONITOR )*/                                       
CREATE TABLE IF NOT EXISTS TA334(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(27) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA334_1 ON TA334(CODIGO);                                          
CREATE INDEX TA334_2 ON TA334(DESCRIPCIO);                                      
                                                                                
/* TA335( TABLAS DE TIPO DE MONITOR )*/                                         
CREATE TABLE IF NOT EXISTS TA335(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(38) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA335_1 ON TA335(CODIGO);                                          
CREATE INDEX TA335_2 ON TA335(DESCRIPCIO);                                      
                                                                                
/* TA336( TABLAS DE TAMA�O DEL MONITOR O PANTALLA )*/                           
CREATE TABLE IF NOT EXISTS TA336(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(16) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA336_1 ON TA336(CODIGO);                                          
CREATE INDEX TA336_2 ON TA336(DESCRIPCIO);                                      
                                                                                
/* TA337( TABLAS DE TAMA�O POR PUNTO )*/                                        
CREATE TABLE IF NOT EXISTS TA337(                                               
   CODIGO      CHAR(4) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(17) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA337_1 ON TA337(CODIGO);                                          
CREATE INDEX TA337_2 ON TA337(DESCRIPCIO);                                      
                                                                                
/* TA338( TABLAS DE TIPO DE CONEXI�N DEL MOUSE )*/                              
CREATE TABLE IF NOT EXISTS TA338(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(11) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA338_1 ON TA338(CODIGO);                                          
CREATE INDEX TA338_2 ON TA338(DESCRIPCIO);                                      
                                                                                
/* TA339( TABLAS DE RESOLUCI�N DE IMPRESORAS )*/                                
CREATE TABLE IF NOT EXISTS TA339(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(20) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA339_1 ON TA339(CODIGO);                                          
CREATE INDEX TA339_2 ON TA339(DESCRIPCIO);                                      
                                                                                
/* TA340( TABLAS DE PROFUNDIDAD DEL COLOR )*/                                   
CREATE TABLE IF NOT EXISTS TA340(                                               
   CODIGO      CHAR(5) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(18) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA340_1 ON TA340(CODIGO);                                          
CREATE INDEX TA340_2 ON TA340(DESCRIPCIO);                                      
                                                                                
/* TA341( TABLAS DE TIPO DE INTERFASE GRABADOR / LECTORAS... )*/                
CREATE TABLE IF NOT EXISTS TA341(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(38) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA341_1 ON TA341(CODIGO);                                          
CREATE INDEX TA341_2 ON TA341(DESCRIPCIO);                                      
                                                                                
/* TA342( TABLAS DE CAPACIDAD DEL DISCO DURO )*/                                
CREATE TABLE IF NOT EXISTS TA342(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(17) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA342_1 ON TA342(CODIGO);                                          
CREATE INDEX TA342_2 ON TA342(DESCRIPCIO);                                      
                                                                                
/* TA343( TABLAS DE VELOCIDAD DE ROTACI�N DEL DISCO DURO )*/                    
CREATE TABLE IF NOT EXISTS TA343(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(11) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA343_1 ON TA343(CODIGO);                                          
CREATE INDEX TA343_2 ON TA343(DESCRIPCIO);                                      
                                                                                
/* TA344( TABLAS DE TIPO DE TARJETA DE VIDEO Y DE RED )*/                       
CREATE TABLE IF NOT EXISTS TA344(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(64) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA344_1 ON TA344(CODIGO);                                          
CREATE INDEX TA344_2 ON TA344(DESCRIPCIO);                                      
                                                                                
/* TA345( TABLAS DE VELOCIDAD DE LECTURA/GRABACI�N... )*/                       
CREATE TABLE IF NOT EXISTS TA345(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  CHAR(7) DEFAULT "",                                              
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA345_1 ON TA345(CODIGO);                                          
CREATE INDEX TA345_2 ON TA345(DESCRIPCIO);                                      
                                                                                
/* TA346( TABLAS DE VELOCIDAD DE TRANSFERENCIA )*/                              
CREATE TABLE IF NOT EXISTS TA346(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(25) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA346_1 ON TA346(CODIGO);                                          
CREATE INDEX TA346_2 ON TA346(DESCRIPCIO);                                      
                                                                                
/* TA347( TABLAS DE CAPACIDAD DE TARJETA DE SONIDO Y RED )*/                    
CREATE TABLE IF NOT EXISTS TA347(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(13) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA347_1 ON TA347(CODIGO);                                          
CREATE INDEX TA347_2 ON TA347(DESCRIPCIO);                                      
                                                                                
/* TA348( TABLAS DE FORMATO DE TARJETA MADRE )*/                                
CREATE TABLE IF NOT EXISTS TA348(                                               
   CODIGO      CHAR(5) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(18) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA348_1 ON TA348(CODIGO);                                          
CREATE INDEX TA348_2 ON TA348(DESCRIPCIO);                                      
                                                                                
/* TA349( TABLAS DE TIPO DE TECLADO )*/                                         
CREATE TABLE IF NOT EXISTS TA349(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(30) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA349_1 ON TA349(CODIGO);                                          
CREATE INDEX TA349_2 ON TA349(DESCRIPCIO);                                      
                         
/* TA350( TABLAS DE CONEXI�N DE PIEZAS DE LA PC )*/                             
CREATE TABLE IF NOT EXISTS TA350(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(19) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA350_1 ON TA350(CODIGO);                                          
CREATE INDEX TA350_2 ON TA350(DESCRIPCIO);                                      
                                                                                
/* TA351( TABLAS DE TIPOS DE ESCANNER )*/                                       
CREATE TABLE IF NOT EXISTS TA351(                                               
   CODIGO      CHAR(4) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(27) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA351_1 ON TA351(CODIGO);                                          
CREATE INDEX TA351_2 ON TA351(DESCRIPCIO);                                      
                                                                                
/* TA352( TABLAS DE TIPO DE DECLARACI�N DEL ANEXO 02 AUTOLIQ )*/                
CREATE TABLE IF NOT EXISTS TA352(                                               
   CODIGO      CHAR(1) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(75) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA352_1 ON TA352(CODIGO);                                          
CREATE INDEX TA352_2 ON TA352(DESCRIPCIO);                                      
                                                                                
/* TA353( TABLAS DE TIPO DE SUSTENTACI�N DEL ANEXO 02 AUTOLI )*/                
CREATE TABLE IF NOT EXISTS TA353(                                               
   CODIGO      CHAR(2) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(50) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA353_1 ON TA353(CODIGO);                                          
CREATE INDEX TA353_2 ON TA353(DESCRIPCIO);                                      
                    
/* TA359( TABLAS DE NOMBRE COMERCIAL DE DATOS,AUDIO Y VIDEO )*/                 
CREATE TABLE IF NOT EXISTS TA359(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(70) DEFAULT "",                                          
   PARTIDA     CHAR(10) DEFAULT "",                                             
   PARTIDA_AN  CHAR(10) DEFAULT "",                                             
   PRIMARY KEY(CODIGO,PARTIDA));                                                        
CREATE INDEX TA359_1 ON TA359(CODIGO);                                          
CREATE INDEX TA359_2 ON TA359(DESCRIPCIO);                                      
CREATE INDEX TA359_3 ON TA359(PARTIDA);                                         
                             
/* TA360( TABLAS DE TIPO DE DISCO )*/                                           
CREATE TABLE IF NOT EXISTS TA360(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(41) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA360_1 ON TA360(CODIGO);                                          
CREATE INDEX TA360_2 ON TA360(DESCRIPCIO);                                      
                                                                                
/* TA361( TABLAS DE DIAMETRO DE DISCO )*/                                       
CREATE TABLE IF NOT EXISTS TA361(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  CHAR(10) DEFAULT "",                                             
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA361_1 ON TA361(CODIGO);                                          
CREATE INDEX TA361_2 ON TA361(DESCRIPCIO);                                      
                                                                                
/* TA362( TABLAS DE CAPACIDAD DE ALMACENAMIENTO )*/                             
CREATE TABLE IF NOT EXISTS TA362(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  CHAR(10) DEFAULT "",                                             
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA362_1 ON TA362(CODIGO);                                          
CREATE INDEX TA362_2 ON TA362(DESCRIPCIO);                                      
                                                                                
/* TA363( TABLAS DE TIPO DE FORMATO DVD )*/                                     
CREATE TABLE IF NOT EXISTS TA363(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(25) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA363_1 ON TA363(CODIGO);                                          
CREATE INDEX TA363_2 ON TA363(DESCRIPCIO);                                      
                                                                                
/* TA364( TABLAS DE MATERIAL DE CINTA DE CASETE DE AUDIO )*/                    
CREATE TABLE IF NOT EXISTS TA364(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(41) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA364_1 ON TA364(CODIGO);                                          
CREATE INDEX TA364_2 ON TA364(DESCRIPCIO);                                      
                                                                                
/* TA365( TABLAS DE FORMATO DE CASETES VHS )*/                                  
CREATE TABLE IF NOT EXISTS TA365(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  CHAR(10) DEFAULT "",                                             
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA365_1 ON TA365(CODIGO);                                          
CREATE INDEX TA365_2 ON TA365(DESCRIPCIO);                                      
                                                                                
/* TA366( TABLAS DE TIPO DE ESTUCHES PARA DISCOS OPTICOS )*/                    
CREATE TABLE IF NOT EXISTS TA366(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(34) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA366_1 ON TA366(CODIGO);                                          
CREATE INDEX TA366_2 ON TA366(DESCRIPCIO);                                      
                                                                                
/* TA367( TABLAS DE TIEMPO DE GRABACI�N )*/                                     
CREATE TABLE IF NOT EXISTS TA367(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(12) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA367_1 ON TA367(CODIGO);                                          
CREATE INDEX TA367_2 ON TA367(DESCRIPCIO);                                      
                                                                                
/* TA368( TABLAS DE PRESENTACI�N O EMPAQUE COMERCIAL )*/                        
CREATE TABLE IF NOT EXISTS TA368(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(26) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA368_1 ON TA368(CODIGO);                                          
CREATE INDEX TA368_2 ON TA368(DESCRIPCIO);                                      
                                                                                
/* TA369( TABLAS DE LECTOR (DRIVE) DE DISCO OPTICO )*/                          
CREATE TABLE IF NOT EXISTS TA369(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(61) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA369_1 ON TA369(CODIGO);                                          
CREATE INDEX TA369_2 ON TA369(DESCRIPCIO);                                      
                                                                                
/* TA370( TABLAS DE VELOCIDAD LECTURA/GRABACI�N/REGRABACI�N )*/                 
CREATE TABLE IF NOT EXISTS TA370(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  CHAR(8) DEFAULT "",                                              
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA370_1 ON TA370(CODIGO);                                          
CREATE INDEX TA370_2 ON TA370(DESCRIPCIO);                                      
                                                                                
/* TA373( TABLAS DE CARTILLA DE VALORES DE REFERENCIA )*/                       
CREATE TABLE IF NOT EXISTS TA373(                                               
   PARTIDA     CHAR(10) NOT NULL,                                               
   DES1        VARCHAR(70) DEFAULT "",                                          
   DES2        VARCHAR(70) DEFAULT "",                                          
   PARTIDA_AN  CHAR(10) DEFAULT "",                                             
   PRIMARY KEY(PARTIDA,DES1));                                                       
CREATE INDEX TA373_1 ON TA373(PARTIDA);                                         
                           
/* TA374( TABLAS DE MERCANCIAS AL AMPARO DE LA LEY 28525 )*/                    
CREATE TABLE IF NOT EXISTS TA374(                                               
   PARTIDA     CHAR(5) NOT NULL,                                                
   PARTIDA2    CHAR(5) DEFAULT "",                                              
   PRODUCTO    VARCHAR(71) DEFAULT "",                                          
   UNIDAD      VARCHAR(12) DEFAULT "",                                          
   VALOR_CIF   DECIMAL(8,2) DEFAULT 0.00,                                       
   PRODUCTO22  VARCHAR(71) DEFAULT "",                                          
   PRODUCTO3   VARCHAR(71) DEFAULT "",
   ORDEN       CHAR(3) NOT NULL,                                                
   PRIMARY KEY(PARTIDA,ORDEN));                                                       
CREATE INDEX TA374_1 ON TA374(PARTIDA);                                         

/* TA377( TABLAS DE TIPO DE LOCAL PARA RESTITUC.DE DERECHOS )*/                 
CREATE TABLE IF NOT EXISTS TA377(                                               
   CODIGO      CHAR(1) NOT NULL,                                                
   DESCRIPCIO  CHAR(10) DEFAULT "",                                             
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA377_1 ON TA377(CODIGO);                                          
                                                                                
/* TA378( TABLAS DE TIPO DE PRODUC.PARA RESTITUC.DE DERECHOS )*/                
CREATE TABLE IF NOT EXISTS TA378(                                               
   CODIGO      CHAR(1) NOT NULL,                                                
   DESCRIPCIO  CHAR(10) DEFAULT "",                                             
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA378_1 ON TA378(CODIGO);                                          
                                                                                
/* TA381( TABLAS DE PARTIDAS ANTID.TEJIDOS (CHINA Y BRASIL) )*/                 
CREATE TABLE IF NOT EXISTS TA381(                                               
   PAIS        CHAR(2) NOT NULL,                                                
   PARTIDA     CHAR(10) NOT NULL,                                               
   TEXTO       CHAR(3) DEFAULT "",                                              
   TIPO_CALC   CHAR(2) DEFAULT "",                                              
   PARTIDA_AN  CHAR(10) DEFAULT "",                                             
   PRIMARY KEY(PAIS,PARTIDA));                                                  
CREATE INDEX TA381_1 ON TA381(PAIS,PARTIDA);                                    
CREATE INDEX TA381_2 ON TA381(PARTIDA);                                         
                                                                                
/* TA382( TABLAS DE MERCANCIAS AL AMPARO DE LA LEY 28583 )*/                    
CREATE TABLE IF NOT EXISTS TA382(                                               
   PARTIDA     CHAR(10) NOT NULL,                                               
   DES1        VARCHAR(87) DEFAULT "",                                          
   DES2        VARCHAR(153) DEFAULT "",                                         
   PARTIDA_AN  CHAR(10) DEFAULT "",                                             
   PRIMARY KEY(PARTIDA));                                                       
CREATE INDEX TA382_1 ON TA382(PARTIDA);                                         
                                                                                
/* TA384( TABLAS DE BIENES PARA PECEPCION POR UNIDAD )*/                        
CREATE TABLE IF NOT EXISTS TA384(                                               
   PARTIDA     CHAR(10) NOT NULL,                                               
   TIPO        CHAR(10) DEFAULT "",                                             
   MONTO       DECIMAL(5,2) DEFAULT 0.00,                                       
   PRIMARY KEY(PARTIDA,TIPO));                                                       
CREATE INDEX TA384_1 ON TA384(PARTIDA);                                         
                           
/* TA385( TABLAS DE TIPOS DE TRANSACCION PARA REG. 43 )*/                       
CREATE TABLE IF NOT EXISTS TA385(                                               
   CODIGO      CHAR(2) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(85) DEFAULT "",      
   REGIMEN     CHAR(2) NOT NULL,                                 
   PRIMARY KEY(CODIGO,REGIMEN));                                                        
CREATE INDEX TA385_1 ON TA385(CODIGO);                                          
CREATE INDEX TA385_2 ON TA385(DESCRIPCIO);                                      
                                                                                
/* TA386( TABLAS DE TIPOS DE ENVIO PARA REG. 43 )*/                             
CREATE TABLE IF NOT EXISTS TA386(                                               
   CODIGO      CHAR(1) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(20) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA386_1 ON TA386(CODIGO);                                          
CREATE INDEX TA386_2 ON TA386(DESCRIPCIO);                                      
                                                                                
/* TA388( TABLAS DE NOMBRE COMERCIAL DE LA FIBRA )*/                            
CREATE TABLE IF NOT EXISTS TA388(                                               
   COD         CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(20) DEFAULT "",                                          
   PRIMARY KEY(COD));                                                           
CREATE INDEX TA388_1 ON TA388(COD);                                             
CREATE INDEX TA388_2 ON TA388(DESCRIPCIO);                                      
                                                                                
/* TA389( TABLAS DE TIPO DE FIBRA )*/                                           
CREATE TABLE IF NOT EXISTS TA389(                                               
   COD         CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(72) DEFAULT "",                                          
   PRIMARY KEY(COD));                                                           
CREATE INDEX TA389_1 ON TA389(COD);                                             
CREATE INDEX TA389_2 ON TA389(DESCRIPCIO);                                      

/* TA390( TABLAS DE COMPOSICI�N DE LA MATERIA TEXTIL )*/                        
CREATE TABLE IF NOT EXISTS TA390(                                               
   COD         CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(25) DEFAULT "",                                          
   DESCRIPCI2  VARCHAR(25) DEFAULT "",                                          
   NENVIO      CHAR(3) DEFAULT "",                                              
   PRIMARY KEY(COD));
CREATE INDEX TA390_1 ON TA390(COD);                                             
CREATE INDEX TA390_2 ON TA390(DESCRIPCIO);                                      
                                                                                
/* TA391( TABLAS DE GRADO DE PREPARACI�N DE LA FIBRA )*/                        
CREATE TABLE IF NOT EXISTS TA391(                                               
   COD         CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(35) DEFAULT "",                                          
   TIPO        CHAR(3) DEFAULT "",                                              
   PRIMARY KEY(COD));                                                           
CREATE INDEX TA391_1 ON TA391(COD);                                             
CREATE INDEX TA391_2 ON TA391(DESCRIPCIO);                                      
                                                                                
/* TA392( TABLAS DE PRESENTACI�N )*/                                            
CREATE TABLE IF NOT EXISTS TA392(                                               
   COD         CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(20) DEFAULT "",                                          
   TIPO        CHAR(3) DEFAULT "",                                              
   PRIMARY KEY(COD));                                                           
CREATE INDEX TA392_1 ON TA392(COD);                                             
CREATE INDEX TA392_2 ON TA392(DESCRIPCIO);                                      
                                                                                
/* TA393( TABLAS DE TIPO DE HILADO )*/                                          
CREATE TABLE IF NOT EXISTS TA393(                                               
   COD         CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(35) DEFAULT "",                                          
   NENVIO      CHAR(3) DEFAULT "",                                              
   PRIMARY KEY(COD));                                                           
CREATE INDEX TA393_1 ON TA393(COD);                                             
CREATE INDEX TA393_2 ON TA393(DESCRIPCIO);                                      
                                                                                
/* TA394( TABLAS DE GRADO DE ELABORACI�N )*/                                    
CREATE TABLE IF NOT EXISTS TA394(                                               
   COD         CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(30) DEFAULT "",                                          
   DESCRIPCI2  VARCHAR(27) DEFAULT "",                                          
   NENVIO      CHAR(3) DEFAULT "",                                              
   PRIMARY KEY(COD));                                                           
CREATE INDEX TA394_1 ON TA394(COD);                                             
CREATE INDEX TA394_2 ON TA394(DESCRIPCIO);                                      
                                                                                
/* TA395( TABLAS DE ACABADOS )*/                                                
CREATE TABLE IF NOT EXISTS TA395(                                               
   COD         CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(36) DEFAULT "",                                          
   NENVIO      CHAR(3) DEFAULT "",                                              
   PRIMARY KEY(COD));                                                           
CREATE INDEX TA395_1 ON TA395(COD);                                             
CREATE INDEX TA395_2 ON TA395(DESCRIPCIO);                                      
                         
/* TA396( TABLAS DE TIPO DE TELA )*/                                            
CREATE TABLE IF NOT EXISTS TA396(                                               
   COD         CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(36) DEFAULT "",     
   NENVIO      CHAR(3) DEFAULT "",
   PRIMARY KEY(COD));                                                           
CREATE INDEX TA396_1 ON TA396(COD);                                             
CREATE INDEX TA396_2 ON TA396(DESCRIPCIO);                                      
                                                                                
/* TA397( TABLAS DE CONSTRUCCI�N DE LA TELA )*/                                 
CREATE TABLE IF NOT EXISTS TA397(                                               
   COD         CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(24) DEFAULT "",                                          
   DESCRIPCI2  VARCHAR(27) DEFAULT "",                                          
   NENVIO      CHAR(3) DEFAULT "",                                              
   PRIMARY KEY(COD));                                                           
CREATE INDEX TA397_1 ON TA397(COD);                                             
CREATE INDEX TA397_2 ON TA397(DESCRIPCIO);                                      
                                                                                
/* TA398( TABLAS DE COMPOSICI�N DE LA MATERIA PLASTICA )*/                      
CREATE TABLE IF NOT EXISTS TA398(                                               
   COD         CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(35) DEFAULT "",                                          
   PRIMARY KEY(COD));                                                           
CREATE INDEX TA398_1 ON TA398(COD);                                             
CREATE INDEX TA398_2 ON TA398(DESCRIPCIO);                                      
                                                                                
/* TA399( TABLAS DE PARTIDAS DE TEXTILES )*/                                    
CREATE TABLE IF NOT EXISTS TA399(                                               
   CAPITULO    CHAR(4) NOT NULL,                                                
   CODIGO      CHAR(3) NOT NULL,                                                
   PRIMARY KEY(CAPITULO,CODIGO));                                               
CREATE INDEX TA399_1 ON TA399(CAPITULO,CODIGO);                                 
                                                                                
/* TA400( TABLAS DE TIPO DE MODALIDA DE ADMISION TEMPORAL )*/                   
CREATE TABLE IF NOT EXISTS TA400(                                               
   CODIGO      CHAR(1) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(60) DEFAULT "",                                          
   STATUS      CHAR(10) DEFAULT "",                                             
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA400_1 ON TA400(CODIGO);                                          
CREATE INDEX TA400_2 ON TA400(DESCRIPCIO);                                      
                                                                                
/* TA401( TABLAS DE TIPOS DE DOC. DE LAS COPIAS AUTENTICADAS )*/                
CREATE TABLE IF NOT EXISTS TA401(                                               
   COD         CHAR(2) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(40) DEFAULT "",                                          
   PRIMARY KEY(COD));                                                           
CREATE INDEX TA401_1 ON TA401(COD);                                             
CREATE INDEX TA401_2 ON TA401(DESCRIPCIO);                                      

/* TA402( Tipos de Despachos no concluidos )*/                                      
CREATE TABLE IF NOT EXISTS TA402(                                               
   COD         CHAR(1) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(50) DEFAULT "",                                          
   PRIMARY KEY(COD));
CREATE INDEX TA402_1 ON TA402(COD);                                          
CREATE INDEX TA402_2 ON TA402(DESCRIPCIO);                                                                                                                      
                                                                                
/* TA403( TABLAS DE SOLICITUD DE AFORO )*/                                      
CREATE TABLE IF NOT EXISTS TA403(                                               
   CODIGO      CHAR(1) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(50) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA403_1 ON TA403(CODIGO);                                          
CREATE INDEX TA403_2 ON TA403(DESCRIPCIO);                                      

/* TA405( TABLAS DE MOTIVOS DE COPIAS AUTENTICADAS )*/                                      
CREATE TABLE IF NOT EXISTS TA405(                                               
   CODIGO      CHAR(2) NOT NULL,                                                
   MOTIVO      VARCHAR(35) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA405_1 ON TA405(CODIGO);                                          
CREATE INDEX TA405_2 ON TA405(MOTIVO);                                      

/* TA406( TABLAS DE SOLICITANTES DE COPIAS AUTENTICADAS )*/                                      
CREATE TABLE IF NOT EXISTS TA406(                                               
   CODIGO      CHAR(2) NOT NULL,                                                
   SOLICITA    VARCHAR(45) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA406_1 ON TA406(CODIGO);                                          
CREATE INDEX TA406_2 ON TA406(SOLICITA);                                      

/* TA407( Tipo de transaccion (Contenedores)                 )*/                                      
CREATE TABLE IF NOT EXISTS TA407(                                               
   CODIGO      CHAR(2) NOT NULL,                                                
   DESCRIPCIO  CHAR(13) DEFAULT "",                                             
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA407_1 ON TA407(CODIGO);                                          
CREATE INDEX TA407_2 ON TA407(DESCRIPCIO);                                      
                                                                                
                                                                                
/* TA408( TABLAS DE TIPO DE TRANSPORTE )*/                                      
CREATE TABLE IF NOT EXISTS TA408(                                               
   CODIGO      CHAR(1) NOT NULL,                                                
   DESCRIPCIO  CHAR(10) DEFAULT "",                                             
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA408_1 ON TA408(CODIGO);                                          
CREATE INDEX TA408_2 ON TA408(DESCRIPCIO);                                      
                                                                                
/* TA409( TABLAS DE TAMANO DEL CONTENEDOR )*/                                   
CREATE TABLE IF NOT EXISTS TA409(                                               
   CODIGO      CHAR(2) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(40) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA409_1 ON TA409(CODIGO);                                          
CREATE INDEX TA409_2 ON TA409(DESCRIPCIO);                                      
                                                                                
/* TA410( TABLAS DE TIPO DE INGRESO AL TERMINAL )*/                             
CREATE TABLE IF NOT EXISTS TA410(                                               
   CODIGO      CHAR(1) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(35) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA410_1 ON TA410(CODIGO);                                          
CREATE INDEX TA410_2 ON TA410(DESCRIPCIO);                                      
                                                                                
/* TA417( TABLAS DE ESTUPEFACIENTES,PSICOTROPICOS,PRECURSORE )*/                
CREATE TABLE IF NOT EXISTS TA417(                                               
   COD         CHAR(4) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(15) DEFAULT "",                                          
   PRIMARY KEY(COD));                                                           
CREATE INDEX TA417_1 ON TA417(COD);                                             
CREATE INDEX TA417_2 ON TA417(DESCRIPCIO);                                      
                                                                                
/* TA418( TABLAS DE NUEVA TABLA D.ESPECIFICO 01.07.2006 )*/                     
CREATE TABLE IF NOT EXISTS TA418(                                               
   CODIGO      CHAR(2) NOT NULL,                                                
   FOB_REF1    CHAR(4) NOT NULL,                                                
   FOB_REF2    CHAR(4) DEFAULT "",                                              
   DER_ESP1    NUMERIC(5,0) DEFAULT 0,                                          
   DER_ESP2    NUMERIC(4,0) DEFAULT 0,                                          
   PRIMARY KEY(CODIGO,FOB_REF1));                                               
CREATE INDEX TA418_1 ON TA418(CODIGO,FOB_REF1);                                 
                                                                                
/* TA420( TABLAS DE IMPORTADORES FRECUENTES )*/                                 
CREATE TABLE IF NOT EXISTS TA420(                                               
   COD         VARCHAR(11) NOT NULL,                                            
   NOMBRE      VARCHAR(58) DEFAULT "",                                          
   PRIMARY KEY(COD));                                                           
CREATE INDEX TA420_1 ON TA420(COD);                                             
CREATE INDEX TA420_2 ON TA420(NOMBRE);                                          
                                                                                
/* TA423( TABLAS DE RANGOS PARA ANTID.BRASIL Y CHINA )*/                        
CREATE TABLE IF NOT EXISTS TA423(                                               
   PAIS        CHAR(2) NOT NULL,                                                
   CEXPODUMP   CHAR(4) NOT NULL,                                                
   VIS         CHAR(1) DEFAULT "",                                              
   NOMB_EMPR   VARCHAR(40) DEFAULT "",                                          
   MINIMO      DECIMAL(10,3) DEFAULT 0.000,                                     
   MAXIMO      DECIMAL(10,3) DEFAULT 0.000,                                     
   ANTI        DECIMAL(10,3) DEFAULT 0.000,                                     
   MENOS       CHAR(1) DEFAULT "",                                              
   CPROD       CHAR(2) DEFAULT "",                                              
   TEXTO       CHAR(3) DEFAULT "",                                              
   PRIMARY KEY(PAIS,CEXPODUMP,CPROD));                                                
CREATE INDEX TA423_1 ON TA423(PAIS,CEXPODUMP);                                  
CREATE INDEX TA423_2 ON TA423(PAIS,VIS);                                        
     
/* TA425( TABLAS DE CRONOGRAMA ACTUAL DE CODIGO 358 )*/                         
CREATE TABLE IF NOT EXISTS TA425(                                               
   CODIGO      CHAR(5) NOT NULL,                                                
   MPO         DECIMAL(6,2) DEFAULT 0.00,                                        
   FECH_INI    DATE,                                                            
   FECH_TER    DATE, 
   ORDEN       CHAR(2) NOT NULL,                                                           
   PRIMARY KEY(CODIGO,ORDEN));                                                        
CREATE INDEX TA425_1 ON TA425(CODIGO);                                          

                           
/* TA426( TABLAS DE PARTIDAS ALADI 358 )*/                                      
CREATE TABLE IF NOT EXISTS TA426(                                               
   COD_NANDI   CHAR(10) NOT NULL,                                               
   COD         CHAR(2) NOT NULL,                                                
   COD_NALAD   CHAR(10) NOT NULL,                                                
   TIP_PROD    CHAR(1) DEFAULT "",                                              
   PAT_HIST    CHAR(3) DEFAULT "",                                              
   MAR_PORCEN  DECIMAL(5,1) DEFAULT 0.0,                                        
   COD_358     CHAR(5) DEFAULT "",                                              
   FECH_TER    DATE,                                                            
   DESCRIP1    VARCHAR(70) DEFAULT "",                                          
   DESCRIP2    VARCHAR(70) DEFAULT "",                                          
   DESCRIP3    VARCHAR(70) DEFAULT "",                                          
   DESCRIP4    VARCHAR(70) DEFAULT "",                                          
   OBSERVAC    VARCHAR(70) DEFAULT "",                                          
   OBSERVAC2   VARCHAR(70) DEFAULT "",                                          
   OBSERVAC3   VARCHAR(70) DEFAULT "",                                          
   OBSERVAC4   VARCHAR(70) DEFAULT "",                                          
   OBSERVAC5   VARCHAR(70) DEFAULT "",                                          
   OBSERVAC6   VARCHAR(70) DEFAULT "",                                          
   OBSERVAC7   VARCHAR(70) DEFAULT "",                                          
   VERIFICAD   NUMERIC(1,0) DEFAULT 0,                                          
   M           CHAR(1) DEFAULT "",                                              
   PARTIDA_AN  CHAR(10) DEFAULT "",                                             
   PRIMARY KEY(COD,COD_NANDI,COD_NALAD,TIP_PROD,COD_358,DESCRIP1));                                                 
CREATE INDEX TA426_1 ON TA426(COD,COD_NANDI);                                   
CREATE INDEX TA426_2 ON TA426(COD,COD_NANDI,COD_NALAD,TIP_PROD);                

/* TA427( TABLAS PARA LA EXPORTACION OMA )*/                         
CREATE TABLE IF NOT EXISTS TA427(                                               
   CODIGO      CHAR(2) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(36) DEFAULT '',                                        
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA427_1 ON TA427(CODIGO);                                          
CREATE INDEX TA427_2 ON TA427(DESCRIPCIO);                                          
                                                                                
/* TA431( TABLAS DE PORCENTAJE DE REGIMEN DE GRADUALIDAD )*/                    
CREATE TABLE IF NOT EXISTS TA431(                                               
   COD         CHAR(1) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(50) DEFAULT "",                                          
   TIPO        CHAR(1) DEFAULT "",
   PRIMARY KEY(COD,TIPO));                                                           
CREATE INDEX TA431_1 ON TA431(COD);                                             
CREATE INDEX TA431_2 ON TA431(DESCRIPCIO);                                                                                                                   

/* TA432( TABLAS DE INDICADOR DE REGIMEN DE GRADUALIDAD )*/                     
CREATE TABLE IF NOT EXISTS TA432(                                               
   COD         CHAR(1) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(20) DEFAULT "",                                          
   PRIMARY KEY(COD));                                                           
CREATE INDEX TA432_1 ON TA432(COD);                                             
CREATE INDEX TA432_2 ON TA432(DESCRIPCIO);                                      
                                                                                
/* TA436( TABLAS DE CORRELACION ARANCEL 2002 - 2007 )*/                         
CREATE TABLE IF NOT EXISTS TA436(                                               
   PAB1        CHAR(10) NOT NULL,                                               
   PAB2        CHAR(10) DEFAULT "",                                             
   PRIMARY KEY(PAB1,PAB2));                                                          
CREATE INDEX TA436_1 ON TA436(PAB1);                                            
CREATE INDEX TA436_2 ON TA436(PAB2);                                            

/* TA437( TABLAS DE CONDICION DEL PROVEEDOR EXTRANJERO )*/                      
CREATE TABLE IF NOT EXISTS TA437(                                               
   CODIGO      CHAR(1) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(20) DEFAULT "",                                          
   DESCRIPCI2  VARCHAR(100) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA437_1 ON TA437(CODIGO);                                          
CREATE INDEX TA437_2 ON TA437(DESCRIPCIO);                                      

/* TA438( TABLAS DE TIPO DE DOCUMENTO ASOCIADO OCS )*/                          
CREATE TABLE IF NOT EXISTS TA438(                                               
   CODIGO      CHAR(2) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(67) DEFAULT "",                                          
   REG_10      CHAR(1) DEFAULT "",                                              
   REG_18      CHAR(1) DEFAULT "",                                              
   REG_20      CHAR(1) DEFAULT "",                                              
   REG_21      CHAR(1) DEFAULT "",                                              
   REG_30      CHAR(1) DEFAULT "",                                              
   REG_70      CHAR(1) DEFAULT "",                                              
   REG_78      CHAR(1) DEFAULT "",                                              
   REG_80      CHAR(1) DEFAULT "",                                              
   REG_89      CHAR(1) DEFAULT "",                                              
   REG_40      CHAR(1) DEFAULT "",                                              
   REG_41      CHAR(1) DEFAULT "",      
   REG_36      CHAR(1) DEFAULT "",      
   REG_48      CHAR(1) DEFAULT "",      
   REG_60      CHAR(1) DEFAULT "",      
   XML         CHAR(1) DEFAULT "",                                               
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA438_1 ON TA438(CODIGO);                                          
CREATE INDEX TA438_2 ON TA438(DESCRIPCIO);                                      

/* TA439( TABLAS DE TIPO DE OPERACION ASOCIADOS OCS )*/                         
CREATE TABLE IF NOT EXISTS TA439(                                               
   CODIGO      CHAR(1) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(67) DEFAULT "",                                          
   REG_10      CHAR(1) DEFAULT "",                                              
   REG_18      CHAR(1) DEFAULT "",                                              
   REG_20      CHAR(1) DEFAULT "",                                              
   REG_21      CHAR(1) DEFAULT "",                                              
   REG_30      CHAR(1) DEFAULT "",                                              
   REG_70      CHAR(1) DEFAULT "",                                              
   REG_78      CHAR(1) DEFAULT "",                                              
   REG_80      CHAR(1) DEFAULT "",                                              
   REG_89      CHAR(1) DEFAULT "",                                              
   REG_40      CHAR(1) DEFAULT "",                                              
   REG_41      CHAR(1) DEFAULT "",                                              
   REG_36      CHAR(1) DEFAULT "",      
   REG_48      CHAR(1) DEFAULT "",      
   REG_60      CHAR(1) DEFAULT "",      
   PRIMARY KEY(CODIGO,DESCRIPCIO));                                                        
CREATE INDEX TA439_1 ON TA439(CODIGO);                                          
CREATE INDEX TA439_2 ON TA439(DESCRIPCIO);                                      

/* TA440( TABLAS DE DECLARACION JURADA DE MERCANCIAS )*/                        
CREATE TABLE IF NOT EXISTS TA440(                                               
   CODIGO      CHAR(2) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(26) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA440_1 ON TA440(CODIGO);                                          
                                                                                
/* TA441( TABLAS DE TIPO DE ENCENDIDO DE VEHICULOS )*/                          
CREATE TABLE IF NOT EXISTS TA441(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(24) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA441_1 ON TA441(CODIGO);                                          
CREATE INDEX TA441_2 ON TA441(DESCRIPCIO);                                      
                                                                                
/* TA442( TABLAS PARA LA EXPORTACION OMA )*/                         
CREATE TABLE IF NOT EXISTS TA442(                                               
   CODIGO      CHAR(2) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(46) DEFAULT '',                                        
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA442_1 ON TA442(CODIGO);                                          
CREATE INDEX TA442_2 ON TA442(DESCRIPCIO);                                          
                                                                                
/* TA443( TABLAS PARA LA EXPORTACION OMA )*/                         
CREATE TABLE IF NOT EXISTS TA443(                                               
   CODIGO      CHAR(1) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(36) DEFAULT '',                                        
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA443_1 ON TA443(CODIGO);                                          
CREATE INDEX TA443_2 ON TA443(DESCRIPCIO);                                          

/* TA444( AUTORIZACION POR CATEGORIA DE RIESGO)*/                                    
CREATE TABLE IF NOT EXISTS TA444(                                               
   CODIGO      CHAR(4) NOT NULL,                                                
   DESCRIPC1   VARCHAR(130) DEFAULT "",                                          
   DESCRIPC2   VARCHAR(130) DEFAULT "",                                          
   ADICIONAL1  VARCHAR(132) DEFAULT "",                                          
   ADICIONAL2  VARCHAR(133) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA444_1 ON TA444(CODIGO);                                          
CREATE INDEX TA444_2 ON TA444(DESCRIPC1);                                      
                                                                                
/* TA445( TABLAS DE CATEGORIAS DE RIESGO )*/                                    
CREATE TABLE IF NOT EXISTS TA445(                                               
   CODIGO      CHAR(1) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(35) DEFAULT "",                                          
   IMP1        CHAR(4) DEFAULT "",                                              
   IMP2        CHAR(4) DEFAULT "",                                              
   IMP3        CHAR(4) DEFAULT "",                                              
   IMP4        CHAR(4) DEFAULT "",                                              
   LL1         CHAR(4) DEFAULT "",                                              
   LL2         CHAR(4) DEFAULT "",                                              
   CONCEPTO1   VARCHAR(140) DEFAULT "",                                         
   CONCEPTO2   VARCHAR(140) DEFAULT "",                                         
   CONCEPTO3   VARCHAR(135) DEFAULT "",                                         
   CONCEPTO4   VARCHAR(135) DEFAULT "",                                         
   CONCEPTO5   VARCHAR(135) DEFAULT "",                                         
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA445_1 ON TA445(CODIGO);                                          
CREATE INDEX TA445_2 ON TA445(DESCRIPCIO);                                      
           
/* TA446( TABLAS DE PARTIDAS CON CATEGORIA DE RIESGO )*/                        
CREATE TABLE IF NOT EXISTS TA446(                                               
   CODIGO      CHAR(2) NOT NULL,                                                
   DES1        VARCHAR(73) DEFAULT "",                                          
   DES2        VARCHAR(71) DEFAULT "",                                          
   DES3        VARCHAR(71) DEFAULT "",                                          
   DES4        VARCHAR(71) DEFAULT "",                                          
   DES5        VARCHAR(70) DEFAULT "",                                          
   DES6        VARCHAR(70) DEFAULT "",                                          
   PARTIDA     CHAR(10) DEFAULT "",                                             
   RIESGO      CHAR(1) DEFAULT "",                                              
   PRIMARY KEY(CODIGO,PARTIDA,RIESGO,DES1));                                                        
CREATE INDEX TA446_1 ON TA446(CODIGO);                                          
CREATE INDEX TA446_2 ON TA446(DES1);                                            
CREATE INDEX TA446_3 ON TA446(PARTIDA);                                         
CREATE INDEX TA446_4 ON TA446(RIESGO,PARTIDA);                                  
                                    
/* TA448( TABLAS DE TIPO DE AUTORIZACION DE PARA EXPORTACION )*/                
CREATE TABLE IF NOT EXISTS TA448(                                               
   PARTIDA     CHAR(10) NOT NULL,                                               
   TIPOREG     CHAR(2) NOT NULL,                                                
   SECUENCIA   CHAR(3)  NOT NULL,                                                
   DESCRIP     VARCHAR(85) DEFAULT "",                                          
   COD_ENTI    CHAR(2) DEFAULT "",                                              
   ENTIDAD     VARCHAR(45) DEFAULT "",                                          
   FECHA_INI   DATE,                                                            
   FECHA_FIN   DATE,                                                            
   MARCA       CHAR(1) DEFAULT "",                                              
   PARTIDA_AN  CHAR(10) DEFAULT "",
   PRIMARY KEY(TIPOREG,PARTIDA,SECUENCIA));                                               
CREATE INDEX TA448_1 ON TA448(TIPOREG,PARTIDA);                                 
                                    
/* TA449( TABLAS DE TIPO DE RESTRICCION (DAV) )*/                               
CREATE TABLE IF NOT EXISTS TA449(                                               
   CODIGO      CHAR(2) NOT NULL,                                                
   CONCEPTO    VARCHAR(90) DEFAULT "",                                          
   CONCEPTO1   VARCHAR(15) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA449_1 ON TA449(CODIGO);                                          
CREATE INDEX TA449_2 ON TA449(CONCEPTO);                                        
                                                                                
/* TA450( TABLAS DE CONDICION O COTRAPRESTACION (DAV) )*/                       
CREATE TABLE IF NOT EXISTS TA450(                                               
   CODIGO      CHAR(2) NOT NULL,                                                
   CONCEPTO    VARCHAR(71) DEFAULT "",                                          
   CONCEPTO1   VARCHAR(71) DEFAULT "",                                          
   CONCEPTO2   VARCHAR(71) DEFAULT "",                                          
   CONCEPTO3   VARCHAR(71) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA450_1 ON TA450(CODIGO);                                          
CREATE INDEX TA450_2 ON TA450(CONCEPTO);                                        
                                                                                
/* TA451( TABLAS DE TIPO DE VINCULACION (DAV) )*/                               
CREATE TABLE IF NOT EXISTS TA451(                                               
   CODIGO      CHAR(2) NOT NULL,                                                
   CONCEPTO    VARCHAR(71) DEFAULT "",                                          
   CONCEPTO1   VARCHAR(71) DEFAULT "",                                          
   CONCEPTO2   VARCHAR(71) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA451_1 ON TA451(CODIGO);                                          
CREATE INDEX TA451_2 ON TA451(CONCEPTO);                                        
                                                                                
/* TA452( TABLAS DE FORMA DE PAGO (DAV) )*/                                     
CREATE TABLE IF NOT EXISTS TA452(                                               
   CODIGO      CHAR(2) NOT NULL,                                                
   CONCEPTO    VARCHAR(71) DEFAULT "",                                          
   CONCEPTO1   VARCHAR(71) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA452_1 ON TA452(CODIGO);                                          
CREATE INDEX TA452_2 ON TA452(CONCEPTO);                                        
                                                                                
/* TA453( TABLAS DE MEDIO DE PAGO (DAV) )*/                                     
CREATE TABLE IF NOT EXISTS TA453(                                               
   CODIGO      CHAR(2) NOT NULL,                                                
   CONCEPTO    VARCHAR(71) DEFAULT "",                                          
   CONCEPTO1   VARCHAR(71) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA453_1 ON TA453(CODIGO);                                          
CREATE INDEX TA453_2 ON TA453(CONCEPTO);                                        
                                                                                
/* TA454( TABLAS DE ADICIONES Y DEDUCCIONES (DAV) )*/                           
CREATE TABLE IF NOT EXISTS TA454(                                               
   CAMPO       CHAR(6) NOT NULL,                                                
   CODIGO      CHAR(2) DEFAULT "",                                              
   CASILLA     VARCHAR(15) DEFAULT "",                                          
   PRIMARY KEY(CAMPO));                                                         
CREATE INDEX TA454_1 ON TA454(CAMPO);                                           
CREATE INDEX TA454_2 ON TA454(CODIGO);                                          
                                                                                
/* TA455( TABLAS DE CODIGO DE TIPO DE PAGO (DHL) )*/                            
CREATE TABLE IF NOT EXISTS TA455(                                               
   COD         CHAR(1) NOT NULL,                                                
   CONCEPTO    VARCHAR(30) DEFAULT "",                                          
   PRIMARY KEY(COD));                                                           
CREATE INDEX TA455_1 ON TA455(COD);                                             
                                                                                
/* TA457( TABLAS DE REQUERIMIENTO DE AUTORIZACION )*/                           
CREATE TABLE IF NOT EXISTS TA457(                                               
   COD         CHAR(1) NOT NULL,                                                
   CONCEPTO    VARCHAR(25) DEFAULT "",                                          
   PRIMARY KEY(COD));                                                           
CREATE INDEX TA457_1 ON TA457(COD);                                             
                                                                                
/* TA458(Tipo de Documento Master )*/                           
CREATE TABLE IF NOT EXISTS TA458(                                            
   COD         CHAR(1) NOT NULL,                                                   
   CONCEPTO    VARCHAR(25) DEFAULT "",                                          
   DESCARGA    CHAR(2) DEFAULT "",
   PRIMARY KEY(COD,DESCARGA));                                                           
CREATE INDEX TA458_1 ON TA458(COD);                                             
                                                                               
/* TA459( TABLAS DE TIPO DE TRANSFERENCIA )*/                                   
CREATE TABLE IF NOT EXISTS TA459(                                               
   COD         CHAR(2) NOT NULL,                                                
   CONCEPTO    VARCHAR(62) DEFAULT "",                                          
   PRIMARY KEY(COD));                                                           
CREATE INDEX TA459_1 ON TA459(COD);                                             
CREATE INDEX TA459_2 ON TA459(CONCEPTO);                                        
                                                                                
/* TA462( TABLAS DE TIPO DE CONTENEDOR PARA LA DUIM )*/                         
CREATE TABLE IF NOT EXISTS TA462(                                               
   CODIGO      CHAR(1) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(30) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA462_1 ON TA462(CODIGO);                                          
CREATE INDEX TA462_2 ON TA462(DESCRIPCIO);                                      
                                                                                
/* TA463( TABLAS DE TIPO DE TRANSACC.TRANSFERENCIA ADMISION )*/                 
CREATE TABLE IF NOT EXISTS TA463(                                               
   COD         CHAR(2) NOT NULL,                                                
   CONCEPTO    VARCHAR(62) DEFAULT "",                                          
   PRIMARY KEY(COD));                                                           
CREATE INDEX TA463_1 ON TA463(COD);                                             
CREATE INDEX TA463_2 ON TA463(CONCEPTO);                                        
                                                                                
/* TA464( TABLAS DE TIPO DE MODALIDAD SALIDA/REINGRESO AEROP )*/                
CREATE TABLE IF NOT EXISTS TA464(                                               
   COD         CHAR(1) NOT NULL,                                                
   CONCEPTO    VARCHAR(20) DEFAULT "",                                          
   PRIMARY KEY(COD));                                                           
CREATE INDEX TA464_1 ON TA464(COD);                                             
CREATE INDEX TA464_2 ON TA464(CONCEPTO);                                        
                                                                                
/* TA465( TABLAS DE RELACION CONTENEDORES Y PALLETS )*/                         
CREATE TABLE IF NOT EXISTS TA465(                                               
   CODIGO      CHAR(1) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(46) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA465_1 ON TA465(CODIGO);                                          
CREATE INDEX TA465_2 ON TA465(DESCRIPCIO);                                      
                                                                                
/* TA467( TABLAS DE NUEVA TABLA DERECHO ESPECIFICO 01.07.08 )*/                 
CREATE TABLE IF NOT EXISTS TA467(                                               
   CODIGO      CHAR(2) NOT NULL,                                                
   FOB_REF1    CHAR(4) NOT NULL,                                                
   FOB_REF2    CHAR(4) DEFAULT "",                                              
   DER_ESP1    NUMERIC(5,0) DEFAULT 0,                                          
   DER_ESP2    NUMERIC(4,0) DEFAULT 0,                                          
   PRIMARY KEY(CODIGO,FOB_REF1));                                               
CREATE INDEX TA467_1 ON TA467(CODIGO,FOB_REF1);                                 
                                                                           
/* TA468( TABLAS PARA LA EXPORTACION OMA )*/                         
CREATE TABLE IF NOT EXISTS TA468(                                               
   CODIGO      CHAR(2) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(97) DEFAULT '',                                        
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA468_1 ON TA468(CODIGO);                                          
CREATE INDEX TA468_2 ON TA468(DESCRIPCIO);                                          

/* TA469( TABLAS DE TIPO DE DEUDOR PARA AUTOLIQUIDACION (NUEVO) )*/             
CREATE TABLE IF NOT EXISTS TA469(                                               
   CODIGO      CHAR(1) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(50) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA469_1 ON TA469(CODIGO);                                          
CREATE INDEX TA469_2 ON TA469(DESCRIPCIO);                                      

/* TA473( TABLAS DE FORMA DE PAGO DEL CLIENTE A LA AGENCIA (UIF) )*/            
CREATE TABLE IF NOT EXISTS TA473(                                               
   CODIGO      CHAR(1) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(25) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA473_1 ON TA473(CODIGO);                                          
CREATE INDEX TA473_2 ON TA473(DESCRIPCIO);                                      

/* TA474( TABLAS DE ENTIDADES EXONERADAS DE PERCEPCI�N DE IGV )*/               
CREATE TABLE IF NOT EXISTS TA474(                                               
   RUC         VARCHAR(11) NOT NULL,                                            
   RAZON_SOCI  VARCHAR(125) DEFAULT "",                                          
   TIPO        VARCHAR(30) DEFAULT "",                                          
   FCH_PUBLIC  DATE,                                                            
   FCH_VIGENC  DATE,                                                            
   PUBLICACIO  VARCHAR(20) DEFAULT "",                                          
   PRIMARY KEY(RUC));                                                           
CREATE INDEX TA474_1 ON TA474(RUC);                                             
CREATE INDEX TA474_2 ON TA474(RAZON_SOCI);                                      

/* TA475( TABLAS DE TIPO DE REGIMEN DE APLICACION PARA 13 )*/                   
CREATE TABLE IF NOT EXISTS TA475(                                               
   CODIGO      CHAR(2) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(25) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA475_1 ON TA475(CODIGO);                                          
CREATE INDEX TA475_2 ON TA475(DESCRIPCIO);                                      

/* TA476( Tipo de envio para la Duim de Carga                )*/              
CREATE TABLE IF NOT EXISTS TA476(                                               
   CODIGO      CHAR(1) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(20) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA476_1 ON TA476(CODIGO);                                          
CREATE INDEX TA476_2 ON TA476(DESCRIPCIO);                                                                                                                     
                                                                                
/* TA477( TABLAS DE CONDICION AL EXTERIOR DEL ACTA DE TRASLADO )*/              
CREATE TABLE IF NOT EXISTS TA477(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(20) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA477_1 ON TA477(CODIGO);                                          
CREATE INDEX TA477_2 ON TA477(DESCRIPCIO);                                      
                                                                                
/* TA478( TABLAS DE TIPO DE ENVIO DE REEXPEDICION DE ENVIOS POSTALES )*/        
CREATE TABLE IF NOT EXISTS TA478(                                               
   CODIGO      CHAR(2) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(20) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA478_1 ON TA478(CODIGO);                                          
CREATE INDEX TA478_2 ON TA478(DESCRIPCIO);                                      
   
/* TA479( TABLAS DE TIPO DE CERTIFICADO DE ORIGEN )*/                           
CREATE TABLE IF NOT EXISTS TA479(                                               
   CODIGO      CHAR(1) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(61) DEFAULT "",                                          
   DESCRIPC2   VARCHAR(61) DEFAULT "",                                          
   PAIS        CHAR(2) NOT NULL,
   ESTADO      VARCHAR(15) DEFAULT "",                                                
   PRIMARY KEY(CODIGO,PAIS));                                                        
CREATE INDEX TA479_1 ON TA479(CODIGO);                                          
CREATE INDEX TA479_2 ON TA479(DESCRIPCIO);                                      
   
/* TA480( TABLAS DE TIPO DE EMISOR DEL CERTIFICADO DE ORIGEN )*/                
CREATE TABLE IF NOT EXISTS TA480(                                               
   CODIGO      CHAR(1) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(30) DEFAULT "",                                          
   PAIS        CHAR(2) NOT NULL,                                                
   PRIMARY KEY(CODIGO,PAIS));                                                        
CREATE INDEX TA480_1 ON TA480(CODIGO);                                          
CREATE INDEX TA480_2 ON TA480(DESCRIPCIO);                                      

/* TA481( TABLAS DE CRITERIO DE ORIGEN )*/                                      
CREATE TABLE IF NOT EXISTS TA481(                                               
   CODIGO      CHAR(1) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(68) DEFAULT "",                                          
   DESCRIPC2   VARCHAR(68) DEFAULT "",                                          
   DESCRIPC3   VARCHAR(68) DEFAULT "",                                          
   PAIS        CHAR(2) NOT NULL,                                                
   PRIMARY KEY(CODIGO,PAIS));                                                        
CREATE INDEX TA481_1 ON TA481(CODIGO);                                          
CREATE INDEX TA481_2 ON TA481(DESCRIPCIO);                                      
                                      
/* TA482( TABLAS DE INDICADOR DE TRANSITO O TRANSBORDO EN UN 3ER PAIS )*/       
CREATE TABLE IF NOT EXISTS TA482(                                               
   CODIGO      CHAR(1) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(68) DEFAULT "",                                          
   DESCRIPC2   VARCHAR(68) DEFAULT "",                                          
   PAIS        CHAR(2) NOT NULL,                                                
   PRIMARY KEY(CODIGO,PAIS));                                                        
CREATE INDEX TA482_1 ON TA482(CODIGO);                                          
CREATE INDEX TA482_2 ON TA482(DESCRIPCIO);                                      
                                                                                
/* TA483( TABLAS DE CRONOGRAMA TLC - EE.UU. )*/                                 
CREATE TABLE IF NOT EXISTS TA483(                                               
   CODIGO      CHAR(5) NOT NULL,                                                
   MPO         DECIMAL(6,2) DEFAULT 0.00,                                       
   FECH_INI    DATE,                                                            
   FECH_TER    DATE,                   
   ORDEN       CHAR(2) NOT NULL,                                         
   PRIMARY KEY(CODIGO,ORDEN));                                                        
CREATE INDEX TA483_1 ON TA483(CODIGO);                                          
                           
/* TA484( TABLAS DE PARTIDAS DEL TLC - EE.UU. )*/                               
CREATE TABLE IF NOT EXISTS TA484(                                               
   PARTIDA     CHAR(10) NOT NULL,                                               
   DESCRIPC    VARCHAR(140) DEFAULT "",                                         
   BASE        NUMERIC(4,0) DEFAULT 0,                                          
   MPO         CHAR(2) DEFAULT "",                                              
   TM          CHAR(5) DEFAULT "",                                              
   OB1         VARCHAR(16) DEFAULT "",                                          
   OB2         VARCHAR(65) DEFAULT "",                                          
   PARTIDA_AN  CHAR(10) DEFAULT "",                                             
   DESCRIP2    VARCHAR(140) DEFAULT "",                                         
   PRIMARY KEY(PARTIDA,DESCRIPC));                                                       
CREATE INDEX TA484_1 ON TA484(PARTIDA);                                         
                               
/* TA485( TABLAS DE CODIGOS DE GUARDA CUSTODIA PARA SENASA IMPORTACION )*/      
CREATE TABLE IF NOT EXISTS TA485(                                               
   CODIGO      CHAR(1) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(40) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA485_1 ON TA485(CODIGO);                                          
CREATE INDEX TA485_2 ON TA485(DESCRIPCIO);                                      
                                                                                
/* TA486( TABLAS DE PARTIDAS PROHIBIDAS DE IMPORTAR DE ECUADOR )*/              
CREATE TABLE IF NOT EXISTS TA486(                                               
   PARTIDA     CHAR(10) NOT NULL,                                               
   DESCRIPCIO  VARCHAR(80) DEFAULT "",                                          
   DESCRIPCI2  VARCHAR(80) DEFAULT "",                                          
   DESCRIPCI3  VARCHAR(80) DEFAULT "",                                          
   PARTIDA_AN  CHAR(10) DEFAULT "",
   PRIMARY KEY(PARTIDA));                                                       
CREATE INDEX TA486_1 ON TA486(PARTIDA);                                         
CREATE INDEX TA486_2 ON TA486(DESCRIPCIO);                                      
                                                                                
/* TA493( TABLAS DE TIPO DE MERCANCIAS PARA SOLICITUD DE AFORO )*/              
CREATE TABLE IF NOT EXISTS TA493(                                               
   CODIGO      CHAR(2) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(60) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA493_1 ON TA493(CODIGO);                                          
CREATE INDEX TA493_2 ON TA493(DESCRIPCIO);                                      
                                                                                
/* TA494( TABLAS DE CODIGO DE OPERACION PARA RECEPCION DE ALMACENES )*/         
CREATE TABLE IF NOT EXISTS TA494(                                               
   CODIGO      CHAR(2) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(60) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA494_1 ON TA494(CODIGO);                                          
CREATE INDEX TA494_2 ON TA494(DESCRIPCIO);                                      

/* TA495( TABLAS DE PARTIDAS CON ROTULADO ESPECIAL )*/                          
CREATE TABLE IF NOT EXISTS TA495(                                               
   PARTIDA     CHAR(10) NOT NULL,                                               
   DESCRIPCIO  VARCHAR(150) DEFAULT "",                                          
   DESCRIPCI2  VARCHAR(55) DEFAULT "",                                          
   PRIMARY KEY(PARTIDA,DESCRIPCIO));                                                       
CREATE INDEX TA495_1 ON TA495(PARTIDA);                                         
CREATE INDEX TA495_2 ON TA495(DESCRIPCIO);                                      

/* TA496( TABLAS DE NIVEL DE CALIFICACION )*/                                   
CREATE TABLE IF NOT EXISTS TA496(                                               
   CODIGO      CHAR(1) NOT NULL,                                                
   DESCRIPCIO  CHAR(8) DEFAULT "",                                              
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA496_1 ON TA496(CODIGO);                                          
CREATE INDEX TA496_2 ON TA496(DESCRIPCIO);                                      
                                                                                
/* TA497( TABLAS DE TIPO DE DOCUMENTOS PARA LA DIGITALIZACION )*/               
CREATE TABLE IF NOT EXISTS TA497(                                               
   CODIGO      CHAR(1) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(140) DEFAULT "",                                         
   TIPO_DOC    CHAR(3) DEFAULT "",                                              
   MODIFICA    CHAR(1) DEFAULT "",                                              
   REGIMEN     CHAR(2) NOT NULL,                                              
   PRIMARY KEY(REGIMEN,CODIGO));                                                        
CREATE INDEX TA497_1 ON TA497(REGIMEN,CODIGO);                                          
CREATE INDEX TA497_2 ON TA497(DESCRIPCIO);                                      
CREATE INDEX TA497_3 ON TA497(TIPO_DOC);                                        
   
/* TA500( TABLAS DE CRONOGRAMA TLC - CANADA )*/                                 
CREATE TABLE IF NOT EXISTS TA500(                                               
   CODIGO      CHAR(5) NOT NULL,                                                
   MPO         DECIMAL(6,2) DEFAULT 0.00,                                       
   FECH_INI    DATE,                                                            
   FECH_TER    DATE,            
   ORDEN       CHAR(2) NOT NULL,                                                                                                
   PRIMARY KEY(CODIGO,ORDEN));                                                        
CREATE INDEX TA500_1 ON TA500(CODIGO);                                          
                           
/* TA501( TABLAS DE PARTIDAS TLC - CANADA )*/                                   
CREATE TABLE IF NOT EXISTS TA501(                                               
   PARTIDA     CHAR(10) NOT NULL,                                               
   DESCRIPC    VARCHAR(60) DEFAULT "",                                          
   DESCRIPC2   VARCHAR(60) DEFAULT "",                                          
   DESCRIPC3   VARCHAR(60) DEFAULT "",                                          
   DESCRIPC4   VARCHAR(60) DEFAULT "",                                          
   BASE        NUMERIC(4,0) DEFAULT 0,                                          
   MPO         CHAR(2) DEFAULT "",                                              
   TM          CHAR(5) DEFAULT "",                                              
   OB1         VARCHAR(45) DEFAULT "",                                          
   OB2         VARCHAR(65) DEFAULT "",                                          
   PARTIDA_A   CHAR(10) DEFAULT "",                                             
   PARTIDA_AN  CHAR(10) DEFAULT "",                                             
   PRIMARY KEY(PARTIDA,BASE,MPO,DESCRIPC,DESCRIPC2,DESCRIPC3,TM));                                                       
CREATE INDEX TA501_1 ON TA501(PARTIDA);                                         

/* TA502( TABLAS DE CRONOGRAMA ACUERDO - SINGAPUR )*/                           
CREATE TABLE IF NOT EXISTS TA502(                                               
   CODIGO      CHAR(5) NOT NULL,                                                
   MPO         DECIMAL(6,2) DEFAULT 0.00,                                       
   FECH_INI    DATE,                                                            
   FECH_TER    DATE,                                                            
   ORDEN       CHAR(2) NOT NULL,                                                                                                
   PRIMARY KEY(CODIGO,ORDEN));                                                        
CREATE INDEX TA502_1 ON TA502(CODIGO);                                          

/* TA503( TABLAS DE PARTIDAS ACUERDO - SINGAPUR )*/                             
CREATE TABLE IF NOT EXISTS TA503(                                               
   PARTIDA     CHAR(10) NOT NULL,                                               
   DESCRIPC    VARCHAR(60) DEFAULT "",                                          
   DESCRIPC2   VARCHAR(60) DEFAULT "",                                          
   DESCRIPC3   VARCHAR(60) DEFAULT "",                                          
   DESCRIPC4   VARCHAR(60) DEFAULT "",                                          
   BASE        NUMERIC(4,0) DEFAULT 0,                                          
   MPO         CHAR(2) DEFAULT "",                                              
   TM          CHAR(5) DEFAULT "",                                              
   OB1         VARCHAR(45) DEFAULT "",                                          
   OB2         VARCHAR(65) DEFAULT "",                                          
   PARTIDA_A   CHAR(10) DEFAULT "",                                             
   PARTIDA_AN  CHAR(10) DEFAULT "",                                             
   PRIMARY KEY(PARTIDA,BASE,MPO,DESCRIPC,DESCRIPC2,DESCRIPC3,TM));                                                       
CREATE INDEX TA503_1 ON TA503(PARTIDA);                                         
 
/* TA504( TABLAS DE PARTIDAS SUSPENDIDAS DE IMPORTAR DE ECUADOR )*/             
CREATE TABLE IF NOT EXISTS TA504(                                               
   PARTIDA     VARCHAR(11) NOT NULL,                                            
   MERCANCIA   VARCHAR(200) DEFAULT "",                                         
   PRIMARY KEY(PARTIDA));                                                       
CREATE INDEX TA504_1 ON TA504(PARTIDA);                                         
                                                                                
/* TA506( TABLAS DE TIPO DE ROL DEL DECLARANTE IMPORTADOR (XML-123) )*/         
CREATE TABLE IF NOT EXISTS TA506(                                               
   CODIGO      CHAR(2) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(50) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA506_1 ON TA506(CODIGO);                                          
CREATE INDEX TA506_2 ON TA506(DESCRIPCIO);                                      
                                                                                
/* TA507( TABLAS DE TIPO DE GASTO DE HOJA DE VEHICULO (XML-331) )*/             
CREATE TABLE IF NOT EXISTS TA507(                                               
   CODIGO      CHAR(2) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(65) DEFAULT "",                                          
   CAMPO_SIS   VARCHAR(45) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA507_1 ON TA507(CODIGO);                                          
CREATE INDEX TA507_2 ON TA507(DESCRIPCIO);                                      
                                                                                
/* TA508( TABLAS DE TIPO DE INDICADOR DE  COMUN (XML-302) )*/                   
CREATE TABLE IF NOT EXISTS TA508(                                               
   CODIGO      CHAR(2) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(90) DEFAULT "",                                          
   CAMPO_SIS   CHAR(10) DEFAULT "",                                             
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA508_1 ON TA508(CODIGO);                                          
CREATE INDEX TA508_2 ON TA508(DESCRIPCIO);                                      
                                                                                
/* TA509( TABLAS DE TIPO DE OBSERVACIONES (XML-369) )*/                         
CREATE TABLE IF NOT EXISTS TA509(                                               
   CODIGO      CHAR(2) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(50) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA509_1 ON TA509(CODIGO);                                          
CREATE INDEX TA509_2 ON TA509(DESCRIPCIO);                                      
                                                                                
/* TA510( TABLAS DE CAMPOS DE DETERMINACION DE LA TRANSACCION (XML-J3) )*/      
CREATE TABLE IF NOT EXISTS TA510(                                               
   CODIGO      CHAR(2) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(90) DEFAULT "",                                          
   CAMPO_SIS   VARCHAR(90) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA510_1 ON TA510(CODIGO);                                          
CREATE INDEX TA510_2 ON TA510(DESCRIPCIO);                                      
                                                                                
/* TA511( TABLAS DE RELACION DE ATRIBUTOS PARA LAS DESCRIP (XML-320) )*/        
CREATE TABLE IF NOT EXISTS TA511(                                               
   CODIGO      CHAR(2) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(90) DEFAULT "",                                          
   CAMPO_SIS   VARCHAR(40) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA511_1 ON TA511(CODIGO);                                          
CREATE INDEX TA511_2 ON TA511(DESCRIPCIO);                                      
                                                                                
/* TA512( TABLAS DE CONDICIONES DE LA TRANSACCION (XML-301) )*/                 
CREATE TABLE IF NOT EXISTS TA512(                                               
   CODIGO      CHAR(2) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(90) DEFAULT "",                                          
   CAMPO_SIS   CHAR(10) DEFAULT "",                                             
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA512_1 ON TA512(CODIGO);                                          
CREATE INDEX TA512_2 ON TA512(DESCRIPCIO);                                      
                                                                                
/* TA513( TABLAS DE EXONERACION DE MERCANCIA RESTRINGIDA (XML-18) )*/           
CREATE TABLE IF NOT EXISTS TA513(                                               
   CODIGO      CHAR(2) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(90) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA513_1 ON TA513(CODIGO);                                          
CREATE INDEX TA513_2 ON TA513(DESCRIPCIO);                                      
                                                                                
/* TA514( TABLAS DE TIPOS DE ENTIDAD EMISORA (XML-334) )*/                      
CREATE TABLE IF NOT EXISTS TA514(                                               
   CODIGO      CHAR(1) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(40) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA514_1 ON TA514(CODIGO);                                          
CREATE INDEX TA514_2 ON TA514(DESCRIPCIO);                                      
                                                                                
/* TA515( TABLAS DE TIPO DE DOCUMENTO DE ENTIDAD PARTICIPANTE (XML-27) )*/      
CREATE TABLE IF NOT EXISTS TA515(                                               
   CODIGO      CHAR(2) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(90) DEFAULT "",
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA515_1 ON TA515(CODIGO);                                          
CREATE INDEX TA515_2 ON TA515(DESCRIPCIO);                                      
                                                                                
/* TA516( TABLAS DE CODIGOS DE ENTIDAD EMISORA AUTORIZANTE (XML-49) )*/         
CREATE TABLE IF NOT EXISTS TA516(                                               
   CODIGO      CHAR(2) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(50) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA516_1 ON TA516(CODIGO);                                          
CREATE INDEX TA516_2 ON TA516(DESCRIPCIO);                                      
                                                                                
/* TA517( TABLAS DE C�DIGO DE TIPO DE MANIFIESTO (XML-202) )*/                  
CREATE TABLE IF NOT EXISTS TA517(                                               
   CODIGO      CHAR(2) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(15) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA517_1 ON TA517(CODIGO);                                          
CREATE INDEX TA517_2 ON TA517(DESCRIPCIO);                                      
                                                                                
/* TA518( TABLAS DE TIPO DE MECANISMO DE PAGO POR SAIDA (XML-366) )*/           
CREATE TABLE IF NOT EXISTS TA518(                                               
   CODIGO      CHAR(1) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(20) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA518_1 ON TA518(CODIGO);                                          
CREATE INDEX TA518_2 ON TA518(DESCRIPCIO);                                      
                                                                                
/* TA519( TABLAS DE TAMA�O DE EQUIPAMIENTO (XML-209) )*/                        
CREATE TABLE IF NOT EXISTS TA519(                                               
   CODIGO      CHAR(4) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(50) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA519_1 ON TA519(CODIGO);                                          
CREATE INDEX TA519_2 ON TA519(DESCRIPCIO);                                      
                                                                                
/* TA520( TABLAS DE CONDICI�N DE EQUIPAMIENTO (XML-210) )*/                     
CREATE TABLE IF NOT EXISTS TA520(                                               
   CODIGO      CHAR(2) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(39) DEFAULT "",                                          
   DESCRIPCI2  VARCHAR(95) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA520_1 ON TA520(CODIGO);                                          
CREATE INDEX TA520_2 ON TA520(DESCRIPCIO);                                      
                                                                                
/* TA521( TABLAS DE INDICADOR DECLARACION JURADA O FACTURA (XML-323) )*/        
CREATE TABLE IF NOT EXISTS TA521(                                               
   COD         CHAR(1) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(39) DEFAULT "",                                          
   PRIMARY KEY(COD));                                                           
CREATE INDEX TA521_1 ON TA521(COD);                                             
CREATE INDEX TA521_2 ON TA521(DESCRIPCIO);                                      
                                               
/* TA522( TABLAS DE TIPO DE OPERACION DE LA DUIM (XMLMANFIESTO) )*/             
CREATE TABLE IF NOT EXISTS TA522(                                               
   CODIGO      CHAR(4) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(45) DEFAULT "",                                          
   POSICION    CHAR(4) DEFAULT "",                                              
   CAMPO       CHAR(10) DEFAULT "",                                             
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA522_1 ON TA522(CODIGO);                                          
CREATE INDEX TA522_2 ON TA522(DESCRIPCIO);                                      
                                                                                
/* TA523( TABLAS DE ESTADO DEL CONTENEDOR DEL LA DUIM (XMLMANIFIESTO) )*/       
CREATE TABLE IF NOT EXISTS TA523(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(39) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA523_1 ON TA523(CODIGO);                                          
CREATE INDEX TA523_2 ON TA523(DESCRIPCIO);                                      
                                                                                
/* TA524( TABLAS DE SITUACION DEL CONTENEDOR/BL (XMLMANIFIESTO) )*/             
CREATE TABLE IF NOT EXISTS TA524(                                               
   CODIGO      CHAR(1) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(39) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA524_1 ON TA524(CODIGO);                                          
CREATE INDEX TA524_2 ON TA524(DESCRIPCIO);                                      
                                                                                
/* TA525( TABLAS DE CONDICION DEL PRECINTO (XMLMANIFIESTO) )*/                  
CREATE TABLE IF NOT EXISTS TA525(                                               
   CODIGO      CHAR(1) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(39) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA525_1 ON TA525(CODIGO);                                          
CREATE INDEX TA525_2 ON TA525(DESCRIPCIO);                                      
                                                                                
/* TA526( TABLAS DE ENTIDAD DE COLOCA EL PRECINTO (XMLMAMINIFIESTO) )*/         
CREATE TABLE IF NOT EXISTS TA526(                                               
   CODIGO      CHAR(2) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(39) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA526_1 ON TA526(CODIGO);                                          
CREATE INDEX TA526_2 ON TA526(DESCRIPCIO);                                      
                                                                                
/* TA527( TABLAS DE TIPO DE MANIFIESTO (XMLMANIFIESTO) )*/                      
CREATE TABLE IF NOT EXISTS TA527(                                               
   CODIGO      CHAR(2) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(39) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA527_1 ON TA527(CODIGO);                                          
CREATE INDEX TA527_2 ON TA527(DESCRIPCIO);                                      
                                                                                
/* TA528( TABLAS DE ULTIMO ENVIO (XMLMANIFIESTO) )*/                            
CREATE TABLE IF NOT EXISTS TA528(                                               
   CODIGO      CHAR(2) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(39) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA528_1 ON TA528(CODIGO);                                          
CREATE INDEX TA528_2 ON TA528(DESCRIPCIO);                                      

/* TA529( TABLAS DE TIPO DE CARGA (XMLMANIFIESTO) )*/                           
CREATE TABLE IF NOT EXISTS TA529(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(60) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA529_1 ON TA529(CODIGO);                                          
CREATE INDEX TA529_2 ON TA529(DESCRIPCIO);                                      
                                                                                
/* TA530( TABLAS DE TIPO DE ENVIO (XMLMANIFIESTO) )*/                           
CREATE TABLE IF NOT EXISTS TA530(                                               
   CODIGO      CHAR(1) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(40) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA530_1 ON TA530(CODIGO);                                          
CREATE INDEX TA530_2 ON TA530(DESCRIPCIO);                                      
                                                                                
/* TA532( TABLAS DE INDICADOR DE PROHIBIDO Y RESTRINGIDO (XML-333) )*/          
CREATE TABLE IF NOT EXISTS TA532(                                               
   CODIGO      CHAR(1) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(39) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA532_1 ON TA532(CODIGO);                                          
CREATE INDEX TA532_2 ON TA532(DESCRIPCIO);                                      
                                                                                
/* TA533( TABLAS DE TIPO DE MECANISMO DE PAGO SAIDA (XML-366) )*/               
CREATE TABLE IF NOT EXISTS TA533(                                               
   CODIGO      CHAR(1) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(39) DEFAULT "",                                          
   STATUS      CHAR(10) DEFAULT "",                                             
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA533_1 ON TA533(CODIGO);                                          
CREATE INDEX TA533_2 ON TA533(DESCRIPCIO);                                      
                                                                                
/* TA536( TABLAS DE NUEVA TABLA DE DERECHO ESPECIFICO 01.01.2010 )*/            
CREATE TABLE IF NOT EXISTS TA536(                                               
   CODIGO      CHAR(2) NOT NULL,                                                
   FOB_REF1    CHAR(4) NOT NULL,                                                
   FOB_REF2    CHAR(4) DEFAULT "",                                              
   DER_ESP1    NUMERIC(5,0) DEFAULT 0,                                          
   DER_ESP2    NUMERIC(4,0) DEFAULT 0,                                          
   PRIMARY KEY(CODIGO,FOB_REF1));                                               
CREATE INDEX TA536_1 ON TA536(CODIGO,FOB_REF1);                                 
                                                                                
/* TA538( TABLAS DE TIPO ENVIO-TRASLADO DIRECTO DE CARGA A TERMINALES )*/       
CREATE TABLE IF NOT EXISTS TA538(                                               
   CODIGO      CHAR(1) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(15) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA538_1 ON TA538(CODIGO);                                          
CREATE INDEX TA538_2 ON TA538(DESCRIPCIO);            
                                                                                
/* TA539( TABLAS DE PARTIDAS TLC - CHINA )*/                                    
CREATE TABLE IF NOT EXISTS TA539(                                               
   PARTIDA     CHAR(10) NOT NULL,                                               
   DES1        VARCHAR(60) DEFAULT "",                                          
   DES2        VARCHAR(60) DEFAULT "",                                          
   DES3        VARCHAR(60) DEFAULT "",                                          
   DES4        VARCHAR(60) DEFAULT "",                                          
   DES5        VARCHAR(60) DEFAULT "",                                          
   DES6        VARCHAR(60) DEFAULT "",                                          
   DES7        VARCHAR(60) DEFAULT "",                                          
   DES8        VARCHAR(60) DEFAULT "",                                          
   DES10       VARCHAR(60) DEFAULT "",                                          
   DES9        VARCHAR(60) DEFAULT "",                                          
   BASE        NUMERIC(4,0) DEFAULT 0,                                          
   MPO         CHAR(2) DEFAULT "",                                              
   TM          CHAR(5) DEFAULT "",                                              
   OB1         VARCHAR(45) DEFAULT "",                                          
   PARTIDA_AN  CHAR(10) DEFAULT "",
   PRIMARY KEY(PARTIDA,BASE,MPO,DES1,DES2,DES3,TM));                                                       
CREATE INDEX TA539_1 ON TA539(PARTIDA);                                         
                   
/* TA540( TABLAS DE CRONOGRAMA TLC - CHINA )*/                                  
CREATE TABLE IF NOT EXISTS TA540(                                               
   CODIGO      CHAR(5) NOT NULL,                                                
   MPO         DECIMAL(6,2) DEFAULT 0.00,                                       
   FECH_INI    DATE,                                                            
   FECH_TER    DATE,   
   ORDEN       CHAR(2) NOT NULL,                                                
   PRIMARY KEY(CODIGO,ORDEN));                                                        
CREATE INDEX TA540_1 ON TA540(CODIGO);                                          
                           
/* TA541( TABLAS DE TABLA DE MODALIDAD )*/                                      
CREATE TABLE IF NOT EXISTS TA541(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(28) DEFAULT "",                                          
   REGIMEN     CHAR(2) DEFAULT "",                                              
   PRIMARY KEY(CODIGO,REGIMEN));                                                        
CREATE INDEX TA541_1 ON TA541(CODIGO);                                          
CREATE INDEX TA541_2 ON TA541(DESCRIPCIO);                                      

/* TA542( TABLAS DE TABLA DE TIPO DE DESPACHO )*/                               
CREATE TABLE IF NOT EXISTS TA542(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(65) DEFAULT "",                                          
   REGIMEN     CHAR(2) DEFAULT "",                                              
   PRIMARY KEY(CODIGO,REGIMEN));                                                        
CREATE INDEX TA542_1 ON TA542(CODIGO);                                          
CREATE INDEX TA542_2 ON TA542(DESCRIPCIO);                                      

/* TA543( TABLAS DE ESTADO DE MERCANC�A - XML )*/                               
CREATE TABLE IF NOT EXISTS TA543(                                               
   COD         CHAR(2) NOT NULL,                                                
   EST_MERC    VARCHAR(20) DEFAULT "",                                          
   TIPO        CHAR(2) DEFAULT "",                                              
   ANTERIOR    CHAR(2) DEFAULT "",                                              
   FECHAINI    DATE,                                                            
   FECHAFIN    DATE,                                                            
   ESTADO      CHAR(10) DEFAULT "",                                             
   PRIMARY KEY(COD));                                                           
CREATE INDEX TA543_1 ON TA543(COD);                                             
CREATE INDEX TA543_2 ON TA543(EST_MERC);                                        

/* TA544( LOCALES ANEXOS DE LOS ALMACENES - XML              )*/                      
CREATE TABLE IF NOT EXISTS TA544(                                               
   CODIGO      CHAR(4) NOT NULL,                                                
   LUG_ENTREG  VARCHAR(90) DEFAULT "",                                         
   COD_ALMA    CHAR(6) NOT NULL,  
   PRIMARY KEY(COD_ALMA,CODIGO),
   CONSTRAINT FK_TA544_TA60 FOREIGN KEY(COD_ALMA) REFERENCES TA60(COD));                                                        
CREATE INDEX TA544_1 ON TA544(COD_ALMA,CODIGO);                                          
CREATE INDEX TA544_2 ON TA544(LUG_ENTREG);                                                                                                                

/* TA545( TABLAS DE STATUS DE VALIDACION DE RESPUESTAS )*/                      
CREATE TABLE IF NOT EXISTS TA545(                                               
   CODIGO      CHAR(2) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(110) DEFAULT "",                                         
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA545_1 ON TA545(CODIGO);                                          
CREATE INDEX TA545_2 ON TA545(DESCRIPCIO);                                      
                                                                                
/* TA547( TABLAS DE TIPO DE LUGAR DE SALIDA Y LLEGADA  XML-MANIF )*/            
CREATE TABLE IF NOT EXISTS TA547(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   CAMPO1      VARCHAR(70) DEFAULT "",                                          
   CAMPO2      VARCHAR(70) DEFAULT "",                                          
   CAMPO3      VARCHAR(70) DEFAULT "",                                          
   CAMPO4      VARCHAR(70) DEFAULT "",                                          
   CAMPO5      VARCHAR(70) DEFAULT "",                                          
   CAMPO6      VARCHAR(70) DEFAULT "",                                          
   CAMPO7      VARCHAR(70) DEFAULT "",                                          
   CAMPO8      VARCHAR(70) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA547_1 ON TA547(CODIGO);                                          
CREATE INDEX TA547_2 ON TA547(CAMPO1);                                          

/* TA548( TABLAS DE TIPO DE DOCUMENTO DE TRANSPORTE MARTER XML-MANIF )*/        
CREATE TABLE IF NOT EXISTS TA548(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(50) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA548_1 ON TA548(CODIGO);                                          
CREATE INDEX TA548_2 ON TA548(DESCRIPCIO);                                      
                                                                                
/* TA549( TABLAS DE TIPO DE ALMACEN XML-MANIF )*/                               
CREATE TABLE IF NOT EXISTS TA549(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(50) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA549_1 ON TA549(CODIGO);                                          
CREATE INDEX TA549_2 ON TA549(DESCRIPCIO);                                      
                                                                                
/* TA550( TABLAS DE TIPO DE CONSIGNATARIO XML-MANIF )*/                         
CREATE TABLE IF NOT EXISTS TA550(                                               
   CODIGO      CHAR(2) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(50) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA550_1 ON TA550(CODIGO);                                          
CREATE INDEX TA550_2 ON TA550(DESCRIPCIO);                                      
                                                                                
/* TA551( TABLAS DE NATURALEZA DE LA CARGA XML-MANIF )*/                        
CREATE TABLE IF NOT EXISTS TA551(                                               
   CODIGO      CHAR(2) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(55) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA551_1 ON TA551(CODIGO);                                          
CREATE INDEX TA551_2 ON TA551(DESCRIPCIO);                                      
                                                                                
/* TA552( TABLAS DE DESTINACION DE LA CARGA XML-MANIF )*/                       
CREATE TABLE IF NOT EXISTS TA552(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   CAMPO1      VARCHAR(90) DEFAULT "",                                          
   CAMPO2      VARCHAR(90) DEFAULT "",                                          
   CAMPO3      VARCHAR(90) DEFAULT "",                                          
   CAMPO4      VARCHAR(90) DEFAULT "",                                          
   CAMPO5      VARCHAR(90) DEFAULT "",                                          
   CAMPO6      VARCHAR(90) DEFAULT "",                                          
   CAMPO7      VARCHAR(90) DEFAULT "",                                          
   CAMPO8      VARCHAR(90) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA552_1 ON TA552(CODIGO);                                          
CREATE INDEX TA552_2 ON TA552(CAMPO1);                                          
                                                                                
/* TA553( TABLAS DE CONDICIONES DEL CONTRATO XML-MANIF )*/                      
CREATE TABLE IF NOT EXISTS TA553(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   CAMPO1      VARCHAR(90) DEFAULT "",                                          
   CAMPO2      VARCHAR(90) DEFAULT "",                                          
   CAMPO3      VARCHAR(90) DEFAULT "",                                          
   CAMPO4      VARCHAR(90) DEFAULT "",                                          
   CAMPO5      VARCHAR(90) DEFAULT "",                                          
   CAMPO6      VARCHAR(90) DEFAULT "",                                          
   CAMPO7      VARCHAR(90) DEFAULT "",                                          
   CAMPO8      VARCHAR(90) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA553_1 ON TA553(CODIGO);                                          
CREATE INDEX TA553_2 ON TA553(CAMPO1);                                          
                                                                                
/* TA554( TABLAS DE REQUERIMIENTO DE SERVICIO XML-MANIF )*/                     
CREATE TABLE IF NOT EXISTS TA554(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   CAMPO1      VARCHAR(90) DEFAULT "",                                          
   CAMPO2      VARCHAR(90) DEFAULT "",                                          
   CAMPO3      VARCHAR(90) DEFAULT "",                                          
   CAMPO4      VARCHAR(90) DEFAULT "",                                          
   CAMPO5      VARCHAR(90) DEFAULT "",                                          
   CAMPO6      VARCHAR(90) DEFAULT "",                                          
   CAMPO7      VARCHAR(90) DEFAULT "",                                          
   CAMPO8      VARCHAR(90) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA554_1 ON TA554(CODIGO);                                          
CREATE INDEX TA554_2 ON TA554(CAMPO1);                                          
                                                                                
/* TA555( TABLAS DE ENTIDAD REGULADORA DE MERC. PELIGROSA XML-MANNIF )*/        
CREATE TABLE IF NOT EXISTS TA555(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(90) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA555_1 ON TA555(CODIGO);                                          
CREATE INDEX TA555_2 ON TA555(DESCRIPCIO);                                      
                                                                                
/* TA556( TABLAS DE TIPO DE FLETE XML-MANIF )*/                                 
CREATE TABLE IF NOT EXISTS TA556(                                               
   CODIGO      CHAR(6) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(55) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA556_1 ON TA556(CODIGO);                                          
CREATE INDEX TA556_2 ON TA556(DESCRIPCIO);                                      
                                                                                
/* TA557( TABLAS DE TIPO DE PAGO DE FLETE )*/                                   
CREATE TABLE IF NOT EXISTS TA557(                                               
   CODIGO      CHAR(2) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(55) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA557_1 ON TA557(CODIGO);                                          
CREATE INDEX TA557_2 ON TA557(DESCRIPCIO);                                      
                                                                                
/* TA559( TABLAS DE TIPOS DE BULTOS PARA MANIFIESTO XML-MANIF )*/               
CREATE TABLE IF NOT EXISTS TA559(                                               
   CODIGO      CHAR(2) NOT NULL,                                                
   CAMPO1      VARCHAR(100) DEFAULT "",                                         
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA559_1 ON TA559(CODIGO);                                          
CREATE INDEX TA559_2 ON TA559(CAMPO1);                                          
                                                                                
/* TA560( TABLAS DE TIPOS DE TRANSACION MANIFIESTO XML-MANIF )*/                
CREATE TABLE IF NOT EXISTS TA560(                                               
   CODIGO      CHAR(2) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(75) DEFAULT "",                                          
   POSICION    CHAR(1) DEFAULT "",                                              
   ABREV       CHAR(3) DEFAULT "", /* Abreviatura */                                              
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA560_1 ON TA560(CODIGO);                                          
CREATE INDEX TA560_2 ON TA560(DESCRIPCIO);                                      

/* TA561( TABLAS DE TIPO DE PUNTO DE LLEGADA )*/                                
CREATE TABLE IF NOT EXISTS TA561(                                               
   CODIGO      CHAR(1) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(45) DEFAULT "",                                          
   TIPO        CHAR(1) DEFAULT "",                                              
   PRIMARY KEY(CODIGO,TIPO));                                                        
CREATE INDEX TA561_1 ON TA561(CODIGO);                                          
CREATE INDEX TA561_2 ON TA561(DESCRIPCIO);                                      
                                    
/* TA562( TABLAS DE NOMBRE COMERCIAL SANITARIOS )*/                             
CREATE TABLE IF NOT EXISTS TA562(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(44) DEFAULT "",                                          
   DESCRIPCI2  VARCHAR(20) DEFAULT "",                                          
   PARTIDA     CHAR(10) DEFAULT "",                                             
   PRIMARY KEY(CODIGO,PARTIDA));                                                        
CREATE INDEX TA562_1 ON TA562(CODIGO);                                          
CREATE INDEX TA562_2 ON TA562(DESCRIPCIO);                                      
                             
/* TA563( TABLAS DE TIPO DE SANITARIOS )*/                                      
CREATE TABLE IF NOT EXISTS TA563(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(31) DEFAULT "",                                          
   DESCRIPCI2  VARCHAR(20) DEFAULT "",                                          
   TIPO        CHAR(3) DEFAULT "",                                              
   COD_SAN     CHAR(3) DEFAULT "",
   CODSOFTPAD  CHAR(3) DEFAULT "",                                                                                        
   PRIMARY KEY(CODIGO,TIPO,COD_SAN));                                                        
CREATE INDEX TA563_1 ON TA563(CODIGO);                                          
CREATE INDEX TA563_2 ON TA563(DESCRIPCIO);                                      
                          
/* TA564( TABLAS DE CALIDAD DE SANITARIOS )*/                                   
CREATE TABLE IF NOT EXISTS TA564(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(18) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA564_1 ON TA564(CODIGO);                                          
CREATE INDEX TA564_2 ON TA564(DESCRIPCIO);                                      
                                                                                
/* TA565( TABLAS DE COLORES DE SANITARIOS )*/                                   
CREATE TABLE IF NOT EXISTS TA565(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(18) DEFAULT "",                                          
   NENVIO      CHAR(3) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));  
CREATE INDEX TA565_1 ON TA565(CODIGO);                                          
CREATE INDEX TA565_2 ON TA565(DESCRIPCIO);                                      
                                                                                
/* TA566( TABLAS DE MATERIAL DE SANITARIOS )*/                                  
CREATE TABLE IF NOT EXISTS TA566(                                           
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(40) DEFAULT "",                                          
   NENVIO      CHAR(3) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA566_1 ON TA566(CODIGO);                                          
CREATE INDEX TA566_2 ON TA566(DESCRIPCIO);                                      
                                                                                
/* TA567( TABLAS DE CONSUMO DE AGUA DE SANITARIOS )*/                           
CREATE TABLE IF NOT EXISTS TA567(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(20) DEFAULT "",                                          
   DESCRIPCI2  VARCHAR(20) DEFAULT "",                                          
   COD_SAN     CHAR(3) DEFAULT "",                                              
   PRIMARY KEY(CODIGO,COD_SAN));                                                        
CREATE INDEX TA567_1 ON TA567(CODIGO);                                          
CREATE INDEX TA567_2 ON TA567(DESCRIPCIO);                                      
                             
/* TA568( TABLAS DE NOMBRE COMERCIAL BALDOSAS )*/                               
CREATE TABLE IF NOT EXISTS TA568(                                               
   CODIGO      CHAR(4) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(30) DEFAULT "",                                          
   PARTIDA     CHAR(10) DEFAULT "",                                             
   TIP_BLD     CHAR(3) DEFAULT "",                                              
   CODSOFTPAD  CHAR(3) DEFAULT "",
   PARTIDA_AN  CHAR(10) DEFAULT "",                                              
   NENVIO      CHAR(3) DEFAULT "",                                                                                   
   PRIMARY KEY(CODIGO,PARTIDA));                                                        
CREATE INDEX TA568_1 ON TA568(CODIGO);                                          
CREATE INDEX TA568_2 ON TA568(DESCRIPCIO);   
     
/* TA569( TABLAS DE TIPO DE ACABADO BALDOSAS )*/   
CREATE TABLE IF NOT EXISTS TA569(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(45) DEFAULT "",                                          
   TIP_BLD     CHAR(3) DEFAULT "",                                              
   NENVIO      CHAR(3) DEFAULT "",                                          
   PRIMARY KEY(CODIGO,TIP_BLD));                                                        
CREATE INDEX TA569_1 ON TA569(CODIGO);                                          
CREATE INDEX TA569_2 ON TA569(DESCRIPCIO);                                      

/* TA570( TABLAS DE MATERIA PRIMA BALDOSAS )*/                                  
CREATE TABLE IF NOT EXISTS TA570(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(30) DEFAULT "",                                          
   NENVIO      CHAR(3) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA570_1 ON TA570(CODIGO);                                          
CREATE INDEX TA570_2 ON TA570(DESCRIPCIO);                                      
                                                                                
/* TA571( TABLAS DE MOLDEO DE BALDOSAS )*/                                      
CREATE TABLE IF NOT EXISTS TA571(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(42) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA571_1 ON TA571(CODIGO);                                          
CREATE INDEX TA571_2 ON TA571(DESCRIPCIO);                                      
                                                                                
/* TA572( TABLAS DE COCCI�N DE BALDOSAS )*/                                     
CREATE TABLE IF NOT EXISTS TA572(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(18) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA572_1 ON TA572(CODIGO);                                          
CREATE INDEX TA572_2 ON TA572(DESCRIPCIO);                                      
                                                                                
/* TA573( TABLAS DE USO DE BALDOSAS )*/                                         
CREATE TABLE IF NOT EXISTS TA573(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(35) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA573_1 ON TA573(CODIGO);                                          
CREATE INDEX TA573_2 ON TA573(DESCRIPCIO);                                      
                                                                                
/* TA574( TABLAS DE COLORES DE BALDOSAS )*/                                     
CREATE TABLE IF NOT EXISTS TA574(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(18) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA574_1 ON TA574(CODIGO);                                          
CREATE INDEX TA574_2 ON TA574(DESCRIPCIO);                                      
                                                                                
/* TA575( TABLAS DE NOMBRE COMERCIAL ARTICULOS DE VIAJE )*/                     
CREATE TABLE IF NOT EXISTS TA575(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(45) DEFAULT "",                                          
   PARTIDA     CHAR(10) DEFAULT "",                                             
   CODSOFTPAD  CHAR(3) DEFAULT "",                                          
   PRIMARY KEY(CODIGO,PARTIDA));                                                        
CREATE INDEX TA575_1 ON TA575(CODIGO);                                          
CREATE INDEX TA575_2 ON TA575(DESCRIPCIO);                                      
                                            
/* TA576( TABLAS DE MATERIAL ARTICULOS II DE VIAJE )*/                          
CREATE TABLE IF NOT EXISTS TA576(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(36) DEFAULT "",                                          
   COD_MAT     CHAR(3) NOT NULL,                                                
   CODSOFTPAD  CHAR(3) DEFAULT "",        
   COD_MATSOF  CHAR(12) DEFAULT "", 
   PRIMARY KEY(CODIGO,COD_MAT));                                                        
CREATE INDEX TA576_1 ON TA576(CODIGO);                                          
CREATE INDEX TA576_2 ON TA576(DESCRIPCIO);                                      
                                                
/* TA577( TABLAS DE COMPOSICI�N DEL FORRO ARTICULOS DE VIAJE )*/                
CREATE TABLE IF NOT EXISTS TA577(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(35) DEFAULT "",                                          
   CODSOFTPAD  CHAR(3) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA577_1 ON TA577(CODIGO);                                          
CREATE INDEX TA577_2 ON TA577(DESCRIPCIO);                                      
                                                                                
/* TA578( TABLAS DE ACABADO ARTICULOS DE VIAJE )*/                              
CREATE TABLE IF NOT EXISTS TA578(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(18) DEFAULT "",                                          
   CODSOFTPAD  CHAR(3) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA578_1 ON TA578(CODIGO);                                          
CREATE INDEX TA578_2 ON TA578(DESCRIPCIO);                                      
                                                                                
/* TA579( TABLAS DE ACCESORIOS ARTICULOS DE VIAJE )*/                           
CREATE TABLE IF NOT EXISTS TA579(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(25) DEFAULT "",                                          
   CODSOFTPAD  CHAR(3) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA579_1 ON TA579(CODIGO);                                          
CREATE INDEX TA579_2 ON TA579(DESCRIPCIO);                                      

/* TA580( TABLAS DE APLICACIONES ARTICULOS DE VIAJE )*/                         
CREATE TABLE IF NOT EXISTS TA580(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(18) DEFAULT "",                                          
   CODSOFTPAD  CHAR(3) DEFAULT "",                                          
   NENVIO      CHAR(3) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA580_1 ON TA580(CODIGO);                                          
CREATE INDEX TA580_2 ON TA580(DESCRIPCIO);                                      
                                                                                
/* TA581( TABLAS DE PRESENTACI�N ARTICULOS DE VIAJE )*/                         
CREATE TABLE IF NOT EXISTS TA581(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(18) DEFAULT "",                                          
   CODSOFTPAD  CHAR(3) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA581_1 ON TA581(CODIGO);                                          
CREATE INDEX TA581_2 ON TA581(DESCRIPCIO);                                      
                                                                                
/* TA582( TABLAS DE USUARIO ARTICULOS DE VIAJE )*/                              
CREATE TABLE IF NOT EXISTS TA582(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(18) DEFAULT "",                                          
   CODSOFTPAD  CHAR(3) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA582_1 ON TA582(CODIGO);                                          
CREATE INDEX TA582_2 ON TA582(DESCRIPCIO);                                      
                                                                                
/* TA583( TABLAS DE NOMBRE COMERCIAL VAJILLA )*/                                
CREATE TABLE IF NOT EXISTS TA583(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(60) DEFAULT "",                                          
   PARTIDA     CHAR(10) DEFAULT "",                                             
   CODSOFTPAD  CHAR(3) DEFAULT "", 
   PARTIDA_AN  CHAR(10) DEFAULT "",
   PRIMARY KEY(CODIGO,PARTIDA));                                                        
CREATE INDEX TA583_1 ON TA583(CODIGO);                                          
CREATE INDEX TA583_2 ON TA583(DESCRIPCIO);                                      
                                  
/* TA584( TABLAS DE COMPONENTES PLASTICOS VAJILLA )*/                           
CREATE TABLE IF NOT EXISTS TA584(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(40) DEFAULT "",                                          
   CODSOFTPAD  CHAR(3) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA584_1 ON TA584(CODIGO);                                          
CREATE INDEX TA584_2 ON TA584(DESCRIPCIO);                                      
                                                    
/* TA585( TABLAS DE ACABADO VAJILLA )*/                                         
CREATE TABLE IF NOT EXISTS TA585(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(18) DEFAULT "",                                          
   CODSOFTPAD  CHAR(3) DEFAULT "",                                          
   NENVIO      CHAR(3) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA585_1 ON TA585(CODIGO);                                          
CREATE INDEX TA585_2 ON TA585(DESCRIPCIO);                                      
                                                                                
/* TA586( TABLAS DE COLOR VAJILLA )*/                                           
CREATE TABLE IF NOT EXISTS TA586(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(25) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA586_1 ON TA586(CODIGO);                                          
CREATE INDEX TA586_2 ON TA586(DESCRIPCIO);                                      
                                                                                
/* TA587( TABLAS DE CALIDAD VAJILLA )*/                                         
CREATE TABLE IF NOT EXISTS TA587(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(30) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA587_1 ON TA587(CODIGO);                                          
CREATE INDEX TA587_2 ON TA587(DESCRIPCIO);                                      
                                                                                
/* TA588( TABLAS DE TIPO DE PROCESO VAJILLA )*/                                 
CREATE TABLE IF NOT EXISTS TA588(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(18) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA588_1 ON TA588(CODIGO);                                          
CREATE INDEX TA588_2 ON TA588(DESCRIPCIO);                                      
                                                                                
/* TA589( TABLAS DE ACCESORIOS VAJILLA )*/                                      
CREATE TABLE IF NOT EXISTS TA589(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(30) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA589_1 ON TA589(CODIGO);                                          
CREATE INDEX TA589_2 ON TA589(DESCRIPCIO);                                      
                                                                                
/* TA590( TABLAS DE TIPO DE MATERIAL I - VAJILLAS )*/                           
CREATE TABLE IF NOT EXISTS TA590(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(50) DEFAULT "",                                          
   COD_ANT     CHAR(12) DEFAULT "",
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA590_1 ON TA590(CODIGO);                                          
CREATE INDEX TA590_2 ON TA590(DESCRIPCIO);                                      
                                                                                
/* TA591( TABLAS DE VERSION DE INCOTERM )*/                                     
CREATE TABLE IF NOT EXISTS TA591(                                               
   CODIGO      CHAR(1) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(20) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA591_1 ON TA591(CODIGO);                                          
CREATE INDEX TA591_2 ON TA591(DESCRIPCIO);                                      
                                                                        
/* TA593( CATEGORIAS DE ICA )*/                                     
CREATE TABLE IF NOT EXISTS TA593(                                               
   CODIGO      CHAR(2) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(20) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA593_1 ON TA593(CODIGO);                                          
CREATE INDEX TA593_2 ON TA593(DESCRIPCIO);                                      

/* TA594(TIPOS DE DOCUMENTOS DE TRANSPORTE DEL ICA )*/                                     
CREATE TABLE IF NOT EXISTS TA594(                                               
   CODIGO      CHAR(1) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(40) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA594_1 ON TA594(CODIGO);                                          
CREATE INDEX TA594_2 ON TA594(DESCRIPCIO);                                      

/* TA595(Tabla de Productos de DS EER )*/                                     
CREATE TABLE IF NOT EXISTS TA595(                                               
   CODIGO      CHAR(8) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(130) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA595_1 ON TA595(CODIGO);                                          
CREATE INDEX TA595_2 ON TA595(DESCRIPCIO);                                      


/* TA596( TABLAS DE NUEVA TABLA DE DERECHO ESPECIFICO 01.01.2011 )*/            
CREATE TABLE IF NOT EXISTS TA596(                                               
   CODIGO      CHAR(2) NOT NULL,                                                
   FOB_REF1    CHAR(4) NOT NULL,                                                
   FOB_REF2    CHAR(4) DEFAULT "",                                              
   DER_ESP1    NUMERIC(5,0) DEFAULT 0,                                          
   DER_ESP2    NUMERIC(4,0) DEFAULT 0,                                          
   PRIMARY KEY(CODIGO,FOB_REF1));                                               
CREATE INDEX TA596_1 ON TA596(CODIGO,FOB_REF1);                                 

/* TA598(Nombre Comercial de Juguetes)*/                                     
CREATE TABLE IF NOT EXISTS TA598(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(40) DEFAULT "",                                          
   CODSOFTPAD  CHAR(3) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA598_1 ON TA598(CODIGO);                                          
CREATE INDEX TA598_2 ON TA598(DESCRIPCIO);                                      

/* TA599(Tipo de Juguetes de Ruedas)*/                                     
CREATE TABLE IF NOT EXISTS TA599(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(25) DEFAULT "",                                          
   DESCRIPCI2  VARCHAR(60) DEFAULT "",                                          
   CODSOFTPAD  CHAR(3) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA599_1 ON TA599(CODIGO);                                          
CREATE INDEX TA599_2 ON TA599(DESCRIPCIO);                                      

/* TA600(Componentes Juguetes)*/                                     
CREATE TABLE IF NOT EXISTS TA600(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(45) DEFAULT "",                                          
   CODSOFTPAD  CHAR(3) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA600_1 ON TA600(CODIGO);                                          
CREATE INDEX TA600_2 ON TA600(DESCRIPCIO);                                      

/* TA601(Actividades del(la) Mu�eco(a) Juguetes)*/                                     
CREATE TABLE IF NOT EXISTS TA601(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(25) DEFAULT "",                                          
   CODSOFTPAD  CHAR(3) DEFAULT "",                                          
   NENVIO      CHAR(3) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA601_1 ON TA601(CODIGO);                                          
CREATE INDEX TA601_2 ON TA601(DESCRIPCIO);                                      

/* TA602(Tipo de Juguetes para Armar Juguetes)*/                                     
CREATE TABLE IF NOT EXISTS TA602(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(20) DEFAULT "",                                          
   CODSOFTPAD  CHAR(3) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA602_1 ON TA602(CODIGO);                                          
CREATE INDEX TA602_2 ON TA602(DESCRIPCIO);                                      

/* TA603(Tipo de Juguetes de distintos elementos Juguetes)*/                                     
CREATE TABLE IF NOT EXISTS TA603(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(20) DEFAULT "",                                          
   CODSOFTPAD  CHAR(3) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA603_1 ON TA603(CODIGO);                                          
CREATE INDEX TA603_2 ON TA603(DESCRIPCIO);                                      

/* TA604(Subtipos de Armas Juguetes)*/                                     
CREATE TABLE IF NOT EXISTS TA604(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(20) DEFAULT "",                                          
   CODSOFTPAD  CHAR(3) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA604_1 ON TA604(CODIGO);                                          
CREATE INDEX TA604_2 ON TA604(DESCRIPCIO);                                      

/* TA605(Proyectiles lanzados por armas Juguetes)*/                                     
CREATE TABLE IF NOT EXISTS TA605(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(20) DEFAULT "",                                          
   CODSOFTPAD  CHAR(3) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA605_1 ON TA605(CODIGO);                                          
CREATE INDEX TA605_2 ON TA605(DESCRIPCIO);                                      

/* TA606(Fuente de Movimiento  Juguetes)*/                                     
CREATE TABLE IF NOT EXISTS TA606(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(45) DEFAULT "",                                          
   CODSOFTPAD  CHAR(3) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA606_1 ON TA606(CODIGO);                                          
CREATE INDEX TA606_2 ON TA606(DESCRIPCIO);                                      

/* TA607(Usuario del Juguete)*/                                     
CREATE TABLE IF NOT EXISTS TA607(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(15) DEFAULT "",                                          
   CODSOFTPAD  CHAR(3) DEFAULT "",                           
   NENVIO      CHAR(3) DEFAULT "",                                    
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA607_1 ON TA607(CODIGO);                                          
CREATE INDEX TA607_2 ON TA607(DESCRIPCIO);                                      

/* TA608(Presentaci�n del Juguete)*/                                     
CREATE TABLE IF NOT EXISTS TA608(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(12) DEFAULT "",                                          
   CODSOFTPAD  CHAR(3) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA608_1 ON TA608(CODIGO);                                          
CREATE INDEX TA608_2 ON TA608(DESCRIPCIO);                                      

/* TA610(Nombre de la Mercancia Utiles)*/                                     
CREATE TABLE IF NOT EXISTS TA610(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(30) DEFAULT "",                                          
   CODSOFTPAD  CHAR(3) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA610_1 ON TA610(CODIGO);                                          
CREATE INDEX TA610_2 ON TA610(DESCRIPCIO);                                      

/* TA611(Composicion del Material externo Utiles)*/                                     
CREATE TABLE IF NOT EXISTS TA611(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(32) DEFAULT "",                                          
   CODSOFTPAD  CHAR(3) DEFAULT "",                                                                            
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA611_1 ON TA611(CODIGO);                                          
CREATE INDEX TA611_2 ON TA611(DESCRIPCIO);                                      

/* TA612(Color Utiles)*/                                     
CREATE TABLE IF NOT EXISTS TA612(                                               
   CODIGO      CHAR(3) NOT NULL,                                                   
   DESCRIPCIO  VARCHAR(27) DEFAULT "",                                          
   CODSOFTPAD  CHAR(3) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA612_1 ON TA612(CODIGO);                                          
CREATE INDEX TA612_2 ON TA612(DESCRIPCIO);                                      

/* TA613(Acabados Utiles)*/                                     
CREATE TABLE IF NOT EXISTS TA613(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(23) DEFAULT "",                                          
   CODSOFTPAD  CHAR(3) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA613_1 ON TA613(CODIGO);                                          
CREATE INDEX TA613_2 ON TA613(DESCRIPCIO);                                      

/* TA614(Aplicacion o Uso Utiles)*/                                     
CREATE TABLE IF NOT EXISTS TA614(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(23) DEFAULT "",                                          
   CODSOFTPAD  CHAR(3) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA614_1 ON TA614(CODIGO);                                          
CREATE INDEX TA614_2 ON TA614(DESCRIPCIO);                                      

/* TA615(Presentacion Utiles)*/                                     
CREATE TABLE IF NOT EXISTS TA615(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(27) DEFAULT "",                                          
   CODSOFTPAD  CHAR(3) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA615_1 ON TA615(CODIGO);                                          
CREATE INDEX TA615_2 ON TA615(DESCRIPCIO);                                      

/* TA616(Composicion del Material interno Utiles)*/                                     
CREATE TABLE IF NOT EXISTS TA616(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(27) DEFAULT "",                                          
   DESCRIPC2   VARCHAR(40) DEFAULT "",                                          
   COD_NOMBRE  CHAR(3) DEFAULT "",                                          
   CODSOFTPAD  CHAR(3) DEFAULT "",                                          
   PRIMARY KEY(COD_NOMBRE,CODIGO));                                                        
CREATE INDEX TA616_1 ON TA616(COD_NOMBRE,CODIGO);                                          
CREATE INDEX TA616_2 ON TA616(DESCRIPCIO);                                      

/* TA617(Tipo o dureza de la Punta Utiles)*/                                     
CREATE TABLE IF NOT EXISTS TA617(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(23) DEFAULT "",                                          
   DESCRIPC2   VARCHAR(28) DEFAULT "",                                            
   COD_NOMBRE  CHAR(3) DEFAULT "",                                          
   CODSOFTPAD  CHAR(3) DEFAULT "",                                          
   PRIMARY KEY(COD_NOMBRE,CODIGO));                                                        
CREATE INDEX TA617_1 ON TA617(COD_NOMBRE,CODIGO);                                          
CREATE INDEX TA617_2 ON TA617(DESCRIPCIO);                                      

/* TA618(Dispositivos Utiles)*/                                     
CREATE TABLE IF NOT EXISTS TA618(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(20) DEFAULT "",                                          
   CODSOFTPAD  CHAR(3) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA618_1 ON TA618(CODIGO);                                          
CREATE INDEX TA618_2 ON TA618(DESCRIPCIO);                                      

/* TA619(Accesorios Utiles)*/                                     
CREATE TABLE IF NOT EXISTS TA619(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(20) DEFAULT "",                                          
   CODSOFTPAD  CHAR(3) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA619_1 ON TA619(CODIGO);                                          
CREATE INDEX TA619_2 ON TA619(DESCRIPCIO);     

                          
/* TA620 (TABLAS DE PARTIDAS DEL TLC - KOREA. )*/                               
CREATE TABLE IF NOT EXISTS TA620(                                               
   PARTIDA     CHAR(10) NOT NULL,                                               
   DESCRIPC    VARCHAR(60) DEFAULT "",                                         
   DESCRIPC2   VARCHAR(60) DEFAULT "",                                          
   DESCRIPC3   VARCHAR(60) DEFAULT "",                                          
   DESCRIPC4   VARCHAR(60) DEFAULT "",                                          
   DESCRIPC5   VARCHAR(60) DEFAULT "",                                          
   DESCRIPC6   VARCHAR(60) DEFAULT "",                                          
   BASE        NUMERIC(8,0) DEFAULT 0,                                          
   MPO         CHAR(5) DEFAULT "",                                              
   TM          CHAR(5) DEFAULT "",                                              
   OB1         VARCHAR(45) DEFAULT "",                                          
   PRIMARY KEY(PARTIDA,DESCRIPC,DESCRIPC2,DESCRIPC3,DESCRIPC4,DESCRIPC5,DESCRIPC6));                                                       
CREATE INDEX TA620_1 ON TA620(PARTIDA);                                         

/* TA621(Partidas TLC - Corea)*/                                     
CREATE TABLE IF NOT EXISTS TA621(                                               
   CODIGO      CHAR(5) NOT NULL,                                                
   MPO         DECIMAL(6,2) DEFAULT 0.00,                                       
   FECH_INI    DATE,                                                            
   FECH_TER    DATE,                   
   ORDEN       CHAR(2) NOT NULL,                                         
   PRIMARY KEY(CODIGO,ORDEN));                                                        
CREATE INDEX TA621_1 ON TA621(CODIGO);                                          
      
/*TA622 (Tipo de Envio de la Digitalizacion)*/
CREATE TABLE IF NOT EXISTS TA622(                                               
   CODIGO      CHAR(2) NOT NULL,                                               
   DESCRIP     VARCHAR(20) DEFAULT "",                                         
   REGIMEN     CHAR(2) NOT NULL,
   PRIMARY KEY(REGIMEN,CODIGO));                                                       
CREATE INDEX TA622_1 ON TA622(CODIGO);                                         

/*TA623 (Partidas TLC - AELC - Suiza                       )*/
CREATE TABLE IF NOT EXISTS TA623(                                               
   PARTIDA     CHAR(10) NOT NULL,                                               
   DESCRIPC    VARCHAR(140) DEFAULT "",                                         
   DESCRIPC2   VARCHAR(140) DEFAULT "",                                          
   DESCRIPC3   VARCHAR(70) DEFAULT "",                                          
   BASE        NUMERIC(8,0) DEFAULT 0,                                          
   MPO         CHAR(5) DEFAULT "",                                              
   TM          CHAR(5) DEFAULT "",                                              
   OB1         VARCHAR(45) DEFAULT "",                                          
   PARTIDA_AN  CHAR(10) DEFAULT "",
   PRIMARY KEY(PARTIDA,DESCRIPC,DESCRIPC2,DESCRIPC3));                                                       
CREATE INDEX TA623_1 ON TA623(PARTIDA);                                         

/*TA624 (Cronograma TLC - Suiza                            )*/
CREATE TABLE IF NOT EXISTS TA624(                                               
   CODIGO      CHAR(5) NOT NULL,                                                
   MPO         DECIMAL(6,2) DEFAULT 0.00,                                       
   FECH_INI    DATE,                                                            
   FECH_TER    DATE,                   
   ORDEN       CHAR(2) NOT NULL,                                         
   PRIMARY KEY(CODIGO,ORDEN));                                                        
CREATE INDEX TA624_1 ON TA624(CODIGO);                                          

/*TA626 (Partidas TLC - AELC - Islandia                    )*/
CREATE TABLE IF NOT EXISTS TA626(                                               
   PARTIDA     CHAR(10) NOT NULL,                                               
   DESCRIPC    VARCHAR(140) DEFAULT "",                                         
   DESCRIPC2   VARCHAR(140) DEFAULT "",                                          
   DESCRIPC3   VARCHAR(140) DEFAULT "",                                          
   BASE        NUMERIC(8,0) DEFAULT 0,                                          
   MPO         CHAR(5) DEFAULT "",                                              
   TM          CHAR(5) DEFAULT "",                                              
   OB1         VARCHAR(45) DEFAULT "",                                          
   PRIMARY KEY(PARTIDA,DESCRIPC,DESCRIPC2,DESCRIPC3));                                                       
CREATE INDEX TA626_1 ON TA626(PARTIDA);                                         

/* TA627( TABLAS DE NUEVA TABLA DE DERECHO ESPECIFICO 01.01.2012 )*/            
CREATE TABLE IF NOT EXISTS TA627(                                               
   CODIGO      CHAR(2) NOT NULL,                                                
   FOB_REF1    CHAR(4) NOT NULL,                                                
   FOB_REF2    CHAR(4) DEFAULT "",                                              
   DER_ESP1    NUMERIC(5,0) DEFAULT 0,                                          
   DER_ESP2    NUMERIC(4,0) DEFAULT 0,                                          
   PRIMARY KEY(CODIGO,FOB_REF1));                                               
CREATE INDEX TA627_1 ON TA627(CODIGO,FOB_REF1);                             

/* TA628( Correlacion arancel 2007 - 2012  )*/            
CREATE TABLE IF NOT EXISTS TA628(                                               
   PAB1        CHAR(10) NOT NULL,                                                
   PAB2        CHAR(10) NOT NULL,                                                
   C           VARCHAR(254) DEFAULT "",                                              
   PRIMARY KEY(PAB1,PAB2));                                               
CREATE INDEX TA628_1 ON TA628(PAB1);                             
CREATE INDEX TA628_2 ON TA628(PAB2);                             

/*TA629 (Partidas TLC - TAILANDIA                     )*/
CREATE TABLE IF NOT EXISTS TA629(                                               
   PARTIDA     CHAR(10) NOT NULL,                                               
   DESCRIPC    VARCHAR(140) DEFAULT "",                                         
   DESCRIPC2   VARCHAR(140) DEFAULT "",                                          
   DESCRIPC3   VARCHAR(140) DEFAULT "",                                          
   BASE        NUMERIC(4,0) DEFAULT 0,                                          
   MPO         CHAR(2) DEFAULT "",                                              
   TM          CHAR(5) DEFAULT "",                                              
   PARTIDA_AN  CHAR(10) DEFAULT "",
   PRIMARY KEY(PARTIDA,DESCRIPC,DESCRIPC2,DESCRIPC3));                                                       
CREATE INDEX TA629_1 ON TA629(PARTIDA);                                         

/*TA630 (Cronograma TLC - TAILANDIA                          )*/
CREATE TABLE IF NOT EXISTS TA630(                                               
   CODIGO      CHAR(5) NOT NULL,                                                
   MPO         DECIMAL(6,2) DEFAULT 0.00,                                       
   FECH_INI    DATE,                                                            
   FECH_TER    DATE,                   
   ORDEN       CHAR(2) NOT NULL,                                         
   PRIMARY KEY(CODIGO,ORDEN));                                                        
CREATE INDEX TA630_1 ON TA630(CODIGO);                                          

/*TA631 (Partidas TLC - MEXICO                     )*/
CREATE TABLE IF NOT EXISTS TA631(                                               
   PARTIDA     CHAR(10) NOT NULL,                                               
   DESCRIPC    VARCHAR(140) DEFAULT "",   	                                      
   DESCRIPC2   VARCHAR(140) DEFAULT "",                                          
   BASE        NUMERIC(4,0) DEFAULT 0,                                          
   MPO         CHAR(5) DEFAULT "",                                              
   TM          CHAR(5) DEFAULT "",                                              
   E           CHAR(2) DEFAULT "",                                              
   F           CHAR(1) DEFAULT "",                                              
   OBSERVAC    CHAR(1) DEFAULT "",                                              
   PARTIDA_AN  CHAR(10) DEFAULT "",
   PRIMARY KEY(PARTIDA,DESCRIPC,DESCRIPC2));                                                       
CREATE INDEX TA631_1 ON TA631(PARTIDA);                                         

/*TA632 (Cronograma TLC - MEXICO                          )*/
CREATE TABLE IF NOT EXISTS TA632(                                               
   CODIGO      CHAR(5) NOT NULL,                                                
   MPO         DECIMAL(6,2) DEFAULT 0.00,                                       
   FECH_INI    DATE,                                                            
   FECH_TER    DATE,                   
   ORDEN       CHAR(2) NOT NULL,         
   C           CHAR(1) DEFAULT "",                                              
   X           CHAR(10) DEFAULT "",                                              
   PRIMARY KEY(CODIGO,ORDEN));                                                        
CREATE INDEX TA632_1 ON TA632(CODIGO);                                          

/*TA633 (Cronograma II TLC - MEXICO                        )*/
CREATE TABLE IF NOT EXISTS TA633(                                               
   MESANIO     CHAR(6) NOT NULL,                                                
   F4          DECIMAL(15,2) DEFAULT 0.00,                                       
   F5          DECIMAL(15,2) DEFAULT 0.00,                                       
   F6          DECIMAL(15,2) DEFAULT 0.00,                                       
   F8          DECIMAL(15,2) DEFAULT 0.00,                                       
   F12         DECIMAL(15,2) DEFAULT 0.00,                                       
   F14         DECIMAL(15,2) DEFAULT 0.00,                                       
   F16         DECIMAL(15,2) DEFAULT 0.00,                                       
   PRIMARY KEY(MESANIO));                                                        
CREATE INDEX TA633 ON TA633(MESANIO);
                         
/*TA634 (Partidas TLC - JAPON             )*/
CREATE TABLE IF NOT EXISTS TA634(                                               
   PARTIDA     CHAR(10) NOT NULL,                                               
   DESCRIPC    VARCHAR(140) DEFAULT "",   	                                      
   DESCRIPC2   VARCHAR(140) DEFAULT "",                                          
   DESCRIPC3   VARCHAR(70) DEFAULT "",                                          
   BASE        NUMERIC(4,0) DEFAULT 0,                                          
   MPO         CHAR(5) DEFAULT "",                                              
   TM          CHAR(5) DEFAULT "",                                              
   E           CHAR(2) DEFAULT "",                                              
   F           CHAR(1) DEFAULT "",                                              
   OBSERVAC    CHAR(1) DEFAULT "",     
   PARTIDA_AN  CHAR(10) DEFAULT "",                                         
   PRIMARY KEY(PARTIDA,DESCRIPC,DESCRIPC2));                                                       
CREATE INDEX TA634_1 ON TA634(PARTIDA);                                         

/*TA635 (Cronograma TLC - JAPON                          )*/
CREATE TABLE IF NOT EXISTS TA635(                                               
   CODIGO      CHAR(5) NOT NULL,                                                
   MPO         DECIMAL(6,2) DEFAULT 0.00,                                       
   FECH_INI    DATE,                                                            
   FECH_TER    DATE,                   
   ORDEN       CHAR(2) NOT NULL,         
   C           CHAR(1) DEFAULT "",                                              
   X           CHAR(10) DEFAULT "",                                              
   PRIMARY KEY(CODIGO,ORDEN));                                                        
CREATE INDEX TA635_1 ON TA635(CODIGO);                                          

/*TA636 (Partidas TLC - PANAMA             )*/
CREATE TABLE IF NOT EXISTS TA636(                                               
   PARTIDA     CHAR(10) NOT NULL,                                               
   DESCRIP     VARCHAR(140) DEFAULT "",   	                                      
   DESCRIP2    VARCHAR(140) DEFAULT "",                                          
   DESCRIP3    VARCHAR(140) DEFAULT "",                                          
   DESCRIP4    VARCHAR(100) DEFAULT "",                                          
   BASE        NUMERIC(4,0) DEFAULT 0,                                          
   MPO         CHAR(5) DEFAULT "",                                              
   TM          CHAR(5) DEFAULT "",                                              
   OBSERVAC    CHAR(50) DEFAULT "",     
   SFP         CHAR(1) DEFAULT "",                                              
   PARTIDA_AN  CHAR(10) DEFAULT "",                                         
   PRIMARY KEY(PARTIDA,DESCRIP,DESCRIP2));                                                       
CREATE INDEX TA636_1 ON TA636(PARTIDA);                                         

/*TA637 (Cronograma TLC - PANAMA                          )*/
CREATE TABLE IF NOT EXISTS TA637(                                               
   CODIGO      CHAR(5) NOT NULL,                                                
   MPO         DECIMAL(6,2) DEFAULT 0.00,                                       
   FECH_INI    DATE,                                                            
   FECH_TER    DATE,                   
   ORDEN       CHAR(2) NOT NULL,         
   C           CHAR(1) DEFAULT "",                                              
   X           CHAR(10) DEFAULT "",                                              
   PRIMARY KEY(CODIGO,ORDEN));                                                        
CREATE INDEX TA637_1 ON TA637(CODIGO);            

/* TA639( TABLAS DE NUEVA TABLA DE DERECHO ESPECIFICO 01.07.2012 )*/            
CREATE TABLE IF NOT EXISTS TA639(                                               
   CODIGO      CHAR(2) NOT NULL,                                                
   FOB_REF1    CHAR(4) NOT NULL,                                                
   FOB_REF2    CHAR(4) DEFAULT "",                                              
   DER_ESP1    NUMERIC(5,0) DEFAULT 0,                                          
   DER_ESP2    NUMERIC(4,0) DEFAULT 0,                                          
   PRIMARY KEY(CODIGO,FOB_REF1));                                               
CREATE INDEX TA639_1 ON TA639(CODIGO,FOB_REF1);                             
                              

/*TA640 (Partidas TLC - NORUEGA          )*/
CREATE TABLE IF NOT EXISTS TA640(                                               
   PARTIDA     CHAR(10) NOT NULL,                                               
   DESCRIPC    VARCHAR(140) DEFAULT "",   	                                      
   DESCRIPC2   VARCHAR(140) DEFAULT "",                                          
   DESCRIPC3   VARCHAR(70) DEFAULT "",                                          
   BASE        NUMERIC(4,0) DEFAULT 0,	                                          
   MPO         CHAR(5) DEFAULT "",                                              
   TM          CHAR(5) DEFAULT "",                                              
   OB1         CHAR(45) DEFAULT "",
   PARTIDA_AN  CHAR(10) DEFAULT "",     
   PRIMARY KEY(PARTIDA,DESCRIPC,DESCRIPC2));                                                       
CREATE INDEX TA640_1 ON TA640(PARTIDA);                                         

/*TA641 (Cronograma TLC - NORUEGA                          )*/
CREATE TABLE IF NOT EXISTS TA641(                                               
   CODIGO      CHAR(5) NOT NULL,                                                
   MPO         DECIMAL(6,2) DEFAULT 0.00,                                       
   FECH_INI    DATE,                                                            
   FECH_TER    DATE,                   
   ORDEN       CHAR(2) NOT NULL,         
   PRIMARY KEY(CODIGO,ORDEN));                                                        
CREATE INDEX TA641_1 ON TA641(CODIGO);                                          

/*TA642 (Partidas de calzado con etiquetado)*/
CREATE TABLE IF NOT EXISTS TA642(                                               
   PARTIDA     CHAR(10) NOT NULL,  
   PARTIDA_AN  CHAR(10) DEFAULT "",
   PRIMARY KEY(PARTIDA));                                                        
CREATE INDEX TA642 ON TA642(PARTIDA);                                          

/*TA643 (Agentss de Retencion)*/
CREATE TABLE IF NOT EXISTS TA643(                                               
   RUC      CHAR(11) NOT NULL,                                                
   NOMBRE   VARCHAR(200) DEFAULT "",
   FECHA    DATE,
   RESOL    VARCHAR(50) DEFAULT "",
   PRIMARY KEY(RUC));                                                        
CREATE INDEX TA643_1 ON TA643(RUC);                                          
CREATE INDEX TA643_2 ON TA643(NOMBRE);                                          


/*TA644 (Cartilla de Ref. de Valores)*/
CREATE TABLE IF NOT EXISTS TA644(                                               
   PARTIDA     CHAR(10) NOT NULL,                                               
   DESCRIPCIO  VARCHAR(150) DEFAULT "",   	                                      
   UMEDIDA     CHAR(10) DEFAULT "",                                          
   CIF_DOL     CHAR(10) DEFAULT "",                                          
   ORDEN       CHAR(3) DEFAULT "",	                                          
   PRIMARY KEY(ORDEN,DESCRIPCIO));                                                       
CREATE INDEX TA644_1 ON TA644(ORDEN);
                                         
/* TA645( TABLAS DE NUEVA TABLA DE DERECHO ESPECIFICO 01.01.2013 )*/            
CREATE TABLE IF NOT EXISTS TA645(                                               
   CODIGO      CHAR(2) NOT NULL,                                                
   FOB_REF1    CHAR(4) NOT NULL,                                                
   FOB_REF2    CHAR(4) DEFAULT "",                                              
   DER_ESP1    NUMERIC(5,0) DEFAULT 0,                                          
   DER_ESP2    NUMERIC(4,0) DEFAULT 0,                                          
   PRIMARY KEY(CODIGO,FOB_REF1));                                               
CREATE INDEX TA645_1 ON TA645(CODIGO,FOB_REF1);                             

/* TA646(Partidas de Maquinarias del D.Leg. 1107)*/            
CREATE TABLE IF NOT EXISTS TA646(                                               
   PARTIDA    CHAR(10) NOT NULL,                                                
   DES1       CHAR(150) NOT NULL,                                                
   DES2       CHAR(150) DEFAULT "",                                              
   PRIMARY KEY(PARTIDA));                                               
CREATE INDEX TA646_1 ON TA646(PARTIDA);                             

/*TA647 (Partidas TLC - UNION EUROPEA  )*/
CREATE TABLE IF NOT EXISTS TA647(                                               
   PARTIDA     CHAR(10) NOT NULL,                                               
   DESCRIP     VARCHAR(140) DEFAULT "",   	                                      
   DESCRIP2    VARCHAR(140) DEFAULT "",                                          
   DESCRIP3    VARCHAR(140) DEFAULT "",                                          
   DESCRIP4    VARCHAR(100) DEFAULT "",                                          
   BASE        NUMERIC(4,0) DEFAULT 0,	                                          
   MPO         CHAR(5) DEFAULT "",                                              
   TM          CHAR(5) DEFAULT "",                                              
   OBSV        CHAR(10) DEFAULT "",     
   OBSERVAC    CHAR(150) DEFAULT "",     
   H           CHAR(5) DEFAULT "",                                              
   PARTIDA_AN  CHAR(10) NOT NULL,                                                   
   PRIMARY KEY(PARTIDA,DESCRIP,DESCRIP2,DESCRIP3));                                                       
CREATE INDEX TA647_1 ON TA647(PARTIDA);                                         

/*TA648 (Cronograma TLC - UNION EUROPEA     )*/
CREATE TABLE IF NOT EXISTS TA648(                                               
   CODIGO      CHAR(5) NOT NULL,                                                
   MPO         DECIMAL(6,2) DEFAULT 0.00,                                       
   FECH_INI    DATE,                                                            
   FECH_TER    DATE,                   
   ORDEN       CHAR(2) NOT NULL,         
   C           CHAR(1) DEFAULT "",
   X           CHAR(10), 
   PRIMARY KEY(CODIGO,ORDEN));                                                        
CREATE INDEX TA648_1 ON TA648(CODIGO);                                          

/*TA649 (Categorias de Riesgo-Mercancia Pecuaria           )*/
CREATE TABLE IF NOT EXISTS TA649(                                               
   CODIGO      CHAR(1) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(35) DEFAULT "",
   IMP1        CHAR(4) DEFAULT "",
   IMP2        CHAR(4) DEFAULT "",
   IMP3        CHAR(4) DEFAULT "",
   IMP4        CHAR(4) DEFAULT "",
   LL1         CHAR(4) DEFAULT "",
   LL2         CHAR(4) DEFAULT "",
   CONCEPTO1   VARCHAR(140) DEFAULT "",
   CONCEPTO2   VARCHAR(140) DEFAULT "",   
   CONCEPTO3   VARCHAR(135) DEFAULT "",
   CONCEPTO4   VARCHAR(135) DEFAULT "",
   CONCEPTO5   VARCHAR(135) DEFAULT "",
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA649_1 ON TA649(CODIGO);                                          

/*TA653 (Partidas con Categoria de Riesgo-Mercancia Pecuari   )*/
CREATE TABLE IF NOT EXISTS TA653(                                               
   CODIGO      CHAR(2) NOT NULL,                                                
   DES1        VARCHAR(80) NOT NULL,
   DES2        VARCHAR(71) DEFAULT "",
   DES3        VARCHAR(71) DEFAULT "",
   DES4        VARCHAR(71) DEFAULT "",
   DES5        VARCHAR(70) DEFAULT "",
   DES6        VARCHAR(70) DEFAULT "",
   PARTIDA     CHAR(10) DEFAULT "",
   RIESGO      CHAR(1) DEFAULT "",
   PRIMARY KEY(CODIGO,DES1,PARTIDA,RIESGO));                                                        
CREATE INDEX TA653_1 ON TA653(CODIGO);                                          

/*TA654 (Productos con calculo de ISC Combinado            )*/
CREATE TABLE IF NOT EXISTS TA654(                                               
   PARTIDA     CHAR(10) NOT NULL,                                                
   CODIGO      CHAR(3) NOT NULL,
   TEXTO       CHAR(3) NOT NULL,
   DESCRIPCIO  VARCHAR(50) DEFAULT "",
   MONTO_FIJO  DECIMAL(6,2) DEFAULT 0.00,
   MONTO_VAL   NUMERIC(2,0) DEFAULT 0,
   MONTO_PVP   NUMERIC(2,0) DEFAULT 0,
   PRIMARY KEY(PARTIDA,CODIGO,TEXTO));                                                        
CREATE INDEX TA654_1 ON TA654(CODIGO);                                          


/*TA658 (C�digo de la unidad temperatura de Flashpoint)*/
CREATE TABLE IF NOT EXISTS TA658(
   CODIGO      CHAR(3) NOT NULL,
   DESCRIPCIO  VARCHAR(30) DEFAULT "",
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA658_1 ON TA658(CODIGO);                                          

/*TA659 (Partidas TLC - COSTA RICA  )*/
CREATE TABLE IF NOT EXISTS TA659(
   PARTIDA     CHAR(10) NOT NULL,                                               
   DESCRIPC    VARCHAR(120) DEFAULT "",   	                                      
   DESCRIPC2   VARCHAR(120) DEFAULT "",                                          
   DESCRIPC3   VARCHAR(80) DEFAULT "",                                          
   BASE        NUMERIC(8,0) DEFAULT 0,	                                          
   MPO         CHAR(3) DEFAULT "",                                              
   TM          CHAR(5) DEFAULT "",                                              
   OBS         VARCHAR(50) DEFAULT "",     
   PRIMARY KEY(PARTIDA,DESCRIPC,DESCRIPC2,DESCRIPC3));                                                       
CREATE INDEX TA659_1 ON TA659(PARTIDA);                                         

/*TA660 (Cronograma TLC - COSTA RICA     )*/
CREATE TABLE IF NOT EXISTS TA660(                                               
   CODIGO      CHAR(5) NOT NULL,                                                
   MPO         DECIMAL(6,2) DEFAULT 0.00,                                       
   FECH_INI    DATE,                                                            
   FECH_TER    DATE,                   
   ORDEN       CHAR(2) NOT NULL,         
   OBSVER      CHAR(5) DEFAULT "",
   PRIMARY KEY(CODIGO,ORDEN));                                                        
CREATE INDEX TA660_1 ON TA660(CODIGO);                                          

/*TA662 (Tabla de modalidades de transbordo  )*/
CREATE TABLE IF NOT EXISTS TA662(                                               
   CODIGO      CHAR(1) NOT NULL,
   DESCRIPCIO  VARCHAR(50) DEFAULT "",
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA662_1 ON TA662(CODIGO);                                          

/*TA663 (Tipo de lugar de carga  )*/
CREATE TABLE IF NOT EXISTS TA663(                                               
   CODIGO      CHAR(3) NOT NULL,
   DESCRIPCIO  VARCHAR(30) DEFAULT "",
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA663_1 ON TA663(CODIGO);                                          

/*TA664 (Tipo de carga usada para determinar el abandono legal)*/
CREATE TABLE IF NOT EXISTS TA664(                                               
   CODIGO      CHAR(2) NOT NULL,
   DESCRIPCIO  VARCHAR(30) DEFAULT "",
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA664_1 ON TA664(CODIGO);                                          

/*TA665 (Mercanc�a Restringida seg�n la Ley 29811)*/
CREATE TABLE IF NOT EXISTS TA665(                                               
   PARTIDA     CHAR(10) NOT NULL,
   DESCRIPCIO  VARCHAR(120) DEFAULT "",
   DESCRIPCI2  VARCHAR(120) DEFAULT "",
   TIPO        CHAR(1) DEFAULT "",
   PRIMARY KEY(PARTIDA));                                                        
CREATE INDEX TA665_1 ON TA665(PARTIDA);                                          

/*TA666 (Partidas TLC - CON VENEZUELA  )*/
CREATE TABLE IF NOT EXISTS TA666(
   PARTIDA     CHAR(10) NOT NULL,                                               
   DESCRIPC    VARCHAR(120) DEFAULT "",   	                                      
   DESCRIPC2   VARCHAR(120) DEFAULT "",                                          
   DESCRIPC3   VARCHAR(50) DEFAULT "",                                          
   MPO         DECIMAL(11,1) DEFAULT 00.0,                                              
   ANEXO       CHAR(2) DEFAULT "",
   TM          CHAR(1) DEFAULT "",                                              
   PART_ANT    CHAR(8) DEFAULT "",     
   PARTIDA_AN  CHAR(10) DEFAULT "",
   PRIMARY KEY(PARTIDA,DESCRIPC,DESCRIPC2,DESCRIPC3));                                                       
CREATE INDEX TA666_1 ON TA666(PARTIDA);                                         

/*TA669 (Tabla de IMPUGNACION              )*/
CREATE TABLE IF NOT EXISTS TA669(
   CODIGO      CHAR(1) NOT NULL,                                               
   DESCRIPCIO  VARCHAR(40) DEFAULT "",   	                                      
   PRIMARY KEY(CODIGO));                                                       
CREATE INDEX TA669_1 ON TA669(CODIGO);                                         

/*TA672 (Percepci�n de Unidades )*/
CREATE TABLE IF NOT EXISTS TA672(
   PARTIDA     CHAR(10) NOT NULL,                                               
   UNIDAD      CHAR(3) DEFAULT "",   	                                      
   TIPO1       DECIMAL(8,2) DEFAULT 00.0,                                              
   TIPO2       DECIMAL(8,2) DEFAULT 00.0,                                              
   TIPO3       DECIMAL(8,2) DEFAULT 00.0,                                              
   PRIMARY KEY(PARTIDA));                                                       
CREATE INDEX TA672_1 ON TA672(PARTIDA);                                         

/*TA675 Tablas exceptuadas de modificacion en CETICOS     */
CREATE TABLE IF NOT EXISTS TA675(
   PARTIDA     CHAR(10) NOT NULL,                                               
   DES1        VARCHAR(87) DEFAULT "",   	                                      
   PARTIDA_AN  CHAR(10) DEFAULT "",
   PRIMARY KEY(PARTIDA));                                                       
CREATE INDEX TA675_1 ON TA675(PARTIDA);                                         

/*TA677 Antidumping Ropa x-Proveedor - CHINA                   */
CREATE TABLE IF NOT EXISTS TA677(
   PAIS        CHAR(2) NOT NULL,                                                
   PARTIDA     CHAR(10) NOT NULL,                                               
   DESCRIP1    VARCHAR(25) DEFAULT "",
   NOMB_EMPR   VARCHAR(35) DEFAULT "",                                          
   MINIMO      DECIMAL(10,3) DEFAULT 0.000,
   MAXIMO      DECIMAL(10,3) DEFAULT 0.000,
   ANTIDUMP    DECIMAL(6,2) DEFAULT 0.00,                                       
   CPROD       CHAR(2) NOT NULL,                                                
   TEXTO       CHAR(3) DEFAULT "",
   TIPO_BASE   CHAR(3) DEFAULT "",
   TIPO_CALC   CHAR(2) DEFAULT "",                                              
   TABANT      CHAR(8) DEFAULT "",
   MENOS       CHAR(1) DEFAULT "",
   PARTIDA_AN  CHAR(10) DEFAULT "",
   EMP_EXON1   VARCHAR(65) DEFAULT "",
   CEXPODUMP   CHAR(4) NOT NULL,      
   ORDEN       CHAR(2) DEFAULT "",                                          
   PRIMARY KEY(PARTIDA,PAIS,CPROD,CEXPODUMP,NOMB_EMPR,DESCRIP1));                                  
CREATE INDEX TA677_1 ON TA677(PARTIDA,PAIS,CPROD,CEXPODUMP);                    
CREATE INDEX TA677_2 ON TA677(NOMB_EMPR);                                       

/*TA678 Operador Receptor de Carga - ICA       */
CREATE TABLE IF NOT EXISTS TA678(
   CODIGO      CHAR(2) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(50) DEFAULT "",   
   PRIMARY KEY(CODIGO));                                  
CREATE INDEX TA678_1 ON TA678(CODIGO);                    
CREATE INDEX TA678_2 ON TA678(DESCRIPCIO);                                       

/*TA681 Tabla de Descripciones Minimas */
CREATE TABLE IF NOT EXISTS TA681(
   CODIGO      CHAR(6) NOT NULL,                                                
   DESCRIPCI1  VARCHAR(180) DEFAULT "",   
   DESCRIPCI2  VARCHAR(180) DEFAULT "",   
   TIPO        CHAR(1) DEFAULT "",
   COD_ADUANA  CHAR(6) NOT NULL,                                                
   PRIMARY KEY(COD_ADUANA,CODIGO));                                  
CREATE INDEX TA681_1 ON TA681(COD_ADUANA,CODIGO);                    
CREATE INDEX TA681_2 ON TA681(DESCRIPCI1);                                       

/*TA682 Tipo de Moto                                             */
CREATE TABLE IF NOT EXISTS TA682(
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(22) DEFAULT "",   
   PRIMARY KEY(CODIGO));                                  
CREATE INDEX TA682_1 ON TA682(CODIGO);                    
CREATE INDEX TA682_2 ON TA682(DESCRIPCIO);                                       

/*TA683 Tipo de Frenos                                    */
CREATE TABLE IF NOT EXISTS TA683(
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(15) DEFAULT "",   
   PRIMARY KEY(CODIGO));                                  
CREATE INDEX TA683_1 ON TA683(CODIGO);                    
CREATE INDEX TA683_2 ON TA683(DESCRIPCIO);                                       

/*TA684 Codigo de Refrigeraci�n                               */
CREATE TABLE IF NOT EXISTS TA684(
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(20) DEFAULT "",   
   PRIMARY KEY(CODIGO));                                  
CREATE INDEX TA684_1 ON TA684(CODIGO);                    
CREATE INDEX TA684_2 ON TA684(DESCRIPCIO);                                       


/*TA685 Si es parte de Vehiculo o Maquinaria              */
CREATE TABLE IF NOT EXISTS TA685(
   CODIGO      CHAR(1) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(70) DEFAULT "",   
   PRIMARY KEY(CODIGO));                                  
CREATE INDEX TA685_1 ON TA685(CODIGO);                    
CREATE INDEX TA685_2 ON TA685(DESCRIPCIO);                                       

/*TA686 Codigos de Absorci�n de Baldosas                  */
CREATE TABLE IF NOT EXISTS TA686(
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(15) DEFAULT "",   
   PRIMARY KEY(CODIGO));                                  
CREATE INDEX TA686_1 ON TA686(CODIGO);                    
CREATE INDEX TA686_2 ON TA686(DESCRIPCIO);                                       

/*TA687 Composici�n del Tejido del Calzado                */
CREATE TABLE IF NOT EXISTS TA687(
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(50) DEFAULT "",   
   NENVIO      CHAR(3) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                  
CREATE INDEX TA687_1 ON TA687(CODIGO);                    
CREATE INDEX TA687_2 ON TA687(DESCRIPCIO);                                       
                                                                                                                                                                                     
/*TA688 Tipo de Manga Parte Superior                      */
CREATE TABLE IF NOT EXISTS TA688(
   CODIGO      CHAR(4) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(25) DEFAULT "",   
   PRIMARY KEY(CODIGO));                                  
CREATE INDEX TA688_1 ON TA688(CODIGO);                    
CREATE INDEX TA688_2 ON TA688(DESCRIPCIO);                                                                                                                                                                                                                          
                                                                                                                                                                                  
                                                                                                                                                                                     
/*TA689 Tipo de Cuello Parte Superior                      */
CREATE TABLE IF NOT EXISTS TA689(
   CODIGO      CHAR(3) NOT NULL, 
   DESCRIPCIO  VARCHAR(20) DEFAULT "",   
   NENVIO      CHAR(3) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                  
CREATE INDEX TA689_1 ON TA689(CODIGO);                    
CREATE INDEX TA689_2 ON TA689(DESCRIPCIO);                                       
                                                                                                                                                                                    
/*TA690 Parte Externa Parte Superior                       */
CREATE TABLE IF NOT EXISTS TA690(
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(30) DEFAULT "",   
   NENVIO      CHAR(3) DEFAULT "",                                  
   PRIMARY KEY(CODIGO));                                  
CREATE INDEX TA690_1 ON TA690(CODIGO);                    
CREATE INDEX TA690_2 ON TA690(DESCRIPCIO);                                       
                                                                                                                                                                                    
/*TA691 Parte Interna Parte Superior                      */
CREATE TABLE IF NOT EXISTS TA691(
   CODIGO      CHAR(4) NOT NULL,                                            
   DESCRIPCIO  VARCHAR(15) DEFAULT "",   
   NENVIO      CHAR(3) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                  
CREATE INDEX TA691_1 ON TA691(CODIGO);                    
CREATE INDEX TA691_2 ON TA691(DESCRIPCIO);                                                                                                                                                                                                                          

/*TA692 Largo Parte Superior                              */
CREATE TABLE IF NOT EXISTS TA692(
   CODIGO      CHAR(4) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(20) DEFAULT "",   
   NENVIO      CHAR(3) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                  
CREATE INDEX TA692_1 ON TA692(CODIGO);                    
CREATE INDEX TA692_2 ON TA692(DESCRIPCIO);                                                                                                                                                                                                                          

/*TA693 Bolsillo Parte Superior                           */
CREATE TABLE IF NOT EXISTS TA693(
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(20) DEFAULT "",   
   PRIMARY KEY(CODIGO));                                  
CREATE INDEX TA693_1 ON TA693(CODIGO);                    
CREATE INDEX TA693_2 ON TA693(DESCRIPCIO);                                                                                                                                                                                                                          

/*TA694 Cintura Parte Superior                            */
CREATE TABLE IF NOT EXISTS TA694(
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(45) DEFAULT "",   
   PRIMARY KEY(CODIGO));                                  
CREATE INDEX TA694_1 ON TA694(CODIGO);                    
CREATE INDEX TA694_2 ON TA694(DESCRIPCIO);                                                                                                                                                                                                                          

/*TA695 Largo Parte Inferior                              */
CREATE TABLE IF NOT EXISTS TA695(
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(20) DEFAULT "",   
   NENVIO      CHAR(3) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                  
CREATE INDEX TA695_1 ON TA695(CODIGO);                    
CREATE INDEX TA695_2 ON TA695(DESCRIPCIO);                                                                                                                                                                                                                          

/*TA696 Pie Parte Inferior                                 */
CREATE TABLE IF NOT EXISTS TA696(
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(12) DEFAULT "",   
   PRIMARY KEY(CODIGO));                                  
CREATE INDEX TA696_1 ON TA696(CODIGO);                    
CREATE INDEX TA696_2 ON TA696(DESCRIPCIO);                                                                                                                                                                                                                          

/*TA697 Abertura Parte Inferior                           */
CREATE TABLE IF NOT EXISTS TA697(
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(50) DEFAULT "",   
   PRIMARY KEY(CODIGO));                                  
CREATE INDEX TA697_1 ON TA697(CODIGO);                    
CREATE INDEX TA697_2 ON TA697(DESCRIPCIO);                                                                                                                                                                                                                          

/*TA698 Bolsillos Parte Inferior                           */
CREATE TABLE IF NOT EXISTS TA698(
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(40) DEFAULT "",   
   PRIMARY KEY(CODIGO));                                  
CREATE INDEX TA698_1 ON TA698(CODIGO);                    
CREATE INDEX TA698_2 ON TA698(DESCRIPCIO);                                                                                                                                                                            

/*TA699 Cintura Parte Inferior                             */
CREATE TABLE IF NOT EXISTS TA699(
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(50) DEFAULT "",   
   PRIMARY KEY(CODIGO));                                  
CREATE INDEX TA699_1 ON TA699(CODIGO);                    
CREATE INDEX TA699_2 ON TA699(DESCRIPCIO);                                                                                                                                                                                                                          

/*TA700 Peto inferior                                      */
CREATE TABLE IF NOT EXISTS TA700(
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(20) DEFAULT "",   
   PRIMARY KEY(CODIGO));                                  
CREATE INDEX TA700_1 ON TA700(CODIGO);                    
CREATE INDEX TA700_2 ON TA700(DESCRIPCIO);                                                                                                                                                                                                                          

/*TA701 Caras de la Prenda                                  */
CREATE TABLE IF NOT EXISTS TA701(
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(20) DEFAULT "",   
   PRIMARY KEY(CODIGO));                                  
CREATE INDEX TA701_1 ON TA701(CODIGO);                    
CREATE INDEX TA701_2 ON TA701(DESCRIPCIO);                                                                                                                                                                                                                          

/*TA702 Elastico de la Prenda                             */
CREATE TABLE IF NOT EXISTS TA702(
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(15) DEFAULT "",   
   PRIMARY KEY(CODIGO));                                  
CREATE INDEX TA702_1 ON TA702(CODIGO);                    
CREATE INDEX TA702_2 ON TA702(DESCRIPCIO);                                                                                                                                                                                                                          

/*TA703 Presentaci�n de Ropa de Cama                                               */
CREATE TABLE IF NOT EXISTS TA703(
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(15) DEFAULT "",   
   PRIMARY KEY(CODIGO));                                  
CREATE INDEX TA703_1 ON TA703(CODIGO);                    
CREATE INDEX TA703_2 ON TA703(DESCRIPCIO);                                                                                                                                                                                                                          

/*TA704 Forma de la Prenda                                 */
CREATE TABLE IF NOT EXISTS TA704(
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(15) DEFAULT "",   
   PRIMARY KEY(CODIGO));                                  
CREATE INDEX TA704_1 ON TA704(CODIGO);                    
CREATE INDEX TA704_2 ON TA704(DESCRIPCIO);                                                                                                                                                                                                                          

/*TA705 Relleno de Almohadas                              */
CREATE TABLE IF NOT EXISTS TA705(
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(35) DEFAULT "",   
   PRIMARY KEY(CODIGO));                                  
CREATE INDEX TA705_1 ON TA705(CODIGO);                    
CREATE INDEX TA705_2 ON TA705(DESCRIPCIO);                                                                                                                                                                                                                          

/*TA706 Aplicaciones Prendas de Vestir                     */
CREATE TABLE IF NOT EXISTS TA706(
   CODIGO      CHAR(4) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(65) DEFAULT "",   
   NENVIO      CHAR(3) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                  
CREATE INDEX TA706_1 ON TA706(CODIGO);                    
CREATE INDEX TA706_2 ON TA706(DESCRIPCIO);                                                                                                                                                                                                                          

/*TA707 Complementos Prendas de Vestir                     */
CREATE TABLE IF NOT EXISTS TA707(
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(15) DEFAULT "",   
   PRIMARY KEY(CODIGO));                                  
CREATE INDEX TA707_1 ON TA707(CODIGO);                    
CREATE INDEX TA707_2 ON TA707(DESCRIPCIO);                                                                                                                                                                                                                          

/*TA708 Presentaci�n Ropa de Cama                         */
CREATE TABLE IF NOT EXISTS TA708(
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(15) DEFAULT "",   
   PRIMARY KEY(CODIGO));                                  
CREATE INDEX TA708_1 ON TA708(CODIGO);                    
CREATE INDEX TA708_2 ON TA708(DESCRIPCIO);                                                                                                                                                                                                                          

/*TA709 Piezas Parte Superior                                */
CREATE TABLE IF NOT EXISTS TA709(
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(35) DEFAULT "",   
   NENVIO      CHAR(3) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                  
CREATE INDEX TA709_1 ON TA709(CODIGO);                    
CREATE INDEX TA709_2 ON TA709(DESCRIPCIO);                                                                                                                                                                                                                          

/*TA710 SubTipo Asociado al Documento de Autorizaci�n     */
CREATE TABLE IF NOT EXISTS TA710(
   CODIGO      CHAR(2) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(130) DEFAULT "",  
   FLAG_XML    CHAR(1) DEFAULT "",  
   PRIMARY KEY(CODIGO));                                  
CREATE INDEX TA710_1 ON TA710(CODIGO);                    
CREATE INDEX TA710_2 ON TA710(DESCRIPCIO);                                                                                                                                                                                                                          


/*TA711 Sub Entidad Asociada a la Autorizaci�n                 */
CREATE TABLE IF NOT EXISTS TA711(
   CODIGO      CHAR(4) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(130) DEFAULT "",   
   ENTIDAD     CHAR(2) DEFAULT "",   
   PRIMARY KEY(CODIGO));                                  
CREATE INDEX TA711_1 ON TA711(CODIGO);                    
CREATE INDEX TA711_2 ON TA711(DESCRIPCIO);                                                                                                                                                              

/*TA712 Codigo de los representantes legales para la UIF         */
CREATE TABLE IF NOT EXISTS TA712(
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(70) DEFAULT "",   
   PRIMARY KEY(CODIGO));                                  
CREATE INDEX TA712_1 ON TA712(CODIGO);                    
CREATE INDEX TA712_2 ON TA712(DESCRIPCIO);                                                                                                                                                                                                                          

/*TA713 Tabla de Ultima Transaccion de Contenedores        */
CREATE TABLE IF NOT EXISTS TA713(
   CODIGO      CHAR(2) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(100) DEFAULT "",   
   PRIMARY KEY(CODIGO));                                  
CREATE INDEX TA713_1 ON TA713(CODIGO);                    
CREATE INDEX TA713_2 ON TA713(DESCRIPCIO);                                                                                                                                                                                                                          

/*TA714 Tipo de Tejido de Calzado para TXT                */
CREATE TABLE IF NOT EXISTS TA714(
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPC    VARCHAR(40) DEFAULT "",   
   PRIMARY KEY(CODIGO));                                  
CREATE INDEX TA714_1 ON TA714(CODIGO);                    
CREATE INDEX TA714_2 ON TA714(DESCRIPC);                                                                                                                                                                                                                          

/*TA715 Tabla de Terminales para Despacho Anticipado      */
CREATE TABLE IF NOT EXISTS TA715(
   CODIGO      CHAR(11) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(80) DEFAULT "",   
   DIRECCION   VARCHAR(90) DEFAULT "",   
   C_ADUANA    CHAR(3) DEFAULT "",
   PRIMARY KEY(CODIGO));                                  
CREATE INDEX TA715_1 ON TA715(CODIGO);                    
CREATE INDEX TA715_2 ON TA715(DESCRIPCIO);

/*TA717 Tipo de Lugar de carga - Transbordo */
CREATE TABLE IF NOT EXISTS TA717(
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(20) DEFAULT "",   
   PRIMARY KEY(CODIGO));                                  
CREATE INDEX TA717_1 ON TA717(CODIGO);                    
CREATE INDEX TA717_2 ON TA717(DESCRIPCIO);                                                                                                                                                                                                                          
 
/*TA718 Tipo de Tranpostista - Transbordo */
CREATE TABLE IF NOT EXISTS TA718(
   CODIGO      CHAR(2) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(20) DEFAULT "",   
   PRIMARY KEY(CODIGO));                                  
CREATE INDEX TA718_1 ON TA718(CODIGO);                    
CREATE INDEX TA718_2 ON TA718(DESCRIPCIO);

/*TA719 Tabla de Modalidades de envio para TRansbordo en XML */
CREATE TABLE IF NOT EXISTS TA719(
   CODIGO      CHAR(2) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(60) DEFAULT "",   
   POSICION    CHAR(1) DEFAULT "",   
   PRIMARY KEY(CODIGO));                                  
CREATE INDEX TA719_1 ON TA719(CODIGO);                    
CREATE INDEX TA719_2 ON TA719(DESCRIPCIO);

/*TA720 Modalidades de Gradualidad                         */
CREATE TABLE IF NOT EXISTS TA720(
   CODIGO      CHAR(1) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(40) DEFAULT "",   
   PRIMARY KEY(CODIGO));                                  
CREATE INDEX TA720_1 ON TA720(CODIGO);                    
CREATE INDEX TA720_2 ON TA720(DESCRIPCIO);

/*TA721 Cronograma de Alianza del Pacifico                                         */
CREATE TABLE IF NOT EXISTS TA721(
   CODIGO      CHAR(5) NOT NULL,
   MPO         DECIMAL(6,2) DEFAULT 0.00,
   FECH_INI    DATE,
   FECH_TER    DATE,
   ORDEN       CHAR(2) DEFAULT "",                                                
   DESCRIPCIO  VARCHAR(40) DEFAULT "",   
   PRIMARY KEY(CODIGO,ORDEN));                                  
CREATE INDEX TA721_1 ON TA721(CODIGO,ORDEN);                    

/*TA722 Modalidades de Gradualidad                         */
CREATE TABLE IF NOT EXISTS TA722(
   PARTIDA       Char(10) not null,
   DESCRIPCIO    Varchar(250) default "",
   BASE          Numeric(5,0) default 0, 
   MPO           Char(5) default "",
   TM            Char(5) default "",
   PAIS          Char(2) default "",
   OBSERVACIO    Varchar(250) default "",
   A_2014        Char(12) default "",
   A_2015        Char(12) default "",
   A_2016        Char(12) default "",
   A_2017        Char(8) default "",
   A_2018        Char(12) default "",
   A_2019        Char(12) default "",
   A_2020        Char(12) default "",
   A_2021        Char(12) default "",
   A_2022        Char(12) default "",
   A_2023        Char(12) default "",
   A_2024        Char(12) default "",
   A_2025        Char(12) default "",
   A_2026        Char(12) default "",
   A_2027        Char(12) default "",
   A_2028        Char(12) default "",
   A_2029        Char(12) default "",
   A_2030        Char(12) default "",
   PARTIDA_AN    CHAR(10) DEFAULT "",
   PRIMARY KEY(partida,pais,descripcio));                                  
CREATE INDEX TA722_1 ON TA722(partida);                    
CREATE INDEX TA722_2 ON TA722(DESCRIPCIO);

/*TA723 Tipo Certificado - Alianza Pacifico                                        */
CREATE TABLE IF NOT EXISTS TA723(
   CODIGO      CHAR(1) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(61) DEFAULT "",   
   DESCRIPC2   VARCHAR(61) DEFAULT "",   
   PRIMARY KEY(CODIGO));                                  
CREATE INDEX TA723_1 ON TA723(CODIGO);                    
CREATE INDEX TA723_2 ON TA723(DESCRIPCIO);

/*TA724 Criterio Origen - Alianza Pacifico                                                        */
CREATE TABLE IF NOT EXISTS TA724(
   CODIGO      CHAR(1) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(68) DEFAULT "",   
   DESCRIPC2   VARCHAR(68) DEFAULT "",   
   DESCRIPC3   VARCHAR(68) DEFAULT "",   
   PRIMARY KEY(CODIGO));                                  
CREATE INDEX TA724_1 ON TA724(CODIGO);                    
CREATE INDEX TA724_2 ON TA724(DESCRIPCIO);
 
/*TA725 Factores de Conversi�n                   */
CREATE TABLE IF NOT EXISTS TA725(
   FECHA       DATE,            
   FECH_VCTO   DATE,                                 
   ANG         DECIMAL(8,6) DEFAULT 0.00,
   AOR         DECIMAL(8,6) DEFAULT 0.00,
   ARS         DECIMAL(8,6) DEFAULT 0.00,
   ATS         DECIMAL(8,6) DEFAULT 0.00,
   AUD         DECIMAL(8,6) DEFAULT 0.00,
   AWG         DECIMAL(8,6) DEFAULT 0.00,
   BBD         DECIMAL(8,6) DEFAULT 0.00,
   BEF         DECIMAL(8,6) DEFAULT 0.00,
   BGL         DECIMAL(8,6) DEFAULT 0.00,
   BOB         DECIMAL(8,6) DEFAULT 0.00,
   BRL         DECIMAL(8,6) DEFAULT 0.00,
   CAD         DECIMAL(8,6) DEFAULT 0.00,
   CHF         DECIMAL(8,6) DEFAULT 0.00,
   CLP         DECIMAL(8,6) DEFAULT 0.00,
   CNY         DECIMAL(8,6) DEFAULT 0.00,
   COP         DECIMAL(8,6) DEFAULT 0.00,
   CRC         DECIMAL(8,6) DEFAULT 0.00,
   CUP         DECIMAL(8,6) DEFAULT 0.00,
   CYP         DECIMAL(8,6) DEFAULT 0.00,
   CZK         DECIMAL(8,6) DEFAULT 0.00,
   DEM         DECIMAL(8,6) DEFAULT 0.00,
   DKK         DECIMAL(8,6) DEFAULT 0.00,
   DOP         DECIMAL(8,6) DEFAULT 0.00,
   DZD         DECIMAL(8,6) DEFAULT 0.00,
   ECS         DECIMAL(8,6) DEFAULT 0.00,
   EGP         DECIMAL(8,6) DEFAULT 0.00,
   ESP         DECIMAL(8,6) DEFAULT 0.00,
   FIM         DECIMAL(8,6) DEFAULT 0.00,
   FJD         DECIMAL(8,6) DEFAULT 0.00,
   FRF         DECIMAL(8,6) DEFAULT 0.00,
   GBP         DECIMAL(8,6) DEFAULT 0.00,
   GRD         DECIMAL(8,6) DEFAULT 0.00, 
   GTQ         DECIMAL(8,6) DEFAULT 0.00,
   HKD         DECIMAL(8,6) DEFAULT 0.00,
   HNL         DECIMAL(8,6) DEFAULT 0.00,
   HTG         DECIMAL(8,6) DEFAULT 0.00,
   HUF         DECIMAL(8,6) DEFAULT 0.00,
   IDR         DECIMAL(8,6) DEFAULT 0.00,
   IEP         DECIMAL(8,6) DEFAULT 0.00,
   ILS         DECIMAL(8,6) DEFAULT 0.00,
   INR         DECIMAL(8,6) DEFAULT 0.00,
   IRR         DECIMAL(8,6) DEFAULT 0.00,
   ITL         DECIMAL(8,6) DEFAULT 0.00,
   JMD         DECIMAL(8,6) DEFAULT 0.00,
   JOD         DECIMAL(8,6) DEFAULT 0.00,
   JPY         DECIMAL(8,6) DEFAULT 0.00,
   KPW         DECIMAL(8,6) DEFAULT 0.00,
   KRW         DECIMAL(8,6) DEFAULT 0.00,
   KWD         DECIMAL(8,6) DEFAULT 0.00,
   LVL         DECIMAL(8,6) DEFAULT 0.00,
   MAD         DECIMAL(8,6) DEFAULT 0.00,
   MXN         DECIMAL(8,6) DEFAULT 0.00,
   MYR         DECIMAL(8,6) DEFAULT 0.00,
   NAD         DECIMAL(8,6) DEFAULT 0.00,
   NGN         DECIMAL(8,6) DEFAULT 0.00,
   NIO         DECIMAL(8,6) DEFAULT 0.00,
   NLG         DECIMAL(8,6) DEFAULT 0.00,
   NOK         DECIMAL(8,6) DEFAULT 0.00,
   NZD         DECIMAL(8,6) DEFAULT 0.00,
   PAB         DECIMAL(8,6) DEFAULT 0.00,
   PEN         DECIMAL(8,6) DEFAULT 0.00,
   PHP         DECIMAL(8,6) DEFAULT 0.00,
   PKR         DECIMAL(8,6) DEFAULT 0.00,
   PLN         DECIMAL(8,6) DEFAULT 0.00,
   PTE         DECIMAL(8,6) DEFAULT 0.00,
   PYG         DECIMAL(8,6) DEFAULT 0.00,
   ROL         DECIMAL(8,6) DEFAULT 0.00,
   RUB         DECIMAL(8,6) DEFAULT 0.00,
   RUR         DECIMAL(8,6) DEFAULT 0.00,
   SAR         DECIMAL(8,6) DEFAULT 0.00,
   SEK         DECIMAL(8,6) DEFAULT 0.00,
   SGD         DECIMAL(8,6) DEFAULT 0.00,
   SVC         DECIMAL(8,6) DEFAULT 0.00,
   SYP         DECIMAL(8,6) DEFAULT 0.00,
   THB         DECIMAL(8,6) DEFAULT 0.00,
   TRL         DECIMAL(8,6) DEFAULT 0.00,
   TTD         DECIMAL(8,6) DEFAULT 0.00,
   TWD         DECIMAL(8,6) DEFAULT 0.00,
   UAH         DECIMAL(8,6) DEFAULT 0.00,
   USD         DECIMAL(8,6) DEFAULT 0.00,
   UYU         DECIMAL(8,6) DEFAULT 0.00,
   VEB         DECIMAL(8,6) DEFAULT 0.00,
   VND         DECIMAL(8,6) DEFAULT 0.00,
   XEU         DECIMAL(8,6) DEFAULT 0.00,
   PRIMARY KEY(FECHA));                                  
CREATE INDEX TA725_1 ON TA725(FECHA);        
           
/*TA726 Tipos de Declarantes para la UIF                                                       */
CREATE TABLE IF NOT EXISTS TA726(
   CODIGO      CHAR(1) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(25) DEFAULT "",   
   PRIMARY KEY(CODIGO));                                  
CREATE INDEX TA726_1 ON TA726(CODIGO);                    
CREATE INDEX TA726_2 ON TA726(DESCRIPCIO);

/*TA727 Tipos de Declarantes para la UIF                                                       */
CREATE TABLE IF NOT EXISTS TA727(
   CODIGO      CHAR(2) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(25) DEFAULT "",   
   PRIMARY KEY(CODIGO));                                  
CREATE INDEX TA727_1 ON TA727(CODIGO);                    
CREATE INDEX TA727_2 ON TA727(DESCRIPCIO);

/*TA728 Tipo de Comprobante - Facturas Electronicas       */
CREATE TABLE IF NOT EXISTS TA728(
   CODIGO      CHAR(8) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(80) DEFAULT "",   
   PREFIJO     CHAR(8) DEFAULT "",   
   PRIMARY KEY(CODIGO));                                  
CREATE INDEX TA728_1 ON TA728(CODIGO);                    
CREATE INDEX TA728_2 ON TA728(DESCRIPCIO);

/* TA729( Correlacion arancel 2012 - 2017  )*/            
CREATE TABLE IF NOT EXISTS TA729(                                               
   PAB1        CHAR(10) NOT NULL,                                                
   PAB2        CHAR(10) NOT NULL,                                                
   C           VARCHAR(254) DEFAULT "",                                              
   PRIMARY KEY(PAB1,PAB2));                                               
CREATE INDEX TA729_1 ON TA729(PAB1);                             
CREATE INDEX TA729_2 ON TA729(PAB2);                             

/*TA730 (Partidas TLC - CON HONDURAS  )*/
CREATE TABLE IF NOT EXISTS TA730(
   PARTIDA     CHAR(10) NOT NULL,                                               
   DESCRIPC    VARCHAR(140) DEFAULT "",   	                                      
   BASE        NUMERIC(4,0) DEFAULT 0,
   MPO         CHAR(3) DEFAULT "",                                              
   TM          CHAR(5) DEFAULT "",                                              
   OB1         VARCHAR(16) DEFAULT "",                                              
   OB2         VARCHAR(65) DEFAULT "",                                              
   PARTIDA_AN  CHAR(10) DEFAULT "",
   DESCRIP2    VARCHAR(140) DEFAULT "",   	                                      
   PRIMARY KEY(PARTIDA,DESCRIPC));                                                       
CREATE INDEX TA730_1 ON TA730(PARTIDA);                                         

/*TA731 (Cronograma TLC con Honduras        )*/
CREATE TABLE IF NOT EXISTS TA731(
   CODIGO      CHAR(5) NOT NULL,                                               
   MPO         DECIMAL(6,2) DEFAULT 0,
   FECH_INI    DATE,
   FECH_TER    DATE,
   ORDEN       CHAR(2),
   PRIMARY KEY(CODIGO,ORDEN));                                                       
CREATE INDEX TA731_1 ON TA731(CODIGO);                                         

/* TA732( Tipos de Documentos de Identidad para la UIF )*/            
CREATE TABLE IF NOT EXISTS TA732(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(60) DEFAULT "",                                              
   PRIMARY KEY(CODIGO));                                               
CREATE INDEX TA732_1 ON TA732(CODIGO);                             
CREATE INDEX TA732_2 ON TA732(DESCRIPCIO);                             

/* TA733( Ocupacion de las personas Naturales para la UIF )*/            
CREATE TABLE IF NOT EXISTS TA733(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(60) DEFAULT "",                                              
   PRIMARY KEY(CODIGO));                                               
CREATE INDEX TA733_1 ON TA733(CODIGO);                             
CREATE INDEX TA733_2 ON TA733(DESCRIPCIO);     

/* TA734( TABLAS DE MARCA DE VEHICULOS )*/                                      
CREATE TABLE IF NOT EXISTS TA734(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(25) DEFAULT "",                                          
   FECHAINI    DATE,                                                            
   FECHAFIN    DATE,                                                            
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA734_1 ON TA734(CODIGO);                                          
CREATE INDEX TA734_2 ON TA734(DESCRIPCIO);                                      
   
/* TA735( TABLAS DE TIPO DE CARROCERIA DE VEHICULOS )*/                         
CREATE TABLE IF NOT EXISTS TA735(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(35) DEFAULT "",                                          
   DESCRIP1    VARCHAR(70) DEFAULT "",                                          
   DESCRIP2    VARCHAR(70) DEFAULT "",                                          
   DESCRIP3    VARCHAR(70) DEFAULT "",                                          
   DESCRIP4    VARCHAR(70) DEFAULT "",                                          
   DESCRIP5    VARCHAR(70) DEFAULT "",                                          
   DESCRIP6    VARCHAR(70) DEFAULT "",                                          
   DESCRIP7    VARCHAR(70) DEFAULT "",                                          
   DESCRIP8    VARCHAR(70) DEFAULT "",                                          
   DESCRIP9    VARCHAR(70) DEFAULT "",                                          
   DESCRIP10   VARCHAR(70) DEFAULT "",                                          
   FECHAINI    DATE,                                                            
   FECHAFIN    DATE,                                                            
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA735_1 ON TA735(CODIGO);                                          
CREATE INDEX TA735_2 ON TA735(DESCRIPCIO);                                      
                        
/* TA736( TABLAS DE TIPO DE CATEGORIA )*/                         
CREATE TABLE IF NOT EXISTS TA736(                                               
   CODIGO      CHAR(4) NOT NULL,                                                
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA736_1 ON TA736(CODIGO);   

/* TA737( COLOR DE LAMINAS PLASTIFICADAS )*/                         
CREATE TABLE IF NOT EXISTS TA737(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(30) DEFAULT "",
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA737_1 ON TA737(CODIGO);   
CREATE INDEX TA737_2 ON TA737(DESCRIPCIO);                                                                                                   

/* TA738( CONDICION DE RESIDENCIA DEL DECLARANTE )*/                         
CREATE TABLE IF NOT EXISTS TA738(                                               
   CODIGO      CHAR(1) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(25) DEFAULT "",
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA738_1 ON TA738(CODIGO);   
CREATE INDEX TA738_2 ON TA738(DESCRIPCIO);                                                                            
                                    
/* TA739( DECLARANTE QUE ACTUA EN REPRESENTACION PARA LA UIF  )*/                         
CREATE TABLE IF NOT EXISTS TA739(                                               
   CODIGO      CHAR(1) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(25) DEFAULT "",
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA739_1 ON TA739(CODIGO);   
CREATE INDEX TA739_2 ON TA739(DESCRIPCIO);                                                                            

/* TA740( Nombre Comercial - Sanitarios (562)               )*/                         
CREATE TABLE IF NOT EXISTS TA740(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(60) DEFAULT "",
   DESCRIPCI2  VARCHAR(20) DEFAULT "",
   PARTIDA     CHAR(10) DEFAULT "",
   PARTIDA_AN  CHAR(10) DEFAULT "",
   PRIMARY KEY(CODIGO,PARTIDA));                                                        
CREATE INDEX TA740_1 ON TA740(CODIGO);   
CREATE INDEX TA740_2 ON TA740(DESCRIPCIO); 

/*TA741 Tipo - Sanitarios (563)                           */
CREATE TABLE IF NOT EXISTS TA741(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(31) DEFAULT "",
   DESCRIPCI2  VARCHAR(20) DEFAULT "",
   TIPO        CHAR(3) DEFAULT "",
   COD_SAN     CHAR(3) DEFAULT "",
   PRIMARY KEY(CODIGO,TIPO,COD_SAN));                                                        
CREATE INDEX TA741_1 ON TA741(CODIGO);   
CREATE INDEX TA741_2 ON TA741(DESCRIPCIO); 

/*TA742 Tipo Logitud de Aro  - Sanitarios                 */
CREATE TABLE IF NOT EXISTS TA742(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(10) DEFAULT "",
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA742_1 ON TA742(CODIGO);   
CREATE INDEX TA742_2 ON TA742(DESCRIPCIO); 

/*TA743 Tipo de funcionamiento  -  Sanitarios             */
CREATE TABLE IF NOT EXISTS TA743(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(10) DEFAULT "",
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA743_1 ON TA743(CODIGO);   
CREATE INDEX TA743_2 ON TA743(DESCRIPCIO); 

/*TA744 Tabla de Descripciones Minimas  - Resumida        */
CREATE TABLE IF NOT EXISTS TA744(                                               
   CODIGO      CHAR(6) NOT NULL,                                                
   DESCRIPCI1  VARCHAR(180) DEFAULT "",
   DESCRIPCI2  VARCHAR(30) DEFAULT "",
   TIPO        CHAR(1) DEFAULT "",
   COD_ADUANA  CHAR(6) NOT NULL,
   PRIMARY KEY(COD_ADUANA,CODIGO));                                  
CREATE INDEX TA744_1 ON TA744(CODIGO);   
CREATE INDEX TA744_2 ON TA744(DESCRIPCI1); 
                                                                       
/*TA745 Tipo de Protectores de Celulares                   */
CREATE TABLE IF NOT EXISTS TA745(                                               
   CODIGO      CHAR(6) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(35) DEFAULT "",
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA745_1 ON TA745(CODIGO);   
CREATE INDEX TA745_2 ON TA745(DESCRIPCIO); 

/*TA746 Indicador de cambio de Precinto                   */
CREATE TABLE IF NOT EXISTS TA746(                                               
   CODIGO      CHAR(2) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(42) DEFAULT "",
   TIPO        CHAR(1) DEFAULT "",
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA746_1 ON TA746(CODIGO);   
CREATE INDEX TA746_2 ON TA746(DESCRIPCIO); 

/*TA747 Mercanc�a Restringida                             */
CREATE TABLE IF NOT EXISTS TA747(                                               
   ANEXO       CHAR(2) NOT NULL,                                                
   SUB_ANEXO   CHAR(4) NOT NULL,                                                
   PARTIDA     CHAR(10) NOT NULL,                                               
   DES1        VARCHAR(73) DEFAULT "",                                          
   DES2        VARCHAR(71) DEFAULT "",                                          
   DES3        VARCHAR(71) DEFAULT "",                                          
   INICIO      DATE,                                          
   PRIMARY KEY(PARTIDA,ANEXO,SUB_ANEXO,DES1,DES2,DES3));                                       
CREATE INDEX TA747_1 ON TA138(PARTIDA,ANEXO,SUB_ANEXO,DES1);                         

/* TA748(Entidades Mercanc�a Restringida                    )*/                                   
CREATE TABLE IF NOT EXISTS TA748(                                               
   ANEXO       CHAR(2) NOT NULL,                                                
   SUB_ANEXO   CHAR(4) NOT NULL,                                                
   PRODUCTO    VARCHAR(230) DEFAULT "",                                         
   CODENTIDAD  CHAR(2) DEFAULT "",                                              
   AUTORIZAC   VARCHAR(230) DEFAULT "",                                         
   BASELEGAL   VARCHAR(230) DEFAULT "",                                         
   NOTA1       VARCHAR(230) DEFAULT "",                                         
   NOTA2       VARCHAR(230) DEFAULT "",                                         
   DS          VARCHAR(125) DEFAULT "",                                         
   PRIMARY KEY(ANEXO,SUB_ANEXO));                                               
CREATE INDEX TA748_1 ON TA748(ANEXO,SUB_ANEXO);                                 

/*TA749 Partidas de Reglamento de Asbesto                 */
CREATE TABLE IF NOT EXISTS TA749(                                               
   PARTIDA   CHAR(10) NOT NULL,                                                
   DESCRIPC  VARCHAR(80) DEFAULT "",
   DESCRIPC2 VARCHAR(80) DEFAULT "",
   DESCRIPC3 VARCHAR(80) DEFAULT "",
   PRIMARY KEY(PARTIDA));                                                        
CREATE INDEX TA749_1 ON TA749(PARTIDA);   
CREATE INDEX TA749_2 ON TA749(DESCRIPC); 

/*TA750 Region de Destino para el CAN */
CREATE TABLE IF NOT EXISTS TA750(                                               
   CODIGO   CHAR(5) NOT NULL,                                                
   DESCRIPC  VARCHAR(60) DEFAULT "",
   COD_P_PRO CHAR(2) NOT NULL,
   PRIMARY KEY(COD_P_PRO,CODIGO));                                                        
CREATE INDEX TA750_1 ON TA750(COD_P_PRO,CODIGO);   
CREATE INDEX TA750_2 ON TA750(DESCRIPC); 

/*TA751 Unidad de Carga para el CAN*/
CREATE TABLE IF NOT EXISTS TA751(                                               
   CODIGO   CHAR(2) NOT NULL,                                                
   DESCRIPC  VARCHAR(37) DEFAULT "",
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA751_1 ON TA751(CODIGO);   
CREATE INDEX TA751_2 ON TA751(DESCRIPC); 

/*TA752 Tipo de Resolucion para el CAN*/
CREATE TABLE IF NOT EXISTS TA752(                                               
   CODIGO   CHAR(2) NOT NULL,                                                
   DESCRIPC  VARCHAR(26) DEFAULT "",
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA752_1 ON TA752(CODIGO);   
CREATE INDEX TA752_2 ON TA752(DESCRIPC); 

/*TA753 Tipo de Medio de pago para el CAN*/
CREATE TABLE IF NOT EXISTS TA753(                                               
   CODIGO   CHAR(2) NOT NULL,                                                
   DESCRIPC  VARCHAR(29) DEFAULT "",
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA753_1 ON TA753(CODIGO);   
CREATE INDEX TA753_2 ON TA753(DESCRIPC); 

/*TA754 Codigo de Entidad Financiera para el CAN */
CREATE TABLE IF NOT EXISTS TA754(                                               
   CODIGO   CHAR(2) NOT NULL,                                                
   DESCRIPC  VARCHAR(80) DEFAULT "",
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA754_1 ON TA754(CODIGO);   
CREATE INDEX TA754_2 ON TA754(DESCRIPC); 

CREATE TABLE IF NOT EXISTS TA755(                         
/*TA755 Tabla de Entidades de la Matricula - XML-MANIF */                      
   CODIGO      CHAR(2) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(60) DEFAULT "",
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA755_1 ON TA755(CODIGO);   
CREATE INDEX TA755_2 ON TA755(DESCRIPCIO); 

CREATE TABLE IF NOT EXISTS TA756(                         
/*TA756 Tabla de A la Orden de la Matricula - XML-MANIF */                      
   CODIGO      CHAR(2) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(60) DEFAULT "",
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA756_1 ON TA756(CODIGO);   
CREATE INDEX TA756_2 ON TA756(DESCRIPCIO); 

CREATE TABLE IF NOT EXISTS TA757(                         
/*TA757 Tabla de Transacciones del IRM-MANIF */                      
   CODIGO      CHAR(2) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(30) DEFAULT "",
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA757_1 ON TA757(CODIGO);   
CREATE INDEX TA757_2 ON TA757(DESCRIPCIO); 

/* TA758 ( TABLAS DE LUGAR DE EMBARQUE )*/                 
CREATE TABLE IF NOT EXISTS TA758(                                               
   RUC         CHAR(11) NOT NULL,
   NOMBRE      VARCHAR(55) DEFAULT "",                                          
   C_ADUANA    CHAR(3) DEFAULT "",                                              
   PRIMARY KEY(RUC));                                                        
CREATE INDEX TA758_1 ON TA758(RUC);                                          
CREATE INDEX TA758_2 ON TA758(NOMBRE);                                        

/* TA759 ( TIPO DE LUGAR DE EMBARQUE )*/                 
CREATE TABLE IF NOT EXISTS TA759(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(50) DEFAULT "",
   TIPO_DESP   CHAR(1) DEFAULT "",
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA759_1 ON TA759(CODIGO);                                          
CREATE INDEX TA759_2 ON TA759(DESCRIPCIO);   
                                     
/* TA762 ( ANEXO DEL CODIGO DE BIEN (MUA) )*/                 
CREATE TABLE IF NOT EXISTS TA762(                                               
   CODIGO      CHAR(2) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(50) DEFAULT "",
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA762_1 ON TA762(CODIGO);                                          
CREATE INDEX TA762_2 ON TA762(DESCRIPCIO);   

/* TA763( NUEVA TABLAS DE BIENES DE MATERIAL PARA USO AERONUTICO )*/                 
CREATE TABLE IF NOT EXISTS TA763(                                               
   CODIGO      CHAR(6) NOT NULL,                                               
   DES1        VARCHAR(65) DEFAULT "",                                          
   DES2        VARCHAR(65) DEFAULT "",                                          
   DES3        VARCHAR(65) DEFAULT "",                                          
   DES4        VARCHAR(65) DEFAULT "",                                          
   DES5        VARCHAR(65) DEFAULT "",                                          
   DES6        VARCHAR(65) DEFAULT "",                                          
   ANEXO       CHAR(2) DEFAULT "",                                             
   STATUS      CHAR(10) default '',
   PRIMARY KEY(ANEXO,CODIGO));                                                        
CREATE INDEX TA763_1 ON TA763(ANEXO,CODIGO);                                          
CREATE INDEX TA763_2 ON TA763(DES1);                                            

/* TA764( TABLAS DE ALMACENES Y DEPOSITOS ADUANEROS )*/                 
CREATE TABLE IF NOT EXISTS TA764(                                               
   CODIGO      CHAR(11) NOT NULL,                                               
   DESCRIPCIO  VARCHAR(85) DEFAULT "",                                          
   STATUS      CHAR(10) default '',
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA764_1 ON TA764(CODIGO);                                          
CREATE INDEX TA764_2 ON TA764(DESCRIPCIO);                                            

/* TA765(TABLAS DE LOCALES ANEXOS DE ALMACENES Y DEPOSITOS ADUANEROS )*/                 
CREATE TABLE IF NOT EXISTS TA765(                                               
   COD_ANEX   CHAR(4) NOT NULL,                                               
   DIRECCION  VARCHAR(85) DEFAULT "",   
   COD_JURIS  CHAR(3) DEFAULT "",                                       
   RUC        CHAR(11) NOT NULL,                                               
   PRIMARY KEY(RUC,COD_ANEX),
   constraint fk_ta765_ta764 foreign key(ruc) references ta764(codigo));                                                        
CREATE INDEX TA765_1 ON TA765(RUC,COD_ANEX);                                          
CREATE INDEX TA765_2 ON TA765(DIRECCION);                                            

/* TA771( OPERACIONES DEL DOC.ASOCIADO RCE )*/                 
CREATE TABLE IF NOT EXISTS TA771(                                               
   CODIGO      CHAR(2) NOT NULL,                                               
   DESCRIPCIO  VARCHAR(70) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA771_1 ON TA771(CODIGO);                                          
CREATE INDEX TA771_2 ON TA771(DESCRIPCIO);                                            

/* TA772( TIPO DE INGRESO DE CONTENEDORES )*/                 
CREATE TABLE IF NOT EXISTS TA772(                                               
   CODIGO      CHAR(1) NOT NULL,                                               
   DESCRIPCIO  VARCHAR(45) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA772_1 ON TA772(CODIGO);                                          
CREATE INDEX TA772_2 ON TA772(DESCRIPCIO);                                            

/* TA773( TIPO DE CONTENEDORES )*/                 
CREATE TABLE IF NOT EXISTS TA773(                                               
   CODIGO      CHAR(2) NOT NULL,                                               
   DESCRIPCIO  VARCHAR(50) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA773_1 ON TA773(CODIGO);                                          
CREATE INDEX TA773_2 ON TA773(DESCRIPCIO);                                            

/* TA774( TIPO DE DESPACHO)*/                 
CREATE TABLE IF NOT EXISTS TA774(                                               
   CODIGO      CHAR(2) NOT NULL,                                               
   DESCRIPCIO  VARCHAR(100) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA774_1 ON TA774(CODIGO);                                          
CREATE INDEX TA774_2 ON TA774(DESCRIPCIO);                                            

/* TA775( FORMA DE PAGO (OMA))*/                 
CREATE TABLE IF NOT EXISTS TA775(                                               
   CODIGO      CHAR(1) NOT NULL,                                               
   DESCRIPCIO  VARCHAR(30) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA775_1 ON TA774(CODIGO);                                          
CREATE INDEX TA775_2 ON TA774(DESCRIPCIO);                                            

/* TA783( FORMA DE PAGO (OMA))*/                 
CREATE TABLE IF NOT EXISTS TA775(                                               
   CODIGO      CHAR(1) NOT NULL,                                               
   DESCRIPCIO  VARCHAR(30) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA775_1 ON TA774(CODIGO);                                          
CREATE INDEX TA775_2 ON TA774(DESCRIPCIO);                                            

/* TA783( TRANSPORTISTAS INTERNOS )*/                   
CREATE TABLE IF NOT EXISTS TA783(                                                
   RUC         CHAR(11) NOT NULL,                                                
   NOMBRE      VARCHAR(50) DEFAULT "",                                          
   PRIMARY KEY(RUC));                                                           
CREATE INDEX TA783_1 ON TA783(RUC);                                               
CREATE INDEX TA783_2 ON TA783(NOMBRE);                                        

/* TA784( PORTUARIOS - RCE )*/                   
CREATE TABLE IF NOT EXISTS TA784(                                                
   RUC         CHAR(11) NOT NULL,                                                
   NOMBRE      VARCHAR(50) DEFAULT "",                                          
   PRIMARY KEY(RUC));                                                           
CREATE INDEX TA784_1 ON TA784(RUC);                                               
CREATE INDEX TA784_2 ON TA784(NOMBRE);                                        

/* TA785( CONDICION DEL CONTENEDOR - RCE )*/                   
CREATE TABLE IF NOT EXISTS TA785(                                                
   CODIGO      CHAR(1) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(7) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                           
CREATE INDEX TA785_1 ON TA785(CODIGO);                                               
CREATE INDEX TA785_2 ON TA785(DESCRIPCIO);        

/* TA786(FORMA DE TRASLADO DE LA MERCANCIA (CONCENTRADOS DE MINERALES) AL LUGAR DE EMBARQUE -DUE  )*/                   
CREATE TABLE IF NOT EXISTS TA786(                                                
   CODIGO      CHAR(2) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(10) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                           
CREATE INDEX TA786_1 ON TA786(CODIGO);                                               
CREATE INDEX TA786_2 ON TA786(DESCRIPCIO);    

/* TA787( TIPO DE CONCENTRADO DE MINERALES -DUE  )*/                   
CREATE TABLE IF NOT EXISTS TA787(                                                
   CODIGO      CHAR(2) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(35) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                           
CREATE INDEX TA787_1 ON TA787(CODIGO);                                               
CREATE INDEX TA787_2 ON TA787(DESCRIPCIO);    

/* TA788( ELEMENTOS DEL CONCENTRADO DE MINERALES-DUE  )*/                   
CREATE TABLE IF NOT EXISTS TA788(                                                
   CODIGO      CHAR(2) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(21) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                           
CREATE INDEX TA788_1 ON TA788(CODIGO);                                               
CREATE INDEX TA788_2 ON TA788(DESCRIPCIO);    
