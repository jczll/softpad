/*VERSION(IDENTIFICA EL MES Y A�O DEL PROCESO DE MANTENIMIENTO*/
CREATE TABLE IF NOT EXISTS VERSION(
   NVERSION CHAR(6) NOT NULL,           /*A�o Y mes del mantenimiento*/
  PRIMARY KEY(NVERSION));            
INSERT INTO VERSION (NVERSION) VALUES ("201706");

CREATE TABLE IF NOT EXISTS AGENCIAS(
   VCOD_AGTE    CHAR(4)      NOT NULL DEFAULT '7072',
   VAGENCIA     VARCHAR(50)  NOT NULL DEFAULT 'AGENCIA DE ADUANA S.A.C.',
   VDIR_AGTE    VARCHAR(40)  NOT NULL DEFAULT 'AV. PARQUE DE LAS LEYENDAS 210 OF: 701-A',
   vDPTO_AGTE   VARCHAR(15)  NOT NULL default "",
   vPROV_AGTE   VARCHAR(15)  NOT NULL default "", 
   vDIST_AGTE   VARCHAR(20)  NOT NULL default "",
   vURB_AGTE    VARCHAR(20)  NOT NULL default "",
   vCALLE_AGT   VARCHAR(40)  NOT NULL default "",
   vNUM_AGTE    VARCHAR(5)   NOT NULL default "",
   vINT_AGTE    VARCHAR(5)   NOT NULL default "",
   VLUG_AGTE    VARCHAR(12)  NOT NULL DEFAULT 'SAN MIGUEL',
   VTELEF1      CHAR(10)     DEFAULT '',
   VTELEF2      CHAR(10)     DEFAULT '',
   VFAX         CHAR(10)     DEFAULT '',
   VRUC_AGTE    CHAR(11)     DEFAULT '20500826526',
   VCLA_AGTE    CHAR(4)      NOT NULL DEFAULT '1150',
   VCASILLA     CHAR(13)     DEFAULT '',
   VOPERADOR    CHAR(1)      NOT NULL DEFAULT '1',
   VEMPRESA     VARCHAR(50)  DEFAULT '',
   VSUCURSAL    CHAR(2)      NOT NULL DEFAULT '01',
   VPROGRAMAD   VARCHAR(40)  DEFAULT '',
   VNEXTEL      CHAR(8)      DEFAULT '',
   VFORMORDEN   CHAR(9)      NOT NULL DEFAULT 'CONREGADU',
   VAPERTURA    CHAR(3)      NOT NULL DEFAULT 'N',
   VSAD13       CHAR(3)      NOT NULL DEFAULT 'DUA',
   VADUANA      CHAR(3)      NOT NULL DEFAULT '235',
   VCODREGI     CHAR(2)      NOT NULL DEFAULT '10',
   VANCHT1      INT          DEFAULT 0,
   VRADUANA     VARCHAR(35)  NOT NULL DEFAULT 'C:/ESTSQL/ADUANAS/',
   VCONTA       VARCHAR(40)  DEFAULT '',
   VRUTA_TXTS   VARCHAR(30)  DEFAULT '',
   VRUTA_OTRO   VARCHAR(40)  DEFAULT '',
   VRUTANORMA   VARCHAR(40)  DEFAULT '',
   VIMPRE1      CHAR(8)      NOT NULL DEFAULT 'FORMATO',
   VTASA_INTER  CHAR(2)      DEFAULT '',
   VFLAGACTA    CHAR(1)      DEFAULT '', /*Si este vale "A" quiere decir que se trabajara con aplicacion de anticipos, si vale "F" lo anticipos pasaran a la factura y si vale "C" pasaran a la Carta de Cobranza*/
   VFLAGDESB    CHAR(1)      DEFAULT '',
   VALOR_UIT    INT          DEFAULT 1350,
   PASORDBORR   CHAR(6)      DEFAULT 'INTOR',
   PASORDMODI   CHAR(6)      DEFAULT '707293',
   PASDOCBORR   CHAR(6)      DEFAULT 'INTOR',
   VTDOC_AGTE   CHAR(2)      DEFAULT "",  
   VOPER_AGTE   CHAR(2)      DEFAULT "",
   VUSU_SOL     VARCHAR(15)  DEFAULT "",
   VCLAVE_SOL   VARCHAR(15)  DEFAULT "", 
   VCOD_ENVIO   CHAR(15)     DEFAULT "",
   VCLAVEWEBS   VARCHAR(20)  DEFAULT "",
   VCLAVE_ELE   VARCHAR(16)  DEFAULT "",
   VFLAG_TCTA   VARCHAR(1)   DEFAULT "O", /* Determina si la cuenta corriente se llevara en Moneda original o Soles y dolares */
   VFCHCLAELE   DATE,
   VFECH_ACT    DATE);
INSERT INTO AGENCIAS(VCOD_AGTE,VSAD13,VOPERADOR,VCODREGI) VALUES ('7072',"SAD","1","10");

CREATE TABLE IF NOT EXISTS CORRELATIVOS(
   TIPO_CORREL CHAR(10) NOT NULL,
   NUME_CORREL CHAR(10) DEFAULT '',
   TAMA_CORREL NUMERIC(2,0) DEFAULT 10,
   DESCRIPCIO  VARCHAR(60) DEFAULT '',
   ORDEN       NUMERIC(2,0) DEFAULT 0,
   PRIMARY KEY(TIPO_CORREL));
INSERT INTO CORRELATIVOS(TIPO_CORREL,NUME_CORREL,TAMA_CORREL,DESCRIPCIO,ORDEN) VALUES('NO',concat(right(left(curdate(),4),2),'000000'),8,'ORDENES DE DESPACHOS',1);
INSERT INTO CORRELATIVOS(TIPO_CORREL,NUME_CORREL,TAMA_CORREL,DESCRIPCIO,ORDEN) VALUES('NOEXP',concat(right(left(curdate(),4),2),'000000'),8,'ORDENES DE EXPORTACION',2);
INSERT INTO CORRELATIVOS(TIPO_CORREL,NUME_CORREL,TAMA_CORREL,DESCRIPCIO,ORDEN) VALUES('NOOTR',concat(right(left(curdate(),4),2),'000000'),8,'ORDENES DE OTROS REGIMENES',3);
INSERT INTO CORRELATIVOS(TIPO_CORREL,NUME_CORREL,TAMA_CORREL,DESCRIPCIO,ORDEN) VALUES('NUMPROF',concat(right(left(curdate(),4),2),'000000'),8,'PROFORMAS DE DESPACHO',4);
INSERT INTO CORRELATIVOS(TIPO_CORREL,NUME_CORREL,TAMA_CORREL,DESCRIPCIO,ORDEN) VALUES('NUMGUIA','0010000000',10,'GUIA DE REMISION',5);
INSERT INTO CORRELATIVOS(TIPO_CORREL,NUME_CORREL,TAMA_CORREL,DESCRIPCIO,ORDEN) VALUES('NUMSOL',concat(right(left(curdate(),4),2),'000000'),8,'SOLICTUD DE CHEQUES',6);
INSERT INTO CORRELATIVOS(TIPO_CORREL,NUME_CORREL,TAMA_CORREL,DESCRIPCIO,ORDEN) VALUES('NUMFACT','0010000000',10,'FACTURAS',7);
INSERT INTO CORRELATIVOS(TIPO_CORREL,NUME_CORREL,TAMA_CORREL,DESCRIPCIO,ORDEN) VALUES('NUMBOL','0010000000',10,'BOLETA DE VENTA',8);
INSERT INTO CORRELATIVOS(TIPO_CORREL,NUME_CORREL,TAMA_CORREL,DESCRIPCIO,ORDEN) VALUES('NUMCOB','0010000000',10,'CARTA DE COBRANZA',9);
INSERT INTO CORRELATIVOS(TIPO_CORREL,NUME_CORREL,TAMA_CORREL,DESCRIPCIO,ORDEN) VALUES('NUMCARGO','0010000000',10,'NOTA DE DEBITO',10);
INSERT INTO CORRELATIVOS(TIPO_CORREL,NUME_CORREL,TAMA_CORREL,DESCRIPCIO,ORDEN) VALUES('NUMABONO','0010000000',10,'NOTA DE CREDITO',11);
INSERT INTO CORRELATIVOS(TIPO_CORREL,NUME_CORREL,TAMA_CORREL,DESCRIPCIO,ORDEN) VALUES('NUMVOU','0010000000',10,'VOUCHER DE INGRESO',12);
INSERT INTO CORRELATIVOS(TIPO_CORREL,NUME_CORREL,TAMA_CORREL,DESCRIPCIO,ORDEN) VALUES('NUMFINAN',concat(right(left(curdate(),4),2),'000000'),8,'FINANCIAMIENTO',13);
INSERT INTO CORRELATIVOS(TIPO_CORREL,NUME_CORREL,TAMA_CORREL,DESCRIPCIO,ORDEN) VALUES('NUMLETRA',concat(right(left(curdate(),4),2),'000000'),8,'LETRAS',14);
INSERT INTO CORRELATIVOS(TIPO_CORREL,NUME_CORREL,TAMA_CORREL,DESCRIPCIO,ORDEN) VALUES('NUMNCC','0010000000',10,'NOTA CONTABLE DE DEBITO',15);
INSERT INTO CORRELATIVOS(TIPO_CORREL,NUME_CORREL,TAMA_CORREL,DESCRIPCIO,ORDEN) VALUES('NUMNCD','0010000000',10,'NOTA CONTABLE DE CREDITO',16);
INSERT INTO CORRELATIVOS(TIPO_CORREL,NUME_CORREL,TAMA_CORREL,DESCRIPCIO,ORDEN) VALUES('NUMVOUE','0010000000',10,'VOUCHER DE EGRESOS',17);
INSERT INTO CORRELATIVOS(TIPO_CORREL,NUME_CORREL,TAMA_CORREL,DESCRIPCIO,ORDEN) VALUES('NUMFACTT','0010000000',10,'FACTURAS DE TRANSPORTE',18);
INSERT INTO CORRELATIVOS(TIPO_CORREL,NUME_CORREL,TAMA_CORREL,DESCRIPCIO,ORDEN) VALUES('NUMGUIAT','0010000000',10,'GUIA DEL TRANSPORTISTA',19);
INSERT INTO CORRELATIVOS(TIPO_CORREL,NUME_CORREL,TAMA_CORREL,DESCRIPCIO,ORDEN) VALUES('NUMCAJA',concat(right(left(curdate(),4),2),'0000'),6,'CAJA ARCHIVISTICA PARA DSI',20);

CREATE TABLE IF NOT EXISTS CLAVES(
   CORREL     CHAR(2) NOT NULL,           /* CORRELACION DE CLAVES */
   CLAVE      CHAR(6) NOT NULL,           /* CLAVE  */
   DESCRIPCIO VARCHAR(60)DEFAULT "",      /* DESCRIPCION DE LA CLAVE*/
   PRIMARY KEY(CORREL));
 INSERT INTO CLAVES VALUES("01","INTOR","CLAVE PARA BORRAR ORDENES");
 INSERT INTO CLAVES VALUES("02","707293","CLAVE PARA INGRESAR A UNA ORDEN NUMERADA");
 INSERT INTO CLAVES VALUES("03","INTOR","CLAVE PARA BORRAR DOCUMENTOS DE VENTA");
 INSERT INTO CLAVES VALUES("04","INTOR","CLAVE PARA ANULAR ORDENES");
 INSERT INTO CLAVES VALUES("06","INTOR","CLAVE PARA CAMBIO DE CORRELATIVO");
 INSERT INTO CLAVES VALUES("07","INTOR","CLAVE CREAR CLIENTES");

/*==================================================*/

/* DIARIOS(DIARIOS DE CONTABILIDAD QUE SE USAN PARA LOS ENLACES */
CREATE TABLE IF NOT EXISTS DIARIOS(
   A�O_DIARIO  CHAR(4) NOT NULL,      /* A�O DEL DIARIO DE CONTABILIDAD  */
   TIP_DIARIO  CHAR(1) NOT NULL,      /* TIPOS DE DIARIO */
   COD_DIARIO  CHAR(2) DEFAULT "",    /* CODIGO DEL DIARIO DE CONTABILIDAD*/
   PRIMARY KEY(A�O_DIARIO,TIP_DIARIO),
   CONSTRAINT FK_DIARIOS_TS12 FOREIGN KEY(TIP_DIARIO) REFERENCES softpad_sistema.ts12(CODIGO));
CREATE INDEX DIARIOS ON DIARIOS(A�O_DIARIO,TIP_DIARIO);
 INSERT INTO DIARIOS(A�O_DIARIO,TIP_DIARIO) VALUES(left(curdate(),4),"1");
 INSERT INTO DIARIOS(A�O_DIARIO,TIP_DIARIO) VALUES(left(curdate(),4),"2");
 INSERT INTO DIARIOS(A�O_DIARIO,TIP_DIARIO) VALUES(left(curdate(),4),"3");
 INSERT INTO DIARIOS(A�O_DIARIO,TIP_DIARIO) VALUES(left(curdate(),4),"4");
 INSERT INTO DIARIOS(A�O_DIARIO,TIP_DIARIO) VALUES(left(curdate(),4),"5");
 
/******************************************************************************************/
/* EST(ESTACIONES DE TRABAJO */

CREATE TABLE IF NOT EXISTS EST(
    VCOD_AGTE  CHAR(4) NOT NULL,
    VCOD_INTER CHAR(4) NOT NULL, 
    NOMBRE_EST VARCHAR(30) NOT NULL,
    SISTEMA    CHAR(3)  NOT NULL DEFAULT '',
    USUARIO    VARCHAR(50) NOT NULL DEFAULT '',
    TIPO       CHAR(1) NOT NULL DEFAULT '',
    EMPRESA    VARCHAR(50) DEFAULT '',
    FECHA      DATE,
    PRIMARY KEY(VCOD_INTER,VCOD_AGTE,SISTEMA,TIPO,USUARIO,NOMBRE_EST));
CREATE INDEX EST ON EST(VCOD_INTER,VCOD_AGTE,SISTEMA,TIPO,USUARIO,NOMBRE_EST);

/******************************************************************************************/
/* AGD(AGENDA DE LA AGENCIA  */

CREATE TABLE IF NOT EXISTS AGD(
   CODIGO    	CHAR(3) NOT NULL,	/*C  2  0*/
   EMPRESA   	VARCHAR(30) DEFAULT 'PONGA AQUI SU EMPRESA',	/*C 30  0*/
   ENCARGADO   	CHAR(40) DEFAULT '',     /*C  5  0*/
   TELEF1 	CHAR(7) DEFAULT '',     /*C  3  0*/
   TELEF2 	CHAR(7) DEFAULT 'S',    /*C  1  0*/
   ANEXO 	CHAR(4) DEFAULT 'S',    /*C  1  0*/
   NEXTEL 	CHAR(8) DEFAULT '',    /*C  50  0*/
   FAX          CHAR(7) DEFAULT "",
   CORREO       VARCHAR(40) DEFAULT "",
   CELULAR 	CHAR(8) DEFAULT '',    /*C  10  0*/
   PRIMARY KEY(CODIGO),	
   CONSTRAINT UQ_EMPRESA_1 UNIQUE(EMPRESA));
CREATE INDEX AGD ON AGD(CODIGO);


/******************************************************************************************/
/* USU(USUARIOS DEL SISTEMA */

CREATE TABLE IF NOT EXISTS USU(
   CODIGO    	CHAR(3) NOT NULL,	/*C  2  0*/
   USUARIO   	VARCHAR(30) DEFAULT 'PONGA AQUI SU NOMBRE',	/*C 30  0*/
   CLAVE     	CHAR(5) DEFAULT '',     /*C  5  0*/
   INICIALES 	CHAR(3) DEFAULT '',     /*C  3  0*/
   TIPO_USER 	CHAR(1) DEFAULT 'S',    /*C  1  0*/
   ESTADO 	CHAR(1) DEFAULT 'S',    /*C  1  0*/
   CORREO 	VARCHAR(50) DEFAULT '',    /*C  50  0*/
   NEXTEL 	VARCHAR(10) DEFAULT '',    /*C  10  0*/
   TIPO_MOVIL   CHAR(1) DEFAULT 'E',    /*C  1  0*/
   CLAVE2       VARCHAR(5) DEFAULT '',    /*CAMPOS SOLO PARA HANSA ADUANAS*/
   ACCESO       VARCHAR(10) DEFAULT '',   /*CAMPOS SOLO PARA HANASA ADUANAS*/
   PRIMARY KEY(CODIGO),	
   CONSTRAINT UQ_USU_1 UNIQUE(USUARIO),
   CONSTRAINT UQ_USU_2 UNIQUE(CLAVE));
CREATE INDEX USU ON USU(CODIGO);
INSERT INTO USU(CODIGO,USUARIO,INICIALES) VALUES('001','SUPERVISOR','SUP');

/******************************************************************************************/
/* ITR(TABLA DE INTERMEDIARIOS)*/
CREATE TABLE IF NOT EXISTS ITR(
   CODIGO       CHAR(4) NOT NULL,
   NOM_INTER    VARCHAR(30) DEFAULT '',
   DIR_INTER    VARCHAR(60) DEFAULT '',
   CIU_INTER    VARCHAR(40) DEFAULT '',
   PAIS_INTER   CHAR(3) DEFAULT '',
   TIPO_INTER   CHAR(1) DEFAULT '',
   PAG_INTER    VARCHAR(60) DEFAULT '',
   EMAIL_INT    VARCHAR(40) DEFAULT '',
   OTROCODINT   VARCHAR(20) DEFAULT '',
   TLF_INTER    VARCHAR(12) DEFAULT '',
   FAX_INTER    VARCHAR(12) DEFAULT '',
   TDOC_INTER   CHAR(2) DEFAULT '',
   NDOC_INTER   CHAR(11) DEFAULT '',
   PRIMARY KEY(CODIGO),
   CONSTRAINT UQ_ITR_1 UNIQUE(NOM_INTER,CIU_INTER,PAIS_INTER));
CREATE INDEX ITR ON ITR(CODIGO);
INSERT INTO ITR(CODIGO,NOM_INTER) values("    ","Z");

/******************************************************************************************/
/* TA57(TABLA DE PROVEEDORES EXTRANJEROS)*/
CREATE TABLE IF NOT EXISTS PRA(
   CODIGO       CHAR(10) NOT NULL,
   NOM_FABR     VARCHAR(60) DEFAULT '',
   PAIS_PROV    CHAR(2) DEFAULT '',
   DIR1         VARCHAR(55) DEFAULT '',
   CIUDAD       VARCHAR(50) DEFAULT '',
   TLF_PROV     CHAR(15) DEFAULT '',
   FAX_PROV     CHAR(15) DEFAULT '',
   CONDI_PRO    CHAR(1) DEFAULT '',
   VINCULAC     CHAR(1) DEFAULT '',
   PAG_WEB      VARCHAR(60) DEFAULT '',
   EMAIL        VARCHAR(50) DEFAULT '',
   PAIS         CHAR(3) DEFAULT '',
   FLAG_A       CHAR(1) DEFAULT '',
   MESANO       CHAR(4) DEFAULT '',
   FECH_DESPA   DATETIME, 
   OTR_NIVC     VARCHAR(20) DEFAULT '',
   PRIMARY KEY(CODIGO),
   CONSTRAINT UQ_PRA_1 UNIQUE(PAIS_PROV,NOM_FABR,CIUDAD));
CREATE INDEX PRA ON PRA(CODIGO);

/* CEX (TABLA DE CONSIGNATARIOS EXTRANJEROS PARA EXPORTACION 40/41)*/
CREATE TABLE IF NOT EXISTS CEX(
   CODIGO     CHAR(4) not null,
   NOMBRE     VARCHAR(40) default '',
   DIRECCION  VARCHAR(60) default '',
   PRIMARY KEY(CODIGO));
CREATE INDEX CEX ON CEX(CODIGO);

/* TRS (TABLA DE TRANSPORTISTAS PARA LA GUIA DE REMISION)*/
CREATE TABLE IF NOT EXISTS TRS(
   CODIGO     CHAR(3) NOT NULL,
   NOMBRE     VARCHAR(80) DEFAULT "",
   DIRECCION  VARCHAR(60) default "",
   RUC        CHAR(11) DEFAULT "",
   TPA        VARCHAR(15) DEFAULT "",  /* No se para que sirve ni idea */
   NUMECERINS VARCHAR(15) DEFAULT "",
   PRIMARY KEY(CODIGO),
   CONSTRAINT UQ_TRS_1 UNIQUE(NOMBRE));
CREATE INDEX TRS ON TRS(CODIGO);

/* CDT (CONDUCTOR DEL VEHICULO DE TRANSPORTE PARA LA GUIA DE REMINSION*/
CREATE TABLE IF NOT EXISTS CDT(
   CODIGO     CHAR(3) NOT NULL,
   CONDUCTOR  VARCHAR(80) DEFAULT "",
   MATR_VEHIC VARCHAR(50) default "",
   NUM_LICENC CHAR(15) DEFAULT "",
   COD_TRANSP CHAR(3) DEFAULT "",
   PRIMARY KEY(COD_TRANSP,CODIGO),
   CONSTRAINT UQ_CDT_1 UNIQUE(COD_TRANSP,CONDUCTOR),
   CONSTRAINT FK_CDT_TRS FOREIGN KEY(COD_TRANSP) REFERENCES TRS(CODIGO));
CREATE INDEX CDT ON CDT(CODIGO);


/*=========================================*/

/* DSP (TABLA DE DESPACHADORES)*/
CREATE TABLE IF NOT EXISTS DSP(
   CODIGO  CHAR(2) not null,
   NOMBRE  VARCHAR(20) default '',
   INIC    VARCHAR(2) default '',
   PRIMARY KEY(CODIGO),
   CONSTRAINT UQ_DSP UNIQUE(NOMBRE));
CREATE INDEX DSP ON DSP(CODIGO);
INSERT INTO DSP values("  ","�","Z");

/*=========================================*/

/* TEC (TABLA DE TECNICOS ADUANEROS PARA UPS)*/
CREATE TABLE IF NOT EXISTS TEC(
   CODIGO  CHAR(2) not null,
   NOMBRE  VARCHAR(20) default '',
   INIC    VARCHAR(2) default '',
   PRIMARY KEY(CODIGO),
   CONSTRAINT UQ_TEC UNIQUE(NOMBRE));
CREATE INDEX TEC ON TEC(CODIGO);
INSERT INTO TEC values("  ","�","Z");

/*=========================================*/

/* EVS (EMPRESAS VINCULANTES PARA SIMPLIFICADA)*/
CREATE TABLE IF NOT EXISTS EVS(
   CODIGO      CHAR(4) not null,
   NOMBRE      VARCHAR(60) default '',
   PRIMARY KEY(CODIGO),
   CONSTRAINT UQ_EVS UNIQUE(NOMBRE));
CREATE INDEX EVS ON EVS(CODIGO);
INSERT INTO EVS values("    ","Z");

/*=========================================*/

/* TGF (TABLA DE GASTOS TIPO DE GASTOS DE LA PROFORMA Y LA FACTURA)*/
CREATE TABLE IF NOT EXISTS TGF(
   CODIGO      CHAR(3) not null,         /*codigo de Gasto */   
   GASTOS      VARCHAR(40) DEFAULT "",   /*Detalle del Gasto */
   RUBRO_N     CHAR(2) DEFAULT "",       /*Rubro en el que se va agrupar en el Registro de Ventas */
   FLAG_PRO    CHAR(1) DEFAULT "",       /*Flag que indica que dicho gasto sera para la Proforma */
   FLAG_FAC    CHAR(1) DEFAULT "",       /*Flag que indica que dicho gasto sera para la Factura */	
   FLAG_COB    CHAR(1) DEFAULT "",       /*Flag que indica que dicho gasto sera para la Carta de Cobranza */
   FLAG_NOT    CHAR(1) DEFAULT "",       /*Flag que indica que dicho gasto sera para la Nota de Debito y Credito */
   FLAG_PLA    CHAR(1) DEFAULT "",       /*Flag que indica que dicho gasto sera para la PLanilla de gastos */	
   FLAG_FAT    CHAR(1) DEFAULT "",       /*Flag que indica que dicho gasto sera para la Factura de Transporte */
   CTASDOC     CHAR(8) DEFAULT "",       /*Cuenta Contable en Soles para los Documentos de Venta pasen a contabilidad */
   CTADDOC     CHAR(8) DEFAULT "",       /*Cuenta Contable en Dolares para los Documentos de Venta pasen a contabilidad */
   CTASCOB     CHAR(8) DEFAULT "",       /*Cuenta Contable en Soles para La Carta de Cobranza pasen a contabilidad */	
   CTADCOB     CHAR(8) DEFAULT "",       /*Cuenta Contable en Dolares para la Carta de Cobranza pasen a contabilidad */
   FLAG_REPO   CHAR(1) DEFAULT "",       /*Flag que indica que gastos van a pasar el reporte de gastos */
   DESC_REPO   VARCHAR(10) DEFAULT "",   /*Descripcion resumida del Gasto que pasara el Reporte */
   FLAG_TRANS  CHAR(2) DEFAULT "",       /*Idinca el codigo del gasto que sera de transporte */
   PAGA_ITF    CHAR(1) DEFAULT "",       /*Indica si ese gasto paga ITF (Solo contabilidad) E-ADUANAS */
   REGIMEN     CHAR(1) DEFAULT "",  	 /*Flag que indica que gastos son para Importacion y cuales para exportacion (Solo DHL)*/
   COD_OTRO    CHAR(6) DEFAULT "",       /*codigo de JBA para DHL */
   PRIMARY KEY(CODIGO),
   CONSTRAINT UQ_TGF UNIQUE(GASTOS));
CREATE INDEX TGF ON TGF(CODIGO);
INSERT INTO `tgf` (`CODIGO`,`GASTOS`,`RUBRO_N`,`FLAG_PRO`,`FLAG_FAC`,`FLAG_COB`,`FLAG_NOT`,`FLAG_PLA`,`FLAG_FAT`,`CTASDOC`,`CTADDOC`,`CTASCOB`,`CTADCOB`,`FLAG_REPO`,`DESC_REPO`,`FLAG_TRANS`,`PAGA_ITF`,`REGIMEN`) VALUES 
 ('','Z','','','','','','','','','','','','','','','',''),
 ('001','DESCARGA                                ','02','X','X','X','X','X','','','','','','X','DESC.     ','','',''),
 ('002','ALMACENAJE                              ','02','X','X','X','X','X','','','','','','X','ALMAC.    ','','',''),
 ('003','TRANSPORTE                              ','02','X','X','X','X','X','','','','','','','          ','','',''),
 ('004','GASTOS OPERATIVOS                       ','02','X','X','X','X','X','','','','','','','          ','','',''),
 ('005','MANIPULEO DE CARGA                      ','02','X','X','X','X','X','','','','','','','          ','','',''),
 ('006','HANDLING                                ','02','X','','X','X','X','','','','','','','          ','','',''),
 ('007','FLETE                                   ','02','X','','X','X','X','','','','','','','          ','','',''),
 ('008','MANIPULEO DE CONTENEDOR                 ','02','X','X','X','X','X','','','','','','','          ','','',''),
 ('009','SOBRESTADIA DE CONTENEDOR               ','02','X','X','X','X','X','','','','','','','          ','','',''),
 ('010','EMBALAJE                                ','02','X','X','X','X','X','','','','','','','          ','','',''),
 ('011','GREMIOS MARITIMOS                       ','02','X','X','X','X','X','','','','','','','          ','','',''),
 ('012','LAVADO DE CONTENEDOR                    ','02','X','X','X','X','X','','','','','','','          ','','',''),
 ('013','DOCUMENTOS                              ','02','X','X','X','X','X','','','','','','','          ','','',''),
 ('014','SERV. EXTRAORDINARIO                    ','02','X','X','X','X','X','','','','','','','          ','','',''),
 ('015','DERECHO DE EMBARQUE                     ','02','X','X','X','X','X','','','','','','','          ','','',''),
 ('016','GASTOS DE MOVILIDAD                     ','02','X','X','','X','X','','','','','','','          ','','',''),
 ('017','TRANSMISION ELECTRONICA                 ','02','X','X','','X','X','','','','','','','          ','','',''),
 ('018','SERVICIO DE PORTEO                      ','02','X','X','X','X','X','','','','','','','          ','','',''),
 ('019','SERVICIO DE PRECINTADO                  ','02','X','X','X','X','X','','','','','','','          ','','',''),
 ('020','CONTROL DE PRECINTOS                    ','02','X','X','X','X','X','','','','','','','          ','','',''),
 ('021','B/L                                     ','02','X','','X','X','X','','','','','','','          ','','',''),
 ('022','FOTOCOPIAS                              ','02','X','X','','X','X','','','','','','','          ','','',''),
 ('023','POLIZA DE SEGURO COBERCONT              ','02','X','X','','X','X','','','','','','','          ','','',''),
 ('024','VISTO BUENO                             ','02','X','X','X','X','X','','','','','','','          ','','',''),
 ('025','CONSOLIDACION/ DESCONS. CARGA           ','02','X','','X','X','X','','','','','','','          ','','',''),
 ('026','TELEDESPACHO                            ','02','X','X','X','X','X','','','','','','','          ','','',''),
 ('027','DIFERENCIA DE CAMBIO                    ','02','X','X','','X','X','','','','','','','          ','','',''),
 ('028','CUADRILLA DE DESCARGA                   ','02','X','X','X','X','X','','','','','','','          ','','',''),
 ('029','GASTOS ADMINISTRATIVOS                  ','02','X','X','X','X','X','','','','','','','          ','','',''),
 ('030','CUADRILLA DE CARGA                      ','02','X','X','X','X','X','','','','','','','          ','','',''),
 ('031','AFORO FISICO                            ','02','X','X','X','X','X','','','','','','','          ','','',''),
 ('032','AFORO PREVIO                            ','02','X','X','X','X','X','','','','','','','          ','','',''),
 ('033','TRAMITE  DOCUMENTARIO                   ','02','X','','X','X','X','','','','','','','          ','','',''),
 ('034','GASTOS FINANCIEROS                      ','02','X','X','X','X','X','','','','','','','          ','','',''),
 ('035','MULTAS                                  ','02','X','','X','X','X','','','','','','','          ','','',''),
 ('036','MOVILIZACION DE CARGA                   ','02','X','','X','X','X','','','','','','','          ','','',''),
 ('037','GASTOS DE DESPACHO                      ','02','X','X','X','X','X','','','','','','','          ','','',''),
 ('038','T.H.C                                   ','02','X','','X','','X','','','','','','','          ','','',''),
 ('039','SENASA                                  ','02','X','','X','','X','','','','','','','          ','','',''),
 ('040','BL TRANSMISION FEE                      ','02','X','','X','','X','','','','','','','          ','','',''),
 ('041','PERMISO DEL MTC                         ','02','X','','X','','X','','','','','','','          ','','',''),
 ('042','TASA DE DESPACHO                        ','02','X','','X','X','X','','','','','','','          ','','',''),
 ('043','GARANTIA DE CONTENEDOR                  ','02','X','','X','X','X','','','','','','','          ','','',''),
 ('044','RECTIFICACION DE MANIFIESTO             ','02','X','','X','','X','','','','','','','          ','','',''),
 ('045','VISACIONES                              ','02','X','','X','','X','','','','','','','          ','','',''),
 ('046','SERVICIO DE LABORATORIO                 ','02','X','X','X','X','X','','','','','','','          ','','',''),
 ('048','GASTOS ADM. POR DERRUMAGE               ','02','X','','X','X','X','','','','','','','          ','','',''),
 ('049','DELIVERY ORDER                          ','02','X','','X','X','X','','','','','','','          ','','',''),
 ('050','INSPECCION FITOSANITARIA                ','02','X','','X','X','X','','','','','','','          ','','',''),
 ('051','GATE IN (20\' 40\')                       ','02','X','X','X','X','X','','','','','','','          ','','',''),
 ('052','SERV. DE ADM. CONTENEDOR                ','02','X','X','X','X','X','','','','','','','          ','','',''),
 ('053','SEGURO DE CONTENEDOR                    ','02','X','X','X','X','X','','','','','','','          ','','',''),
 ('054','TRACCION                                ','02','X','X','X','X','X','','','','','','','          ','','',''),
 ('055','IMPUGNACION                             ','02','X','X','X','X','X','','','','','','','          ','','',''),
 ('056','SOBRETASAS                              ','02','X','X','X','X','X','','','','','','','          ','','',''),
 ('057','AGENCIAMIENTO / SERV AL CLIENTE         ','02','X','','X','','X','','','','','','','          ','','',''),
 ('058','ESTIBA                                  ','02','','','X','','','','','','','','','          ','','',''),
 ('059','SERVICIO DE TERMINAL                    ','02','X','','X','','','','','','','','','          ','','',''),
 ('061','SERVICIO DESPACHO ADUANERO              ','02','','','X','','','','','','','','','          ','','',''),
 ('062','RESGUARDO                               ','02','','X','','','','','','','','','','          ','','',''),
 ('063','ENAJENACION DE ACTIVOS FIJOS            ','02','','X','','','','','','','','','','          ','','',''),
 ('Z01','DERECHOS                                ','Z1','','','X','X','X','','','','','','','          ','','',''),
 ('Z02','COMISION                                ','Z2','','','','X','','','','','','','','          ','','',''),
 ('Z03','I.G.V.                                  ','Z3','','','','X','','','','','','','','          ','','',''),
 ('Z04','INTERESES                               ','Z4','X','X','X','X','','','','','','','','          ','','',''),
 ('Z05','TOTAL DOCUMENTO                         ','Z5','','','X','','','','','','','','','          ','','',''),
 ('Z06','A CUENTA ( SOLO PARA C/C)               ','Z6','','','','','','','','','','','','          ','','',''),
 ('Z07','NOTA DE DEBITO ( SOLO PARA C/C)         ','Z7','','','','','','','','','','','','          ','','',''),
 ('Z08','A CUENTA CTA.COBRANZA ( SOLO PARA C/C)  ','Z8','','','','','','','','','','','','          ','','',''),
 ('Z09','ANTICIPO A DEVOLVER ( SOLO PARA C/C)    ','Z9','','','','','','','','','','','','          ','','',''),
 ('ZPA','PERCEPCION DE IGV                       ','ZA','','X','X','','','','','','','','','          ','','',''),
 ('ZAD','AUTOLIQUIDACION DOLARES                 ','ZD','','','X','','','','','','','','','AUT. DOLAR','','',''),
 ('ZAS','AUTOLIQUIDACION SOLES                   ','ZS','','','X','','','','','','','','','AUT. SOLES','','','');


/*=========================================*/

/* VEN (VENDEDORES O COMISIONISTAS DE LA AGENCIA)*/
CREATE TABLE IF NOT EXISTS VEN(
   CODIGO      CHAR(4) not null,
   VENDEDOR    VARCHAR(25) default '',
   PORCENTAJE  DECIMAL(6,2) default 0.00,
   PORC_CONTE  NUMERIC(9,0) DEFAULT 0, 
   VIGENTE     CHAR(1) DEFAULT "S", 
   FECH_INGRE  DATETIME,
   PRIMARY KEY(CODIGO),
   CONSTRAINT UQ_VEN UNIQUE(VENDEDOR));
CREATE INDEX VEN ON VEN(CODIGO);
INSERT INTO VEN(CODIGO,VENDEDOR) values("    ","Z");

/*=========================================*/

/*GPO (GRUPO EMPRESARIAL)*/
CREATE TABLE IF NOT EXISTS GPO(
   COD_GPO     CHAR(2) not null,
   RAZ_SOC_GPO VARCHAR(25) default '',
   FECH_INGRE  DATETIME,
   PRIMARY KEY(COD_GPO),
   CONSTRAINT UQ_GPO UNIQUE(RAZ_SOC_GPO));
CREATE INDEX GPO ON GPO(COD_GPO);
INSERT INTO GPO(COD_GPO,RAZ_SOC_GPO) values("  ","Z");

/*=========================================*/

CREATE TABLE IF NOT EXISTS CLI(
   CODIGO    	CHAR(5) NOT NULL,               /*C  5  0 CODIGO CORRELATIVO DEL CLIENTE*/
   NOMBRE    	VARCHAR(100) DEFAULT '',	        /*C 80  0 NOMBRE DEL CLIENTE SEGUN SUNAT*/
   DIRECC    	VARCHAR(60) DEFAULT '',	        /*C 60  0 DIRECCION COMERCIAL DEL CLIENTE*/
   DISTRITO  	CHAR(6) DEFAULT '',             /*C  6  0 DISTRITO*/
   NOMBRES   	VARCHAR(70) DEFAULT '',	        /*C 70  0 NOMBRE DE LA PERSONA NATURAL (COURIERS)*/
   APELLIDOS 	VARCHAR(70) DEFAULT '',	        /*C 70  0 APELLIDOS DE LA PERSONA NATURAL  (COURIERS)*/
   TELEF1    	CHAR(10) DEFAULT '',	        /*C 10  0 TELEFONO*/
   TIPO_DOCUM	CHAR(1) NOT NULL,               /*C  1  0 TIPO DE DOCUMENTO DEL CLIENTE*/
   COD_LINEA 	CHAR(4) DEFAULT '',             /*C  4  0 CODIGO DE LINEA AEREA PARA EL DMA*/
   DOCUMENTO 	CHAR(11) NOT NULL,              /*C 11  0 RUC/DOCUMENTO DEL CLIENTE*/
   FAX       	CHAR(10) DEFAULT '',	        /*C 10  0 FAX DEL CLIENTE*/
   CODVEND1  	CHAR(4) DEFAULT '',             /*C  4  0 CODIGO DEL VENDEDOR O COMISIONISTA RELACIONADO AL CLIENTE*/
   TELEF2    	CHAR(10) DEFAULT '',            /*C 10  0 TELEFONO 2 DEL CLIENTE*/
   COD_GRUP  	CHAR(2) DEFAULT '',             /*C  2  0 CODIGO DE GRUPO EMPRESARIAL*/
   NIVEL_COM 	CHAR(1) DEFAULT '',	        /*C  1  0 NIVEL COMERCIAL PARA LA DECLARACION DE VALOR*/
   NOMBRE_BCO	VARCHAR(40) DEFAULT '',	        /*C 40  0 NOMBRE COMERCIAL DE CLIENTE PARA LA EMISION DE LETRAS*/
   UBIGEO    	CHAR(6) DEFAULT '',	        /*C  6  0*/
   DIASVENDOC   NUMERIC(3,0) DEFAULT 0,             /*       */
   TIPODOCDCL	CHAR(1) DEFAULT '',             /*C  1  0 TIPO DE DOCUMENTO DEL REPRESENTANTE LEGAL*/
   VIGENTE   	CHAR(1) DEFAULT 'S',            /*C  1  0 FLAG QUE DETERMINA SI EL CLIENTE ESTA VIGENTE O NO*/
   EMAIL_CLI 	VARCHAR(90) DEFAULT '',	        /*C 30  0 CORREO ELECTRONICO DEL CLIENTE*/
   EMAIL_CLI1	VARCHAR(90) DEFAULT '',	        /*C 30  0 OTROS CORREOS ELECTRONICOS DEL CLIENTE*/
   EMAIL_CLI2	VARCHAR(90) DEFAULT '',	        /*C 30  0 OTROS CORREOS ELECTRONICOS DEL CLIENTE*/
   COD_ENTREG	CHAR(4) DEFAULT '',             /*C  4  0 CODIGO DE LUGAR DE ENTREGA AL CLIENTE*/
   DES_ENTREG	VARCHAR(50) DEFAULT '',	        /*C 50  0 DESCRIPCION DEL LUGAR DE ENTREGA AL CLIENTE*/
   TIPO_COMIS	NUMERIC(1,0) DEFAULT 0,	        /*N  1  0 TIPO DE COMISION PARA CLIENTES POR INTERVALOS  O FIJO*/
   DIREC_FACT	VARCHAR(150) DEFAULT '',	/*C 60  0 DIRECCION DE FACTURACION*/
   PAIS_IMPOR	CHAR(2) DEFAULT '',             /*C  2  0 NACIONALIDAD DEL IMPORTADOR*/
   TASA_INTER	DECIMAL(7,3) DEFAULT 0.000,     /*N  7  3 TASA DE INTERES A COBRAR CUANDO SE HAGA UN FINANCIAMIENTO AL CLIENTE*/
   COMISINIGV	CHAR(1) DEFAULT 'N',	        /*C  1  0 FLAG QUE DETERMINA SI LA COMISION COBRADA AL CLIENTE INCLUIRA EL IGV*/
   CANC_DERE 	CHAR(1) DEFAULT '',	        /*C  1  0 FLAG QUE INIDICA LOS LOS DERECHOS LOS CANCELA EL CLIENTE O LA AGENCIA (DANZAS AEI)*/
   TIPO_TASA 	CHAR(2) DEFAULT '',             /*C  2  0 TIPO DE TASA FIJA A APLICAR A LOS FINANCIAMIENTOS DEL CLIENTE*/
   CCTA_PAEL 	VARCHAR(20) DEFAULT '',	        /*C 20  0 CTA. CTE. DEL PAGO ELECTRONICO*/
   CBCO_PAEL 	CHAR(3) DEFAULT '',	        /*C  3  0 CODIGO DE BANCO DEL PAGO ELECTRONICO*/
   EXCLU_UIF 	CHAR(1) DEFAULT '',	        /*C  1  0 FLAG QUE DETERMINA SI EL CLIENTE VA A SER EXCLUIDO DE LA UIF*/
   MOTEXCLUIF	VARCHAR(90) DEFAULT '',	        /*C 90  0 Motivo de Exclusion de la UIF*/
   ENVIAR_C  	CHAR(1) DEFAULT 'N',            /*C  1  0 Flag que determina si al cliente se le va enviar la C por correo al momento que se numere su despacho*/
   PIGV      	CHAR(1) DEFAULT '',             /*C  1  0 Campo de percepcion de IGV*/
   ESTATUTO  	CHAR(8) DEFAULT '',	        /*C  8  0 Estatuto o copia literal de la persona Juridica del Cliente*/
   VENC_ESTA 	DATE,                           /*D  8  0 Fecha de vencimiento del Estatuto*/
   NOMBRE_CAR	VARCHAR(30) DEFAULT '',	        /*C 30  0 NOMBRE DE LA PERSONA QUE VA DIRIGIDO LA CARTA*/
   LLEVACARTA	CHAR(1) DEFAULT 'S',            /*C  1  0 INDICADOR SI EL CLIENTE DEBE LLEVAR CARTA CARGO*/
   PESOADICTR	DECIMAL(12,2) DEFAULT 0.00,     /*N 12  2 PESO ADICIONAL AL TOPE MAXIMO DE LAS TARIFAS DE TRANSPORTE*/
   IMPOADICTR	DECIMAL(12,2) DEFAULT 0.00,     /*N 12  2 IMPORTE ADICIONAL A COBRAR POR PESO ADICIONAL A TRANSPORTAR*/
   MONEDA_TRA	CHAR(1) DEFAULT '',	        /*C  1  0 MONEDA DE LAS TARIFAS DE TRANSPORTE*/
   PORCEN_TRA	DECIMAL(7,3) DEFAULT 0.000,     /*N  7  3 PORCENTAJE A COBRAR POR TARIFA DE TRANSPORTE*/
   SECTORISTA	CHAR(3) DEFAULT '',	        /*C  2  0 SECTORISTA DEL CLIENTE*/
   DIFTCAMBIO	DECIMAL(5,3) DEFAULT 0.000,	/*N  5  3 DIFERENCIA DE CAMBIO PARA J&N*/
   TIPOMONEDA	CHAR(1) DEFAULT '',	        /*C  1  0 TIPO DE MONEDA PARA LA CTA.CTE. DE JN*/
   FCH_INGRE 	DATETIME NOT NULL,              /*D  8  0 FECHA DE CREACION DEL CLIENTE*/
   COD_USER  	CHAR(3) DEFAULT '',	        /*C  2  0 CODIGO DEL USUARIO QUE CREO EL CLIENTE*/
   FRECUENTE    CHAR(1) DEFAULT '',             /*C  1  0 FLAG QUE INDICA QUE EL IMPORTADOR ES FRECUENTE  */
   URB_CLI      VARCHAR(20)DEFAULT '',          /*C 20 0 URBANIZACION DEL CLIENTE */
   CALLE_CLI    VARCHAR(40)DEFAULT '',          /*C 40  0 NOMBRE DE LA CALLE DEL CLIENTE*/
   NUMER_CLI    VARCHAR(5) DEFAULT '',          /*C  5  0 NUMERO DE LA CALLE DEL CLIENTE*/
   INTER_CLI    VARCHAR(5) DEFAULT '',          /*C  5  0 INTERIOR DE LA CALLE DEL CLIENTE.*/
   CONS_CLI     CHAR(1) DEFAULT '',             /*  0 INDICADOR PARA SABER SI EL CLIENTE A SIDO PROCESADO PARA EL TA427*/
   CIUDAD       VARCHAR(20) DEFAULT '',         /*  0 CIUDAD DEL IMPORTADOR*/
   OTR_NIVC     VARCHAR(20) DEFAULT '',         /*  0 OTROS EN NIVEL COMERCIALA*/
   NIV_CALIF    CHAR(1) DEFAULT '',             /*  C  1  0 NIVEL DE CALIFICACION*/
   FINI_CALI    DATE,                           /*   8  0 FECHA DE INICIO DE NIVEL DE CALIFICACION*/
   FVEN_CALI    DATE,                           /*D  8  0 FECHA DE VENCIMIENTO DE NIVEL DE CALIFICACION*/
   FECH_DESPA   DATETIME,                       /*D  8  0 FECHA DE USO DEL CLIENTE EN UN ULTIMO DESPACHO*/
   TIPO_DECLA   CHAR(2) DEFAULT "",             /*2  0 TIPO DE DECLARANTE */
   COD_GPO      CHAR(2) DEFAULT "",
   DRAWBACK     CHAR(1) DEFAULT "",             /*1    INDENTIFICADOR DE DRAWBACK PARA LAS EXPORTACIONES DE DHL */
   DIASVENCOB   NUMERIC(3,0) DEFAULT 0,         /*    */ 
   PRIMARY KEY(CODIGO),
   CONSTRAINT FK_CLI_USU FOREIGN KEY(COD_USER) REFERENCES USU(CODIGO),
   CONSTRAINT FK_CLI_VEN FOREIGN KEY(CODVEND1) REFERENCES VEN(CODIGO),
   CONSTRAINT FK_CLI_GPO FOREIGN KEY(COD_GPO) REFERENCES GPO(COD_GPO),
   CONSTRAINT UQ_CLI_1 UNIQUE(NOMBRE),
   CONSTRAINT UQ_CLI_2 UNIQUE(TIPO_DOCUM,DOCUMENTO));
CREATE INDEX CLI            ON CLI(CODIGO);
CREATE INDEX CLI_NOMBRE     ON CLI(NOMBRE);
CREATE INDEX CLI_FECH_DESPA ON CLI(FECH_DESPA);
insert into cli(codigo,nombre,tipo_docum,documento,cod_user,fch_ingre)
values('','Z','','','001',concat(curdate(),' ',curtime()));
insert into cli(codigo,nombre,nombre_bco,direcc,distrito,ubigeo,NIVEL_COM,EMAIL_CLI,telef1,telef2,tipo_docum,documento,cod_user,fch_ingre)
values('00000','SOFTWARE PARA ADUANAS S.A.C.','SOFTPAD S.A.C.','AV. COLONIAL 4525 OF: 505 ',
'070101','070101','1','jczll@softpad.com.pe','4511420','5622803','4','20500826526','001',concat(curdate(),' ',curtime()));

/* CLG(GASTOS FIJOS POR CLIENTE)*/
CREATE TABLE IF NOT EXISTS CLG(
   COD_CLIEN 	CHAR(5) NOT NULL,        	/*C  5  0 CODIGO CORRELATIVO DEL CLIENTEa*/
   CORREL       CHAR(2) NOT NULL,               /*C  2  0 CORRELACION DEL REGISTROS */
   TIPO_ADUAN	CHAR(1) DEFAULT '',     	/*C  1  0 TIPO DE ADUANA AEREA,MARITIMA,POSTAL,TERRESTRE*/
   TIPO_REGIM	CHAR(3) DEFAULT '',     	/*C  3  0 TIPO DE REGIMEN A COBRAR COMISION "IMP,EXP,DEP,TMP"*/
   COD_GASTO 	CHAR(3) DEFAULT '',     	/*C  2  0 CODIGO DEL GASTO*/
   DGASTO    	DECIMAL(12,2) DEFAULT 0.00,	/*N 12  2 IMPORTE EN DOLARES DEL GASTO FIJO*/
   SGASTO    	DECIMAL(12,2) DEFAULT 0.00,	/*N 12  2 IMPORTE EN SOLES DEL GASTO FIJO*/
   TIPO_OPER 	CHAR(3) DEFAULT '',	        /*C  3  0 TIPO DE OPERACION (IMP,EXP,TMP)*/
   PRIMARY KEY(COD_CLIEN,CORREL),
   CONSTRAINT UQ_CLG_1     UNIQUE(COD_CLIEN,TIPO_ADUAN,TIPO_REGIM,COD_GASTO),
   CONSTRAINT FK_CLG_CLI   FOREIGN KEY(COD_CLIEN) REFERENCES CLI(CODIGO),
   CONSTRAINT FK_CLG_TGF   FOREIGN KEY(COD_GASTO) REFERENCES TGF(CODIGO),
   CONSTRAINT FK_CLG_TS371 FOREIGN KEY(TIPO_ADUAN) REFERENCES softpad_sistema.Ts371(CODIGO),
   CONSTRAINT FK_CLG_TS372 FOREIGN KEY(TIPO_REGIM) REFERENCES softpad_sistema.Ts372(CODIGO));
   CREATE INDEX CLG ON CLG(COD_CLIEN);

/*CLM(COMISIONES POR CLIENTE)*/
CREATE TABLE IF NOT EXISTS CLM(
   COD_CLIEN 	CHAR(5) NOT NULL,	        /*C  5  0 CODIGO DEL CLIENTE*/
   CORREL       CHAR(2) NOT NULL,               /*C  2  0 CORRELACION DEL REGISTROS */
   TIPO_ADUAN	CHAR(1) DEFAULT '',	        /*C  1  0 TIPO DE ADUANA AEREA,MARITIMA,POSTAL,TERRESTRE*/
   TIPO_REGIM	CHAR(3) DEFAULT '',	        /*C  3  0 TIPO DE REGIMEN A COBRAR COMISION "IMP,EXP,DEP,TMP"*/
   PORC_COMIS	DECIMAL(12,2) DEFAULT 0.00,	/*N 12  2 PORCENTAJE DE COMSION A COBRAR*/
   TIPO_FINAN   CHAR(2) DEFAULT "",             /*Tipo de pago (FINANCIADO O CONTADO)*/
   TIPO_BASE 	CHAR(1) DEFAULT '',      	/*C  1  2 TIPO DE BASE DE CALCULO*/
   COMIS_MIN 	DECIMAL(12,2) DEFAULT 0.00,	/*N 12  2 COMISION MINIMA*/
   COMIS_MAX 	DECIMAL(12,2) DEFAULT 0.00,	/*N 12  2 COMISION MAXIMA*/
   TIPO_COMIS	CHAR(1) DEFAULT '',	        /*C  1  0 TIPO DE COMISION (FIJA O CON INTERVALOS)*/
   MONEDA       CHAR(1) DEFAULT "",             /*Tipo de moneda de la comision */  
   PRIMARY KEY(COD_CLIEN,CORREL),
   CONSTRAINT UQ_CLM_1     UNIQUE(COD_CLIEN,TIPO_ADUAN,TIPO_REGIM,TIPO_FINAN),
   CONSTRAINT FK_CLM_CLI   FOREIGN KEY(COD_CLIEN)  REFERENCES CLI(CODIGO),
   CONSTRAINT FK_CLM_TS371 FOREIGN KEY(TIPO_ADUAN) REFERENCES softpad_sistema.Ts371(CODIGO),
   CONSTRAINT FK_CLM_TS372 FOREIGN KEY(TIPO_REGIM) REFERENCES softpad_sistema.Ts372(CODIGO),
   CONSTRAINT FK_CLM_TS505 FOREIGN KEY(TIPO_FINAN) REFERENCES softpad_sistema.Ts505(CODIGO),
   CONSTRAINT FK_CLM_TS6   FOREIGN KEY(TIPO_COMIS) REFERENCES softpad_sistema.Ts6(COD),
   CONSTRAINT FK_CLM_TS98  FOREIGN KEY(TIPO_BASE)  REFERENCES softpad_sistema.Ts98(COD));
   CREATE INDEX CLM ON CLM(COD_CLIEN);

/*CLR(COMISIONES POR RANGO DE VALORES)*/
CREATE TABLE IF NOT EXISTS CLR(
   COD_CLIEN 	CHAR(5) NOT NULL,         	 /*C  5  0 CODIGO DEL CLIENTE*/
   CORRE_CLM    CHAR(2) NOT NULL DEFAULT '01',   /*       CORRELATIVO FISICO DE LOS REGISTROS **/
   CORREL       CHAR(2) NOT NULL DEFAULT '01',   /*       CORRELATIVO FISICO DE LOS REGISTROS **/
   BASEC_INI 	DECIMAL(12,2) DEFAULT 0.00,	 /*N 12  2 IMPORTE DESDES*/
   BASEC_FIN 	DECIMAL(12,2) DEFAULT 0.00,	 /*N 12  2 IMPORTE HASTA*/
   PORC_COMIS	DECIMAL(12,2) DEFAULT 0.00,	 /*N 12  2 PORCENTAJE DE COMSION A COBRAR*/
   PRIMARY KEY(COD_CLIEN,CORRE_CLM,CORREL),
   CONSTRAINT FK_CLR_CLM FOREIGN KEY(COD_CLIEN,CORRE_CLM) REFERENCES CLM(COD_CLIEN,CORREL));
   CREATE INDEX CLR ON CLR(COD_CLIEN);

/*CPV(PROVEEDORES POR CLIENTE)*/
CREATE TABLE IF NOT EXISTS CPV(
   COD_PROV  	CHAR(10) NOT NULL,	/*C 10  0 //codigo del proveedor*/
   VINCULAC  	CHAR(1) DEFAULT '',	/*C  1  0 //Vinc.con proveedor extranjero*/
   INFL_VINCU	CHAR(1) DEFAULT '',	/*C  1  0 //Influencia de la vinculacion en precio*/
   PVATR12B  	CHAR(1) DEFAULT '',	/*C  1  0 //Aprox.valor transac.a Art. 1.2 B) OMC*/
   PRECE1    	CHAR(1) DEFAULT '',	/*C  1  0 //Restricciones cesion/utilizacion art 1 OMC*/
   PCONMCIA  	CHAR(1) DEFAULT '',	/*C  1  0 //Depende venta o precio con mercancias a valorar*/
   PDECOND   	CHAR(1) DEFAULT '',	/*C  1  0 //Puede determinarse valor con condiciones*/
   SPAG_INDIR	CHAR(1) DEFAULT '',	/*C  1  0 //Pago indirecto de las mercancias*/
   PDESRET   	CHAR(1) DEFAULT '',	/*C  1  0 //descuentos retroactivos*/
   SDER_LICEN	CHAR(1) DEFAULT '',	/*C  1  0 //canones y derechos de licencia de mercancia*/
   VENT_CONDI	CHAR(1) DEFAULT '',	/*C  1  0 //Venta condicionada por un acuerdo*/
   CONTMCIA  	CHAR(1) DEFAULT '',	/*C  1  0 //contrato relativo a las mercancias*/
   CONTSUMI  	CHAR(1) DEFAULT '',	/*C  1  0 //contrato global de suministro larga duracion*/
   CLAUREVI  	CHAR(1) DEFAULT '',	/*C  1  0 //clausula de revisi�n de precio*/
   INTIMPCLI 	CHAR(1) DEFAULT '',	/*C  1  0 //Inetemediario imp. a solicitud cliente*/
   DIFVALASI 	CHAR(1) DEFAULT '',	/*C  1  0 //Diferente valor asignado emp.verificadora*/
   COND16    	CHAR(1) DEFAULT '',	/*C  1  0 //OTros*/
   COND17    	CHAR(1) DEFAULT '',	/*C  1  0 //OTros*/
   COND18    	CHAR(1) DEFAULT '',	/*C  1  0 //OTros*/
   COND19    	CHAR(1) DEFAULT '',	/*C  1  0 //OTros*/
   COND20    	CHAR(1) DEFAULT '',	/*C  1  0 //OTros*/
   CARACESTIM	CHAR(1) DEFAULT '',	/*C  1  0 //Pregunta para DAV Casillero (80) Tiene caracter estimativo*/
   COD_CLIEN 	CHAR(5) NOT NULL,	/*C  5  0 //Codigo del cliente Relacionado*/
   COD_INTERM   CHAR(4) DEFAULT '',     /* 0 //Codigo deIntermedirio*/
   PRIMARY KEY(COD_CLIEN,COD_PROV),
   CONSTRAINT FK_CPV_CLI FOREIGN KEY(COD_CLIEN) REFERENCES CLI(CODIGO),
   CONSTRAINT FK_CPV_ITR FOREIGN KEY(COD_INTERM) REFERENCES ITR(CODIGO),
   CONSTRAINT FK_CPV_PRA FOREIGN KEY(COD_PROV) REFERENCES PRA(CODIGO));
   CREATE INDEX CPV ON CPV(COD_CLIEN,COD_PROV);

/*ECG(ENCARGADOS DE AREA POR CLIENTE)*/
CREATE TABLE IF NOT EXISTS ECG(
   CODIGO    	CHAR(2) NOT NULL,	/*C  2  0 CODIGO CORRELATIVO*/
   NOMBRE    	VARCHAR(50) DEFAULT '',	/*C 50  0 NOMBRE DEL ENCARGADO DE AREA*/
   NEXTEL    	CHAR(8) DEFAULT '',	/*C  8  0 NUMERO DE NEXTEL DEL ENCARGADO*/
   DESC_AREA 	VARCHAR(20) DEFAULT '',	/*C 20  0 AREA DEL ENCARGADO*/
   COD_CLIEN 	CHAR(5) NOT NULL,	/*C  5  0 CODIGO DEL CLIENTE AL QUE PERTENECE EL REPRESENTANTE LEGAL*/
   PRIMARY KEY(COD_CLIEN,CODIGO),
   CONSTRAINT FK_ECG_CLI FOREIGN KEY(COD_CLIEN) REFERENCES CLI(CODIGO));
   CREATE INDEX ECG ON ECG(COD_CLIEN);

CREATE TABLE IF NOT EXISTS CTT(
   COD_CLIEN 	CHAR(5) NOT NULL,	/*C  5  0 CODIGO DEL CLIENTE*/
   TIPO_CARGA	CHAR(1),	/*C  1  0 TIPO DE CARGA (CONTENEDOR O CARGA SUELTA)*/
   CORREL       CHAR(2) NOT NULL DEFAULT '01',   /*CORRELATIVO FISICO DE LOS REGISTROS **/
   PESO_DESDE	DECIMAL(12,2) DEFAULT 0.00,	/*N 12  2 PESO DESDE*/
   PESO_HASTA	DECIMAL(12,2) DEFAULT 0.00,	/*N 12  2 PESO HASTA*/
   ZONA_1    	DECIMAL(13,2) DEFAULT 0.00,	/*N 13  2 ZONA 1*/
   ZONA_2    	DECIMAL(13,2) DEFAULT 0.00,	/*N 13  2 ZONA 2*/
   ZONA_3    	DECIMAL(13,2) DEFAULT 0.00,	/*N 13  2 ZONA 3*/
   CONTENE   	CHAR(2) DEFAULT "",	/*C  2  0 TIPO DE CONTENEDOR*/
   PRIMARY KEY(COD_CLIEN,TIPO_CARGA,CORREL),
   CONSTRAINT FK_CTT_CLI FOREIGN KEY(COD_CLIEN) REFERENCES CLI(CODIGO));
   CREATE INDEX CTT ON CTT(COD_CLIEN);

/* CLB(TABLA DE LINEA DE CREDITO POR CLIENTE)*/
CREATE TABLE IF NOT EXISTS CLB(
   COD_CLIEN 	CHAR(5),	/*C  5  0 CODIGO DEL CLIENTE*/
   CTA       	VARCHAR(25),	/*C 25  0 NUMERO DE LA CTA CTE DONDE SE HARA LOS ABONOS DE LAS LETRAS*/
   COD_BANCO 	CHAR(2),	/*C  2  0 CODIGO DE BANCO*/
   BANCO     	CHAR(2),	/*C  2  0 NOMBRE DEL BANCO EN EL QUE SE DESIGNARA LAS LETRAS*/
   TIPO_MON  	CHAR(1),	/*C  1  0 MONEDA DE LA LETRA*/
   LINEA_ASI 	DECIMAL(12,2) DEFAULT 0.00,	/*N 12  2 LINEA MONETARIA ASIGNADA POR EL BANCO AL CLIENTE*/
   LINEA_UTI 	DECIMAL(12,2) DEFAULT 0.00,	/*N 12  2 LINEA MONETARIA UTILIZADA EL CLIENTE*/
   LINEA_DIS 	DECIMAL(12,2) DEFAULT 0.00,	/*N 12  2 LINEA MONETARIA DISPONIBLE PARA EL CLIENTE*/
   DIAS_VECOB   NUMERIC(2,0) DEFAULT 0,
   DIAS_VEFAC   NUMERIC(2,0) DEFAULT 0,
   DIAS_VECO1   NUMERIC(2,0) DEFAULT 0,
   PRIMARY KEY(COD_CLIEN,CTA),
   CONSTRAINT FK_CLB_CLI FOREIGN KEY(COD_CLIEN) REFERENCES CLI(CODIGO));
 CREATE INDEX CLB ON CLB(COD_CLIEN);

/* LUG(LUGAR DEL ENTREGA DE LA MERCADERIA POR CLIENTE)*/
CREATE TABLE IF NOT EXISTS LUG(
   CODIGO    	CHAR(4) NOT NULL,	/*C  4  0 CODIGO CORRELATIVO*/
   LUG_ENTREG	VARCHAR(70) DEFAULT '',	/*C 70  0 DESCRIPCION DEL LUGAR DE ENTREGA*/
   LL_VIATIPO	CHAR(10) DEFAULT '',	/*C 10  0 Via Tipo de Punto del Lugar de Entrega*/
   LL_VIANOMB	VARCHAR(40) DEFAULT '',	/*C 40  0 Via Nombre de Punto del Lugar de Entrega*/
   LL_NUMERO 	CHAR(10) DEFAULT '',	/*C 10  0 Numero de Punto del Lugar de Entrega*/
   LL_INTER  	CHAR(5) DEFAULT '',	/*C  5  0 Interior de Punto del Lugar de Entrega*/
   LL_ZONA   	VARCHAR(20) DEFAULT '',	/*C 20  0 Zona de Punto del Lugar de Entrega*/
   LL_DIST   	VARCHAR(20) DEFAULT '',	/*C 20  0 Punto de Llegada - Distrito*/
   LL_PROV   	VARCHAR(15) DEFAULT '',	/*C 15  0 Punto de Llegada - Provincia*/
   LL_DPTO   	VARCHAR(15) DEFAULT '',	/*C 15  0 Punto de Llegada - Departamento*/
   COD_CLIEN 	CHAR(5) NOT NULL,	/*C  5  0 CODIGO DEL CLIENTE AL QUE PERTENECE EL LUGAR DE ENTREGA*/
   REFERENCIA	VARCHAR(35) DEFAULT '',	/*C 35  0 Referencia del lugar de entrega*/
   PRIMARY KEY(COD_CLIEN,CODIGO),
   CONSTRAINT FK_LUG_CLI FOREIGN KEY(COD_CLIEN) REFERENCES CLI(CODIGO),
   CONSTRAINT UQ_LUG_1 UNIQUE(COD_CLIEN,LUG_ENTREG));
   CREATE INDEX LUG ON LUG(COD_CLIEN);

/* REP(REPRESENTANTE LEGAL DE LOS CLIENTES)*/
CREATE TABLE IF NOT EXISTS REP(
   CODIGO    	CHAR(2) NOT NULL,      	/*C  2  0 CODIGO CORRELATIVO*/
   NOMBRE    	VARCHAR(60) DEFAULT '',	/*C 50  0 NOMBRE DEL REPRESENTANTE LEGAL*/
   TD        	CHAR(1) DEFAULT '',	/*C  1  0 TIPO DE DOCUMENTO DEL REPRESENTANTE LEGAL*/
   DOCUMENTO 	CHAR(11) DEFAULT '',	/*C 11  0 NUMERO DE DOCUMENTO DEL REPRESENTANTE LEGAL*/
   TD1       	CHAR(1) DEFAULT '',	/*C  1  0 OTRO TIPO DE DOCUMENTO DEL REPRESENTANTE LEGAL (SOLO UIF)*/
   DOCUMENTO1	CHAR(11) DEFAULT '',	/*C 11  0 OTRO NUMERO DE DOCUMENTO DEL REPRESENTANTE LEGAL (SOLO UIF)*/
   FECH_NAC  	DATE,	                /*D  8  0 FECHA DE NACIMIENTO DEL REPRESENTANTE LEGAL*/
   CARGO     	VARCHAR(25) DEFAULT '',	/*C 25  0 CALIDAD DEL REPRESENTANTE LEGAL*/
   COD_CLIEN 	CHAR(5) NOT NULL,	/*C  5  0 CODIGO DEL CLIENTE AL QUE PERTENECE EL REPRESENTANTE LEGAL*/
   COD_CARGO    CHAR(3) DEFAULT '',     /*C  3  0 CODIGO DEL CARGO DE REPRESENTANTE LEGAL PARA LA UIF */  
   STATUS       CHAR(1) DEFAULT 'S',     /*C  1  0 VIGENTE O NO VIGENTE */
   PRIMARY KEY(COD_CLIEN,CODIGO),
   CONSTRAINT FK_REP_CLI FOREIGN KEY(COD_CLIEN) REFERENCES CLI(CODIGO),
   CONSTRAINT UQ_REP_1 UNIQUE(COD_CLIEN,NOMBRE));
   CREATE INDEX REP ON REP(COD_CLIEN);
INSERT INTO REP(codigo,nombre,td,documento,fech_nac,cod_clien,cargo) values("01","JUAN CARLOS ZORRILLA LLERENA","2","09506613","1970-02-24","00000","REPRESENTANTE");

/* CTC(CUENTAS BANCARIAS DE LOS CLIENTES PARA EL PAGO ELECTRONICO)*/
CREATE TABLE IF NOT EXISTS CTC(
   NRO_CTACTE CHAR(20) NOT NULL DEFAULT "",   /* Nro de cta. cte asociada al banco*/
   BANCO      VARCHAR(15) DEFAULT "",         /* Codigo del Banco*/
   COD_CLIEN  CHAR(5) NOT NULL DEFAULT "",    /* Codigo de Cliente*/
   PRIMARY KEY(COD_CLIEN,NRO_CTACTE),
   CONSTRAINT FK_CTC_CLI FOREIGN KEY(COD_CLIEN) REFERENCES CLI(CODIGO));
CREATE INDEX CTC ON CTC(COD_CLIEN);

/* UIF(TABLA DE DATOS ADICIONALES PARA LA UIF)*/
CREATE TABLE IF NOT EXISTS UIF(
   COD_CLIEN 	CHAR(5) NOT NULL,               /*C  5  0 CODIGO CLIENTE AL QUE CORRESPONDEN LOS DATOS ADICIONALES */
   TIPO_PERS    CHAR(1) DEFAULT "",             /*TIPO DE PARTICIPANTE (PERSONA NATURAL O JURIDICA) */ 
   NACIONALI    VARCHAR(15) DEFAULT "",         /*Codigo de Nacionalidad */
   PROFESION    VARCHAR(30) DEFAULT "",         /*Profesion */
   EST_CIVIL    CHAR(1) DEFAULT "",             /*Estado Civil */
   NOM_CONYU    VARCHAR(80) DEFAULT "",         /*Nombre del Conyugue */ 
   FUN_PUBLI1   VARCHAR(100) DEFAULT "",        /*C100  0 Cargo o Funcion Publica especificando la Entidad*/
   FUN_PUBLI2   VARCHAR(100) DEFAULT "",        /*C100  0 Cargo o Funcion Publica especificando la Entidad*/
   FUN_PUBLI3   VARCHAR(100) DEFAULT "",        /*C100  0 Cargo o Funcion Publica especificando la Entidad*/
   ORIG_FOND    VARCHAR(100) DEFAULT "",        /*Origen de los fondos involucrados  Publica especificando la Entidad */     
   OBLIG_UIF    CHAR(1) DEFAULT "",             /*Es sujeto obligado informar a la UIF-Per�?*/
   DESIG_OFI    CHAR(1) DEFAULT "",             /*En caso marc� SI, indique si design� a su Oficial de Cumplimiento:*/ 
   OBJ_SOCIAL   CHAR(5) DEFAULT "",             /*Objeto social y actividad econ�mica principal (comercial, industrial, construcci�n, transporte, etc.).*/
   IDENT_ACC    VARCHAR(100) DEFAULT "",        /*C100  0 Identificaci�n de los accionistas, socios o asociados, que tengan un porcentaje igual o mayor al 5% de las acciones o participaciones de la persona jur�dica.*/
   IDENT_ACC2   VARCHAR(100) DEFAULT "",        /*C100  0 Identificaci�n de los accionistas, socios o asociados, que tengan un porcentaje igual o mayor al 5% de las acciones o participaciones de la persona jur�dica.*/
   IDENT_ACC3   VARCHAR(100) DEFAULT "",        /*C100  0 Identificaci�n de los accionistas, socios o asociados, que tengan un porcentaje igual o mayor al 5% de las acciones o participaciones de la persona jur�dica.*/
   IDENT_ACC4   VARCHAR(100) DEFAULT "",        /*C100  0 Identificaci�n de los accionistas, socios o asociados, que tengan un porcentaje igual o mayor al 5% de las acciones o participaciones de la persona jur�dica.*/
   IDENT_REP    CHAR(2) DEFAULT "",             /*Identificaci�n del representante legal o de quien comparece con facultades de representaci�n y/o disposici�n de la persona jur�dica.  */
   DOMICILIO    VARCHAR(150) DEFAULT "",        /*Domicilio */
   IDENT_TER    VARCHAR(100) DEFAULT "",        /*Identificaci�n del tercero, sea persona natural (nombres y apellidos) o persona jur�dica (raz�n o denominaci�n social) por cuyo intermedio se realiza la operaci�n, de ser el caso.*/
   LUGAR_NAC    VARCHAR(30)  DEFAULT "",        /*Lugar de Nacimiento*/
   FECH_NAC     DATE,                           /*Fecha de Nacimiento*/
   PRIMARY KEY(COD_CLIEN),
   CONSTRAINT FK_UIF_CLI FOREIGN KEY(COD_CLIEN) REFERENCES CLI(CODIGO));
CREATE INDEX UIF ON UIF(COD_CLIEN);

/* UF1(TABLA DE DATOS ADICIONALES PARA LA UF1)*/  
CREATE TABLE IF NOT EXISTS UF1(
   COD_CLIEN  CHAR(5) NOT NULL,               /*C  5  0 CODIGO CLIENTE AL QUE CORRESPONDEN LOS DATOS ADICIONALES */
   NOMBRE       VARCHAR(30) DEFAULT "",         /*Nombres Si es Persona Natural*/   
   APELLIDOS    VARCHAR(30) DEFAULT "",         /*Apellidos Si es Persona Natural*/   
   NACIONALI    VARCHAR(15) DEFAULT "",         /*Codigo de Nacionalidad */   
   NOM_CONYU    VARCHAR(80) DEFAULT "",         /*Nombre del Conyugue */ 
   DIRECC_AV    VARCHAR(40) DEFAULT "",         /*Direcci�n Avenida */
   DIRECC_NRO   VARCHAR(4) DEFAULT "",          /*Direcci�n Numero */
   DIRECC_INT   VARCHAR(4) DEFAULT "",          /*Direcci�n Interior */
   DIRECC_URB   VARCHAR(20) DEFAULT "",         /*Direcci�n Urbanizacion */
   DIRECC_DST   VARCHAR(20) DEFAULT "",         /*Direcci�n Distrito */
   DIRECC_PRV   VARCHAR(20) DEFAULT "",         /*Direcci�n Provincia */
   DIRECC_DPT   VARCHAR(20) DEFAULT "",         /*Direcci�n Departamento */
   OCUPACION    VARCHAR(50) DEFAULT "",         /*Profesion */
   PEP_SOY      VARCHAR(1) DEFAULT "",          /*PEP Soy */
   PEP_HESIDO   VARCHAR(1) DEFAULT "",          /*PEP HeSido */
   PEP_NOSOY    VARCHAR(1) DEFAULT "",          /*PEP NoSoy */
   PEP_NOSIDO   VARCHAR(1) DEFAULT "",          /*PEP NoHeSido */
   PEP_CARGO    VARCHAR(30) DEFAULT "",         /*PEP Cargo */
   PEP_INSTIT   VARCHAR(50) DEFAULT "",         /*PEP Soy Instituci�n */
   ORIG_FOND    VARCHAR(100) DEFAULT "",        /*Origen de los fondos involucrados  Publica especificando la Entidad */     
   PROPOSITO    VARCHAR(100) DEFAULT "",        /*Proposito*/
   NUM_OPER     NUMERIC(4,0) DEFAULT 0,         /*Numero de operaciones proyectadas para simplificada*/
   MONTO_OPER   DECIMAL(12,2) DEFAULT 0.00,     /*Monto aproximado */
   PRIMARY KEY(COD_CLIEN),
   CONSTRAINT FK_UF1_CLI FOREIGN KEY(COD_CLIEN) REFERENCES CLI(CODIGO));
CREATE INDEX UF1 ON UF1(COD_CLIEN);

/* UF2(TABLA DE SOCIOS O PARIENTES DEL CLIENTE PARA LA UIF)*/  
CREATE TABLE IF NOT EXISTS UF2(
   COD_CLIEN    CHAR(5) NOT NULL,               /*C  5  0 CODIGO CLIENTE AL QUE CORRESPONDEN LOS DATOS ADICIONALES */
   TIPO_PERS    CHAR(1) NOT NULL,               /*TIPO DE PARTICIPANTE (PERSONA NATURAL O JURIDICA) */  
   CORREL       CHAR(2) NOT NULL,               /* Correlativos de socios o parientes del cliente */
   NOMBRE       VARCHAR(30) DEFAULT "",         /*Nombres de Socios si es Persona Natural*/   
   APELLIDOS    VARCHAR(30) DEFAULT "",         /*Apellidos de Socios si es Persona Natural*/   
   RAZ_SOCIAL   VARCHAR(100) DEFAULT "",        /*Razon Social de Soios si es Persona Juridica*/   
   TIPO_DOC     VARCHAR(1) DEFAULT "",          /*Tipo Documento de Socios */   
   DOCUMENTO    VARCHAR(11) DEFAULT "",         /*Documento de Socios */   
   OCUPACION    VARCHAR(30) DEFAULT "",         /*Ocupaci�n de Socios */     
   COD_PARENT   CHAR(2) DEFAULT "",             /*Codigo de Parentesco para persona natural */ 
   PRIMARY KEY(COD_CLIEN,TIPO_PERS,CORREL),
   CONSTRAINT FK_UF2_UF1 FOREIGN KEY(COD_CLIEN) REFERENCES UF1(COD_CLIEN));
CREATE INDEX UF2 ON UF2(COD_CLIEN,TIPO_PERS,CORREL);

/* DST (DESTINATARIOS DE LA GUIA DE REMISION SOLO PARA DHL */
CREATE TABLE IF NOT EXISTS DST(
   CODIGO       CHAR(4) not null,
   NOMB_DESTI   VARCHAR(90) default '',
   DIR_DESTI    VARCHAR(80) default '',
   TDOC_DESTI   CHAR(2) DEFAULT '', 
   DOCU_DESTI   CHAR(11) DEFAULT '',
   COD_CLIEN    CHAR(5) NOT NULL, 
   PRIMARY KEY(COD_CLIEN,CODIGO),
   CONSTRAINT FK_DST_CLI FOREIGN KEY(COD_CLIEN) REFERENCES CLI(CODIGO));
CREATE INDEX DST ON DST(COD_CLIEN,CODIGO);

/* TID(TABLA DE INCIDENCIA DE DESPACHOS)*/
CREATE TABLE IF NOT EXISTS TID(
    COD         CHAR(2) NOT NULL,        /*Codigo de la Incidencia */
    INCIDENCIA  VARCHAR(55) DEFAULT "",  /*Descripcion de la Indicencia */
    DESCRIPCIO  VARCHAR(11) DEFAULT "",  /*Descripcion Resumida de la Incidencia */
    AUTOMATICO  CHAR(1) DEFAULT "",      /*Flag que indica que la Incidencia es Automatica */
    RUTA_TXTS   VARCHAR(50) DEFAULT "",  /*Ruta donde el sistema generara un Archivo de Texto */
   PRIMARY KEY(COD),
   CONSTRAINT UQ_TID_1 UNIQUE(COD,INCIDENCIA));
CREATE INDEX TID ON TID(COD);
INSERT INTO `tid` (`COD`,`INCIDENCIA`,`DESCRIPCIO`,`AUTOMATICO`,`RUTA_TXTS`) VALUES 
 ('',' Z','','X','                                                  '),
 ('00','ORDEN PROFORMADA                                      ','PROFORMADA ','X','                                                  '),
 ('01','ORDEN APERTURADA                                      ','APERTURADA ','X','                                                  '),
 ('02','ORDEN ASIGNADA                                        ','ASIGNADA   ','X','                                                  '),
 ('03','ORDEN EN DIGITACION                                   ','DIGITACION ','X','                                                  '),
 ('04','ORDEN ENVIADA A NUMERAR                               ','ENVIADA    ','X','                                                  '),
 ('05','ORDEN REENVIADA                                       ','REENVIADA  ','X','                                                  '),
 ('06','ORDEN RECHAZADA                                       ','RECHAZADA  ','X','                                                  '),
 ('07','ORDEN CON ADVERTENCIA                                 ','ADVERTENCIA','X','                                                  '),
 ('08','ORDEN NUMERADA                                        ','NUMERADA   ','X','                                                  '),
 ('09','MODIFICADA DESPUES DE NUMERAR                         ','MODIFICADA ','X','                                                  '),
 ('10','ORDEN RECTIFICADA                                     ','RECTIFICADA','X','                                                  '),
 ('11','ORDEN CANCELADA                                       ','CANCELADA  ','X','                                                  '),
 ('12','PREPARAR DUA PARA REGULARIZAR ORDEN                   ','REGULARIZAR','X','                                                  '),
 ('13','DUA ENVIADA A ADUANAS                                 ','REGULENVIA ','X','                                                  '),
 ('14','DUA NUMERADA                                          ','REGULNUMER ','X','                                                  '),
 ('15','ORDEN FACTURADA                                       ','FACTURADA  ','X','                                                  '),
 ('16','ORDEN IMPRESA                                         ','IMPRESA    ','X','                                                  '),
 ('18','REACTIVADA POR USUARIO                                ','REACTIVADA ','X','                                                  '),
 ('19','DOCUMENTOS ORIGINALES                                 ','DOCUMENTOS ','','                                                   '),
 ('20','PROFORMA POR ORDEN IMPRESA                            ','PROF.IMPRES','X','                                                  '),
 ('21','ORDEN CON V§ B§ DE NAVIERA                          ','VoBoNAVIERA','','                                                   '),
 ('22','ORDEN RETIRADA                                        ','RETIRADA   ','','                                                   '),
 ('23','ORDEN ENVIADA AL CLIENTE                              ','CLIENTE    ','','                                                   '),
 ('24','MERCANCIA ENTREGADA                                   ','ENTREGADA  ','','                                                   '),
 ('25','ORDEN EN ARCHIVO                                      ','ARCHIVO    ','','                                                   '),
 ('99','OTRAS INCIDENCIAS                                     ','OTROS      ','','                                                   '),
 ('AF','ORDEN AFORADA                                         ','AFORADA    ','X','                                                  '),
 ('CR','CAMBIO DE REGIMEN/ADUANA                              ','CAMBIO REG.','X','                                                  '),
 ('ET','ORDEN X ENTREGAR                                      ','ENTREGA    ','X','                                                  '),
 ('LV','ORDEN CON LEVANTE                                     ','LEVANTE    ','X','                                                  '),
 ('MT','DESPACHO MULTIPLICADO DE LA O/.                       ','MULTIPLICAR','X','                                                  '),
 ('O1','GENERO LAS SERIES DE A DESDE EL FORMATO B             ','GENERO DE B','X','                                                  '),
 ('ME','MODIFICACION DE ARCHIVO DE ENVIO A ADUANAS            ','MODIF.ENVIO','X','                                                  '),
 ('AN','ANULADA POR                                           ','MOT.ANULADO','X','                                                  '),
 ('DN','SE QUITO CANCELACION POR                              ','QUITO CANC.','X','                                                  '),
 ('90','PAGO CON GARANTIA ART. 160                            ','PAG.GARANT.','X','                                                  '),
 ('RT','ORDEN CON RETIRO                                      ','RETIRO     ','X','                                                  '),
 ('O2','GENERO B CONSERVANDO EL A SIN INCLUIR DESCRIPCIONES   ','GENERO DE B','X','                                                  '),
 ('Z1','ORDEN CON FACTURA ANULADA                             ','FACT.ANUL. ','X','                                                  '),
 ('PC','PEDIR CANAL AUTOMATICO                                ','PEDIR.CANAL','X','                                                  ');


/******************************************************************************************/

/* CIN(COMPRADOR INICIAL)*/
CREATE TABLE IF NOT EXISTS CIN(
   CODIGO    	CHAR(4),	/*C  4  0*/
   RAZON_SOC 	VARCHAR(60),	/*C 50  0*/
   DOCUMENTO 	CHAR(11),	/*C 11  0*/
   TIPO_DOCUM	CHAR(1),	/*C  1  0*/
   PRIMARY KEY(CODIGO));
   CREATE INDEX CIN ON CIN(CODIGO);

/******************************************************************************************/

/* CAM(TIPO DE CAMBIO)*/
CREATE TABLE IF NOT EXISTS CAM(
   FECHA_DIA 	DATE NOT NULL,                   	/*D  8  0*/
   DOLAR_BANC	DECIMAL(12,10) DEFAULT 0.0000000000,	/*N 12 10*/
   DOLAR_COMP	DECIMAL(12,10) DEFAULT 0.0000000000,	/*N 12 10*/
   PRIMARY KEY(FECHA_DIA));
   CREATE INDEX CAM ON CAM(FECHA_DIA);

/*****************************************************************************************/
/* PRV(TABLA DE PROVEEDORES DE IMPORTACION SIMPLIFICADA)*/
CREATE TABLE IF NOT EXISTS PRV(	
   CODIGO    	CHAR(10) NOT NULL, /*C 10  0*/
   NOM_FABR  	VARCHAR(60) DEFAULT '',	/*C 60  0*/
   PAIS_PROV 	CHAR(2) DEFAULT '',	/*C  2  0*/
   DIR1      	VARCHAR(55) DEFAULT '',	/*C 55  0*/
   CIUDAD    	VARCHAR(50) DEFAULT '',	/*C 50  0*/
   TLF_PROV  	VARCHAR(15) DEFAULT '',	/*C 15  0*/
   FAX_PROV  	VARCHAR(15) DEFAULT '',	/*C 15  0*/
   CONDI_PRO 	CHAR(1) DEFAULT '',	/*C  1  0*/
   VINCULAC  	CHAR(1) DEFAULT '',	/*C  1  0*/
   PAIS      	CHAR(3) DEFAULT '',	/*C  3  0*/
   EMAIL        VARCHAR(30) DEFAULT '',
   PAG_WEB      VARCHAR(60) DEFAULT '',
   FECH_DESPA   DATETIME,               /*D  8  0 FECHA DE USO DEL CLIENTE EN UN ULTIMO DESPACHO*/
   PRIMARY KEY(CODIGO),
   CONSTRAINT UQ_PRV_1 UNIQUE(PAIS_PROV,NOM_FABR));
 CREATE INDEX PRV ON PRV(CODIGO);
 INSERT INTO PRV(CODIGO,NOM_FABR) values("          ","Z");

/* UBM(TABLA DE UBICACION DE LA MERCANCIA)*/
CREATE TABLE IF NOT EXISTS UBM(	
   CODIGO    	CHAR(5) NOT NULL,               /*C 10  0*/
   NOMBRE_EST  	VARCHAR(90) DEFAULT '',  	/*C 60  0*/
   TDOC         CHAR(2) DEFAULT "",             /*C  2  0   Tipo de documento del Participante*/
   NDOC         VARCHAR(11) DEFAULT "",         /*C 11  0   Numero de Documento del Participante*/
   TIPO_PARTI   CHAR(2) DEFAULT "",             /*C  2  0   Tipo de Participante*/
   COD_ANEXO    CHAR(6) DEFAULT "",             /*C  6  0   Codigo del Establecimiento Anexo*/
   PRIMARY KEY(CODIGO),
   CONSTRAINT UQ_UBM_1 UNIQUE(CODIGO,NOMBRE_EST));
 CREATE INDEX UBM ON UBM(CODIGO);
 INSERT INTO UBM(CODIGO,NOMBRE_EST) values("          ","Z");

/****************************************************************************************/
		
/* REQ (TABLA DE REQUERIMIENTOS POR AGENCIA)*/

CREATE TABLE IF NOT EXISTS REQ(
   N_REQUER  	CHAR(7),	/*C  7  0 NUMERO DE REQ. COD. INTERNO+CORRELATIVO*/
   FCH_DIGIT 	DATETIME  NOT NULL, /*D  8  0 FECHA DE DIGITACION*/
   COD_USER  	CHAR(3) NOT NULL, /*C  2  0 CODIGO DEL USUARIO*/
   CONCEPTO  	VARCHAR(50) DEFAULT "",	/*C 50  0 CONCEPTO GENERAL*/
   OBS1      	VARCHAR(100) DEFAULT "", /*C100  0 LINEA DE REQ. 1*/
   OBS2      	VARCHAR(100) DEFAULT "", /*C100  0 LINEA DE REQ.*/
   OBS3      	VARCHAR(100) DEFAULT "", /*C100  0 LINEA DE REQ.*/
   OBS4      	VARCHAR(100) DEFAULT "", /*C100  0 LINEA DE REQ.*/
   OBS5      	VARCHAR(100) DEFAULT "", /*C100  0 LINEA DE REQ.*/
   OBS6      	VARCHAR(100) DEFAULT "", /*C100  0 LINEA DE REQ.*/
   OBS7      	VARCHAR(100) DEFAULT "", /*C100  0 LINEA DE REQ.*/
   OBS8      	VARCHAR(100) DEFAULT "", /*C100  0 LINEA DE REQ.*/
   OBS9      	VARCHAR(100) DEFAULT "", /*C100  0 LINEA DE REQ.*/
   OBS10     	VARCHAR(100) DEFAULT "", /*C100  0 LINEA DE REQ.*/
   OBS11     	VARCHAR(100) DEFAULT "", /*C100  0 LINEA DE REQ.*/
   OBS12     	VARCHAR(100) DEFAULT "", /*C100  0 LINEA DE REQ.*/
   OBS13     	VARCHAR(100) DEFAULT "", /*C100  0 LINEA DE REQ.*/
   OBS14     	VARCHAR(100) DEFAULT "", /*C100  0 LINEA DE REQ.*/
   OBS15     	VARCHAR(100) DEFAULT "", /*C100  0 LINEA DE REQ.*/
   FCH_ENVIO 	DATETIME,      	/*D  8  0 FECHA DE ENVIO*/
   FCH_ENTREG	DATE,	        /*D  8  0 FECHA DE ENTREGA DEL REQUERIMIENTO*/
   COD_PROG     CHAR(3) DEFAULT "", /*C  3  0 CODIGO DEL PROGRAMADOR*/
   PRIMARY KEY(N_REQUER),
   CONSTRAINT FK_REQ_USU FOREIGN KEY(COD_USER) REFERENCES USU(CODIGO));
   CREATE INDEX REQ ON REQ(N_REQUER);

/*=========================================================================================*/

/* COR(TABLA DE CORREOS ELECTRONICOS DE LA aGENCIA )*/
CREATE TABLE IF NOT EXISTS COR(
   VCOD_AGTE 	CHAR(4) NOT NULL ,	/*C  4  0 CODIGO CORRELATIVO DEL CLIENTE*/
   VCOD_INTER	CHAR(4) NOT NULL,	/*C  4  0 NOMBRE DEL CLIENTE SEGUN SUNAT*/
   CORREL       CHAR(2) NOT NULL,               /*C  2  0 CORRELACION DEL REGISTROS */  
   EMAIL     	VARCHAR(60) DEFAULT '',	/*C 60  0 DIRECCION COMERCIAL DEL CLIENTE*/
   USUARIO   	VARCHAR(30) DEFAULT '',	/*C 30  0 DISTRITO*/
   CARGO     	VARCHAR(25) DEFAULT '',	/*C 25  0 CALIDAD DEL IMPORTADOR*/
   NEXTEL    	CHAR(14) DEFAULT '',	/*C 10  0 NEXTEL*/
   OSBVE1    	VARCHAR(90) DEFAULT '',	/*C 90  0 OBSERVACIONES DEL CLIENTE*/
   OSBVE2    	VARCHAR(90) DEFAULT '',	/*C 90  0 OBSERVACIONES DEL CLIENTE*/
   OSBVE3    	VARCHAR(90) DEFAULT '',	/*C 90  0 OBSERVACIONES DEL CLIENTE*/
   OSBVE4    	VARCHAR(90) DEFAULT '',	/*C 90  0 OBSERVACIONES DEL CLIENTE*/
   OSBVE5    	VARCHAR(90) DEFAULT '',	/*C 90  0 OBSERVACIONES DEL CLIENTE*/
   SISTEMA      CHAR(3) NOT NULL,        /*C  3  0 */  
   TIPO_CEL     CHAR(1) DEFAULT 'N',     /*Tipo de Telefomo movil o celurar */    
   PRIMARY KEY(VCOD_AGTE,VCOD_INTER,CORREL),
   CONSTRAINT UQ_COR_1 UNIQUE(EMAIL));
   CREATE INDEX COR ON COR(VCOD_AGTE);

/*=========================================================================================*/

/* CAR(CARGO DE MANTENIMIENTO) */
CREATE TABLE IF NOT EXISTS CAR(
   TIPO_ID      CHAR(3) NOT NULL,
   ANIO      	CHAR(2) NOT NULL,/*C  2  0 A�O EN CURSO*/
   MES       	CHAR(2) NOT NULL,/*C  2  0 MES A QUE PERTENECE EL CARGO*/
   ORDEN     	CHAR(4) NOT NULL,/*C  2  0 ORDEN CORRELATIVO*/
   DESCRIPCIO	VARCHAR(100),	/*C100  0 DETALLE DE LA MODIFICACION*/
   SAD       	CHAR(2),	/*C  2  0 FLAG DE SISTEMA*/
   DSI       	CHAR(2),	/*C  2  0 FLAG DE SISTEMA*/
   DMA       	CHAR(2),	/*C  2  0 FLAG DE SISTEMA*/
   RMF       	CHAR(2),	/*C  2  0 FLAG DE SISTEMA*/
   DVA       	CHAR(2),	/*C  2  0 FLAG DE SISTEMA*/
   SADSQL      	CHAR(2),	/*C  2  0 FLAG DE SISTEMA*/
   PRIMARY KEY(ANIO,MES,TIPO_ID,ORDEN));
   CREATE INDEX CAR ON CAR(TIPO_ID,ANIO,MES,ORDEN);

/********************************************************************************************/
/***************         TABLAS PARA EL LLENADO DE LA DUA                     ***************/
/********************************************************************************************/
/***********************    APERTURA DE ORDENES                               ***************/
/********************************************************************************************/
/* APE(ARCHIVO DE APERTURA DE CABECERA DE TODAS LAS ORDENES)*/
CREATE TABLE IF NOT EXISTS APE(
   N_ORDEN   	CHAR(11) NOT NULL,	        /*C  9  0  N� de Orden --- PRINCIPAL---*/
   C_ADUANA  	CHAR(3) NOT NULL,	        /*C  3  0  C�digo de Aduana -- FORMATO (DUA)*/
   TIPOREG   	CHAR(2) NOT NULL,	        /*C  2  0  Tipo de R�gimen o Destinaci�n*/
   F_DATE    	DATETIME NOT NULL,              /*D  8  0  Fecha de creaci�n de la Orden*/
   REF_CLIE  	VARCHAR(200) DEFAULT '',	/*C 25  0  Referencia del Cliente*/
   COD_CLIEN 	CHAR(5)  DEFAULT '',	        /*C  5  0  Codigo del Cliente*/
   LUG_ENTREG	CHAR(4) DEFAULT '',	        /*C  4  0  Lugar de Entrega de la Mercaderia al Cliente*/
   COD_USER  	CHAR(3) DEFAULT '',	        /*C  2  0  Codigo de Usuario del sistema*/
   CODVEND1  	CHAR(4) DEFAULT '',	        /*C  4  0  Codigo del Vendedor*/
   ENCARGADO    CHAR(2) DEFAULT '', 		/*C  2  0  Encargado del despacho por parte del Cliente*/
   SECTORISTA	CHAR(3) DEFAULT '',      	/*C  2  0  Sectorista de la Agencia*/
   REPRES_CLI	CHAR(2) DEFAULT '',    	        /*C  2  0  Representante Legal*/
   N_DECLAR     CHAR(6) DEFAULT '', 		/*C  6  0**** * ******Numeraci�n de la Orden dado por Aduanas a su aceptaci�n*/
   TDOC_CDA     CHAR(2) DEFAULT '', 		/*C  2  0**** * ******Num.Aduanas: Tipo de CDA*/
   DIGI_VERI    NUMERIC(3,0) default 0,         /*N  3  0** * * *** **Num.Aduanas: Digito Verificador*/
   SDOC_CDA     CHAR(2) DEFAULT '', 		/*C  2  0**** *  *****Num.Aduanas: SDOC_CDA*/
   FCHNUMER     DATETIME, 	                /*D  8  0**** * ******Fecha de Numeraci�n*/
   FUNC_RESUM   VARCHAR(40) DEFAULT '', 	/*C 40  0**** ********Clave de validaci�n para uso de la Aduana*/
   MSG_NOTIF    varchar(219) DEFAULT '',        /*C100  0      *    * Notificacion de Aduanas al momento de llegar la Respuesta*/
   ARCH_RES_P   CHAR(12) DEFAULT '', 	        /*C 12  0**** ********Archivo de respuesta --- DATOS DE LA NUMERACION -----------*/
   TIPO_ENVIO   CHAR(1) DEFAULT '', 	        /*C  1  0             Flag de Aduanas que sirve para diferenciar de una numeracion de Aduana/Tipo de Envio para Regim 43*/
   FLAG_ERROR   CHAR(1) DEFAULT '', 		/*C  1  0             Flag que indica que la poliza tiene Error*/
   FLAG_ADVER   CHAR(1) DEFAULT '', 		/*C  1  0             Flag que indica que la poliza tiene Advertencias*/
   FCH_RECTIF   DATE, 	                        /*D  8  0*            Fecha de Rectificaci�n de DUE, Anulaci�n de Orden de Embarque, Regularizaci�n de 10/70*/
   FCHPLAN      DATE,                           /*D  8  0** * * ******Fecha de Cancelacion de Derechos*/
   T_CAMBIO     DECIMAL(7,3) DEFAULT 0.000, 	/*N  7  3** * * ******Tipo de Cambio de la fecha de Cancelacion*/
   MONT_CANCE   DECIMAL(11,2) DEFAULT 0.00, 	/*N 11  2             Monto Cancelado por Pago Electronico/Monto de la Liquidacion de Cobranza*/
   SINDI_PAEL   CHAR(1) DEFAULT '', 		/*C  1  0*************Indicador de pago Electronico*/
   CBCO_PAEL    CHAR(3) DEFAULT '', 		/*C  3  0  *          Cogigo del Banco Autorizado para pago Electronico*/
   CCTA_PAEL    VARCHAR(20) DEFAULT '', 	/*C 20  0             Numero de cuenta para pago Electronico*/
   FLAG_CREA 	CHAR(1)  DEFAULT '',	        /*C  1  0  Flag que determina que la orden ha sido creada*/
   OBSERVAC  	VARCHAR(75)  DEFAULT '',	/*C 75  0  Observaciones en la Apertura de Ordenes*/
   ENUSO        VARCHAR(22) DEFAULT '',         /*C  1  0  flag que determina que la orden esta siendo usada*/
   ANULADA   	CHAR(1)  DEFAULT '',    	/*C  1  0  Indica si la Orden Aperturda esta Anulada*/
   TELEWEB      VARCHAR(16) DEFAULT '',         /*C 16  0  Numero y fecha para la numeracion por el Servicio WEB */ 
   NTICKETXML   CHAR(10)  DEFAULT '',    	/*C  4  0  Numero de Ticket para la Numeracion de Xml*/
   FILE_EXPED   CHAR(10) NOT NULL,    	
   FCHESTENTR   DATE ,	                        /*D  8  0** * * ******Fecha estimada de entregada*/
   FECH_ALMAC   DATE ,	                        /*D  8  0** * * ******Fecha termino de almacenaje*/
   FECH_SOBRE   DATE ,	                        /*D  8  0** * * ******Fecha termino de entregada*/
   FECH_REGUL   DATE, 	                        /*D  8  0*            Fecha de Regularizacion 10,20,21,70,89*/
   PRIMARY KEY(N_ORDEN),
   CONSTRAINT FK_APE_USU  FOREIGN KEY(COD_USER) REFERENCES USU(CODIGO),
   CONSTRAINT FK_APE_VEN  FOREIGN KEY(CODVEND1) REFERENCES VEN(CODIGO),
   CONSTRAINT FK_APE_CLI  FOREIGN KEY(COD_CLIEN) REFERENCES CLI(CODIGO),
   CONSTRAINT FK_APE_TA15 FOREIGN KEY(TIPOREG) REFERENCES softpad_tablas.TA15(COD),
   CONSTRAINT FK_APE_TA1  FOREIGN KEY(C_ADUANA) REFERENCES softpad_tablas.TA1(COD));
   CREATE INDEX APE             ON APE(N_ORDEN,TIPOREG,C_ADUANA);
   CREATE INDEX APE_F_DATE      ON APE(F_DATE);  /*PARA EL INGRESO DE ORDENES PARA LA FUNCION BUSCAA�OSAPE*/  
   CREATE INDEX APE_COD_CLIEN   ON APE(COD_CLIEN); /*PARA LA CONSULTA DE OBSEQUIOS POR CLIENTE*/  
   CREATE INDEX APE_FCHNUMER    ON APE(FCHNUMER); /*PARA LA CONSULTA DE OBSEQUIOS POR CLIENTE*/  
   CREATE INDEX APE_FCH_RECTIF  ON APE(FCH_RECTIF); /*PARA FECHA DE RECTIFICACIONS*/  
   CREATE INDEX APE_FECH_REGUL  ON APE(FECH_REGUL); /*PARA LOS VENCIMIENTOS DE ANTICIPADOS POR REGULARIZAR*/  
insert into ape(n_orden,tiporeg,c_aduana,cod_user,sectorista,f_date) values("","10","235","001","001","2011-01-01");

/* TKT(NUMERO DE TICKET DE ENVIO POR XML) */
CREATE TABLE IF NOT EXISTS TKT(
   N_ORDEN   	CHAR(11) NOT NULL,	 /*C  9  0  N� de Orden*/
   NTICKETXML   CHAR(10)  DEFAULT '',    /*C  4  0  Numero de Ticket para la Numeracion de Xml*/
   PROCESADO    CHAR(1) DEFAULT "",      /*C  1  0  Indicador si el numero de ticket procesado */
   FECHA        DATETIME,                /*D  8  0  Fecha y hora del Proceso */ 
   PRIMARY KEY(N_ORDEN,NTICKETXML),
   CONSTRAINT FK_TKT_APE FOREIGN KEY(N_ORDEN) REFERENCES APE(N_ORDEN));
   CREATE INDEX TKT ON TKT(N_ORDEN,NTICKETXML);

/* ADJ(DOCUMENTOS ADJUNTOS A LA APERTURA DE ORDENES */
CREATE TABLE IF NOT EXISTS ADJ(
   N_ORDEN   	CHAR(11) NOT NULL,	 /*C  9  0  N� de Orden*/
   CORREL       CHAR(3) NOT NULL,        /*C  3  0 //Numero de los Documentos Adjuntos*/
   F_DATE    	DATE,           	 /*D  8  0  Fecha de creaci�n de la Orden*/
   TIPO_DOC  	CHAR(2)  DEFAULT '',	 /*C  2  0  Tipo de Documento*/
   N_DOC     	VARCHAR(40)  DEFAULT '', /*C 40  0  Flag que determina el Estado de La Orden*/
   FECH_ORIG 	DATETIME,                /*D  8  0  Observacion del Status de la Orden*/
   FECH_COPIA	DATETIME,                /*D  8  0  Nombre del Proveedor Extranjero*/
   FECH_RECEP	DATE,  	                 /*D  8  0  Fecha de Recepcion*/
   OBSERVACIO	CHAR(2)  DEFAULT '',	 /*C  2  0  Codigo de Usuario del sistema*/
   PRIMARY KEY(N_ORDEN,CORREL),
   CONSTRAINT FK_ADJ_APE FOREIGN KEY(N_ORDEN) REFERENCES APE(N_ORDEN));
   CREATE INDEX ADJ ON ADJ(N_ORDEN);


/*RER(TABLA DE ERRORES DE ENVIO POR TELEDESPACHO)*/
CREATE TABLE IF NOT EXISTS RER(
   N_ORDEN   	CHAR(11) NOT NULL,	/*C  9  0*/
   FECHA     	DATETIME,	/*D  8  0*/
   CODI_ERROR	CHAR(5)  DEFAULT '',	/*C  4  0*/
   NUME_SERIE	CHAR(4)  DEFAULT '',	/*C  4  0*/
   DESC_ADVER	VARCHAR(100)  DEFAULT '',	/*C100  0*/
   TIPO_ENVIO	CHAR(1)  DEFAULT '',	/*C  1  0*/
   NOMB_ADVER	VARCHAR(40)  DEFAULT '',	/*C 40  0*/
   CODI_ADUAN	CHAR(3)  DEFAULT '',	/*C  3  0*/
   ANO_ORDEN 	CHAR(4)  DEFAULT '',	/*C  4  0*/
   NUME_ITEM 	CHAR(4)  DEFAULT '',	/*C  4  0*/
   TIPO_ERROR	CHAR(1)  DEFAULT '',	/*C  1  0 && Flag que determina si es un error o una advertencia*/
   CODI_REGI    CHAR(2)  DEFAULT '',
   DETA_ADVER   VARCHAR(1024) DEFAULT '',
   NTICKETXML   CHAR(10)  DEFAULT '',    	/*C  4  0  Numero de Ticket para la Numeracion de Xml*/
   PRIMARY KEY(N_ORDEN,FECHA,CODI_ERROR,NUME_SERIE,NUME_ITEM,DESC_ADVER),
   CONSTRAINT FK_RER_APE FOREIGN KEY(N_ORDEN) REFERENCES APE(N_ORDEN));
   CREATE INDEX RER ON RER(N_ORDEN);

/* INC (INCIDENCIAS DEL DESPACHO) */
CREATE TABLE IF NOT EXISTS INC(
   N_ORDEN   	CHAR(11) NOT NULL,	 /*C  9  0*/
   COD_USER  	CHAR(3)  DEFAULT '',	 /*C  2  0*/
   FECHA_INC 	DATETIME,       	 /*D  8  0*/
   ESTADO    	CHAR(2)  DEFAULT '',	 /*C  2  0*/
   INCIDENCIA	VARCHAR(80)  DEFAULT '', /*C 55  0*/
   MARCA     	NUMERIC(1,0)  DEFAULT 0, /*N  1  0*/
   AUTOMATICO	CHAR(1)  DEFAULT '',	 /*C  1  0*/
   FLAG_AEI  	CHAR(1)  DEFAULT '',	 /*C  1  0 FLAG PARA EL ARCHIVO DE TEXTO DE AEI*/
   SITUACION 	CHAR(1)  DEFAULT '',	 /*C  1  0 SITUACION DE INCIDENCIAS DE DANZAS AEI*/
   FECH_OCURR   DATETIME,                /*FECHA DE LA OCURRENCIA REAL DEL STATUS*/
   COD_RESPON   CHAR(2) DEFAULT '',      /*0 CODIGO DEL RESPONSABLE DE LA INCIDENCIA - DHL */
   LOGIS        VARCHAR(6) DEFAULT '',    /* CODIGO DE LOGISTICA PARA DHL */
   OBSERVAC     VARCHAR(60) DEFAULT '',   /* OBSERVACIONES PARA DHL */
   COD_INCID2   CHAR(2) DEFAULT '',       /* CODIGO DE DISCREPANCI DE INCIDENCIA DHL */   
   PRIMARY KEY(N_ORDEN,FECHA_INC,ESTADO),
   CONSTRAINT FK_INC_APE FOREIGN KEY(N_ORDEN) REFERENCES APE(N_ORDEN),
   CONSTRAINT FK_INC_USU FOREIGN KEY(COD_USER) REFERENCES USU(CODIGO),
   CONSTRAINT FK_INC_TID FOREIGN KEY(ESTADO) REFERENCES TID(COD),
   CONSTRAINT FK_INC_DSP FOREIGN KEY(COD_RESPON) REFERENCES DSP(CODIGO));
CREATE INDEX INC ON INC(N_ORDEN);

/*OCS (TABLA DE DOCUMENTOS ASOCIADOS AL DESPACHO)*/
CREATE TABLE IF NOT EXISTS OCS(
   N_ORDEN   	CHAR(11) NOT NULL,	/*C  9  0   N� de Orden de despacho*/
   CORREL       CHAR(4) NOT NULL,       /*C  3  0   CORRELACION DE DOCUMENTOS ASOCIADOS */
   NUME_SERIE	NUMERIC(4,0) DEFAULT 0,	/*N  4  0   Numero de serie*/
   NUME_SECUP	CHAR(3) DEFAULT "",	/*C  2  0   Numero de secuencia del proveedor*/
   NUME_SECUF	CHAR(3) DEFAULT "",	/*C  3  0   Numero de Secuencia de la Factura*/
   NUM_ITEM  	NUMERIC(4,0) DEFAULT 0,	/*N  4  0   Numero del Item de la Factura*/
   TIPO_PROCE	CHAR(1) DEFAULT '',	/*C  1  0   Tipo de operaci�n/proceso*/
   TIPO_DOCAS	CHAR(2) DEFAULT '',	/*C  2  0   Tipo de documento asociado*/
   ANNO_DOCAS	CHAR(4) DEFAULT '',	/*C  4  0   A�o de documento asociado*/
   NUME_DOCAS	VARCHAR(25) DEFAULT '',	/*C 15  0   Numero de documento asociado*/
   FECH_DOCAS	DATE,	/*D  8  0   Fecha documento asociado*/
   FECH_VENCI	DATE,	/*D  8  0   Fecha Vcto plazo*/
   ENTI_EMISO	VARCHAR(40) DEFAULT '',	/*C 40  0   Nombre de Entidad Emisora*/
   CODLUG    	CHAR(3) DEFAULT '',	/*C  3  0   Codigo de Aduana de la Autorizacion*/
   TPROD     	CHAR(2) DEFAULT '',	/*C  2  0   Tipo de Autorizacion*/
   AUT_RESTRI   CHAR(1) DEFAULT '',     /*C  1  0   Flag para Autorizacion de Mercancia Restringido ("X") caso contrario (" ") Blanco */
   GCUSTODIA    CHAR(1) DEFAULT '',     /*C  1  0   Guarda Custodia (1 tiene blanco no tiene )*/
   TDOC_ENTI    CHAR(2) DEFAULT "",     /* C  2  0   Tipo de Documento de la Entidad Autorizante*/
   NDOC_ENTI    VARCHAR(11) DEFAULT "", /*  Numero de documento de la Autoridad autorizante*/
   TIPO_ENTI    CHAR(1) DEFAULT "",     /*C  1  0   Tipo de Entidad Emisora*/
   NUM_ITEAUT   NUMERIC(4,0) DEFAULT 0,	/*N  4  0   Numero de Item de Autorizacion de IQBF*/
   MARCA_REG    NUMERIC(4,0) DEFAULT 0,          /* Para marcar los registros que seran borrados (nunca se graba)*/
   SUBTIPOAUT   CHAR(2) DEFAULT "",     /*C  2  0   C�digo de subtipo asociado al tipo de documento de soporte*/
   NROITEMAUT   NUMERIC(6,0) DEFAULT 0,  /* N  6  0   N�mero de �tem del documento de soporte*/
   SUBENTIDAD   CHAR(4) DEFAULT "",     /*C  4  0   C�digo de sub entidad asociada a entidad, banco u otros*/
   PRIMARY KEY(N_ORDEN,CORREL),
   CONSTRAINT FK_OCS_APE FOREIGN KEY(N_ORDEN) REFERENCES APE(N_ORDEN));
   CREATE INDEX OCS ON OCS(n_orden);

/* CONSTRAINT FK_OCS_SEA FOREIGN KEY(N_ORDEN,NUME_SERIE) REFERENCES SEA(N_ORDEN,N_SERIE),*/
/* CONSTRAINT FK_OCS_ADA FOREIGN KEY(N_ORDEN,NUME_SECUP,NUME_SECUF,NUM_ITEM) REFERENCES ADA(N_ORDEN,NUME_SECUP,NUME_SECUF,NUM_ITEM))*/


/*=========================================================================================*/
/* CAT (REGISTRO DE COPIAS AUTENTICADAS) */
CREATE TABLE IF NOT EXISTS CAT(
   N_ORDEN   	CHAR(11) NOT NULL,	 /*C  9  0*/
   FCH_COPIAS   DATETIME,                /*  D  8  0 fecha de emision de las copias*/
   COD_SOLICI   CHAR(2) DEFAULT '',      /*  0 Codigo del Solicitante de la Copia Autenticada*/
   SOLICITA     VARCHAR(40) DEFAULT '',  /*0 nombre del solicitante*/
   COD_MOTIVO   CHAR(2) DEFAULT '',      /*  0 Tipos de Motivo de las Copias Autenticadas*/
   MOTIVO       VARCHAR(35) DEFAULT '',  /*  0 motivo por el cual se solicitan las copias*/
   TIPO_DOC     CHAR(2) DEFAULT ''    ,  /* C  2  0 tipo de documento que que solicitan las copias*/
   DOCUMENTO    VARCHAR(40) DEFAULT '',  /*  0 descripcion del documento que se solicitan las copias*/
   DES1         VARCHAR(50) DEFAULT '',  /*  0 descripcion del despacho*/
   COPIAS       NUMERIC(5,0) DEFAULT 0,  /*N  5  0 numero de copias solicitadas */
   OBSERVACIO   VARCHAR(35) DEFAULT '',  /*  0 observaciones referentes a las copias autenticadas*/
   PRIMARY KEY(N_ORDEN,COD_SOLICI,FCH_COPIAS),
   CONSTRAINT FK_CAT_APE FOREIGN KEY(N_ORDEN) REFERENCES APE(N_ORDEN));
   CREATE INDEX CAT ON CAT(N_ORDEN);

/* MDT (JALAR DATOS DEL MANIFIESTO         ) */
CREATE TABLE IF NOT EXISTS MDT(
   N_ORDEN      CHAR(11) NOT NULL,           /*C  9  N� de Orden de despacho --- DATOS PRINCIPALES*/
   NUMBLGUIA    VARCHAR(25) DEFAULT '',      /* C 25  0N� de BL/Guia*/
   NUMDET       CHAR(5) DEFAULT '',          /* C  3  0Numero de detalle en caso de mas de un Bl/Guia*/
   CODI_TERM    CHAR(6) DEFAULT '',          /*C  6  CODIGO DE TERMINAL O DEPOSITO AUTORIZADO*/
   COD_TRANSP   CHAR(4) DEFAULT '',          /*C  4  CODIGO DE LA EMPRESA DE TRANSPORTE*/
   PUER_EMBAR   CHAR(6) DEFAULT '',          /* C  6  PUERTO DE EMBARQUE*/
   CANT_BRECI   DECIMAL(14,3) DEFAULT 0.000, /*N 14 3CANTIDAD DE BULTOS*/
   TPESO_RECI   DECIMAL(14,3) DEFAULT 0.000, /*N 14 3PESO BRUTO*/
   PRIMARY KEY(N_ORDEN),
   CONSTRAINT UQ_MDT_1 UNIQUE(N_ORDEN,NUMBLGUIA),
   CONSTRAINT FK_MDT_APE FOREIGN KEY(N_ORDEN) REFERENCES APE(N_ORDEN));
   CREATE INDEX MDT ON MDT(N_ORDEN);

/* DHL (ARCHIVO DE OCURRENCIAS PARA DHL ) */
CREATE TABLE IF NOT EXISTS DHL(
   N_ORDEN      CHAR(11) NOT NULL,           /*C  9  N� de Orden de despacho --- DATOS PRINCIPALES*/
   INCIDENCIA   CHAR(2) NOT NULL,
   F_DATE       DATE,
   FECHA_OCU    DATE,
   REFEREN1     VARCHAR(30) DEFAULT '',      /* C 25  0N� de Referencia Adicional para Hansa*/
   REFEREN2     VARCHAR(30) DEFAULT '',      /* C 25  0N� de Referencia Adicional para Hansa*/
   REFEREN3     VARCHAR(30) DEFAULT '',      /* C 25  0N� de Referencia Adicional para Hansa*/
   REFEREN4     VARCHAR(30) DEFAULT '',      /* C 25  0N� de Referencia Adicional para Hansa*/
   REFEREN5     VARCHAR(30) DEFAULT '',      /* C 25  0N� de Referencia Adicional para Hansa*/
   REFEREN6     VARCHAR(30) DEFAULT '',      /* C 25  0N� de Referencia Adicional para Hansa*/
   REFEREN7     VARCHAR(30) DEFAULT '',      /* C 25  0N� de Referencia Adicional para Hansa*/
   REFEREN8     VARCHAR(30) DEFAULT '',      /* C 25  0N� de Referencia Adicional para Hansa*/
   REFEREN9     VARCHAR(30) DEFAULT '',      /* C 25  0N� de Referencia Adicional para Hansa*/
   REFEREN10    VARCHAR(30) DEFAULT '',      /* C 25  0N� de Referencia Adicional para Hansa*/
   REFEREN11    VARCHAR(30) DEFAULT '',      /* C 25  0N� de Referencia Adicional para Hansa*/
   REFEREN12    VARCHAR(30) DEFAULT '',      /* C 25  0N� de Referencia Adicional para Hansa*/
   REFEREN13    VARCHAR(30) DEFAULT '',      /* C 25  0N� de Referencia Adicional para Hansa*/
   REFEREN14    VARCHAR(30) DEFAULT '',      /* C 25  0N� de Referencia Adicional para Hansa*/
   REFEREN15    VARCHAR(30) DEFAULT '',      /* C 25  0N� de Referencia Adicional para Hansa*/
   REFEREN16    VARCHAR(30) DEFAULT '',      /* C 25  0N� de Referencia Adicional para Hansa*/
   REFEREN17    VARCHAR(30) DEFAULT '',      /* C 25  0N� de Referencia Adicional para Hansa*/
   REFEREN18    VARCHAR(30) DEFAULT '',      /* C 25  0N� de Referencia Adicional para Hansa*/
   REFEREN19    VARCHAR(30) DEFAULT '',      /* C 25  0N� de Referencia Adicional para Hansa*/
   REFEREN20    VARCHAR(30) DEFAULT '',      /* C 25  0N� de Referencia Adicional para Hansa*/
   UNID_NEGO    CHAR(2) DEFAULT '',
   PRIMARY KEY(N_ORDEN,INCIDENCIA),
   CONSTRAINT FK_DHL_APE FOREIGN KEY(N_ORDEN) REFERENCES APE(N_ORDEN),
   CONSTRAINT FK_DHL_TID FOREIGN KEY(INCIDENCIA) REFERENCES TID(COD));
   CREATE INDEX DHL ON DHL(N_ORDEN);

/*=========================================================================================*/
/*=============                    PROFORMAS DE DESPACHOS                ==================*/
/*=========================================================================================*/
	
/* PRO(PROFORMAS DE DESPACHOS)*/
CREATE TABLE IF NOT EXISTS PRO(
   N_PROF    	CHAR(8) NOT NULL,                     /*Numero de Proforma*/
   FCHPROF   	DATETIME,                             /*Fecha de la Proforma*/
   TIPO_PROF    CHAR(1) DEFAULT "O",                  /*Flag que determina SI LA PROFORMA ES POR ORDEN,REFERENCIA O SIN SERIES)*/
   COD_CLIEN	CHAR(5) DEFAULT "",                   /*Codigo del Cliente*/
   N_ORDEN	CHAR(11) DEFAULT "",                  /*No de Orden Asociada a la Proforma*/
   C_ADUANA	CHAR(3) DEFAULt "",                   /*Codigo de Aduana*/
   TIPOREG 	CHAR(2) DEFAULT "",	              /*Tipo de R�gimen o Destinaci�n*/
   REF_CLIE	VARCHAR(25) DEFAULT "",               /*Referencia de cliente*/
   C_BULTO	VARCHAR(20) DEFAULT "",               /*Clase de Bulto*/
   NAVE	        VARCHAR(50) DEFAULT "",               /*Nave de Llegada*/
   CONT1	VARCHAR(75) DEFAULT "",               /*Descripci�n Gen�rica de la Mercader�a*/
   COD_P_ADQ    CHAR(3) DEFAULT "",                   /*codigo del pais de Adquisicion */
   FCHLLE	DATE,                                 /*Fecha de Llegada*/
   PRORRATEO	CHAR(1) DEFAULT "2",	              /*Tipo de prorrateo*/
   NUMPARTIDA	NUMERIC(5,0) DEFAULT 1,               /*Numero de series ingresadas por Normal*/
   FCH_PRELIQ	DATE,                                 /*Fecha de presentaci�n de la poliza a la Aduana*/
   FACTOR	DECIMAL(13,10) DEFAULT 1.0000000000,  /*Factor de conversi�n del Fob*/
   FOB      	DECIMAL(13,3) DEFAULT 0.000,          /*Fob en transacci�n/Valor de Clausula de Venta*/
   FOB_DOL	DECIMAL(13,3) DEFAULT 0.000,          /*Fob en d�lares*/
   CODFOB	CHAR(3) DEFAULT "USD",                /*C�digo de Fob*/
   FLETE	DECIMAL(13,3) DEFAULT 0.000,          /*Flete en transacci�n/Comisi�n al Exterior   */
   FLETE_DOL	DECIMAL(13,3) DEFAULT 0.000,          /*Flete en d�lares*/
   CODFLETE	CHAR(3) DEFAULt "USD",                 /*C�digo de Flete*/
   FACTOR_FLE	DECIMAL(13,10) DEFAULT 0.0000000000,  /*Factor de conversion del Flete*/
   SEGURO	DECIMAL(13,3) DEFAULT 0.000,          /*Seguro en transacci�n/Otros gastos Deducibles*/
   SEGURO_DOL	DECIMAL(13,3) DEFAULT 0.000,          /*Seguro en d�lares*/
   CODSEGURO	CHAR(3) DEFAULt "USD",                 /*C�digo de Seguro*/
   FACTOR_SEG	DECIMAL(13,10) DEFAULT 0.0000000000,  /*Factor de conversion del Seguro*/
   TIPO_SEG	CHAR(1) DEFAULt "",                   /*Tipo de Seguro*/
   CIFDOL	DECIMAL(13,3) DEFAULT 0.000,          /*Cif en d�lares/Valor Neto de entrega*/
   T_BULTOS	DECIMAL(14,3) DEFAULT 0.000,          /*Total Bultos*/
   TOTUFIS	DECIMAL(18,3) DEFAULT 0.000,          /*Total Unidades Fisicas*/
   KNE	 	DECIMAL(14,3) DEFAULT 0.000,          /*Kilos Netos*/
   KBR	 	DECIMAL(14,3) DEFAULT 0.000,          /*Kilos Brutos*/
   TOT_ADV      DECIMAL(10,3) DEFAULT 0.000,  	 /*N 10  3******   *** Tasa de advalorem acumulada del despacho/Alto en Nota de Embarque*/
   TOT_ISC      DECIMAL(10,3) DEFAULT 0.000, 	 /*N 10  3******       Tasa de ISC acumulada del despacho/Largo en Nota de Embarque*/
   TOT_IGV      DECIMAL(10,3) DEFAULT 0.000, 	 /*N 10  3******   *** Tasa de IGV acumulada del despacho/Ancho en Nota de Embarque*/
   TOT_IPM      DECIMAL(10,3) DEFAULT 0.000, 	 /*N 10  3******   *** Tasa de IPM acumulada del despacho/Cubicaje en Nota de Embarque*/
   INCLUYE	CHAR(1) DEFAULt "S",                  /*Flag para indicar si se suma o no los Derechos a la Factura*/
   MONEDA	CHAR(1) DEFAULt "D",                  /*Moneda de la proforma ("S"oles o "D"olares )*/
   T_CAMBIO	DECIMAL(7,3) DEFAULT 0.000,           /*Tipo de Cambio de la Proforma*/
   TDGAS 	DECIMAL(12,2) DEFAULT 0.00,           /*Sumatoria total de los Gastos de la Proforma (Dolares)*/
   DCOMISION	DECIMAL(12,2) DEFAULT 0.00,           /*Comision proformada en Dolares*/
   DBASE	DECIMAL(12,2) DEFAULT 0.00,           /*Base imponible para el calculo del IGV en Dolares*/
   DIGV	        DECIMAL(12,2) DEFAULT 0.00,           /*Igv de la proforma en Dolares*/
   DTOT_PROF	DECIMAL(12,2) DEFAULT 0.00,           /*Monto Total y final de la proforma (Dolares)*/
   TSGAS	DECIMAL(12,2) DEFAULT 0.00,           /*Sumatoria total de los Gastos de la Proforma (Soles)*/
   SCOMISION	DECIMAL(12,2) DEFAULT 0.00,           /*Proformada en Soles*/
   SBASE 	DECIMAL(12,2) DEFAULT 0.00,           /*Base imponible para el calculo del IGV en Soles*/
   SIGV 	DECIMAL(12,2) DEFAULT 0.00,           /*Igv de la proforma en Soles*/
   STOT_PROF	DECIMAL(12,2) DEFAULT 0.00,           /*Monto Total y final de la proforma (Soles)*/
   OBSVE1	VARCHAR(60) DEFAULT "",               /*Observaciones de la Proforma*/
   OBSVE2	VARCHAR(60) DEFAULT "",               /*Observaciones de la Proforma*/
   OBSVE3	VARCHAR(60) DEFAULT "",               /*Observaciones de la Proforma*/
   OBSVE4	VARCHAR(60) DEFAULT "",               /*Observaciones de la Proforma*/
   OBSVE5	VARCHAR(60) DEFAULT "",               /*Observaciones de la Proforma*/
   OBSVE6	VARCHAR(60) DEFAULT "",               /*Observaciones de la Proforma*/
   OBSVE7	VARCHAR(60) DEFAULT "",               /*Observaciones de la Proforma*/
   OBSVE8	VARCHAR(60) DEFAULT "",               /*Observaciones de la Proforma*/
   OBSVE9	VARCHAR(60) DEFAULT "",               /*Observaciones de la Proforma*/
   OBSVE10	VARCHAR(60) DEFAULT "",               /*Observaciones de la Proforma*/
   OBSVE11	VARCHAR(60) DEFAULT "",               /*Observaciones de la Proforma*/
   OBSVE12	VARCHAR(60) DEFAULT "",               /*Observaciones de la Proforma*/
   OBSVE13	VARCHAR(60) DEFAULT "",               /*Observaciones de la Proforma*/
   OBSVE14	VARCHAR(60) DEFAULT "",               /*Observaciones de la Proforma*/
   OBSVE15	VARCHAR(60) DEFAULT "",               /*Observaciones de la Proforma*/
   OBSVE16	VARCHAR(60) DEFAULT "",               /*Observaciones de la Proforma*/
   FECH_EMIS	DATE,                                 /*Fecha de Emisi�n del Documento*/
   COD_USER	CHAR(3) DEFAULT "",                   /*Codigo de Usuario o Liquidador*/
   PUNT_CAMB	DECIMAL(4,2) DEFAULT 0.00,            /*Puntos a reducir en el tipo de Cambio para el Calculo de Diferencia de Cambio (ADUANALES)*/
   FECHTERREG	DATE,                                 /*fecha de vencimiento de Fianza para el calculo de TIC para el 21,20*/
   CANT_CONTE	NUMERIC(4,0) DEFAULT 0.00,            /*Cantidad de Contenedores (Solo para J&N)*/
   TIC          DECIMAL(13,3) DEFAULT 0.00,           /*Tasa de Interes compensatorio */  
   NUMGUIA      VARCHAR(25) DEFAULT "",               /*Numero de B/L Guia Aerea */  
   CLIENTE      VARCHAR(30) DEFAULT "",               /*Nombre del Cliente solo cuando es proforma sin codigo de cliente */
   RUC          VARCHAR(11) DEFAULT "",               /*Ruc del Cliente solo cuando es proforma sin codigo de cliente */
   REFEREN      VARCHAR(50) DEFAULT "",               /*Direccion del cliente solo cuando es proforma sin codigo de cliente */
   PERCEPCION   VARCHAR(1) DEFAULT "",                /*Percepcion de IGV solo cuando es proforma sin codigo de cliente */
   REPRES       VARCHAR(30) DEFAULT "",               /*Nombre del Representante solo cuando es proforma sin codigo de cliente */
   CODMODALI    CHAR(2) DEFAULT "",                   /*Codigo de Modalidad solo para la 18*/
   PRIMARY KEY(N_PROF),
   CONSTRAINT FK_PRO_APE FOREIGN KEY(N_ORDEN) REFERENCES APE(N_ORDEN),
   CONSTRAINT FK_PRO_USU FOREIGN KEY(COD_USER) REFERENCES USU(CODIGO),
   CONSTRAINT FK_PRO_CLI FOREIGN KEY(COD_CLIEN) REFERENCES CLI(CODIGO),
   CONSTRAINT FK_PRO_TA15 FOREIGN KEY(TIPOREG) REFERENCES softpad_tablas.TA15(COD),
   CONSTRAINT FK_PRO_TA1  FOREIGN KEY(C_ADUANA) REFERENCES softpad_tablas.TA1(COD));
CREATE INDEX PRO ON PRO(N_PROF);
CREATE INDEX PRF ON PRO(FCHPROF,N_PROF);
CREATE INDEX PRC ON PRO(COD_CLIEN,N_PROF);
CREATE INDEX PRN ON PRO(N_ORDEN,N_PROF);
insert into pro(n_prof,tiporeg,c_aduana,cod_clien,cod_user,fchprof) values("","10","235","","001","2011-01-01");


/*(DRP) DERECHOS DE LA PROFORMA  */
CREATE TABLE IF NOT EXISTS DRP(
   N_PROF     CHAR(8) NOT NULL,	                   /*Numero de la Proforma */
   TIPO_DERE  CHAR(1) NOT NULL,                    /*Tipo de Derechos [P]rovisionales,[D]efinitivos,[A]proximados*/
   CODIGO     CHAR(2) NOT NULL ,                   /*codigo del tipo de Derecho segun codificacion Interna */
   DERE_LIQUI DECIMAL(12,2) DEFAULT 0.00,          /*Importe del los derechos [L]iquidados */
   DERE_PAGAR DECIMAL(12,2) DEFAULT 0.00,          /*Importe del los derechos de a [P]agar */
   PRIMARY KEY(N_PROF,TIPO_DERE,CODIGO),
   CONSTRAINT FK_DRP_PRO FOREIGN KEY(N_PROF) REFERENCES PRO(N_PROF), 
   CONSTRAINT FK_DRP_TS35 FOREIGN KEY(CODIGO) REFERENCES softpad_sistema.TS35(CODIGO));
create index DRP on DRP(N_PROF,TIPO_DERE,CODIGO);

/*(PDE) GASTOS DE LA PROFORMA */
CREATE TABLE IF NOT EXISTS PDE(
   N_PROF     CHAR(8) NOT NULL,	           /*Numero de la Proforma */
   CODGASTO   CHAR(3) DEFAULT "",          /*CODIGO DEL GASTO QUE SE DETALLA*/
   CONCEPTO   VARCHAR(40) DEFAULT "",      /*DESCRIPCION O CONCEPTO DEL GASTO*/
   SGASTO     DECIMAL(12,2) DEFAULT 0.00,  /*IMPORTE EN SOLES DEL GASTO*/
   DGASTO     DECIMAL(12,2) DEFAULT 0.00,  /*IMPORTE EN DOLARES DEL GASTO*/
   AFECTO     CHAR(1) DEFAULT "",          /*FLAG QUE IDENTIFICA SI ESTE IMPORTE ESTA AFECTO A IGV O NO/Tipo de Proforma en Documentos a Financiar (05)*/
   T_CAMBIO   DECIMAL(7,3) DEFAULT 0.000,  /*TIPO DE CAMBIO DEL DOCUMENTO*/
   MON        CHAR(1) DEFAULT "",          /*TIPO DE MONEDA DEL GASTO*/
   OBSERVAC   VARCHAR(40) DEFAULT "",      /*OBERVACIONES AL CONCEPTO DE LA PROFORMA*/
   COD_PROV   CHAR(11) DEFAULT "",         /*Codigo del Proveedor*/
   PRIMARY KEY(N_PROF,CODGASTO),
   CONSTRAINT FK_PDE_PRO FOREIGN KEY(N_PROF) REFERENCES PRO(N_PROF), 
   CONSTRAINT FK_PDE_TGF FOREIGN KEY(CODGASTO) REFERENCES TGF(CODIGO));
create index PDE on PDE(N_PROF,CODGASTO);

/*(PSE) SERIES DE LA PROFORMA */
CREATE TABLE IF NOT EXISTS PSE(
   N_PROF     CHAR(8) NOT NULL,	                   /*Numero de la Proforma */
   N_SERIE    NUMERIC(4,0) NOT NULL,       	   /*N� Serie	*/
   PARTIDA    CHAR(10) DEFAULT '',     	           /*Partida Nandina	*/
   COD_P_PRO  CHAR(3) DEFAULT '',     	           /*Pais de origen	*/
   COD_LIB    CHAR(4) DEFAULT '',     	           /*TPI, TPN o Cod.Lib*/	
   MPO	      DECIMAL(9,3) DEFAULT 0.000,          /*Margen porcentual de liberacion de advalorem	*/
   PAN	      CHAR(10) DEFAULT '',        	   /*P.Naladisa � P.Nabandina*/	
   FOBSER     DECIMAL(13,3) DEFAULT 0.000,         /*Fob    en transacci�n	*/
   FOBSDOL    DECIMAL(13,3) DEFAULT 0.000,         /*Fob    en d�lares	*/
   FLESER     DECIMAL(13,3) DEFAULT 0.000,         /*Flete  en transacci�n	*/
   FLESDOL    DECIMAL(13,3) DEFAULT 0.000,         /*Flete  en d�lares	*/
   SEGSER     DECIMAL(13,3) DEFAULT 0.000,         /*Seguro en transacci�n	*/
   SEGSDOL    DECIMAL(13,3) DEFAULT 0.000,         /*Seguro en d�lares	*/
   TIPO_SEG   CHAR(1) DEFAULT '',         	   /*Tipo de Seguro de la Serie			*/
   TNAN	      CHAR(2) DEFAULT '',         	   /*Codigo de Tnan de la Serie		*/
   CIFSER     DECIMAL(13,3) DEFAULT 0.000,         /*Cif en transacci�n	*/
   CIFSDOL    DECIMAL(13,3) DEFAULT 0.000,         /*Cif en d�lares	*/
   KNSER      DECIMAL(14,3) DEFAULT 0.000,         /*Kilo Neto	*/
   KBSER      DECIMAL(13,3) DEFAULT 0.000,         /*Kilo Bruto	*/
   UFISICAS   DECIMAL(13,3) DEFAULT 0.000,         /*unidades fisicas*/	
   TIPOUFIS   VARCHAR(12) DEFAULT '',     	   /*tipo de unidad fisica*/	
   FCH_EMB    DATE,                                /*Fecha de embarque	*/
   ADVALSER   DECIMAL(7,3) DEFAULT 0.000,          /*Tasa de Advalorem	*/
   ADVDOL     DECIMAL(12,2) DEFAULT 0.00,          /*Advalorem a pagar	*/
   LADVDOL    DECIMAL(12,2) DEFAULT 0.00,          /*Advalores liquidado	*/
   SOBRETSER  DECIMAL(7,3) DEFAULT 0.000,          /*Tasa de sobretasa	*/
   SB10DOL    DECIMAL(13,2) DEFAULT 0.00,          /*Sobretasa a pagar	*/
   LSB10DOL   DECIMAL(13,2) DEFAULT 0.00,          /*Sobretasa liquidada	*/
   D_ESP      DECIMAL(10,2) DEFAULT 0.00,          /*Monto de derecho especifico de tabla*/	
   DS16DOL    DECIMAL(13,2) DEFAULT 0.00,          /*Derecho espefico a pagar	*/
   LDS16DOL   DECIMAL(13,2) DEFAULT 0.00,          /*Derecho espefico liquidado	*/
   ISCSER     DECIMAL(7,3) DEFAULT 0.000,          /*Tasa de I.S.C.	*/
   VAISCSER   DECIMAL(7,3) DEFAULT 0.000,          /*Tasa Variante de I.S.C. para algunas partidas, remplaza a la del arancel	*/
   PRESOLISC  DECIMAL(12,2) DEFAULT 0.00,          /*Precio en soles por galon para calculo de I.S.C. para partidas de gasolina	*/
   ISCDOL     DECIMAL(12,2) DEFAULT 0.00,          /*I.S.C. a pagar	*/
   LISCDOL    DECIMAL(12,2) DEFAULT 0.00,          /*I.S.C. liquidado*/	
   IGVSER     DECIMAL(7,3) DEFAULT 0.000,          /*Tasa de IGV	*/
   VAIGVSER   DECIMAL(7,3) DEFAULT 0.000,          /*Tasa variante de I.G.V. para algunas partidas remplaza a la del Arancel para Libros etc.	*/
   IGVDOL     DECIMAL(12,2) DEFAULT 0.00,          /*I.G.V. a pagar	*/
   LIGVDOL    DECIMAL(12,2) DEFAULT 0.00,          /*I.G.V. liquidado*/	
   IPMSER     DECIMAL(7,3) DEFAULT 0.000,          /*Tasa de IPM	*/
   VAIPMSER   DECIMAL(7,3) DEFAULT 0.000,          /*Tasa variante de I.P.M. remplaza a la del Arancel para Libros etc.	*/
   IPMDOL     DECIMAL(12,2) DEFAULT 0.00,          /*I.P.M. a pagar	*/
   LIPMDOL    DECIMAL(12,2) DEFAULT 0.00,          /*I.P.M. liquidado*/	
   ANTIDOL    DECIMAL(12,2) DEFAULT 0.00,          /*Monto de antidumping en dolares	*/
   PIGVDOL    DECIMAL(12,2) DEFAULT 0.00,          /*Importe de la percepcion en Dolares	*/
   FECHINIREG DATE,                                /*Fecha de inicio de precedende para (18,48)	*/
   CPROD      CHAR(2) DEFAULT '',     	           /*Codigo de antidumping por producto	*/
   CEXPODUMP  CHAR(4) DEFAULT '',     	           /*Codigo de Antidumping para empresa exportadora	*/
   TIPO_MARGE CHAR(1) DEFAULT '',     	           /*Tipo de margen	*/
   AADV_DOL   DECIMAL(12,2) DEFAULT 0.00,          /*Advalorem sin rebaja por Derecho Expecifico	*/
   ASB10DOL   DECIMAL(13,2) DEFAULT 0.00,          /*Sobretasa sin rebaja por Derecho Expecifico	*/
   QUNIISC    DECIMAL(15,3) DEFAULT 0.000,         /*Cantidad de unidades de I.S.C.	*/
   TUNIISC    CHAR(3) DEFAULT '',     	           /*Tipo de unidades de I.S.C.	*/
   REGI_PROCE CHAR(2) DEFAULT '',     	           /*Regimen Precedente	*/
   ESTADO     CHAR(2) DEFAULT '',     	           /*Estado de la Mercancia	*/
   FOB_PNETO  DECIMAL(14,3) DEFAULT 0.000,         /*Fob por peso Neto exigido para Tejidos/Peso Vehicular para usados/Precio venta de Cigarrillos y Cervezas	*/
   OBSERVAC   VARCHAR(40) DEFAULT "",              /*Observaciones para productos restringidos	*/
   D6         CHAR(1) DEFAULT '',     	           /*Indicador de percepcion para los discos opticos	*/
   MERCANCIA  VARCHAR(35) DEFAULT "",              /*Nombre de la Mercancia como ayuda de productos	*/
   FOB_FACT   DECIMAL(17,6) DEFAULT 0.00,          /*Fob Fact.para Antidump.("10") en dolares*/  
   PRIMARY KEY(N_PROF,N_SERIE),
   CONSTRAINT FK_PSE_PRO FOREIGN KEY(N_PROF) REFERENCES PRO(N_PROF));
create index PSE on PSE(N_PROF,N_SERIE);

/********************************************************************************************/
/*****************                  FORMATO A                                ****************/
/********************************************************************************************/

/*DGA (DATOS GENEREALES DEL DESPACHO)                           */
CREATE TABLE IF NOT EXISTS DGA(
   N_ORDEN    CHAR(11) NOT NULL,	         /**************       N� de Orden --- PRINCIPAL---*/
   TIPO_DESPA CHAR(3)DEFAULT '',	      	 /**** ********        Tipo de despacho (Normal,anticipado,urgencia etc.)*/
   CODMODALI  CHAR(2)DEFAULT '',  	      	 /** ***  *****        C�digo de modalidad/Tipo de Transacion para Regimen 43*/
   NOMTRANSP  VARCHAR(40) DEFAULT '',         	 /*************        Nombre de Empresa de Transporte*/
   EMPTRANSP  CHAR(4) DEFAULT '',  	      	 /*************        C�digo de Empresa de Transporte*/
   NUMMANIF   CHAR(14) DEFAULT '',  	      	 /*************        Numero de manifiesto*/
   V_TRANSP   CHAR(1) DEFAULT '',  	      	 /*************	       V�a de Tranporte*/
   C_ADUAN_S  CHAR(3) DEFAULT '',             	 /******       	       Aduana de Salida (80,81,89) / Numero de detalle para Reg (16)/ Nacionalidad para (18,48)/Tipo de Contenedor para Regimen 43 operador 7*/
   NOMTR_S    VARCHAR(40) DEFAULT '',         	 /*    *       	       Nombre de Empresa de Transporte de Salida (80,81,89) / Nombre del consignatario de la Nota de Embar*/
   VIA_TRADES CHAR(1) DEFAULT '',	      	 /*   ******   	       Via de transporte de destino/Flag para prorratear Vta.Sucesiva en Importaci�n/Flag que indica que una Autoliquidacion ya fue transferida a la Orden (96)*/
   COD_P_ADQ  CHAR(3) DEFAULT '',             	 /*                    Pa�s de Adquisici�n*/
   NOMBRE_D   VARCHAR(50) DEFAULT '',	      	 /*************        Nombre de Almac�n*/
   CODDEPO    CHAR(6) DEFAULT '',  	      	 /*0*************      C�digo de Almac�n*/
   DESOEMPT   VARCHAR(50) DEFAULT '',  	      	 /*0*  *     * **      Nombre de Dep�sito Autorizado/Empresa de transporte de Salida (81,82)*/
   C_DEPOSP   CHAR(4) DEFAULT '',             	 /*0*  *     *         Dep�sito Autorizado/ Empresa de transporte de Salida (81,82)/Agencia de Aduanas para Duim (14 operador 7)*/
   PLAZO_NUM  NUMERIC(3,0) DEFAULT 0,          	 /*N  3  0   *    ***  Plazo solicitado para el deposito / Numero de Parcial para Agencias Unidas*/
   PLAZO_TIPO CHAR(1) DEFAULT '',	      	 /*C  1  0*  *    ***  Tipo de plazo solicitado (Meses � dias) */
   CODBANCO   CHAR(3) DEFAULT '',  	      	 /*0* *  ***  *        C�digo de la Entidad Financiera*/
   DESC_BANCO VARCHAR(55) DEFAULT '',         	 /*0* *  ***  *        Descripci�n de la Entidad finaciera/ Descripcion del Material de Guerra*/
   PAGO_EXT   CHAR(1) DEFAULT '', 	      	 /*0******   ***       Forma de pago al exterior*/
   CONT1      VARCHAR(75)  DEFAULT '',	/*C 75  0  Descripci�n Gen�rica de la Mercader�a*/
   NAVE       VARCHAR(50)  DEFAULT '',	/*C 50  0  Nave de Llegada de la Mercaderia*/
   FOB        DECIMAL(13,3) DEFAULT 0.000,	/*N 13  3  Fob en transacci�n/Valor de Clausula de Venta*/
   CODFOB     CHAR(3)  DEFAULT 'USD',      	/*C  3  0  C�digo de Fob*/
   FOB_DOL    DECIMAL(13,3) DEFAULT 0.000,    	 /*************        Fob en d�lares*/
   FACTOR     DECIMAL(15,10) DEFAULT 1.000000000,/*N 13 10*************Factor de conversi�n del Fob*/
   FOB_GTOS   DECIMAL(13,3) DEFAULT 0.000,	 /*    *     *         Fob gastos en transacci�n*/
   FOBGTOS_D  DECIMAL(13,3) DEFAULT 0.000,	 /*    *     *         Fob Gastos en d�lares*/
   COD_GASTO  CHAR(3) DEFAULT 'USD', 		 /*C  3  0*************C�digo de Fob Gastos*/
   FACTOR_GTO DECIMAL(15,10) DEFAULT 1.000000000,/*N 13 10*************Factor de conversion del Fob Gastos*/
   AJUSTE     DECIMAL(13,3) DEFAULT 0.000, 	 /*N 13  3*     *      Monto total del ajuste en dolares*/
   PRORR_AJUS CHAR(1) DEFAULT 'N', 		 /*C  1  0*************Flag que determina si prorratea el Ajuste en el A Antes (T_CARGA)*/
   VTA_SUCESI DECIMAL(13,3) DEFAULT 0.000,	 /*N 13  3*            Monto de la Venta Sucesiva en dolares*/
   FLETE      DECIMAL(13,3) DEFAULT 0.000,	/*N 13  3  Flete en Transacci�n/Comisi�n al Exterior*/
   CODFLETE   CHAR(3)  DEFAULT 'USD',	        /*C  3  0  C�digo de Flete*/
   FLETE_DOL  DECIMAL(13,3) DEFAULT 0.000,	 /*N 13  3****** * *** Flete en d�lares*/
   FACTOR_FLE DECIMAL(15,10) DEFAULT 1.000000000,/*N 13 10*************Factor de conversion del Flete*/
   PRORR_FLE  CHAR(1) DEFAULT '',                /*C  1  0*************FLAG de prorrateo del flete*/
   SEGURO     DECIMAL(13,3) DEFAULT 0.000,	/*N 13  3  Seguro en Transacci�n/Otros gastos Deducibles*/
   CODSEGURO  CHAR(3)  DEFAULT 'USD',    	/*C  3  0  C�digo de Seguro*/
   TIPO_SEG   CHAR(1)  DEFAULT '',    	/*C  1  0  Tipo de seguro*/
   SEGURO_DOL DECIMAL(13,3) DEFAULT 0.000,	 /******** ***         Seguro en d�lares*/
   FACTOR_SEG DECIMAL(15,10) DEFAULT 1.000000000,/*N 13 10*************Factor de conversion del Seguro*/
   PRORR_SEG  CHAR(1) DEFAULT 'S',		 /*C  1  0*************FLAG de prorrateo del Seguro.*/
   CIFDOL     DECIMAL(13,3) DEFAULT 0.000,	 /*N 13  3*************Cif en d�lares/Valor Neto de entrega*/
   T_BULTOS   DECIMAL(15,3) DEFAULT 0.000,	 /*N 14  3*************Total Bultos / Cant.Bultos 43*/
   TOTUFIS    DECIMAL(15,3) DEFAULT 0.000,	 /*N 18  3*************Total Unidades Fisicas*/
   TOTUCOM    DECIMAL(15,3) DEFAULT 0.000,	 /*N 18  3*************Total Unidades Comerciales*/
   KNE        DECIMAL(14,3) DEFAULT 0.000,	 /*N 14  3*************Kilos Netos*/
   KBR        DECIMAL(14,3) DEFAULT 0.000,	 /*************        Kilos Brutos /Peso Bruto para 43*/
   RECEP_STRI CHAR(17) DEFAULT '',		 /*C 17  0***********  Documentos adjuntos (10,20,21,40,41,50,70,80,89)*/
   DCLANUL    CHAR(1) DEFAULT '', 		 /*C  1  0      **     Rectificaci�n de exportaci�n y Regularizaci�n de Anticipado*/
   TIPO_TRATO CHAR(1) DEFAULT '', 		 /*C  1  0******  **** Tipo de Trato (todos excepto 18,30,40,41,48,60)*/
   CENDOIMP   CHAR(2) DEFAULT '', 		 /*C  2  0*************C�digo de endose de importador y Regimen Asociado a Autoliquidacion*/
   T_DOCORI   CHAR(1) DEFAULT '',		 /*C  1  0***     *    tipo de documento del comprador inicial/tipo de Documento del Importador(33)/Pregunta si tiene Anexo 1 (40)*/
   N_DOCORI   CHAR(11) DEFAULT '', 	         /*C 11   0***         Numero del documento del comprador inicial/Numero de Documento del Importador(33)*/
   D_DOCORI   VARCHAR(60) DEFAULT '', 	         /*C 40  0***     **   Razon social del comprador inicial  / Descripcion de Nota de Embarque (40,41) y Volante de Despacho/Descripcion del Material de Guerra*/
   PLAZ_CREDI NUMERIC(4,0) DEFAULT 0,            /*N  4  0** * * * *   Plazo de credito para Reg 70/A�o de la Autoliquidaci�n*/
   FCHREC     DATE, 	                         /*D  8  0             Fecha de Carta de Cr�dito\Fecha de la Nota de Embarque\Fecha de Presentacion de la Autoliquidaci�n 96*/
   FCHLLE     DATE,	                         /*D  8  0             Fecha Estimada de Llegada*/
   TSOLAFO    CHAR(1) DEFAULT '0',		 /*C  1  0*************Solicitud de Reconoc.Fisico (10,18,40,48)/Tipo de Declaracion de Anexo 2 (96)*/
   CODPTD     CHAR(6) DEFAULT '',		 /*C  6  0   *  *******C�digo de Puerto de Desembarque (40,41,48,50) y de Embarque para los demas regimenes*/
   OTROPUERTO VARCHAR(30) DEFAULT '',	         /*C 30  0   *  *******Nombre de Pto. Desembarque (40,41,48,50) y de Desembarque para los demas regimenes*/
   NRO_DESPUR CHAR(14) DEFAULT '',		 /*C 14  0             A�o y Nro de Despacho Urgente regimen (18)/ NRO.ACTA DE TRASLADO REGIMEN(16)/ Codigo debe decir para (01)Rectificacion de Manifiestos*/
   COD_P_DES  CHAR(3) DEFAULT '',		 /*C  3  0*  *       **Codigo de pais de Origen para regimen Simplificado (18,48) / Clase de bulto para Regimenes 81,82*/
   CFERIA     CHAR(4) DEFAULT '', 		 /*0 *                 C�digo de feria*/
   CODFORM    CHAR(2) DEFAULT '', 		 /*C  2  0******** *** Tipo de Accionista (Solicitud Electronica)/ Cod. Forma Pago (40,41,50)*/
   FORMPAG    CHAR(25) DEFAULT '', 	         /*C 25  0  *   **  *  Descripci�n de forma pago (40,41,50)*/
   TIPO_PQT   CHAR(1) DEFAULT '', 		 /*C  1  0    **       Tipo empaque exterior de los bultos/Moneda de la Percepcion del CDA (10)*/
   CDURGE     CHAR(2) DEFAULT '',		 /*C  2  0***          Cod.producto acogigo a despacho urgente/Sustento de Valor Observado (96)*/
   T_INGRE    CHAR(1) DEFAULT '',		 /*C  1  0*************Tipo de Ingreso (1.Normal 2.Agrupar 3.B)*/
   PRORRATEO  CHAR(1) DEFAULT '1',		 /*C  1  0*************Tipo de prorrateo*/
   INCLU_UIF  CHAR(1)  DEFAULT 'N',              /*C  1  0  Para determinar si es un Despacho inusual o sospechoso que deba reportarse a la UIF.*/
   NFAC_VTASU VARCHAR(40) DEFAULT '',  	         /*0* *   **           Numero de Factura del a Vta. Sucesiva/N� de 2da Factura de (71)/Descripcion de Nota de Embarque (40,41) y Volante de Despac/ Descripcion del Material de Guerra*/
   FFAC_VTASU DATE, 	                         /*D  8  0*            Fecha de la  Factura de la Vta. Sucesiva/Fecha de la Segunda Factura de (71)/Fecha de Inicio de Embarque (41)*/
   LUGDESTINO VARCHAR(50) DEFAULT '',  	         /*0** *  **           Motivo de Anulacion o Rectificacion en (40,41)*/
   FPRIMA_SEG DECIMAL(13,3) DEFAULT 0.000,	 /*                    Monto de la Poliza de Seguro (10)*/
   OBS_DECLAR VARCHAR(30) DEFAULT '',  	         /*0  *                Observaciones Declarante (40,41)/ Entidad de la fianza (70,20,21)/Cia de Seguro en (10,18)/Nro. de Documento de transporte Master (14)*/
   PROV_EXT   CHAR(4) DEFAULT '',  	         /*0**    ****         C�digo de Consignatario Extranjero (40,41) y Codigo de Comprador Inicial (10)*/
   CADUTRA    CHAR(3) DEFAULT '',		 /*C  3  0            *C�d.aduana transito*/
   FCH_PRELIQ DATE,                              /*D  8  0*************Fecha de presentaci�n de la poliza a la Aduana*/
   NUMPARTIDA NUMERIC(4,0)  DEFAULT 1,	         /*N  5  0*************Numero de series ingresadas por Normal*/
   NUM_ITEMO  NUMERIC(4,0)  DEFAULT 1,	         /*N  4  0** *       * Cantidad de Items en formato B / Dias del Prorroga de Deposito (70)*/
   TOT_ADV    DECIMAL(10,3) DEFAULT 0.000,  	 /*N 10  3******   *** Tasa de advalorem acumulada del despacho/Alto en Nota de Embarque*/
   TOT_ISC    DECIMAL(10,3) DEFAULT 0.000, 	 /*N 10  3******       Tasa de ISC acumulada del despacho/Largo en Nota de Embarque*/
   TOT_IGV    DECIMAL(10,3) DEFAULT 0.000, 	 /*N 10  3******   *** Tasa de IGV acumulada del despacho/Ancho en Nota de Embarque*/
   TOT_IPM    DECIMAL(10,3) DEFAULT 0.000, 	 /*N 10  3******   *** Tasa de IPM acumulada del despacho/Cubicaje en Nota de Embarque*/
   OBSER1     varchar(47) DEFAULT '', 	         /*C 47  0** * *  *****observacion1/ Descripcion del Sustento de la Duda Razonable (96)*/
   OBSER2     varchar(47) DEFAULT '', 	         /*C 47  0** * *  **** observacion2/ Observaciones de la Duda Razonable (96)*/
   OBSER3     varchar(47) DEFAULT '', 	         /*C 47  0**   *  **** observacion3/ Observaciones de la Duda Razonable (96)*/
   OBSER4     varchar(47) DEFAULT '', 	         /*C 47  0**   *   *** observacion4*/
   OBSER5     varchar(47) DEFAULT '', 	         /*C 47  0**   *  ** * observacion5*/
   OBSER6     varchar(47) DEFAULT '', 	         /*C 47  0**   *     * observacion6*/
   OBSER7     varchar(47) DEFAULT '', 	         /*C 47  0**   * * * * observacion7*/
   NORDEN_EMB CHAR(9) DEFAULT '',		 /*C  8  0      **     Orden de Embarque (41,43) y codigo debe decir para (01)/ Numero de Deposito para (79)*/
   FCH_OR_EMB DATE, 	                         /*D  8  0   *  **   **Fecha  de Orden de Embarque (40,43)/Fecha del Deposito a Prorrogar (79)*/
   FECHXREGUL DATE, 	                         /*D  8  0             Fecha por Regularizar Regimen (10 antipado y urgente)*/
   FV_NUM     DATE, 	                         /*D  8  0* *       ** Ultimo dia de pago*/
   NRO_PERCEP CHAR(6) DEFAULT '', 	         /*C 25  0*            Numero de Resolucion en (20,21,50)/Nro de CDA de la Percepci�n para la(10)(ANTES UBIC_BULTO)/Nro. Resp de Manif (14)*/
   TIPO_AFORO CHAR(1) DEFAULT '', 		 /*C  1  0**** * ******Num.Aduanas: tipo de Aforo / Tipo de moneda de CDA Autoliquidacion*/
   FCHAFORO   DATETIME,	                         /*D  8  0*  *   **** *Fecha de Aforo*/
   TIPO_OPERA CHAR(1) DEFAULT '', 		 /*C  1  0*************Tipo de Operaci�n Aduanera ([I]mportacion [E]xportacion [V]Operaciones Varias*/
   FOB_DOLLIQ DECIMAL(15,3) DEFAULT 0.000, 	 /*N 15  3**** ********Fob en dolares Ajustado por Aduanas (Despues de Numeracion)*/
   FLE_DOLLIQ DECIMAL(15,3) DEFAULT 0.000, 	 /*N 15  3**** * * *** Flete en dolares Ajustado por Aduanas (Despues de Numeracion)*/
   SEG_DOLLIQ DECIMAL(15,3) DEFAULT 0.000, 	 /*N 15  3**** *** *** Seguro en dolares Ajustado por Aduanas (Despues de Numeracion)*/
   CIFDOLLIQ  DECIMAL(15,3) DEFAULT 0.000, 	 /*N 15  3**** ********Cif en dolares Ajustado por Aduanas*/
   TIC        DECIMAL(13,3) DEFAULT 0.000, 	 /*N 13  3*            Tasa de Interes Compensatorio*/
   INCIDENCIA VARCHAR(20) DEFAULT '',            /*C 20  0             Incidencias del Despacho (Para el Registro de operaciones*/
   OBSERVACIO VARCHAR(50) DEFAULT '',            /*C 50  0             Observaciones del Registro de Operaciones*/
   NUMCOMPTAS VARCHAR(15) DEFAULT '',	         /*C 15  0             Numero de Comprobante de pago por la Liquidacion del Servicio de Despacho*/
   MONTO_FB   DECIMAL(13,2) DEFAULT 0.00,  	 /*N 13  2***          Monto de la Fianza Bancaria*/
   N_FIANZA   CHAR(10) DEFAULT '', 	         /*C 10 	0***   Numero de La fianza del Regimen Temporal/Numero de correlativo de Envio de 43*/
   MULTA_VCTO DECIMAL(15,2) DEFAULT 0.00, 	 /*N 15  2**           Multa x Vencimiento de Regularizaci�n*/
   FECHINIREG DATE, 	                         /*D  8  0****     *   Fecha de inicio del Regimen temporal*/
   FECHTERREG DATE, 	                         /*D  8  0****    **   Fecha de termino del regimen Temporal*/
   VCTOREG    DATE, 	                         /*D  8  0****    *    Fecha de vencimiento del Regimen Temporal/Fecha de fin de descarga (14)*/
   FECH_LEVAN DATETIME,	                         /*D  8  0*        *   Fecha de levante*/
   FECH_RECEP DATE,	                         /*D  8  0*            Fecha de Recepcion*/
   F_SALIDA   DATETIME, 	                 /*D  8  0************ fecha de salida de la mercaderia*/
   DESPACHA   CHAR(2) DEFAULT '', 		 /*C  2  0             C�digo de despachador de la Agencia*/
   TPAGO_DERE CHAR(1) DEFAULT '',		 /*C  1  0             Tipo de Pago de los Derechos Arancelarios por el Cliente*/
   N_PROF     CHAR(8) DEFAULT '',
   FECH_RETIR DATETIME,	                         /*D  8  0*            Fecha de ReTIRO*/
   TIPO_MANIF CHAR(2) DEFAULT "",                /*C  2  0             Tipo de Manifiesto */  
   NUM_FOLIO  NUMERIC(8,0) DEFAULT 0,             
   COD_CENVIO CHAR(2) DEFAULT '',                 /* Categoria del Envio DS EER*/
   FILE_DANZA VARCHAR(90) DEFAULT '',
   VOLUNTAD   CHAR(1) DEFAULT "",                 /* Voluntad de Regularizar en el despacho (SADAC)/Digito Verificador en la Autoliquidacion (96)  */
   ENVDIGIORD CHAR(2) DEFAULT "",                 /* Codigo de Tipo de Envio de Arhcivo Digitalizado*/
   FEC_EXPMER DATE,                               /* FECHA DE EXPIRACION DE LA MERCANCIA PERECIBLE PARA LA 70 */
   COD_LUGMER CHAR(5) DEFAULT "",                 /* codigo del lugar de la Mercancia*/
   COD_UNEGO  CHAR(2) DEFAULT "",                 /* Codigo de Unidad de Negocio SOLO PARA EXPEDITORS*/
   UNEGOCIO   VARCHAR(90) DEFAULT "",             /* Descripcion de la unidad de Negocio SOLO PARA EXPEDITORS*/ 
   RESPONSA   VARCHAR(90) DEFAULT "",             /* Descripcion del responsable SOLO PARA EXPEDITORS*/
   HP_COMIS   DECIMAL(13,3) DEFAULT 0.000,        /* Importe de Comision de Hp SOLO PARA EXPEDITORS */
   HP_ALMACE  DECIMAL(13,3) DEFAULT 0.000,        /* Importe de Almacenaje de Hp SOLO PARA EXPEDITORS */
   HP_ENTREGA CHAR(2) DEFAULT "",                 /* Lugar de Entrega de mercaderia para HP EXPEDITORS */
   HORA_CANC  CHAR(8) DEFAULT "",                 /* Hora de cancelacion de los derechos HP EXPEDITORS */
   FECH_INI_P DATETIME,                           /* FECHA INICIO PREVIO HP EXPEDITORS */
   FECH_FIN_P DATETIME,                           /* FECHA FIN PREVIO HP EXPEDITORS */
   DESC_INCID VARCHAR(100),                       /* DESCRIPCION DE INCIDENCIA HP EXPEDITORS */
   COMEN_STAT VARCHAR(100),                       /* COMENTARIO/STATUS HP EXPEDITORS */
   COD_CTOUIF CHAR(4) DEFAULT "",                 /* codigo del CONCTACTO DE LA UIF*/
   HP_TRANSP  DECIMAL(13,3) DEFAULT 0.000,        /* Transporte para HP*/
   HP_DESCARG DECIMAL(13,3) DEFAULT 0.000,        /* DESCARGA para HP */
   PRIMARY KEY(N_ORDEN),
   CONSTRAINT FK_DGA_APE FOREIGN KEY(N_ORDEN) REFERENCES APE(N_ORDEN),
   CONSTRAINT FK_DGA_DSP FOREIGN KEY(DESPACHA) REFERENCES DSP(CODIGO));
   create index dga on dga(n_orden);
   insert into dga(n_orden) values("");

/* DEA (DERECHOS DE ADUANA POR DESPACHOS PREVIOS Y DEFINITIVOS ) */
CREATE TABLE IF NOT EXISTS DEA(
   N_ORDEN    CHAR(11) NOT NULL,	           /*C  9  0*************N� de Orden de despacho */
   TIPO_DERE  CHAR(1) NOT NULL,                    /*      Tipo de Derechos [P]rovicionales,[D]efinitivos,[A]proximados*/
   CODIGO     CHAR(2) NOT NULL ,                   /*C  2  0codigo del tipo de Derecho segun codificacion Interna */
   DERE_LIQUI DECIMAL(12,2) DEFAULT 0.00,          /*      Importe del los derechos [L]iquidados */
   DERE_PAGAR DECIMAL(12,2) DEFAULT 0.00,          /*      Importe del los derechos de a [P]agar */
   PRIMARY KEY(N_ORDEN,TIPO_DERE,CODIGO),
   CONSTRAINT FK_DEA_DGA FOREIGN KEY(N_ORDEN) REFERENCES DGA(N_ORDEN),   
   CONSTRAINT FK_DEA_TS35 FOREIGN KEY(CODIGO) REFERENCES softpad_sistema.TS35(CODIGO));
   create index dea on dea(n_orden,tipo_dere,codigo);

/* DEL (MULTAS, MORAS Y PERCEPCION EN LIQUIDACIONES DE COBRANZA ) */
CREATE TABLE IF NOT EXISTS DEL(
   N_ORDEN	CHAR(11) NOT NULL,	           /*N� de Orden de despacho */					
   CORREL       CHAR(2) NOT NULL,                  /*C  2  0 //Numero de correlativo de las Liquidaciones de Cobranza*/
   CODIGO	CHAR(2) DEFAULT "",                /*codigo del tipo de Derecho segun codificacion Interna */					
   NUMERO_LC	VARCHAR(30) DEFAULT "",            /*Numero de la liquidacion de cobranza que sustenta este pago */					
   FECHA_LC	DATE, 			           /*Fecha de la liquidacion de cobranza que sustenta este pago */					
   MONEDA	CHAR(1) DEFAULT "",                /*Moneda de la liquidacion de cobranza*/
   T_CAMBIO	DECIMAL(7,3)DEFAULT 0.000,         /*Tipo de Cambio de la liquidacion */					
   DERE_DOLAR	DECIMAL(13,2) DEFAULT 0.00,        /*Importe en Dolares     					*/
   DERE_SOLES	DECIMAL(13,2) DEFAULT 0.00,        /*Importe en Soles*/    			
   PRIMARY KEY(N_ORDEN,CORREL),
   CONSTRAINT FK_DEL_DGA FOREIGN KEY(N_ORDEN) REFERENCES DGA(N_ORDEN), 
   CONSTRAINT FK_DEL_TS35 FOREIGN KEY(CODIGO) REFERENCES softpad_sistema.TS35(CODIGO));
   create index del on del(n_orden,codigo,numero_lc);

/* SEA (SERIES DEL DESPACHO) */
CREATE TABLE IF NOT EXISTS SEA(
   N_ORDEN    	CHAR(11) NOT NULL,	           /*C  9  0*************N� de Orden de despacho --- DATOS PRINCIPALES*/
   N_SERIE    	NUMERIC(4,0) NOT NULL,       	   /*N  4  0*************N� Serie*/
   REGI_PROCE 	CHAR(1) DEFAULT 'N', 	           /*C  1  0*************Si la serie tiene regimenes Precedentes*/
   REGI_PROC1 	CHAR(2) DEFAULT '',     	   /*C  2  0** *         Regimen precedente en Importaci�n*/
   APL_ULTRA  	CHAR(2) DEFAULT '',     	   /*C  2  0*            Aplicaci�n de ultractividad*/
   OTROPUERTO	VARCHAR(25) DEFAULT '', 	   /*C 25  0             nombre de puerto de Embarque*/
   FCH_EMB    	DATE, 	                           /*D  8  0******   *** Fecha de embarque*/
   COD_P_EMB  	CHAR(6) DEFAULT '',     	   /*C  6  0************ Codigo de puerto de Embarque*/
   NUMBLGUIA  	CHAR(25) DEFAULT '', 	           /*C 25  0*************N� de BL/Guia*/
   NUMDET     	CHAR(5) DEFAULT '', 	           /*C  3  0*  * *   *   Numero de detalle en caso de mas de un Bl/Guia*/
   CERT_ORIG  	VARCHAR(30) DEFAULT '', 	   /*C 16  0*  *         N� Certificado de Origen*/
   FCERT_ORI  	DATE, 	                           /*D  8  0*  *         Fecha Certificado de Origen*/
   UNI_COMER  	DECIMAL(13,3) DEFAULT 0.000, 	   /*N 13  3*************Unidades comerciales*/
   CLAS_COMER 	CHAR(3) DEFAULT '', 	           /*C  3  0*************clase de unidades comerciales*/
   CEXOCER    	CHAR(2) DEFAULT '',     	   /*C  2  0*  *     * * Codigo exoner. del certificado de Inspecci�n*/
   NUMBULTOS  	DECIMAL(14,3) DEFAULT 0.000, 	   /*N 14  3*************Numero de bultos*/
   CLASEBULTO 	CHAR(3) DEFAULT '', 	           /*C  3  0*************Clase de bultos*/
   KNSER      	DECIMAL(14,3) DEFAULT 0.000, 	   /*N 14  3*************Kilo Neto*/
   KBSER      	DECIMAL(14,3) DEFAULT 0.000, 	   /*N 14  3*************Kilo Bruto*/
   UFISICAS   	DECIMAL(13,3) DEFAULT 0.000, 	   /*N 13  3*************unidades fisicas*/
   TIPOUFIS   	CHAR(12) DEFAULT '', 	           /*C 12  0*************tipo de unidad fisica*/
   CANT_EQUIV 	DECIMAL(14,3) DEFAULT 0.000, 	   /*N 14  3* *   **  *  Cantidad de unidades equivalentes a la Prod.  para ordenes que preceden de una admisi�n/ Cantidad de Bultos para Guiar Eer 48*/
   TIPO_EQUIV 	CHAR(3) DEFAULT '',     	   /*C  3  0* *   **  *  tipo de unidades equivalente a la prod. para ordenes que preceden de una admisi�n*/
   NUME_SERPR 	CHAR(6) DEFAULT '',     	   /*C  6  0* *       *  N�mero item CIP*/
   PARTIDA    	CHAR(10) DEFAULT '',     	   /*C 10  0*************Partida Nandina*/
   PAN        	CHAR(10) DEFAULT '', 	           /*C 10  0*  *         P.Naladisa */
   PART_NABAN 	CHAR(8) DEFAULT '',     	   /*C  8  0*            Partida Nabandina*/
   COD_LIB    	CHAR(4) DEFAULT '', 	           /*C  4  0*  *       * TPI, TPN o Cod.Lib*/
   TRATO_PREF 	CHAR(4) DEFAULT '',     	   /*C  4  0*            TPI, TPN o Cod.Lib*/
   TIPO_MARGE 	CHAR(1) DEFAULT '',     	   /*C  1  0*      *     Tipo de margen*/
   COD_P_PRO  	CHAR(3) DEFAULT '',     	   /*C  3  0******   *** Pais de origen*/
   COD_P_ADQ  	CHAR(3) DEFAULT '',     	   /*C  3  0*************Pa�s de Adquisici�n*/
   REGI_APLIC 	CHAR(2) DEFAULT '',     	   /*C  2  0      **     Si la serie tiene regimenes aplicativos*/
   FOBSER     	DECIMAL(13,3) DEFAULT 0.000, 	   /*N 13  3*************Fob    en transacci�n*/
   FOBSDOL    	DECIMAL(13,3) DEFAULT 0.000, 	   /*N 13  3*************Fob    en d�lares*/
   FOBGSER    	DECIMAL(13,3) DEFAULT 0.000, 	   /*N 13  3*    *     * Gtos.  en transacci�n*/
   FOBGDOL    	DECIMAL(13,3) DEFAULT 0.000, 	   /*N 13  3*    *     * Gtos.  en d�lares*/
   AJUSTE     	DECIMAL(13,3) DEFAULT 0.000, 	   /*N 13  3*            Monto del ajuste realizado por el Agente de aduanas en dolares*/
   VTA_SUCESI 	DECIMAL(13,3) DEFAULT 0.000, 	   /*N 13  3*            Valor prorrateado por serie de la venta Sucesiva*/
   FLESER     	DECIMAL(13,3) DEFAULT 0.000, 	   /*N 13  3******** *** Flete en transacci�n*/
   FLESDOL    	DECIMAL(13,3) DEFAULT 0.000, 	   /*N 13  3******** *** Flete en d�lares*/
   SEGSER     	DECIMAL(13,3) DEFAULT 0.000, 	   /*N 13  3******   *** Seguro en transacci�n*/
   SEGSDOL    	DECIMAL(13,3) DEFAULT 0.000, 	   /*N 13  3******   *** Seguro en d�lares*/
   TIPO_SEG     CHAR(1) DEFAULT '',                /*C  1  0             Tipo de seguro por serie  */
   TNAN      	CHAR(2) DEFAULT '', 	           /*C  2  0*    *     * Tipo de IGV e ISC por serie de acuerdo a la Partida*/
   CIFSER     	DECIMAL(13,3) DEFAULT 0.000, 	   /*N 13  3*************Cif en transacci�n*/
   CIFSDOL    	DECIMAL(13,3) DEFAULT 0.000, 	   /*N 13  3*************Cif en d�lares*/
   DES1      	VARCHAR(100) DEFAULT '', 	   /*C100  0*************Descripci�n comercial*/
   DES2       	VARCHAR(150) DEFAULT '', 	   /*C150  0**** ********Forma de presentaci�n*/
   DES3       	VARCHAR(150) DEFAULT '', 	   /*C150  0** * ******* Materiales de composicion porcentual*/
   DES4       	VARCHAR(150) DEFAULT '', 	   /*C150  0** * ********Uso o aplicacion*/
   DES5       	VARCHAR(150) DEFAULT '', 	   /*C150  0** * ********Otras caracteristicas*/
   PORCENTAJE 	DECIMAL(10,3) DEFAULT 0.000,	   /*N  6  3**           Porcentaje de mermas*/
   CEXPODUMP  	CHAR(4) DEFAULT '',     	   /*C  4  0*            Codigo de Antidumping para empresa exportadora*/
   CPROD      	CHAR(2) DEFAULT '',     	   /*C  2  0*            Codigo de antidumping por producto*/
   TPROD      	CHAR(2) DEFAULT 'N',     	   /*C  2  0*************Codigo de autorizaci�n de mercancia restringida*/
   CODIDE     	CHAR(11) DEFAULT '',     	   /*C 11  0*  *  ***    Codigo de identificacion en Mitinci/Numero de Documento del Importador(33)/Numero de placa para operador 7 Regimen (14)*/
   ANOAUT     	CHAR(4) DEFAULT '',     	   /*C  4  0*  * ****  * A�o de autorizaci�n en Mitinci/discamec y Codigo de Sanciones en "96"*/
   NUMAUT     	CHAR(9) DEFAULT '',     	   /*C  9  0*  * ****  * Numero de autorizacion en Mitinci/Discamec*/
   CODLUG    	CHAR(3) DEFAULT '',     	   /*C  3  0*  * ****  * Codigo de aduana autorizada en Mitinci/Discamec*/
   FOB_PNETO 	DECIMAL(14,3) DEFAULT 0.000, 	   /*N 14  3** *  ** * * Fob por peso Neto exigido para Tejidos/Peso Vehicular para usados/Precio venta de Cigarrillos y Cervezas*/
   CPROH     	CHAR(2) DEFAULT '',     	   /*C  2  0*     **     Codigo de no prohibido de exportar*/
   CEXCNAN   	CHAR(1) DEFAULT '',     	   /*C  1  0* *   ***    Codigo de exoneracion de la prohibicion a exportar/ Tipo de despacho para la DUIM/Tipo de Documento del Importador(33)/Indicador para que no prorratee los Kilos Neto*/
   CCUOEXP   	CHAR(2) DEFAULT '',     	   /*C  2  0             Codigo de cuota de exportaci�n*/
   UBIGEO    	CHAR(6) DEFAULT '',     	   /*C  6  0**    ***** *Codigo de Ubigeo y Codigo de insumo en "29"*/
   FEEMIAUT  	DATE, 	                   /*D  8  0*  * ****    Fecha inicio.Doc.Autorizaci�n Merc.Restringida*/
   FEVENAUT  	DATE, 	                   /*D  8  0*  *  ***  * Fecha Venc.Doc.Autorizaci�n Merc.Restringida*/
   CZONFRA   	CHAR(1) DEFAULT '',        	   /*C  1  0*************0,1 Procede o no de zona Franca*/
   DZONFRA   	VARCHAR(25) DEFAULT '', 	   /*C 25  0             Nombre de la zona franca de CZONFRA es igual a 1/Numero de Parte de referencia donde se jalo las series como ayuda (CURDMAS)*/
   FOB_FACT  	DECIMAL(17,6) DEFAULT 0.000000,    /*N 17  6*************Fob Fact.para Antidump.("10") en dolares*/
   CCODDOC   	CHAR(2) DEFAULT '',      	   /*C  2  0*  * *****/
   FACT_COMER 	CHAR(1) DEFAULT '', 	           /*C  1  0             Tiene factura comercial esta serie/ Excedente de PAT para simplificada (18)*/
   MPO       	DECIMAL(9,3) DEFAULT 0.000, 	   /*N  9  3*  *       * Margen porcentual ------ SISTEMA ------  de liberacion de advalorem*/
   ESTADO    	CHAR(2) DEFAULT '', 	           /*C  2  0************ Estado de la mercancia*/
   DOC_CANCEL 	CHAR(1) DEFAULT '', 	           /*C  1  0      **  *  Indica Acogimiento a Doc.Cancelat.4201,4202*/
   ADVALSER  	DECIMAL(7,3) DEFAULT 0.000, 	   /*N  7  3******   *** Tasa de Advalorem*/
   ADVDOL    	DECIMAL(12,2) DEFAULT 0.00, 	   /*N 12  2******   * * Advalorem a pagar*/
   LADVDOL   	DECIMAL(12,2) DEFAULT 0.00, 	   /*N 12  2******   *** Advalores liquidado*/
   SOBRETSER 	DECIMAL(7,3) DEFAULT 0.000, 	   /*N  7  3*  *       * Tasa de sobretasa*/
   SB10DOL   	DECIMAL(13,2) DEFAULT 0.00, 	   /*N 13  2*  *       * Sobretasa a pagar*/
   LSB10DOL  	DECIMAL(13,2) DEFAULT 0.00, 	   /*N 13  2*  *       * Sobretasa liquidada*/
   D_ESP     	DECIMAL(10,2) DEFAULT 0.00, 	   /*N 10  2             Monto de derecho especifico de tabla*/
   DS16DOL   	DECIMAL(13,2) DEFAULT 0.00, 	   /*N 13  2             Derecho espefico a pagar*/
   LDS16DOL  	DECIMAL(13,2) DEFAULT 0.00, 	   /*N 13  2             Derecho espefico liquidado*/
   ISCSER    	DECIMAL(7,3) DEFAULT 0.000, 	   /*N  7  3*  *         Tasa de I.S.C.*/
   VAISCSER  	DECIMAL(7,3) DEFAULT 0.000, 	   /*N  7  3*            Tasa Variante de I.S.C. para algunas partidas, remplaza a la del arancel*/
   PRESOLISC 	DECIMAL(12,2) DEFAULT 0.00, 	   /*N 12  2*            Precio en soles por galon para calculo de I.S.C. para partidas de gasolina*/
   ISCDOL    	DECIMAL(12,2) DEFAULT 0.00, 	   /*N 12  2*  *         I.S.C. a pagar*/
   LISCDOL   	DECIMAL(12,2) DEFAULT 0.00, 	   /*N 12  2*  *         I.S.C. liquidado*/
   IGVSER    	DECIMAL(7,3) DEFAULT 0.000, 	   /*N  7  3******   *** Tasa de IGV*/
   VAIGVSER  	DECIMAL(7,3) DEFAULT 0.000, 	   /*N  7  3*    *     * Tasa variante de I.G.V. para algunas partidas remplaza a la del Arancel para Libros etc.*/
   IGVDOL    	DECIMAL(12,2) DEFAULT 0.00, 	   /*N 12  2******   * * I.G.V. a pagar*/
   LIGVDOL   	DECIMAL(12,2) DEFAULT 0.00, 	   /*N 12  2******   *** I.G.V. liquidado*/
   IPMSER    	DECIMAL(7,3) DEFAULT 0.000, 	   /*N  7  3******   *** Tasa de IPM*/
   VAIPMSER  	DECIMAL(7,3) DEFAULT 0.000, 	   /*N  7  3*    *     * Tasa variante de I.P.M. remplaza a la del Arancel para Libros etc.*/
   IPMDOL    	DECIMAL(12,2) DEFAULT 0.00, 	   /*N 12  2******   * * I.P.M. a pagar*/
   LIPMDOL   	DECIMAL(12,2) DEFAULT 0.00, 	   /*N 12  2******   *** I.P.M. liquidado*/
   ANTIDOL   	DECIMAL(12,2) DEFAULT 0.00, 	   /*N 12  2             Monto de antidumping en dolares*/
   FACTSEG   	DECIMAL(17,10)DEFAULT 0.0000000000,/*N 13 10             Factor de seguro para Southern (7436 - 7418)/FOB UNITARIO PARA tacna*/
   NUMDECPRO 	VARCHAR(25) DEFAULT '',            /*C 25  0** *         Numero de Declaraci�n Precedente para (18,48)*/
   SERITEM   	NUMERIC(4,0) DEFAULT 0,	           /*N  5  0             Numero de serie de la declaraci�n precedente para (18,48)*/
   FECHINIREG 	DATE, 	                   /*D  8  0** *         Fecha de inicio de precedende para (18,48)*/
   FCHVCTOPRO 	DATE, 	                   /*D  8  0** *         Fecha de Termino para (18,48)*/
   NUM_FACT1 	VARCHAR(40) DEFAULT '', 	   /*C 40  0*************Para regimen (18,48)*/
   FCH_FACT1 	DATE, 	                   /*D  8  0*************Para regimen (18,48)*/
   D6    	CHAR(1) DEFAULT '',                /*C  1  0             Inciso para regimen (18,48)/ Tipo de Percepcion para Discos opticos (d6)*/
   INFORMAC1 	VARCHAR(60) DEFAULT '', 	   /*C 60  0*********** *Informaci�n complementaria al despacho/ Nombres del Destinatario (18) para Couriers*/
   INFORMAC2 	VARCHAR(60) DEFAULT '', 	   /*C 60  0*********** *Informaci�n complementaria al despacho/ Apellidos del Destinatario (18) para Couriers*/
   INFORMAC3 	VARCHAR(60) DEFAULT '', 	   /*C 60  0** ********  Informaci�n complementaria al despacho/ Direccion del Destinatario (33) para Couriers*/
   INFORMAC4 	VARCHAR(60) DEFAULT '',   	   /*C 60  0*  * ******  Informaci�n complementaria al despacho*/
   INFORMAC5 	VARCHAR(60) DEFAULT '', 	   /*C 60  0**    ** **  Informaci�n complementaria al despacho*/
   NUME_ITEMB 	VARCHAR(100) DEFAULT '', 	   /*C100  0** *       * Items que se han juntado para formar esta serie*/
   QUNIISC   	DECIMAL(15,3) DEFAULT 0.000, 	   /*N 15  3*            Cantidad de unidades de I.S.C.*/
   TUNIISC   	CHAR(3) DEFAULT '', 	           /*C  3  0*            Tipo de unidades de I.S.C.*/
   PIGVDOL   	DECIMAL(12,2) DEFAULT 0.00, 	   /*N 12  2*            Importe del IGV en Dolares*/
   AADV_DOL  	DECIMAL(12,2) DEFAULT 0.00,        /*N 12  2             Advalorem sin rebaja por Derecho Expecifico*/
   ASB10DOL  	DECIMAL(13,2) DEFAULT 0.00,	   /*N 13  2             Sobretasa sin rebaja por Derecho Expecifico*/
   FLAG_BASE 	CHAR(3) DEFAULT '', 	           /*C  3  0             Indicador para Agrupamiento de Ordenes*/
   NUME_FFCO 	CHAR(5) DEFAULT '', 	           /*C  5  0******   *   Numero de Firmas de Certificado de Origen*/
   KBSERANT  	DECIMAL(14,3) DEFAULT 0.000, 	   /*N 14  3             Kilos Neto Original (Anticipado)*/
   TIPOCODLIB 	CHAR(3) DEFAULT 'TPI', 	           /*C  3  0****         Tipo de codigo Liberatorio usado*/
   TIPOCODLI1 	CHAR(3) DEFAULT '', 	           /*C  3  0****         Segundo tipo codigo Liberatorio usado*/
   F_ROTULADO 	DATE, 	                   /*D  8  0*            Fecha de Vencimiento (Perecibles) para Rotulados*/
   ROTULADO  	CHAR(1) DEFAULT '', 	           /*C  1  0*            Marca para indicar si hay Rotulados*/
   PRORR_PESO 	CHAR(1) DEFAULT '', 	           /*C  1  0********     Para importacion indica el tipo de prorrateo para el Flete y para Exportacion indica si el peso es prorrateado*/
   FLAGKBRKNE 	CHAR(1) DEFAULT '',	           /*C  1  0             Si esta vacio indica que peso bruto debe ser prorrateado si esta lleno Peso Bruto ingresado y ademas ("S"=Debe Prorratear el neto basado en el Bruto,"N"=No debe prorratear el Neto)*/
   TIPO_CONO    CHAR(1) DEFAULT '',                /*C  1  0             Tipo de documento de Transporte /Tipo de Documento del consignatario para (18)*/
   CONO_MAST    VARCHAR(25) DEFAULT '',            /*C  25 0             Documento de transporte Master /Dispocision Transitoria (18)*/
   CONSIGNA     CHAR(5) DEFAULT '',                /*C   5 0             Consignatario para Importacion Simplificada */
   RIESGOSAN    CHAR(2) DEFAULT '',                /*C   1 0             Riesgo Sanitatio para Importacion */    
   TIP_CERTOR   CHAR(1) DEFAULT '',                /*C   1 0             Tipo de Certificado de Origen*/
   TIP_EMICER   CHAR(1) DEFAULT '',                /*c   1 0             Tipo de Emisor del Certificado de Origen*/
   NOM_EMICER   VARCHAR(100) DEFAULT '',           /*C 100 0             Nombre del Emisor del Certificado de Origen*/
   FEC_IEMBCE   DATE,                              /*D   8 0             Fecha de Inicio para el embarque segun C.O.*/
   FEC_FEMBCE   DATE,                              /*D   8 0             Fecha de fin para el embarque segun C.O. */
   CRI_ORIGEN   CHAR(1) DEFAULT '',                /*C   1 0             Criterio de Origen*/
   IND_TRANS    CHAR(1) DEFAULT '',                /*C   1 0             Indicador de transito o transbordo en un 3er pais*/
   FEC_EMBPTR   DATE,                              /*D   8 0             Fecha de embarque en puerto de origen*/
   NUM_EMBAR    NUMERIC(2,0) DEFAULT 0,            /*N   2 0             Numero de Embarque para embarques parciales (40,41)*/
   N_PARTE   	VARCHAR(25)  DEFAULT '', 	   /*C   25              Numero de parte*/
   COD_PRODUC   CHAR(4) DEFAULT '',                /* Codigo de Producto*/
   FLAG_DIGPA   CHAR(1) DEFAULT '',                /* Flag que indca que se ha digitado la partida en las series del A.*/ 
   NUMAUTOEXP   VARCHAR(25) DEFAULT '',            /* Numero de Autorizacion del Exportador/ Numero de Guia Eer para 48 */
   NOM_PRODUC   VARCHAR(100) DEFAULT '',           /* Nombre del Producto */
   PEMB_ORIG    CHAR(5) DEFAULT '',                /* Pto.Emabarque de Lugar de origen*/
   CNT_GUIAS    NUMERIC(4,0) DEFAULT 0,            /* Cantidad de Guias ERR 18/48*/
   COD_CENVIO   CHAR(2) DEFAULT "",                /* codigo de Envio para la 48 "*/
   VAL_ESTIMA   DECIMAL(13,3) DEFAULT 0.00, 	   /* Valor estimado de la mercancia/fob Total de la mercancia para el Calculo del Seguro en la Reimportacion*/
   TIPOREG_S    VARCHAR(2) DEFAULT "",             /*Para la ayuda de productos en las series de exportacion */
   FCHNUMER_S   DATE,                              /*Para la ayuda de productos en las series de exportacion */
   ANULADA      CHAR(1) DEFAULT "",                /*Para la anulacion de algunas series en la Rectificacion de Simplificadas EER. */
   REVISION     CHAR(3) DEFAULT "",                /*Revisado de Rotulado/ Restringida/Prohibido*/
   IND_PARTES   CHAR(1) DEFAULT "",                /*Indicador de partes de Vehiculos para Importacion */
   GRADO_ALCO   DECIMAL(6,2) DEFAULT 0.00,         /*grado de alcohol  */
   PRIMARY KEY(N_ORDEN,N_SERIE),
   CONSTRAINT FK_SEA_DGA FOREIGN KEY(N_ORDEN) REFERENCES DGA(N_ORDEN));
   create index sea on sea(n_orden,n_serie);
   create index sea_numblguia   on sea(numblguia);
   create index sea_consigna    on sea(consigna);
   create index sea_partida     on sea(partida); /*Para la Consulta de obsequios en Simplificada thisform.obsequios saddsia */
   create index sea_tiporeg_s   on sea(tiporeg_s); /*Para la ayuda de productos en las series de exportacion */
   create index sea_fchnumer_s  on sea(fchnumer_s); /*Para la ayuda de productos en las series de exportacion */
   create index sea_numdecpro   on sea(numdecpro,seritem);
   create index sea_dzonfra     on sea(dzonfra);


/* FEX (LISTA DE FACTURAS POR SERIE QUE INTERVIENEN EN EL DESPACHO)*/
CREATE TABLE IF NOT EXISTS FEX(
   N_ORDEN   	CHAR(11) NOT NULL,	/*C  9  0*/
   NUME_SERIE	NUMERIC(4,0) DEFAULT 0,	/*N  4  0*/
   NUME_FACTU	VARCHAR(40) DEFAULT '',	/*C 40  0*/
   FECH_FACTU	DATE,	/*D  8  0*/
   INCOTERM  	CHAR(3) DEFAULT '',	/*C  3  0*/
   FLAG      	CHAR(1) DEFAULT '',	/*C  1  0*/
   COD_MONFAC   CHAR(3) DEFAULT '',	/*C  3  0*/
   VAL_TOTFAC   DECIMAL(14,3) DEFAULT 0.000,
   TIPO_FACTU   CHAR(1) DEFAULT "",     /* 0 Tipo de Factura (V-Si corresponde a la Venta Sucesiva)*/
   PRIMARY KEY(N_ORDEN,NUME_SERIE,NUME_FACTU),
   CONSTRAINT FK_FEX_SEA FOREIGN KEY(N_ORDEN,NUME_SERIE) REFERENCES SEA(N_ORDEN,N_SERIE));
   create index fex on fex(n_orden);

/* SDC(LISTA DE CONTENEDORES QUE INCLUYE EL DESPACHO */
CREATE TABLE IF NOT EXISTS SDC(
   N_ORDEN   	CHAR(11) NOT NULL,	/*C  9  0 //Numero de Orden*/
   CORREL       CHAR(3) NOT NULL,       /*C  3  0 //Numero de correlativo de contenedores*/
   CON1      	CHAR(17) DEFAULT '',	/*C 15  0 //Numero de Contenedor*/
   PRECINTO  	CHAR(15) DEFAULT '',	/*C 15  0 //Numero de Precinto*/
   PULGADAS  	CHAR(2) DEFAULT '',	/*C  2  0 //Tama�o en pies del contenedor*/
   MARCA     	CHAR(15) DEFAULT '',	/*C 15  0 //Marcas Adicionales*/
   NUME_SERIE	NUMERIC(4,0) DEFAULT 0,	/*N  4  0 //Numero de serie a la que pertenece*/
   PREC_ROTO1   VARCHAR(15) DEFAULT "", /*c 15  0 //Precinto Adicional para los controles Macromar*/
   PREC_ROTO2   VARCHAR(15) DEFAULT "", /* C 15  0 //Precinto Adicional para los controles Macromar*/
   PREC_ROTO3   VARCHAR(15) DEFAULT "", /*C 15  0 //Precinto Adicional para los controles Macromar*/
   COND_EQUIP   CHAR(2) DEFAULT "",     /*C  2  0 //codigo de la condicion del equipamiento*/
   TAMA_EQUIP   CHAR(4) DEFAULT "",     /*C  4  0 //Codigo del Tama�o del equipamiento*/
   PARTE        CHAR(1) DEFAULT "",     /* C  1  0 //Indicador si es parte o no de contenedor*/
   IND_AGNAV    CHAR(1) DEFAULT "",     /*Indocador de naviera */
   PRIMARY KEY(N_ORDEN,CORREL),
   CONSTRAINT UQ_SDC_1 UNIQUE(N_ORDEN,CON1,PRECINTO),
   CONSTRAINT FK_SDC_DGA FOREIGN KEY(N_ORDEN) REFERENCES DGA(N_ORDEN));
   CREATE INDEX sdc on sdc(n_orden);

/* SDP(LISTA DE PRECINTOS X CONTENEDOR QUE INCLUYE EL DESPACHO */
CREATE TABLE IF NOT EXISTS SDP(
   N_ORDEN    CHAR(11) NOT NULL,
   CORREL_SDC CHAR(3) NOT NULL,	        /*C 15  0 //Correlativo del Contenedor*/
   CORREL     CHAR(2) NOT NULL,         /*C  2  0 //Correlativo del Precinto */
   PRECINTO   CHAR(15) DEFAULT "", 
   CONDICION  CHAR(1) DEFAULT "",
   ENTIDAD    CHAR(2) DEFAULT "",
   PRIMARY KEY(N_ORDEN,CORREL_SDC,CORREL),
   CONSTRAINT FK_SDP_SDC FOREIGN KEY(N_ORDEN,CORREL_SDC) REFERENCES SDC(N_ORDEN,CORREL));
   CREATE INDEX SDP ON SDP(N_ORDEN,CORREL_SDC,CORREL);

/* EMP (EMPRESAS DE TRANSPORTE )*/
CREATE TABLE IF NOT EXISTS EMP(
   N_ORDEN   	CHAR(11) NOT NULL,	/*C  9  0   N� de Orden de despacho*/
   CORREL       NUMERIC(3,0) NOT NULL,   
   CODI_ETRAN	CHAR(4) DEFAULT '',	/*C  4  0   C�digo de Empresa de Transporte de salida*/
   DESC_ETRAN	VARCHAR(30) DEFAULT '',	/*C 30  0   Nombre de Empresa de Transporte de salida*/
   MATR_NAVE 	VARCHAR(30) DEFAULT '',	/*C 30  0   Nave*/
   PRIMARY KEY(N_ORDEN,CORREL),
   CONSTRAINT FK_EMP_DGA FOREIGN KEY(N_ORDEN) REFERENCES DGA(N_ORDEN));
   CREATE INDEX EMP ON EMP(n_orden);

/*RGP (TABLA DE REGIMENES PRECEDENTES)*/
CREATE TABLE IF NOT EXISTS RGP(
   N_ORDEN   	CHAR(11) NOT NULL,	/*C  9  0 //Numero de la orden de despacho*/
   CORREL       NUMERIC(4,0) NOT NULL,   
   N_SERIE   	NUMERIC(4,0) DEFAULT 0,	/*N  4  0 //Numero de la serie de la orden*/
   TIPO      	CHAR(1) DEFAULT '',	/*C  1  0 //Tipo de Documento*/
   REGI_PROCE	CHAR(2) DEFAULT '',	/*C  2  0 //Tipo de regimen Precedente*/
   CADUREGPRE	CHAR(3) DEFAULT '',	/*C  3  0 //Codigo de aduana de regimen precedente*/
   FANOREGPRE	CHAR(4) DEFAULT '',	/*C  4  0 //A�o del regimen precedente*/
   NDCLREGPRE	CHAR(6) DEFAULT '',	/*C  6  0 //Numero de declaracion del regimen precedente*/
   FINIREGPRE	DATE,	/*D  8  0 //Fecha de inicio del regimen precedente*/
   FTERREGPRE	DATE,	/*D  8  0 //Fecha de termino del regimen precedente*/
   NUME_SERPR	NUMERIC(4,0) DEFAULT 0,	/*N  4  0 //Numero de serie del regimen precedente*/
   ANO_DOCUM 	CHAR(4) DEFAULT '',	/*C  4  0 //A�o de la liquidacion de cobranza o de Adecuaci�n*/
   NRO_DOCUM 	CHAR(6) DEFAULT '',	/*C  6  0 //Nro de la liquidacion de cobranza o de Adecuacion*/
   NUME_ITEM 	NUMERIC(4,0) DEFAULT 0,	/*N  4  0 //Item del cuadro de insumo producto*/
   UNID_FIQTY	DECIMAL(14,3) DEFAULT 0.000,	/*N 14  3 //Unidades fisicas*/
   NACI_EXCAD	CHAR(1) DEFAULT '',	/*C  1  0*/
   TIPOREGPR 	CHAR(4) DEFAULT '',	/*C  4  0 //Identificador para difereciar si es regimen precedente o aplicativo*/
   PRIMARY KEY(N_ORDEN,CORREL),
   CONSTRAINT FK_RGP_SEA FOREIGN KEY(N_ORDEN,N_SERIE) REFERENCES SEA(N_ORDEN,N_SERIE));
   CREATE INDEX RGP ON RGP(n_orden);
   CREATE INDEX RGP_1 ON RGP(REGI_PROCE,FANOREGPRE,CADUREGPRE,NDCLREGPRE);

/*FPR(TABLA VALORES POR FACTURA PARA EL PRORRATEO DE SERIES)*/
CREATE TABLE IF NOT EXISTS FPR(	
   N_ORDEN      CHAR(11) NOT NULL,	/*C  9  0 //N� de Orden de despacho*/
   NUM_FACT  	VARCHAR(40) DEFAULT '',	/*C 40  0 //Numero de factura / Numero del B/L o Guia para Prorrateo del Flete*/
   FOB_GTOS  	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //Fob Gastos en Dolares de la factura / Fob de las Series agrupor por B/L (Prorrateo de Flete)*/
   FOBGTOS_D 	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //Fob de la factura (le falta venta sucesiva) / Fob de las Series con tipo de Prorrateo 3 (Prorrateo de Flete)*/
   FLETE_FACT	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //Total flete por Factura (Suma prorrateada de los items de esta factura ) / Flete de las Series con tipo de Prorrateo 3 (Prorrateo  de Flete)*/
   FLETE_TRAN	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //Flete de la factura en transaccion / Flete de  cada B/L o Guia Aerea*/
   SEGURO    	DECIMAL(13,3) DEFAULT 0.000,	/*N 13  3 //Seguro en transacci�n/Otros gastos Deducibles*/
   SEGURO_DOL	DECIMAL(13,3) DEFAULT 0.000,	/*N 13  3 //Seguro en d�lares*/
   KBR       	DECIMAL(15,3) DEFAULT 0.000,	/*N 15  3 //KILOS BRUTO PARA PRORRATEAO POR FACTURA / Kilos Bruto de las Series Agrupados por B/L*/
   KNE        	DECIMAL(15,3) DEFAULT 0.000,	/*N 15  3 //KILOS NETO PARA PRORRRATEO POR FACTURA*/
   FOB_PRORR1	DECIMAL(13,3) DEFAULT 0.000,	/*N 13  3 //SUMA DEL FOB DE LAS SERIES AGRUPADAS POR BL Y PRORRATEADAS CON TIPO 1*/
   FOB_PRORR3	DECIMAL(13,3) DEFAULT 0.000,	/*N 13  3 //SUMA DEL FOB DE LAS SERIES AGRUPADAS POR BL Y PRORRATEADAS CON TIPO 3*/
   KNE_PRORR1 	DECIMAL(15,3) DEFAULT 0.000,	/*N 15  3 //SUMA DEL PESO NETO DE LAS SERIES AGRUPADAS POR BL Y PRORRATEADAS CON TIPO 1*/
   KNE_PRORR3 	DECIMAL(15,3) DEFAULT 0.000,	/*N 15  3 //SUMA DEL PESO NETO DE LAS SERIES AGRUPADAS POR BL Y PRORRATEADAS CON TIPO 3*/
   KBR_PRORR1 	DECIMAL(15,3) DEFAULT 0.000,	/*N 15  3 //SUMA DEL PESO BRUTO DE LAS SERIES AGRUPADAS POR BL Y PRORRATEADAS CON TIPO 1*/
   KBR_PRORR3 	DECIMAL(15,3) DEFAULT 0.000,	/*N 15  3 //SUMA DEL PESO BRUTO DE LAS SERIES AGRUPADAS POR BL Y PRORRATEADAS CON TIPO 3*/
   FLE_PRORR1 	DECIMAL(15,3) DEFAULT 0.000,	/*N 15  3 //SUMA DE LOS FLETES DE LAS SERIES AGRUPADAS POR BL Y PRORRATEADAS CON TIPO 1*/
   FLE_PRORR3 	DECIMAL(15,3) DEFAULT 0.000,	/*N 15  3 //SUMA DE LOS FLETES DE LAS SERIES AGRUPADAS POR BL Y PRORRATEADAS CON TIPO 3*/
   TVAL_ITEMD	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //Precio de factura para Aduanas, para impresion y envio*/
   PRIMARY KEY(N_ORDEN,NUM_FACT),
   CONSTRAINT FK_FPR_DGA FOREIGN KEY(N_ORDEN) REFERENCES DGA(N_ORDEN));
   CREATE INDEX FPR ON FPR(n_orden);

 /*MAN (MANISFIESTOS DESDOBLADOS PARA EXPORTACION)*/
CREATE TABLE IF NOT EXISTS MAN(
   N_ORDEN   	CHAR(11) NOT NULL,	/*C  9  0*/
   CORREL       NUMERIC(3,0) NOT NULL,   
   CADU_MANIF	CHAR(3) DEFAULT '',	/*C  3  0*/
   ANO_MANIF 	CHAR(4) DEFAULT '',	/*C  4  0*/
   NUME_MANIF	NUMERIC(5,0) DEFAULT 0, 	/*N  5  0*/
   TPESO_BRUT	DECIMAL(15,3) DEFAULT 0.000,	/*N 15  3*/
   TCANT_BULT	DECIMAL(15,3) DEFAULT 0.000,	/*N 15  3*/
   EMPR_TRANS	CHAR(4) DEFAULT '',	   /*C  4  0*/
   VIA_TRANSP   CHAR(1) DEFAULT '',        /*C  1  0*/
   CODI_ALMA    CHAR(4) DEFAULT "",        /*C  4  0*/
   NUM_EMBAR    NUMERIC(2,0) DEFAULT 0.00,  /*N  2  0*/
   PRIMARY KEY(N_ORDEN,CORREL),
   CONSTRAINT FK_MAN_DGA FOREIGN KEY(N_ORDEN) REFERENCES DGA(N_ORDEN),
   CONSTRAINT UQ_MAN_1 UNIQUE(N_ORDEN,CADU_MANIF,ANO_MANIF,NUME_MANIF));
   CREATE INDEX MAN ON MAN(N_ORDEN);


/*FCT (LISTA DE FACTURAS POR TERCEROS PARA EXPORTACION )*/
CREATE TABLE IF NOT EXISTS FCT(
   N_ORDEN   	CHAR(11) NOT NULL, 	/*C  9  0   N� de Orden de despacho*/
   CORREL       NUMERIC(3,0) NOT NULL,   
   NUME_FACTU	VARCHAR(40) DEFAULT '', 	/*C 40  0   N� de factura*/
   FECH_FACTU	DATE, 	/*D  8  0   Fecha de factura*/
   TIPO_DOCUM	CHAR(1) DEFAULT '',	/*C  1  0   Tipo Documento de Exportador minoritario*/
   NUME_DOCUM	CHAR(11) DEFAULT '', 	/*C 11  0   Numero Documento de Exportador minoritario*/
   TFOB_FACT 	DECIMAL(15,3) DEFAULT 0.000,	/*N 15  3   Total valor fob de la factura en US$*/
   N_SERIE   	NUMERIC(4,0) DEFAULT 0,  	/*N  4  0   Numero de serie*/
   PORC_PARTI   DECIMAL(5,2) DEFAULT 0.00, 
   PRIMARY KEY(N_ORDEN,CORREL),
   CONSTRAINT UQ_FCT_1 UNIQUE(N_ORDEN,NUME_FACTU,TIPO_DOCUM,NUME_DOCUM,N_SERIE),
   CONSTRAINT FK_FCT_DGA FOREIGN KEY(N_ORDEN) REFERENCES DGA(N_ORDEN));
   CREATE INDEX FCT ON FCT(N_ORDEN);

/*SLF (SOLICITUD DE AFORO FISICO CUANDO ES EN EL LOCAL DEL EXPORTADOR )*/
CREATE TABLE IF NOT EXISTS SLF(
   N_ORDEN    CHAR(11) NOT NULL, /*C  9  0   N� de Orden de despacho*/
   TDOC       CHAR(2) DEFAULT '',/*C  2  0   Tipo de documento del a Entidad del Documento Asociado*/
   NDOC       CHAR(11)DEFAULT '',/*  0   Numero de Documento del a Entidad del Documento Asociado*/
   TDOCREPLEG CHAR(2) DEFAULT '',/*C  2  0   Tipo de Documento de Representante Legal*/
   NDOCREPLEG CHAR(11) DEFAULT '',/* C 11  0   Numero de documento del Representante Legal*/
   CODI_ALMA  CHAR(4) DEFAULT '',/*C  4  0   Codigo del almacen donde se realizara la Inspeccion*/
   TDIR_ALMA  VARCHAR(80) DEFAULT '',/*C 80  0   Direccion del Almacen donde se realizara la Inspeccion*/
   TDESCRIPC1 VARCHAR(85) DEFAULT '', /*C 85  0   Descripcion del Motivo de Sustenta la Solicitud de Aforoidad Emisora*/
   TDESCRIPC2 VARCHAR(85) DEFAULT '',/*C 85  0   Descripcion del Motivo de Sustenta la Solicitud de Aforoidad Emisora*/
   TDESCRIPC3 VARCHAR(85) DEFAULT '',/*  0   Descripcion del Motivo de Sustenta la Solicitud de Aforoidad Emisora*/
   TIPO_MERCA CHAR(2) DEFAULT "",    /*Tipo de Mercancia */    
   PRIMARY KEY (N_ORDEN,TDOC,NDOC),
   CONSTRAINT FK_SLF_DGA FOREIGN KEY(N_ORDEN) REFERENCES DGA(N_ORDEN));
   CREATE INDEX SLF ON SLF(N_ORDEN);

/*DIG (DIGITALIZACION DE DESPACHOS )*/
CREATE TABLE IF NOT EXISTS DIG(
   N_ORDEN   CHAR(11) NOT NULL,         /*C  9  0   N� de Orden de despacho*/
   TIPO_DOC  CHAR(3) DEFAULT "",        /*C  3  0 Tipo de Documento Digitalizado*/
   NUME_DOC  VARCHAR(40) DEFAULT "",    /*C 40  0 Numero de Documento Digitalizado*/
   FECH_DOC  DATE,                      /* D  8  0 Fecha del documento Digitalizado*/
   CORRELA   CHAR(3) DEFAULT "",        /* C  3  0 Correlativo del Tipo de Documento*/
   ARCH_TIF  VARCHAR(25) DEFAULT "",    /* C 25  0 Nombre del Archivo Digitalizado indicado por Aduanas*/
   ANTES_TIF VARCHAR(80) DEFAULT "",    /*C 80  0 Nombre del Archivo Scaneado dado por la Agencia*/
   FLAG1     NUMERIC(1,0) DEFAULT 0,    /*N  1  0 Flag indicador de los archivos que se van a enviar a la Aduana*/
   FLAG2     NUMERIC(1,0) DEFAULT 0,    /*N  1  0 Flag indicador de los archivos que ya se han enviado a la Aduana*/
   TAMANO    NUMERIC(10,0) DEFAULT 0,   /*  0 Para el tama�o del archivo digitalizado*/
   FCH_NUMER DATE,                      /*   8  0 Fecha de numeracion del envio*/
   FLAG3     NUMERIC(1,0) DEFAULT 0,     /* N  1  0 Flag indicador de los archivos para la Anulacion Parcial*/
   PRIMARY KEY (N_ORDEN,TIPO_DOC,CORRELA),
   CONSTRAINT FK_DIG_DGA FOREIGN KEY(N_ORDEN) REFERENCES DGA(N_ORDEN));
   CREATE INDEX DIG ON DIG(N_ORDEN);

/******************************************************************************************/

/* EMB(ARCHIVO ADICIONAL DE EMBARQUES PARA EL TRANSBORDO "81")*/
CREATE TABLE IF NOT EXISTS EMB(
   N_ORDEN   	CHAR(11) NOT NULL,	     /*C  9  0 //Numero de Orden*/
   NUME_SERIE	NUMERIC(4,0) DEFAULT 0,	     /*N  4  0 //Numero de Serie del Transbordo*/
   SECU_EMB  	NUMERIC(4,0) DEFAULT 0,      /*N  4  0 //Secuencia de Embarque*/
   FECH_EMB  	DATETIME,	             /*D  8  0 //Fecha de Embarque*/
   CANT_BULT 	DECIMAL(14,3) DEFAULT 0.000, /*N 14  3 //Cantidad de Bultos Embarcados*/
   NAVE      	VARCHAR(25)  DEFAULT '',     /*C 25  0 //Nombre de la Nave*/
   EMPR_TRANS	CHAR(4)  DEFAULT '',	     /*C  4  0 //Empresa de transporte de Salida*/
   FCHNUMER  	DATE,	                     /*D  8  0 //Fecha de Numeracion de la Regularazcion del Embarque*/
   ELEGIDO   	NUMERIC(1,0) DEFAULT 0,      /*N  1  0 //Indicador que ha sido elegido para ser enviado*/
   MANIF_SAL    VARCHAR(12) DEFAULT '',      /*        //Numero de Manifiesto de Salida del Embarque */
   LUG_CARGA    VARCHAR(3) DEFAULT '',    /* TIPO LUGAR DE CARGA */
   TIPO_TRANSP  VARCHAR(2) DEFAULT '',    /* CODIGO TIPO DE TRANSPORTISTA */
   PORTUARIO    VARCHAR(11) DEFAULT '',   /* OPERADOR PORTUARIO */
   KBR          DECIMAL(15,3) DEFAULT 0.00,   /* PESO BRUTO POR EMBARQUE */
   NRODET_SAL   NUMERIC(3,0) DEFAULT 0.00,   /* PESO BRUTO POR EMBARQUE */
   TIPOMAN_SAL  CHAR(2) DEFAULT "",   /* PESO BRUTO POR EMBARQUE */
   DOCTRANS_SAL VARCHAR(30) DEFAULT "", 
   PRIMARY KEY(N_ORDEN,SECU_EMB,NUME_SERIE),
   CONSTRAINT FK_EMB_DGA FOREIGN KEY(N_ORDEN) REFERENCES DGA(N_ORDEN));
   CREATE INDEX EMB ON EMB(N_ORDEN);

/*******************************************************************************************/

/* REE(ARCHIVO ADICIONAL PARA REEXPEDICIONES Y DEVOLUCIONES "85")*/
CREATE TABLE IF NOT EXISTS REE(
   N_ORDEN   	CHAR(11) NOT NULL,	/*C  9  0*/
   CORREL       NUMERIC(4,0) NOT NULL,   
   NUME_FACTU	VARCHAR(40) DEFAULT '',	/*C 40  0*/
   FECH_FACTU	DATE,           	/*D  8  0*/
   PRIMARY KEY(N_ORDEN,CORREL),
   CONSTRAINT FK_REE_DGA FOREIGN KEY(N_ORDEN) REFERENCES DGA(N_ORDEN));
   create index REE on REE(n_orden);

/*******************************************************************************************/

/* IVD (INDICADOR VARIABLE DE DUA PARA XML)*/
CREATE TABLE IF NOT EXISTS IVD(
   N_ORDEN     CHAR(11) NOT NULL,	/*C  9  0*/
   CODIGO      CHAR(2)  DEFAULT '',
   DETALLE     VARCHAR(20) DEFAULT '',
   PRIMARY KEY(N_ORDEN,CODIGO),
   CONSTRAINT FK_IVD_DGA FOREIGN KEY(N_ORDEN) REFERENCES DGA(N_ORDEN));
   create index IVD on IVD(n_orden);

/*******************************************************************************************/

/* RGC(RECTIFICACION DE GUIAS CONSOLIDADAS PARA IMPORTACION SIMPLIFICADAS (PARTE DE LA 18))*/
CREATE TABLE IF NOT EXISTS RGC(
   N_ORDEN     CHAR(11) NOT NULL,	/*C  9  0*/
   N_SERIE     NUMERIC(4,0) DEFAULT 0,  
   NUM_ITEM    NUMERIC(4,0) DEFAULT 0,  
   NUMBLGUIA   VARCHAR(25) DEFAULT '',
   CANT_BULTO  DECIMAL(15,3) DEFAULT 0.000,
   PESO_BRUTO  DECIMAL(15,3) DEFAULT 0.000,
   FOB_CONO    DECIMAL(12,2) DEFAULT 0.00,
   CONSIGNA    CHAR(5) DEFAULT '',
   OBS1        VARCHAR(70) DEFAULT '',
   NOM_CONS    VARCHAR(80) DEFAULT '', 
   DIR_CONS    VARCHAR(60) DEFAULT '',
   NUMBLGUIA2  VARCHAR(25) DEFAULT '',
   PRIMARY KEY(N_ORDEN,N_SERIE,NUMBLGUIA),
   CONSTRAINT FK_RGC_SEA FOREIGN KEY(N_ORDEN,N_SERIE) REFERENCES SEA(N_ORDEN,N_SERIE));
   create index RGC on RGC(n_orden,N_SERIE);

/* FVS (FACTURA DE VENTA SUCESIVA PARA XML)*/
CREATE TABLE IF NOT EXISTS FVS(
   N_ORDEN     CHAR(11) NOT NULL,	/*C  9  0*/
   NUME_SECUP  CHAR(3)  DEFAULT '',
   NUME_SECUF  CHAR(3)  DEFAULT '',
   NFAC_VTASU  CHAR(40) DEFAULT '',
   FFAC_VTASU  DATE,
   IMPO_VTASU  NUMERIC(13,3) DEFAULT 0,
   PRIMARY KEY(N_ORDEN,NUME_SECUP,NUME_SECUF,NFAC_VTASU),
   CONSTRAINT FK_FVS_DGA FOREIGN KEY(N_ORDEN) REFERENCES DGA(N_ORDEN));
create index FVS on FVS(n_orden,NUME_SECUP,NUME_SECUF,NFAC_VTASU);

/*CAD(Cuadro Consolidado de Adm.Reexp.en el mismo Estado)*/
CREATE TABLE IF NOT EXISTS CAD(
   N_ORDEN      CHAR(11) NOT NULL ,          /*N� de orden del Cuadro*/
   REG          NUMERIC(6,0) NOT NULL,       /*correlacion de ITems*/     
   SERIE_PIT	NUMERIC(4,0) DEFAULT 0,      /*Serie del PIT*/
   ORDEN_ASOC 	CHAR(11) DEFAULT "",         /*Orden asociada*/
   TIPO_OPER 	CHAR(3) DEFAULT "",          /*Tipo de Operacion*/
   C_ADUANA  	CHAR(3) DEFAULT "",          /*Codigo de Aduana de Declaracion*/
   ANIO     	CHAR(4) DEFAULT "",          /*Anio de Declaracion*/
   N_DECLAR  	CHAR(6) DEFAULT "",          /*Numero de Declaracion*/
   N_SERIE   	NUMERIC(4,0) DEFAULT 0,      /*N  4  0**** ********Numero de serie*/
   DESCRIPCIO   VARCHAR(40) DEFAULT "",      /*C 40  0** ***  *****Descripcion*/
   NETO      	DECIMAL(20,3) DEFAULT 0.000, /*N 20  3*************Cantidad de Neto*/
   U_NETO    	CHAR(3) DEFAULT "",          /*C  3  0*************Unidad de medida de Neto*/
   MERMA     	DECIMAL(20,3) DEFAULT 0.000, /*N 20  3*************Cantidad de Mermas*/
   U_MERMA   	CHAR(3) DEFAULT "",          /*C  3  0*************Unidad de medida de Mermas*/
   TOTAL     	DECIMAL(20,3) DEFAULT 0.000, /*N 20  3*************Cantidad de Total*/
   U_TOTAL   	CHAR(3) DEFAULT "",          /*C  3  0*************Unidad de medida de Total*/
   PRIMARY KEY(N_ORDEN,REG),
   CONSTRAINT FK_CAD_APE FOREIGN KEY(ORDEN_ASOC) REFERENCES APE(N_ORDEN),
   CONSTRAINT FK_CAD_DGA FOREIGN KEY(N_ORDEN) REFERENCES DGA(N_ORDEN));
   CREATE INDEX CAD ON CAD(N_ORDEN,REG);

/********************************************************************************************/
/******************               FORMATO B                     *****************************/
/********************************************************************************************/

/* DJA (DECLARACION JURADA POR CADA PROVEEDOR DEL DESPACHO)*/
CREATE TABLE IF NOT EXISTS DJA(
   NUME_SECUP	CHAR(3) NOT NULL,	/*C  2  0 //Numero de secuencia de DVA*/
   COD_PROV  	CHAR(10) DEFAULT '',	/*C 10  0 //codigo del proveedor*/
   N_ORDEN   	CHAR(11) NOT NULL,	/*C  9  0 //Numero de orden*/
   NATURALEZA	CHAR(2) DEFAULT '11',	/*C  2  0 //naturaleza*/
   TERM1     	CHAR(3) DEFAULT '',	/*C  3  0 //Codigo incoterm*/
   TERM2     	VARCHAR(25) DEFAULT '',	/*C 25  0 //Lugar incoterm*/
   FORM_ENVIO	CHAR(1) DEFAULT '1',	/*C  1  0 //forma de envio*/
   NUME_ENVIO	NUMERIC(8,0) DEFAULT 1,	/*N  8  0 //numero de envios*/
   VINCULAC  	CHAR(1) DEFAULT '',	/*C  1  0 //Vinc.con proveedor extranjero*/
   INFL_VINCU	CHAR(1) DEFAULT '',	/*C  1  0 //Influencia de la vinculacion en precio*/
   PVATR12B  	CHAR(1) DEFAULT '',	/*C  1  0*Aprox.valor transac.a Art. 1.2 B) OMC*/
   PRECE1    	CHAR(1) DEFAULT '1',	/*C  1  0*Restricciones cesion/utilizacion art 1 OMC*/
   PCONMCIA  	CHAR(1) DEFAULT '2',	/*C  1  0*Depende venta o precio con mercancias a valorar*/
   PDECOND   	CHAR(1) DEFAULT '2',	/*C  1  0*Puede determinarse valor con condiciones*/
   SPAG_INDIR	CHAR(1) DEFAULT '2',	/*C  1  0*Pago indirecto de las mercancias*/
   PDESRET   	CHAR(1) DEFAULT '2',	/*C  1  0*descuentos retroactivos*/
   SDER_LICEN	CHAR(1) DEFAULT '2',	/*C  1  0*canones y derechos de licencia de mercancia*/
   VENT_CONDI	CHAR(1) DEFAULT '2',	/*C  1  0*Venta condicionada por un acuerdo*/
   CONTMCIA  	CHAR(1) DEFAULT '2',	/*C  1  0*contrato relativo a las mercancias*/
   CONTSUMI  	CHAR(1) DEFAULT '2',	/*C  1  0*contrato global de suministro larga duracion*/
   CLAUREVI  	CHAR(1) DEFAULT '2',	/*C  1  0*clausula de revisi�n de precio*/
   INTIMPCLI 	CHAR(1) DEFAULT '2',	/*C  1  0*Inetemediario imp. a solicitud cliente*/
   DIFVALASI 	CHAR(1) DEFAULT '2',	/*C  1  0*Diferente valor asignado emp.verificadora*/
   COND16    	CHAR(1) DEFAULT '',	/*C  1  0*OTros*/
   COND17    	CHAR(1) DEFAULT '',	/*C  1  0*OTros*/
   COND18    	CHAR(1) DEFAULT '',	/*C  1  0*OTros*/
   COND19    	CHAR(1) DEFAULT '',	/*C  1  0*OTros*/
   COND20    	CHAR(1) DEFAULT '',	/*C  1  0*OTros*/
   CANT_FACTU	NUMERIC(4,0) DEFAULT 1,	/*N  4  0*Total facturas*/
   PRED_FACT 	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6*Precio neto segun factura en dolares*/
   VTA_SUCESI	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6*Monto total de venta sucesiva*/
   FLETE_FACT	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //Flete  de la factura*/
   SEGUR_FACT	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //Seguro de la factura*/
   DGASTO1   	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //815 Gastos de transporte decarga y manipulacion*/
   DGASTO2   	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6// 816 Otros gastos Diferencias*/
   DGASTO3   	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //812 Otros gastos de la Factura*/
   DGASTO4   	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //813 Otros gastos de la Factura*/
   DGASTO5   	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //814 Otros gastos de la Factura*/
   DADIC1    	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //821  Adiciones 1*/
   DADIC2    	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //822  Adiciones 2*/
   DADIC3    	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //823  Adiciones 3*/
   DADIC4    	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //8231 Adiciones 4*/
   DADIC5    	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //8232 Adiciones 5*/
   DADIC6    	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //8233 Adiciones 6*/
   DADIC7    	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //8234 Adiciones 7*/
   DADIC8    	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //824  Adiciones 8*/
   DADIC9    	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //825  Adiciones 9*/
   DDEDUC1   	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //851 Otros gastos de la Factura*/
   DDEDUC2   	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //852 Otros Gastos de la Factura*/
   DDEDUC3   	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //853 Otros Gastos de la Factura*/
   DDEDUC4   	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //854 Otros gastos de la Factura*/
   DDEDUC5   	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //855 Otros gastos de la factura*/
   DFLETE2   	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //831*/
   COD_P_ADQ 	CHAR(2) DEFAULT '',	/*C  2  0 //Pais de Adquisicion de Productos del Pacto Andino*/
   CANT_DAV  	NUMERIC(4,0) DEFAULT 0,	/*N  4  0 //Correlacion de Facturas del Pacto Andino*/
   FOB_FACT  	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //Fob de la Factura acumulado por DAV*/
   CARACESTIM	CHAR(1) DEFAULT '',     	/*C  1  0 //Pregunta para DAV Casillero (80) Tiene caracter estimativo*/
   CONT_OTRO    CHAR(1) DEFAULT "N",            /*C  1  0 //Pregunta si lleva contrato u Otro Docuemento */   
   NUM_CONTRA   VARCHAR(20) DEFAULT '',     	/* C 20  0 //Numero de Contrato*/
   FCH_CONTRA   DATE,                           /* D  8  0 //Fecha de Contrato*/
   OTRODOC      VARCHAR(20) DEFAULT '',     	/*C 20  0 //Tipo de Otro Documento*/
   FORMAPAGO    CHAR(2) DEFAULT '',     	/*C  2  0 //Codigo de forma de Pago*/
   OTROFORMA    VARCHAR(20) DEFAULT '',     	/*C 20  0 //Otros en forma de pago*/
   MEDIOPAGO    CHAR(2) DEFAULT '',     	/*C  2  0 //Codigo de medio de pago*/
   OTROMEDIO    VARCHAR(20) DEFAULT '',     	/*C 20  0 //Otros en medio de pago*/
   OTRONATURA   VARCHAR(20) DEFAULT '',     	/*C 20  0 //Otros en Naturaleza de Transaccion*/
   COD_RESTRI   CHAR(2) DEFAULT '',     	/*C  2  0 //Codigo de Tipo de Restriccion*/
   COD_CONDI    CHAR(2) DEFAULT '',     	/*C  2  0 //Codigo de condicion o contraprestacion*/
   OTR_CONDI    VARCHAR(20) DEFAULT '',     	/*C 20  0 //Otros en condicion o contraprestacion*/
   COD_VINC     CHAR(4) DEFAULT '',     	/*C  2  0 //Codigo de Tipo de Vinculacion*/
   C_DOCORI     CHAR(4) DEFAULT '',     	/*C  4  0 //Codigo del Comprador Inicial*/
   T_DOCORI     CHAR(1) DEFAULT '',     	/*C  1  0 //tipo de documento del comprador inicial/tipo de Documento del Importador(33)/Pregunta si tiene Anexo 1 (40)*/
   N_DOCORI     CHAR(11) DEFAULT '',     	/*C 11  0 //Numero del documento del comprador inicial/Numero de Documento del Importador(33)*/
   D_DOCORI     VARCHAR(60) DEFAULT '',     	/*C 60  0 //Razon social del comprador inicial  / Descripcion de Nota de Embarque (40,41) y Volante de Despacho/Descripcion del Material de Guerra/Sector Competente (25)*/
   COD_INTERM   CHAR(4) DEFAULT '',     	/*C  4  0 //Codigo de Intermediario*/
   PAIS_PROV    CHAR(2) DEFAULT '',     	/*C  2  0 //Pais del Proveedor*/
   CANT_ITEMS	NUMERIC(4,0) DEFAULT 1,  /*N  4 0*Cantidad de Items*/
   PRE_FACT     DECIMAL(17,6) DEFAULT 0.000000, /*N 17  6*Precio neto segun factura*/
   AJUSTE    	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //Total Ajuste (Suma todos los gastos del 8.2)*/
   TOT_DEDUC 	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //Total deducciones (Suma de todos los gastos 8.5)*/
   TERM3        CHAR(1) DEFAULT "",             /*A�o del Incoterm */
   NIVEL_COM 	CHAR(1) DEFAULT '',	        /*C  1  0 NIVEL COMERCIAL PARA LA DECLARACION DE VALOR*/
   OTR_NIVC     VARCHAR(20) DEFAULT "",         /*  C 20  0 //Otro Nivel Comercial del Importador*/
   CONDI_PRO    CHAR(1) DEFAULT "",             /*C  1  0 //Condicion del Proveedor */
   OTR_CONDP    VARCHAR(20) DEFAULT "",         /*C 20  0 //otras Condiciones del Proveedor */
   TPROVIS    	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //Total provisional solo para DHL */
   NUME_ENVP    NUMERIC(8,0) DEFAULT 0,         /* N  8  0 //NUMERO DE ENVIO PARCIAL PARA FORM_ENVIO 2*/
   PRIMARY KEY(N_ORDEN,NUME_SECUP),
   CONSTRAINT FK_DJA_DGA FOREIGN KEY(N_ORDEN) REFERENCES DGA(N_ORDEN),
   CONSTRAINT UQ_DJA_1 UNIQUE(N_ORDEN,COD_PROV,TERM1,NATURALEZA),
   CONSTRAINT FK_DJA_ITR FOREIGN KEY(COD_INTERM) REFERENCES ITR(CODIGO),
   CONSTRAINT FK_DJA_PRA FOREIGN KEY(COD_PROV) REFERENCES PRA(CODIGO));
   CREATE INDEX DJA ON DJA(N_ORDEN);

/* DVF(FACTURAS POR PROVEEDOR Y ORDEN )*/
CREATE TABLE IF NOT EXISTS DVF(
   NUME_SECUF	CHAR(3) NOT NULL,	/*C  3  0 //Numero de Secuencia de la FACTURA*/
   NUM_FACT  	VARCHAR(40) DEFAULT '',	/*C 40  0 //Numero de factura*/
   N_ORDEN   	CHAR(11) NOT NULL,/*C  9  0 //N� de Orden de despacho*/
   NUME_SECUP	CHAR(3) NOT NULL,	/*C  2  0 //Numero de Secuencia de la DVA*/
   FCH_FACT  	DATE,	/*D  8  0 //fecha de factura*/
   CODFOB    	CHAR(3) DEFAULT 'USD',	/*C  3  0 //Codigo de moneda*/
   FACTOR    	DECIMAL(13,10) DEFAULT 1.0000000000,	/*N 13 10 //factor para otra moneda*/
   PRE_FACT  	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //Precio segun factura en moneda original*/
   PRED_FACT 	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //Precio segun factura en Dolares*/
   TVAL_ITEMD	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //Precio de factura para Aduanas, para impresion y envio*/
   FLAG_GAST 	CHAR(1) DEFAULT 'N',	/*C  1  0 //Flag que permite editar los gastos,ajustes u otros*/
   DGASTO1   	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //815 Gastos de transporte decarga y manipulacion*/
   DGASTO2   	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6// 816 Otros gastos Diferencias*/
   DGASTO3   	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //812 Otros gastos de la Factura*/
   DGASTO4   	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //813 Otros gastos de la Factura*/
   DGASTO5   	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //814 Otros gastos de la Factura*/
   DADIC1    	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //821  Adiciones 1*/
   DADIC2    	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //822  Adiciones 2*/
   DADIC3    	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //823  Adiciones 3*/
   DADIC4    	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //8231 Adiciones 4*/
   DADIC5    	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //8232 Adiciones 5*/
   DADIC6    	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //8233 Adiciones 6*/
   DADIC7    	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //8234 Adiciones 7*/
   DADIC8    	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //824  Adiciones 8*/
   DADIC9    	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //825  Adiciones 9*/
   DDEDUC1   	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //851 Otros gastos de la Factura*/
   DDEDUC2   	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //852 Otros Gastos de la Factura*/
   DDEDUC3   	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //853 Otros Gastos de la Factura*/
   DDEDUC4   	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //854 Otros gastos de la Factura*/
   DDEDUC5   	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6// 855 Otros gastos de la factura*/
   DFLETE2   	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //831*/
   VTA_SUCESI	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //Total Vta. Sucesiva por Factura (suma de lo prorrateado por Item)*/
   FOB_FACT  	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //Fob de la factura (le falta venta sucesiva)*/
   FLETE_FACT	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //Total flete por Factura (Suma prorrateada de los items de esta factura )*/
   SEGUR_FACT	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //Total Seguro por Factura (Suma prorrateada o de arancel de los items de esta factura )*/
   AJUSTE    	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //Total Ajuste (Suma todos los gastos del 8.2)*/
   TOT_DEDUC 	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //Total deducciones (Suma de todos los gastos 8.5)*/
   UNI_COMER 	DECIMAL(18,3) DEFAULT 0.000,	/*N 18  3 //Total unidades comerciales*/
   COD_P_ADQ 	CHAR(3) DEFAULT '',	/*C  3  0 //Pais de Embarque*/
   COD_P_PRO 	CHAR(3) DEFAULT '',	/*C  3  0 //Pais de Origen*/
   CANT_ITEM 	NUMERIC(4,0) DEFAULT 1,	/*N  4  0"//Total items de la factura*/
   FLETE_TRAN	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //Flete de la factura en transaccion*/
   SEGUR_TRAN	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //Seguro de la factura en transaccion*/
   AJUST_INF 	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //Diferencia entre el Fob del C.I. y la Factura*/
   TVAL_ITEM 	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //Valor total de los items en moneda de Transaccion*/
   PRORRAJUST	NUMERIC(1,0) DEFAULT 1,	/*N  1  0 //Flag que determina si se van a prorratear los Ajustes*/
   PRORRGASTO	NUMERIC(1,0) DEFAULT 1,	/*N  1  0*/
   FLAG_AJUST	CHAR(1) DEFAULT 'N',	/*C  1  0 //Flag que determina si hay ajustes*/
   FLAG_DEDUC	CHAR(1) DEFAULT 'N',	/*C  1  0 //Flag que determina si hay deducciones*/
   KBR       	DECIMAL(15,3) DEFAULT 0.000,	/*N 15  3 //KILOS BRUTO PARA PRORRATEAO POR FACTURA*/
   KNE       	DECIMAL(15,3) DEFAULT 0.000,	/*N 15  3 //KILOS NETO PARA PRORRRATEO POR FACTURA*/
   COD_PROV  	CHAR(10) DEFAULT '',	/*C 10  0 ******** CAMPOS PARA LA DECLARACION DE FACTURAS PARA SIMPLIFICADAS*/
   FECH_EXPO 	DATE,	                /*D  8  0 //FECHA DE EMBARQUE DE MERCANCIA*/
   TIPO_ENVIO	CHAR(1) DEFAULT '1',	/*C  1  0 //FLAG QUE INDICA TIPO DE DOCUMENTO: '1' FACTURA, '2' DECLARACION JURADA*/
   PROVEE_A  	CHAR(1) DEFAULT '',	/*C  1  0 //TIENE USTED VINCULACION CON SU PROVEEDOR EXTRANJERO? '1':SI '0':NO*/
   PROVEE_B  	CHAR(1) DEFAULT '',	/*C  1  0 //HA INFLUIDO LA VINCULACION EN EL PRECIO? '1':SI '0':NO*/
   PROVEE_C  	CHAR(1) DEFAULT '',	/*C  1  0 //EXISTEN PAGOS INDIRECTOS RELATIVOS A LAS MERCANCIAS QUE SE IMPORTAN? '1':SI '0':NO*/
   PROVEE_D  	CHAR(1) DEFAULT '',	/*C  1  0 //EXISTEN CANONES O DERECHOS DE LICENCIAS RELATIVAS A && LAS MERCANCIAS IMPORTADAS QUE UD. ESTA OBL*/
   PROVEE_E  	CHAR(1) DEFAULT '',	/*C  1  0 //ESTA LA VENTA CONDICIONADA POR UN ACUERDO SEGUN LA CUAL UNA PARTE DEL PRODUCTO DE CUALQUIER VENTA*/
   CANT_DAV  	NUMERIC(4,0) DEFAULT 0,	/*N  4  0 //Correlacion de Facturas de la Declaracion Andina de Valor*/
   NUMBLGUIA 	CHAR(25) DEFAULT '',	/*C 25  0 //N� de BL/Guia*/
   NUMDET    	CHAR(5) DEFAULT '',	/*C  3  0 **Numero de detalle en caso de mas de un Bl/Guia*/
   FCH_EMB   	DATE,            	/*D  8  0 **Fecha de embarque*/
   COD_P_EMB 	CHAR(6) DEFAULT '',	/*C  6  0 //Codigo de puerto de Embarque*/
   CODPAISADQ	CHAR(3) DEFAULT '',	/*C  3  0 //Codigo del Pais de Adquisici�n*/
   PRORR_GTO1	CHAR(1) DEFAULT 'S',	/*C  1  0 //Indica si prorratea el Gasto1 a los items*/
   PRORR_GTO2	CHAR(1) DEFAULT 'S',	/*C  1  0 //Indica si prorratea el Gasto2 a los items*/
   PRORR_GTO3	CHAR(1) DEFAULT 'S',	/*C  1  0 //Indica si prorratea el Gasto3 a los items*/
   PRORR_GTO4	CHAR(1) DEFAULT 'S',	/*C  1  0 //Indica si prorratea el Gasto4 a los items*/
   PRORR_GTO5	CHAR(1) DEFAULT 'S',	/*C  1  0 //Indica si prorratea el Gasto5 a los items*/
   PRORR_ADI1	CHAR(1) DEFAULT 'S',	/*C  1  0 //Indica si prorratea la Adicion 1 a los items*/
   PRORR_ADI2	CHAR(1) DEFAULT 'S',	/*C  1  0 //Indica si prorratea la Adicion 2 a los items*/
   PRORR_ADI3	CHAR(1) DEFAULT 'S',	/*C  1  0 //Indica si prorratea la Adicion 3 a los items*/
   PRORR_ADI4	CHAR(1) DEFAULT 'S',	/*C  1  0 //Indica si prorratea la Adicion 4 a los items*/
   PRORR_ADI5	CHAR(1) DEFAULT 'S',	/*C  1  0 //Indica si prorratea la Adicion 5 a los items*/
   PRORR_ADI6	CHAR(1) DEFAULT 'S',	/*C  1  0 //Indica si prorratea la Adicion 6 a los items*/
   PRORR_ADI7	CHAR(1) DEFAULT 'S',	/*C  1  0 //Indica si prorratea la Adicion 7 a los items*/
   PRORR_ADI8	CHAR(1) DEFAULT 'S',	/*C  1  0 //Indica si prorratea la Adicion 8 a los items*/
   PRORR_ADI9	CHAR(1) DEFAULT 'S',	/*C  1  0 //Indica si prorratea la Adicion 9 a los items*/
   PRORR_DED1	CHAR(1) DEFAULT 'S',	/*C  1  0 //Indica si prorratea la Deduccion 1 a los items*/
   PRORR_DED2	CHAR(1) DEFAULT 'S',	/*C  1  0 //Indica si prorratea la Deduccion 2 a los items*/
   PRORR_DED3	CHAR(1) DEFAULT 'S',	/*C  1  0 //Indica si prorratea la Deduccion 3 a los items*/
   PRORR_DED4	CHAR(1) DEFAULT 'S',	/*C  1  0 //Indica si prorratea la Deduccion 4 a los items*/
   PRORR_DED5	CHAR(1) DEFAULT 'S',	/*C  1  0 //Indica si prorratea la Deduccion 5 a los items*/
   NFAC_VTASU	VARCHAR(40) DEFAULT '',	/*C 40  0 //Numero de la Factura de la Venta Sucesiva*/
   FFAC_VTASU	DATE,            	/*D  8  0 //Fecha de la Factura de la Venta Sucesiva*/
   INDI_FACDD	CHAR(1) DEFAULT '',	/*C  1  0 //Indicador del Documento si es factura o declaracion Jurada*/
   CODGASTO1    CHAR(3) DEFAULT '',             /*  0 //Codigo de moneda*/
   GASTO1       DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //815 Gastos de transporte decarga y manipulacion*/
   FACTORGTO1   DECIMAL(13,10) DEFAULT 1.0000000000,	/*13 10 //factor para otra moneda*/
   CODGASTO2    CHAR(3) DEFAULT '',             /*C  3  0 //Codigo de moneda*/
   FACTORGTO2   DECIMAL(13,10) DEFAULT 1.0000000000,	/* N 13 10 //factor para otra moneda*/
   GASTO2       DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6// 816 Otros gastos Diferencias*/
   CARPET_EXP   VARCHAR(12) DEFAULT '',         /* Campos para registrar el Numero de Carpeta de Reipley (EXPEDITOR) */
   PRIMARY KEY(N_ORDEN,NUME_SECUP,NUME_SECUF),
   CONSTRAINT UQ_DVF_1 UNIQUE(N_ORDEN,NUME_SECUP,NUM_FACT),
   CONSTRAINT FK_DVF_PRV FOREIGN KEY(COD_PROV) REFERENCES PRV(CODIGO),
   CONSTRAINT FK_DVF_DJA FOREIGN KEY(N_ORDEN,NUME_SECUP) REFERENCES DJA(N_ORDEN,NUME_SECUP));
   CREATE INDEX DVF_N_ORDEN ON DVF(N_ORDEN);
   CREATE INDEX DVF_NUM_FACT ON DVF(NUM_FACT);

/* ADA (ITEMS DEL DESPACHO POR FACTURA,PROVEEDOR Y ORDEN )*/
CREATE TABLE IF NOT EXISTS ADA(
   N_ORDEN   	CHAR(11) NOT NULL,               /*C  9  0     N� de Orden de despacho - DATOS PRINCIPALES -*/
   NUME_SECUP 	CHAR(3) NOT NULL,                /*C  2  0  // C�digo del  proveedor -- DATOS DE LOS ITEMS ---*/
   NUME_SECUF 	CHAR(3) NOT NULL,       	 /*C  3  0  // Numero de Secuencia de la Factura*/
   NUM_ITEM  	NUMERIC(4,0) NOT NULL, 	         /*N  4  0  // Nro. de Item secuencial por Factura*/
   NUM_ITEMP 	NUMERIC(4,0) NOT NULL, 	         /*N  4  0  // Nro. de Item secuencial por Proveedor*/
   NUM_ITEMO 	NUMERIC(4,0) NOT NULL, 	         /*N  4  0  // Nro. de Item secuencial por Orden*/
   PARTIDA   	CHAR(10)  DEFAULT '', 	         /*C 10  0   //Partida Nandina*/
   CODIGO    	CHAR(6)  DEFAULT '', 	         /*C  6  0   //Codigo de producto*/
   COD_P_PRO 	CHAR(3)  DEFAULT '', 	         /*C  3  0   //Pais de origen*/
   MERCANCIA 	VARCHAR(35)  DEFAULT '', 	 /*C 35  0   //mercancia (Nombre comercial)*/
   MARCA     	VARCHAR(30)  DEFAULT '', 	 /*C 30  0   //marca     (Marca )*/
   MODELO    	VARCHAR(27)  DEFAULT '', 	 /*C 27  0   //modelo    (modelo)*/
   DETACARACT   CHAR(1)      DEFAULT 'C',        /*Flag acceder a la pantalla de las Caracteristicas  */
   CARACTERI1 	VARCHAR(150)  DEFAULT '', 	 /*C150  0   //Caracteristica 1*/
   CARACTERI2 	VARCHAR(150)  DEFAULT '', 	 /*C150  0   //Caracteristica 2*/
   CARACTERI3 	VARCHAR(150)  DEFAULT '', 	 /*C150  0   //Caracteristica 3*/
   CARACTERI4 	VARCHAR(150)  DEFAULT '', 	 /*C150  0   //Caracteristica 4*/
   IDENTSOFT 	CHAR(1)  DEFAULT '', 	         /*C  1  0  //Identificador de software*/
   POSINFVERI 	CHAR(1)  DEFAULT '0', 	         /*C  1  0  //Posici�n frente al Inf.Verificaci�n*/
   TIPO_VALOR 	CHAR(1)  DEFAULT '1', 	         /*C  1  0  //Tipo de VAlor*/
   FVAL_PROVI 	DATE, 	                         /*D  8  0   //Fecha estimada de valor provisional*/
   VALOR_ESTI 	DECIMAL(17,6) DEFAULT 0.000000,  /*N 17  6   //Valor definitivo estimado*/
   DEDUCDISTI 	CHAR(1)  DEFAULT '2', 	         /*C  1  0  //Deducciones distinguidas*/
   VAL_ITEM  	DECIMAL(17,6) DEFAULT 0.000000,  /*N 17  6   //Precio del item segun Factura*/
   VAL_ITEMD 	DECIMAL(17,6) DEFAULT 0.000000,  /*N 17  6   //Precio en dolares del Item segun Factura*/
   PRED_FACT 	DECIMAL(17,6) DEFAULT 0.000000,  /*N 17  6   //Precio segun factura x Item en Dolares*/
   FOB_ITEM  	DECIMAL(17,6) DEFAULT 0.000000,  /*N 17  6   //Fob del Item en Dolares*/
   FOBUNI    	DECIMAL(17,6) DEFAULT 0.000000,  /*N 17  6   //Fob Unitario*/
   AJUSTE    	DECIMAL(17,6) DEFAULT 0.000,	 /*N 13  3 Monto del ajuste realizado por el Agente de aduanas en dolares*/
   VTA_SUCESI 	DECIMAL(17,6) DEFAULT 0.000000,	 /*N 17  6   //Valor prorrateado por serie de la venta Sucesiva*/
   FLESDOL   	DECIMAL(17,6) DEFAULT 0.000, 	 /*N 17  6   //Flete en d�lares Prorrateado de los Kilos Netos Ingresado por la B*/
   SEGSDOL   	DECIMAL(17,6) DEFAULT 0.000, 	 /*N 17  6   //Seguro en d�lares Prorrateado del Valor del Item cuando la Factura esta en CFR o CIF*/
   NSERIE_A  	NUMERIC(4,0) DEFAULT 0, 	 /*N  4  0   //Numero de serie en el A al cual pertenece el Item*/
   FLAG_BASE 	CHAR(3)  DEFAULT '001',	         /*C  3  0   //Indicador para Agrupamiento de Ordenes*/
   OBSERVAC1 	VARCHAR(150)  DEFAULT '', 	 /*C150        Observaciones de cada Item*/
   OBSERVAC2 	VARCHAR(150)  DEFAULT '', 	 /*C150        Observaciones de cada Item*/
   OBSERVAC3 	VARCHAR(150)  DEFAULT '', 	 /*C150        Observaciones de cada Item*/
   NUME_FFCO 	CHAR(5)  DEFAULT '', 	         /*C  5  0     Numero de Firmas de Certificado de Origen*/
   OBSERVAC4 	VARCHAR(150)  DEFAULT '', 	 /*C150        Observaciones de cada Item*/
   N_PARTE   	VARCHAR(25)  DEFAULT '', 	 /*C 20        Numero de parte*/
   TPROD     	CHAR(2)  DEFAULT 'N', 	         /*C  2  0   //Codigo de autorizaci�n de mercancia restringida*/
   DES_MINIMA 	CHAR(3)  DEFAULT '',  	         /*C  3        Identificacion para las Descripciones minimas*/
   KNSER     	DECIMAL(14,3) DEFAULT 0.000, 	 /*N 14  3   //Kilo Neto*/
   KBSER     	DECIMAL(14,3) DEFAULT 0.000, 	 /*N 14  3   //Kilo Bruto*/
   UNI_COMER  	DECIMAL(17,6) DEFAULT 0.000, 	 /*N 13  3*************Unidades comerciales*/
   CLAS_COMER 	CHAR(3)  DEFAULT '', 	         /*C  3  0   //clase de unidades comerciales*/
   ESTADO    	CHAR(2)  DEFAULT '',             /*C  2  0   //Estado de la mercancia*/
   NUMBLGUIA 	CHAR(25) DEFAULT '',	         /*C 25  0 //N� de BL/Guia*/
   NUMDET    	CHAR(5) DEFAULT '',       	 /*C  3  0 **Numero de detalle en caso de mas de un Bl/Guia*/
   FCH_EMB   	DATE,	                         /*D  8  0 **Fecha de embarque*/
   COD_P_EMB 	CHAR(6) DEFAULT '',	         /*C  6  0 //Codigo de puerto de Embarque*/
   NUMBULTOS 	DECIMAL(14,3) DEFAULT 0.000, 	 /*N 14  3   //Numero de bultos*/
   CLASEBULTO 	CHAR(3)  DEFAULT '', 	         /*C  3  0   //Clase de bultos*/
   UFISICAS  	DECIMAL(14,3) DEFAULT 0.000, 	 /*N 13  3   //unidades fisicas*/
   TIPOUFIS  	CHAR(12)  DEFAULT '',     	 /*C 12  0   //tipo de unidad fisica*/
   PRORR_PESO	CHAR(1)  DEFAULT '2', 	         /*C  1  0***  Para importacion indica el tipo de prorrateo para el Flete y para Exportacion indica si el peso es prorrateado*/
   FLAGKBRKNE	CHAR(1)  DEFAULT '', 	         /*C  1  0     Si esta vacio indica que peso bruto debe ser prorrateado si esta lleno Peso Bruto ingresado y ademas ("S"=Debe Prorratear el neto basado en el Bruto,"N"=No debe prorratear el Neto)*/
   GASTO1   	DECIMAL(17,6) DEFAULT 0.000000,  /*N 17  6     815 Gastos de transporte decarga y manipulacion en Transaccion*/
   DGASTO1   	DECIMAL(17,6) DEFAULT 0.000000,  /*N 17  6     815 Gastos de transporte decarga y manipulacion*/
   GASTO2   	DECIMAL(17,6) DEFAULT 0.000000,  /*N 17  6     816 Otros gastos Diferencias en Transaccion*/
   DGASTO2   	DECIMAL(17,6) DEFAULT 0.000000,  /*N 17  6     816 Otros gastos Diferencias*/
   DGASTO3   	DECIMAL(17,6) DEFAULT 0.000000,  /*N 17  6     812 Otros gastos de la Factura*/
   DGASTO4   	DECIMAL(17,6) DEFAULT 0.000000,  /*N 17  6     813 Otros gastos de la Factura*/
   DGASTO5   	DECIMAL(17,6) DEFAULT 0.000000,  /*N 17  6     814 Otros gastos de la Factura*/
   DADIC1    	DECIMAL(17,6) DEFAULT 0.000000,  /*N 17  6     821  Adiciones 1*/
   DADIC2    	DECIMAL(17,6) DEFAULT 0.000000,  /*N 17  6     822  Adiciones 2*/
   DADIC3    	DECIMAL(17,6) DEFAULT 0.000000,  /*N 17  6     823  Adiciones 3*/
   DADIC4    	DECIMAL(17,6) DEFAULT 0.000000,  /*N 17  6     8231 Adiciones 4*/
   DADIC5    	DECIMAL(17,6) DEFAULT 0.000000,  /*N 17  6     8232 Adiciones 5*/
   DADIC6    	DECIMAL(17,6) DEFAULT 0.000000,  /*N 17  6     8233 Adiciones 6*/
   DADIC7    	DECIMAL(17,6) DEFAULT 0.000000,  /*N 17  6     8234 Adiciones 7*/
   DADIC8    	DECIMAL(17,6) DEFAULT 0.000000,  /*N 17  6     824  Adiciones 8*/
   DADIC9    	DECIMAL(17,6) DEFAULT 0.000000,  /*N 17  6     825  Adiciones 9*/
   DDEDUC1   	DECIMAL(17,6) DEFAULT 0.000000,  /*N 17  6     851 Otros gastos de la Factura*/
   DDEDUC2   	DECIMAL(17,6) DEFAULT 0.000000,  /*N 17  6     852 Otros Gastos de la Factura*/
   DDEDUC3   	DECIMAL(17,6) DEFAULT 0.000000,  /*N 17  6     853 Otros Gastos de la Factura*/
   DDEDUC4   	DECIMAL(17,6) DEFAULT 0.000000,  /*N 17  6     854 Otros gastos de la Factura*/
   DDEDUC5   	DECIMAL(17,6) DEFAULT 0.000000,  /*N 17  6     855 Otros gastos de la factura*/
   TOT_DEDUC 	DECIMAL(17,6) DEFAULT 0.000000,  /*N 17  6 //Total deducciones (Suma de todos los gastos 8.5)*/
   DFLETE2   	DECIMAL(17,6) DEFAULT 0.000000,  /*N 17  6     831*/
   TIPO_MERCA	VARCHAR(25)  DEFAULT '', 	 /*C 25  0     Tipo de mercancia para la Andina de Valor*/
   RIESGOSAN 	CHAR(2)  DEFAULT '', 	         /*C  2  0     Codigo de riesgo Sanitario para Importacion*/
   FMON_PROVI	CHAR(3)  DEFAULT '', 	         /*C  3  0     codigo de moneda del valor provisional*/
   FTCA_PROVI   DATE,	                         /*D  8  0     Fecha del tipo de cambio del Valor provisional*/
   FLESER   	DECIMAL(17,6) DEFAULT 0.000, 	 /*N 17  6   //Flete en Transaccion x Item B*/
   NUME_SERPR 	CHAR(6) DEFAULT '',     	 /*C  6  0* *  Numero item CIP*/
   SUBPARTIDA   CHAR(2) DEFAULT '',              /*C  2  0  SUBPARTIDA PARA VEHICULOS */
   SEGSER       DECIMAL(17,6) DEFAULT 0.000,     /* Seguro en transacci�n*/
   MARCA_REG    NUMERIC(4,0) DEFAULT 0,          /* Para marcar los registros que seran borrados (nunca se graba)*/
   ARO_ANIO     VARCHAR(21) DEFAULT "",          /*Aro y a�o del Vehiculo, Maquinaria o Becicletas */             
   CEXCNAN   	CHAR(1) DEFAULT '',     	 /*C  1  0* /* Indicador de Desechos y desperdicios*/
   CANT_EQUIV 	DECIMAL(14,3) DEFAULT 0.000, 	 /*N 14  3* /* Cantidad de unidades equivalentes a la Prod.  para ordenes que preceden de una admisi�n*/
   TIPO_EQUIV 	CHAR(3) DEFAULT '',     	 /*C  3  0* /* tipo de unidades equivalente a la prod. para ordenes que preceden de una admisi�n*/
   REFER_ITEM   VARCHAR(15) DEFAULT "",          /*Referencia de item para las Americas */
   CERT_ORIG  	VARCHAR(20) DEFAULT '', 	 /*C 16  0*  *   N� Certificado de Origen Solo para transferencia desde EXCEL */
   FCERT_ORI  	DATE, 	                         /*D  8  0*  *   Fecha Certificado de Origen Solo para transferencia desde EXCEL */
   PART_NABAN 	CHAR(8) DEFAULT '',     	 /*C  8  0*      Partida Nabandina Solo para transferencia desde EXCEL */
   DEC_JURADA   CHAR(1) DEFAULT '',     	 /*C  1  0       Declaracion Jurada solo para DHL*/
   PRIMARY KEY(N_ORDEN,NUME_SECUP,NUME_SECUF,NUM_ITEM),
   CONSTRAINT FK_ADA_DVF FOREIGN KEY(N_ORDEN,NUME_SECUP,NUME_SECUF) REFERENCES DVF(N_ORDEN,NUME_SECUP,NUME_SECUF));
   CREATE INDEX ADA           ON ADA(N_ORDEN);
   CREATE INDEX ADA_1         ON ADA(MARCA,MODELO,MERCANCIA,N_PARTE);
   CREATE INDEX ADA_MARCA     ON ADA(MARCA);
   CREATE INDEX ADA_MODELO    ON ADA(MODELO);
   CREATE INDEX ADA_MERCANCIA ON ADA(MERCANCIA);
   CREATE INDEX ADA_N_PARTE   ON ADA(N_PARTE);
   CREATE INDEX ADA_2         ON ADA(N_ORDEN,NUME_SECUP,NUME_SECUF);


/* TEX(DESCRIPCIONES MINIMAS PARA TELAS,TEJIDOS,CONFECCION,FIBRAS Y OTROS CONFECCIONES)*/
CREATE TABLE IF NOT EXISTS TEX(
   N_ORDEN      CHAR(11) NOT NULL,      /*  9  0  N� de Orden de despacho - DATOS PRINCIPALES -*/
   NUME_SECUP   CHAR(3) NOT NULL,      /*  C  2  0  C�digo del  proveedor -- DATOS DE LOS ITEMS ---*/
   NUME_SECUF   CHAR(3) NOT NULL,      /*  C  3  0  Numero de Secuencia de la Factura */
   NUM_ITEM     NUMERIC(4,0) NOT NULL,     /*  N  4  0  Nro. de Item secuencial por Factura */
   TIPO_TEJID   CHAR(3)  DEFAULT '',      /*  C  3  0  Tipo de tejido */
   COD_NOMBRE   CHAR(3)  DEFAULT '',      /*  3  0  Codigo del nombre*/
   NOMBRE       CHAR(30)  DEFAULT '',      /*C 30  0 Nombre */
   COD_TIPO     CHAR(3)  DEFAULT '',      /* C  3  0   //Codigo de Tipo*/
   TIPO         VARCHAR(20)  DEFAULT '',  /* C 20  0   //Tipo */
   COD_HILADO   CHAR(3)  DEFAULT '',      /*  0   //Codigo de Tipo de Hilado**/
   HILADO       VARCHAR(20)  DEFAULT '',  /* 20   //Tipo de Hilado */
   COD_COMPO1   CHAR(3)  DEFAULT '',      /*C  3  0   //Codigo de Componente 1*/
   COMPO1       VARCHAR(20)  DEFAULT '',  /*C 20  0   //Componente 1*/
   PORCENT_1    CHAR(3)  DEFAULT '',      /*C  3  0   //Porcentaje de Componente 1*/
   COD_COMPO2   CHAR(3)  DEFAULT '',      /*3  0   //Codigo de Componente 2*/
   COMPO2       VARCHAR(20)  DEFAULT '',  /*C 20  0   //Componente 2*/
   PORCENT_2    CHAR(3)  DEFAULT '',      /*C  3  0   //Porcentaje de Componente 2*/
   COD_COMPO3   CHAR(3)  DEFAULT '',      /*C  3  0   //Codigo de Componente 3*/
   COMPO3       VARCHAR(20)  DEFAULT '',  /*C 20  0   //Componente 3*/
   PORCENT_3    CHAR(3)  DEFAULT '',      /* C  3  0   //Porcentaje de Componente 3*/
   COD_COMPO4   CHAR(3)  DEFAULT '',      /* C  3  0   //Codigo de Componente 4*/
   COMPO4       VARCHAR(20)  DEFAULT '',  /* C 20  0   //Componente 4*/
   PORCENT_4    CHAR(3)  DEFAULT '',      /*C  3  0   //Porcentaje de Componente 4*/
   COD_ACAB1    CHAR(3)  DEFAULT '',      /*C  3  0   //Codigo de Acabado 1*/
   ACABADO1     VARCHAR(20)  DEFAULT '',  /*C 20  0   //Acabado 1*/
   COD_ACAB2    CHAR(3)  DEFAULT '',      /*C  3  0  //Codigo de Acabado 2 */
   ACABADO2     VARCHAR(20)  DEFAULT '',  /*C 20  0   //Acabado 2 */
   COD_PREP     CHAR(3)  DEFAULT '',      /*C  3  0   //Codigo de Preparacion/Grado de Elaboracion*/
   PREPARAC     VARCHAR(20)  DEFAULT '',  /* 20  0   //Preparacion/Grado de Elaboracion */
   COD_PRESEN   CHAR(3)  DEFAULT '',      /*3  0   //Codigo de Presentacion*/
   PRESENTAC    VARCHAR(20)  DEFAULT '',  /*C 20  0   //Presentacion*/
   ESTR_FIS     VARCHAR(90)  DEFAULT '',  /*C 90  0   //Estructura fisica de la Fibra*/
   CLASE        VARCHAR(45)  DEFAULT '',  /*C 45  0   //Clase */
   USO          VARCHAR(45)  DEFAULT '',  /* C 45  0   //Uso*/
   DENSIDAD     DECIMAL(6,2) DEFAULT 0.00, /*N  6  2   //Densidad */
   ESPESOR      DECIMAL(5,2) DEFAULT 0.00, /*N  5  2   //Espesor */
   GRAMAJE      NUMERIC(4,0) DEFAULT 0,     /* N  4  0   //Gramaje */
   COD_MATPL    CHAR(3)  DEFAULT '',      /*C  3  0   //Codigo de Materia plastica*/
   MAT_PLAST    VARCHAR(20)  DEFAULT '',  /*C 20  0   //Materia Plastica */
   COMPLEMENT   VARCHAR(90)  DEFAULT '',  /*C 90  0   //Complementos */
   CARACTERIS   VARCHAR(90)  DEFAULT '',  /*C 90  0   //Caracteristicas */
   OBSERVAC1    VARCHAR(90)  DEFAULT '',  /*C 90  0   //Observaciones */
   CODMNGSUP    CHAR(4)  DEFAULT '',      /*C  4  0 */
   MANGA_SUP    VARCHAR(20)  DEFAULT '',  /*C 20  0 */
   CODCUESUP    CHAR(3)  DEFAULT '',      /*C  3  0 */
   CUELLO_SUP   VARCHAR(20)  DEFAULT '',  /*C 20  0 */
   COD_P_EXT    CHAR(3)  DEFAULT '',      /*C  3  0 */
   PARTE_EXT    VARCHAR(20)  DEFAULT '',  /*C 20  0 */
   COD_P_INT    CHAR(4)  DEFAULT '',      /*C  3  0 */
   PARTE_INT    VARCHAR(20)  DEFAULT '',  /*C 20  0 */
   CODLAR_SUP   CHAR(4)  DEFAULT '',      /*C  4  0 */
   LARGO_SUP    VARCHAR(20)  DEFAULT '',  /*C 20  0 */
   COD_BOL_S    CHAR(3)  DEFAULT '',      /*C  3  0 */
   BOLSIL_SUP   VARCHAR(20)  DEFAULT '',  /*C 20  0 */
   COD_CINT_S   CHAR(3)  DEFAULT '',      /*C  3  0 */
   CINTURA_S    VARCHAR(20)  DEFAULT '',  /*C 20  0 */
   CODLAR_INF   CHAR(3)  DEFAULT '',      /*C  3  0 */
   LARGO_INF    VARCHAR(20)  DEFAULT '',  /*C 20  0 */
   CODPIE_INF   CHAR(3)  DEFAULT '',      /*C  3  0 */
   PIE_INF      VARCHAR(20)  DEFAULT '',  /*C 20  0 */
   CODABE_INF   CHAR(3)  DEFAULT '',      /*C  3  0 */
   ABERTU_INF   CHAR(3)  DEFAULT '',      /*C 20  0 */
   COD_BOL_I    CHAR(3)  DEFAULT '',      /*C  3  0 */
   BOLSIL_INF   VARCHAR(20)  DEFAULT '',  /*C 20  0 */
   COD_CINT_I   CHAR(3)  DEFAULT '',      /*C  3  0 */
   CINTURA_I    VARCHAR(20)  DEFAULT '',  /*C 20  0 */
   COD_PETO     CHAR(3)  DEFAULT '',      /*C  3  0 */
   PETO_INF     VARCHAR(20)  DEFAULT '',  /*C 20  0 */
   COD_CARAS    CHAR(3)  DEFAULT '',      /*C  3  0 */
   CARAS        VARCHAR(20)  DEFAULT '',  /*C 20  0 */
   COD_ELASTI   CHAR(3)  DEFAULT '',      /*C  3  0 */
   ELASTICO     VARCHAR(20)  DEFAULT '',  /*C 20  0 */
   COD_FORMA    CHAR(3)  DEFAULT '',      /*C  3  0 */
   FORMA        VARCHAR(20)  DEFAULT '',  /*C 20  0 */
   COD_RELLEN   CHAR(3)  DEFAULT '',      /*C  3  0 */
   RELLENO      VARCHAR(20)  DEFAULT '',  /*C 20  0 */
   COD_APLIC    CHAR(4)  DEFAULT '',      /*C  3  0 */
   APLICACION   VARCHAR(20)  DEFAULT '',  /*C 20  0 */
   COD_COMPL    CHAR(3)  DEFAULT '',      /*C  3  0 */
   COD_PRES2    CHAR(3)  DEFAULT '',      /*C  3  0 */
   PRESENTAC2   VARCHAR(20)  DEFAULT '',  /*C 20  0 */
   COD_PZA1_S   CHAR(3)  DEFAULT '',      /*C  3  0 */
   PZA_1_SUP    VARCHAR(20)  DEFAULT '',  /*C 20  0 */
   COD_PZA2_S   CHAR(3)  DEFAULT '',      /*C  3  0 */
   PZA_2_SUP    VARCHAR(20)  DEFAULT '',  /*C 20  0 */
   COD_PZA3_S   CHAR(3)  DEFAULT '',      /*C  3  0 */
   PZA_3_SUP    VARCHAR(20)  DEFAULT '',  /*C 20  0 */
   COD_PZA4_S   CHAR(3)  DEFAULT '',      /*C  3  0 */
   PZA_4_SUP    VARCHAR(20)  DEFAULT '',  /*C 20  0 */
   COD_PZA5_S   CHAR(3)  DEFAULT '',      /*C  3  0 */
   PZA_5_SUP    VARCHAR(20)  DEFAULT '',  /*C 20  0 */
   COD_PZA1_I   CHAR(3)  DEFAULT '',      /*C  3  0 */
   PZA_1_INF    VARCHAR(20)  DEFAULT '',  /*C 20  0 */
   COD_PZA2_I   CHAR(3)  DEFAULT '',      /*C  3  0 */
   PZA_2_INF    VARCHAR(20)  DEFAULT '',  /*C 20  0 */
   COD_PZA3_I   CHAR(3)  DEFAULT '',      /*C  3  0 */
   PZA_3_INF    VARCHAR(20)  DEFAULT '',  /*C 20  0 */
   COD_PZA4_I   CHAR(3)  DEFAULT '',      /*C  3  0 */
   PZA_4_INF    VARCHAR(20)  DEFAULT '',  /*C 20  0 */
   COD_PZA5_I   CHAR(3)  DEFAULT '',      /*C  3  0 */
   PZA_5_INF    VARCHAR(20)  DEFAULT '',  /*C 20  0 */
   PZAS_CJTO    VARCHAR(20)  DEFAULT '',  /*C 20  0 */
   PZACJTOSUP   VARCHAR(20)  DEFAULT '',  /*C 20  0 */
   PZACJTOINF   VARCHAR(20)  DEFAULT '',  /*C 20  0 */
   PESO_UNITA   VARCHAR(20)  DEFAULT '',  /*C 20  0 */
   cod_aplic2   CHAR(3)  DEFAULT '',
   aplicacio2   VARCHAR(25)  DEFAULT '',
   cod_aplic3   CHAR(3)  DEFAULT '',
   aplicacio3   VARCHAR(25)  DEFAULT '',
   PRIMARY KEY(N_ORDEN,NUME_SECUP,NUME_SECUF,NUM_ITEM),
   CONSTRAINT FK_TEX_ADA FOREIGN KEY(N_ORDEN,NUME_SECUP,NUME_SECUF,NUM_ITEM) REFERENCES ADA(N_ORDEN,NUME_SECUP,NUME_SECUF,NUM_ITEM));
   CREATE INDEX TEX ON TEX(N_ORDEN);

/* CRR(DESCRIPCIONES MIMINAS PARA CIERRES Y PARTES DE CIERRES)*/
CREATE TABLE IF NOT EXISTS CRR(
   N_ORDEN   	CHAR(11) NOT NULL,    	/*C  9*/
   NUME_SECUP	CHAR(3) NOT NULL,	/*C  2*/
   NUME_SECUF	CHAR(3) NOT NULL,	/*C  3*/
   TIPO_C    	CHAR(1)  NOT NULL,	/*C  1*/
   NUM_ITEM  	NUMERIC(4,0) NOT NULL,	/*N  4*/
   NOMBRE    	CHAR(3)  DEFAULT '',	/*C  3*/
   N_NOMBRE  	VARCHAR(22)  DEFAULT '',	/*C 22*/
   TIPO      	CHAR(3)  DEFAULT '',	/*C  3*/
   COMPOS    	CHAR(3)  DEFAULT '',	/*C  3*/
   N_COMPOS  	VARCHAR(20)  DEFAULT '',	/*C 20*/
   PRESENTAC 	CHAR(3)  DEFAULT '',	/*C  3*/
   TIPO_LLAVE	CHAR(3)  DEFAULT '',	/*C  3*/
   MAT_LLAVE 	CHAR(3)  DEFAULT '',	/*C  3*/
   NMAT_LLAVE	VARCHAR(20)  DEFAULT '',	/*C 20*/
   TAM_CREMAL	CHAR(3)  DEFAULT '',	/*C  3*/
   MAT_DIEN  	CHAR(3)  DEFAULT '',	/*C  3*/
   NMAT_DIEN 	VARCHAR(20)  DEFAULT '',	/*C 20*/
   NUM_DIENTE	CHAR(3)  DEFAULT '',	/*C  3*/
   OBSERVAC1 	VARCHAR(90)  DEFAULT '',	/*C 90*/
   N_CREMALLE   NUMERIC(6,2) DEFAULT 0.00,	
   N_DIENTE     NUMERIC(5,1) DEFAULT 0.0,	
   des_tipcrr   VARCHAR(25) DEFAULT '',
   des_precta   VARCHAR(25) DEFAULT '',
   des_tiplla   VARCHAR(25) DEFAULT '',
   tam_llave    VARCHAR(25) DEFAULT '',
   PRIMARY KEY(N_ORDEN,NUME_SECUP,NUME_SECUF,NUM_ITEM),
   CONSTRAINT FK_CRR_ADA FOREIGN KEY(N_ORDEN,NUME_SECUP,NUME_SECUF,NUM_ITEM) REFERENCES ADA(N_ORDEN,NUME_SECUP,NUME_SECUF,NUM_ITEM));
   CREATE INDEX CRR ON CRR(N_ORDEN);


/* ZAP(DESCRIPCIONES MINIMAS PARA CALZADO)*/
CREATE TABLE IF NOT EXISTS ZAP(
   N_ORDEN   	CHAR(11) NOT NULL,	/*C  9  0*/
   NUME_SECUP	CHAR(3) NOT NULL,	/*C  2  0*/
   NUME_SECUF	CHAR(3) NOT NULL,	/*C  3  0*/
   NUM_ITEM  	NUMERIC(4,0) NOT NULL,	/*N  4  0*/
   NOMBRE    	CHAR(3)  DEFAULT '',	/*C  3  0*/
   SUPERIOR  	CHAR(3)  DEFAULT '',	/*C  3  0*/
   ORIGEN    	CHAR(3)  DEFAULT '',	/*C  3  0*/
   N_ORIGEN  	VARCHAR(20)  DEFAULT '',	/*C 20  0*/
   ACABADO   	CHAR(3)  DEFAULT '',	/*C  3  0*/
   N_ACABADO 	VARCHAR(20)  DEFAULT '',	/*C 20  0*/
   COMPOS1   	CHAR(3)  DEFAULT '',	/*C  3  0*/
   N_COMPOS1 	VARCHAR(20)  DEFAULT '',	/*C 20  0*/
   PORCENT1  	CHAR(3)  DEFAULT '',	/*C  3  0*/
   COMPOS2   	CHAR(3)  DEFAULT '',	/*C  3  0*/
   N_COMPOS2 	VARCHAR(20)  DEFAULT '',	/*C 20  0*/
   PORCENT2  	CHAR(3)  DEFAULT '',	/*C  3  0*/
   TIPO      	CHAR(3)  DEFAULT '',	/*C  3  0*/
   N_TIPO    	VARCHAR(20)  DEFAULT '',	/*C 20  0*/
   SUELA     	CHAR(3)  DEFAULT '',	/*C  3  0*/
   FORRO     	CHAR(3)  DEFAULT '',	/*C  3  0*/
   USUARIO   	CHAR(3)  DEFAULT '',	/*C  3  0*/
   TALLA     	CHAR(11)  DEFAULT '',	/*C 11  0*/
   OBSERVAC1 	VARCHAR(90)  DEFAULT '',	/*C 90  0*/
   CONSTRUCC 	CHAR(3)  DEFAULT '',	/*C  3  0*/
   OTR_CONSTR	VARCHAR(20)  DEFAULT '',	/*C 20  0*/
   P_ORIG_CUE	NUMERIC(3,0) default 0,	/*N  3  0 */
   P_ACAB_CUE	NUMERIC(3,0) DEFAULT 0,	/*N  3  0 */
   COMPOS3   	CHAR(3)  DEFAULT '',	/*C  3  0 */
   N_COMPOS3 	VARCHAR(20)  DEFAULT '',/*C 20  0 */
   PORCENT3  	CHAR(3)  DEFAULT '',	/*C  3  0 */
   COM_TEJ   	CHAR(3)  DEFAULT '',	/*C  3  0 */
   NCOM_TEJ  	VARCHAR(20)  DEFAULT '',/*C 20  0 */
   PCOM_TEJ  	CHAR(3)  DEFAULT '',	/*C  3  0 */
   PORCEN_TEX	CHAR(3)  DEFAULT '',	/*C  3  0 */
   COM_FORRO    VARCHAR(25)  DEFAULT '',/*C 20  0 */
   PARTESUPER   VARCHAR(25)  DEFAULT '',/*C 20  0 */
   PRIMARY KEY(N_ORDEN,NUME_SECUP,NUME_SECUF,NUM_ITEM),
   CONSTRAINT FK_ZAP_ADA FOREIGN KEY(N_ORDEN,NUME_SECUP,NUME_SECUF,NUM_ITEM) REFERENCES ADA(N_ORDEN,NUME_SECUP,NUME_SECUF,NUM_ITEM));
   CREATE INDEX ZAP ON ZAP(N_ORDEN);


/* GAF(DESCRIPCIONES MINIMAS PARA LETES Y GAFAS)*/
CREATE TABLE IF NOT EXISTS GAF(
   N_ORDEN   	CHAR(11) NOT NULL,	/*C  9  0 //Numero de Orden*/
   NUME_SECUP	CHAR(3) NOT NULL,	/*C  2  0 //Secuencia de Proveedor*/
   NUME_SECUF	CHAR(3) NOT NULL,	/*C  3  0 //Secuencia de Factura*/
   NUM_ITEM  	NUMERIC(4,0) NOT NULL,	/*N  4  0 //Secuencia de Item por Factura*/
   COD_NOMBRE	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Nombre de Lentes*/
   N_NOMBRE  	VARCHAR(30)  DEFAULT '',	/*C 30  0 //Nombre de Lentes*/
   CODMATMERC	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Material de Mercancia*/
   N_MATMERC 	VARCHAR(30)  DEFAULT '',	/*C 30  0 //Nombre de Material de Mercanc�a*/
   CODMATLENT	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Material del Lente*/
   COD_MEDIDA	CHAR(2)  DEFAULT '',	/*C  2  0 //Codigo de Medida*/
   MEDIDA    	CHAR(9)  DEFAULT '',	/*C  9  0 //Medida*/
   TIPO      	CHAR(3)  DEFAULT '',	/*C  3  0 //Tipo de Lente*/
   BLANDO    	CHAR(3)  DEFAULT '',	/*C  3  0 //Si es blando: CON � DES*/
   N_FOCO    	CHAR(3)  DEFAULT '',	/*C  3  0 //Numero de foco*/
   MONOFOCAL 	CHAR(3)  DEFAULT '',	/*C  3  0 //Si es monofocales:ESF, CIL � COM*/
   COLOR     	CHAR(3)  DEFAULT '',	/*C  3  0 //Tipo de Color*/
   TRATAMIEN 	CHAR(3)  DEFAULT '',	/*C  3  0 //Tratamiento*/
   ACABADO   	CHAR(3)  DEFAULT '',	/*C  3  0 //Acabado*/
   OBSERVAC1 	VARCHAR(90)  DEFAULT '',	/*C 90  0 //Observaciones*/
   PRIMARY KEY(N_ORDEN,NUME_SECUP,NUME_SECUF,NUM_ITEM),
   CONSTRAINT FK_GAF_ADA FOREIGN KEY(N_ORDEN,NUME_SECUP,NUME_SECUF,NUM_ITEM) REFERENCES ADA(N_ORDEN,NUME_SECUP,NUME_SECUF,NUM_ITEM));
   CREATE INDEX GAF ON GAF(N_ORDEN);

/*PLT(DESCRIPCIONES MIMINAS PARA PILAS)*/
CREATE TABLE IF NOT EXISTS PLT(
   N_ORDEN   	CHAR(11) NOT NULL,	/*C  9  0 //Numero de Orden*/
   NUME_SECUP	CHAR(3) NOT NULL,	/*C  2  0 //Secuencia de Proveedor*/
   NUME_SECUF	CHAR(3) NOT NULL,	/*C  3  0 //Secuencia de Factura*/
   NUM_ITEM  	NUMERIC(4,0) NOT NULL,	/*N  4  0 //Secuencia de Item por Factura*/
   GRAD_PROD1	CHAR(3)  DEFAULT '',	/*C  3  0 //Grado de Elaboraci�n del producto 1*/
   GRAD_PROD2	CHAR(3)  DEFAULT '',	/*C  3  0 //Grado de Elaboraci�n del producto 2*/
   GRAD_PROD3	CHAR(3)  DEFAULT '',	/*C  3  0 //Grado de Elaboraci�n del producto 3*/
   C_COM_PLT1	CHAR(2)  DEFAULT '',	/*C  2  0 //Codigo del componente plastico 1*/
   N_COM_PLT1	VARCHAR(26)  DEFAULT '',	/*C 26  0 //Nombre del componente plastico 1*/
   P_COM_PLT1	NUMERIC(3,0) DEFAULT 0,	/*N  3  0 //Porcentaje del componente plastico 1*/
   C_COM_PLT2	CHAR(2)  DEFAULT '',	/*C  2  0 //Codigo del componente plastico 2*/
   N_COM_PLT2	VARCHAR(27)  DEFAULT '',	/*C 27  0 //Nombre del componente plastico 2*/
   P_COM_PLT2	NUMERIC(2,0) DEFAULT 0,	/*N  2  0 //Porcentaje del componente plastico 2*/
   COD_SOPORT	CHAR(2)  DEFAULT '',	/*C 2  0 //Soporte*/
   N_SOPORTE 	VARCHAR(25)  DEFAULT '',	/*C 25  0 //Nombre de Marca de Vehiculo*/
   COD_TNT1  	CHAR(2)  DEFAULT '',	/*C  2  0 //Codigo del Tejido y no Tejido 1*/
   N_TNT1    	VARCHAR(25)  DEFAULT '',	/*C 25  0 //Nombre del Tejido y no Tejido 1*/
   P_TNT1    	CHAR(2)  DEFAULT '',	/*C  2  0 //Porcentaje del Tejido y no Tejido 1*/
   COD_TNT2  	CHAR(2)  DEFAULT '',	/*C  2  0 //Codigo del Tejido y no Tejido 2*/
   N_TNT2    	VARCHAR(25)  DEFAULT '',	/*C 25  0 //Nombre del Tejido y no Tejido 2*/
   P_TNT2    	CHAR(2)  DEFAULT '',	/*C  2  0 //Porcentaje del Tejido y no Tejido 2*/
   GRADO_ELAB	CHAR(2)  DEFAULT '',	/*C  2  0 //Grado de Elaboracion*/
   C_COLOR   	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo del Color*/
   N_COLOR   	VARCHAR(27)  DEFAULT '',	/*C 27  0 //Nombre del Color*/
   C_ACABADO 	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo del Acabado*/
   N_ACABADO 	VARCHAR(27)  DEFAULT '',	/*C 27  0 //Nombre del Acabado*/
   C_CALIDAD 	CHAR(2)  DEFAULT '',	/*C  2  0 //Codigo del Calidad*/
   N_CALIDAD 	VARCHAR(27)  DEFAULT '',	/*C 27  0 //Nombre del Calidad*/
   ESPESOR1  	DECIMAL(6,3) DEFAULT 0.000,	/*N  6  3 //Espesor 1*/
   ESPESOR2  	DECIMAL(6,3) DEFAULT 0.000,	/*N  6  3 //Espesor 2*/
   GRAMAJE   	DECIMAL(7,2) DEFAULT 0.00,	/*N  7  2 //Gramaje*/
   ANCHO       	DECIMAL(7,3) DEFAULT 0.000,	/*N  7  3 //Ancho*/
   UNIDAD    	CHAR(3)  DEFAULT '',	/*C  3  0 //Unidad de Medida*/
   PLASTIFIC 	NUMERIC(3,0) DEFAULT 0,	/*N  3  0 //Plastificante*/
   OBSERVAC1 	VARCHAR(100)  DEFAULT '',	/*C100  0 //Observaciones*/
   est_compla   VARCHAR(25)  DEFAULT '',
   est_sopor    VARCHAR(25)  DEFAULT '',
   ELABORAC1    VARCHAR(25)  DEFAULT '',
   ELABORAC2    VARCHAR(25)  DEFAULT '',
   ELABORAC3    VARCHAR(25)  DEFAULT '',
   PRIMARY KEY(N_ORDEN,NUME_SECUP,NUME_SECUF,NUM_ITEM),
   CONSTRAINT FK_PLT_ADA FOREIGN KEY(N_ORDEN,NUME_SECUP,NUME_SECUF,NUM_ITEM) REFERENCES ADA(N_ORDEN,NUME_SECUP,NUME_SECUF,NUM_ITEM));
   CREATE INDEX PLT ON PLT(N_ORDEN);

/* NEU(DESCRIPCIONES MINIMIAS PARA NEUMATICOS)*/
CREATE TABLE IF NOT EXISTS NEU(
   N_ORDEN   	CHAR(11) NOT NULL,	/*C  9  0 //Numero de Orden*/
   NUME_SECUP	CHAR(3) NOT NULL,	/*C  2  0 //Secuencia de Proveedor*/
   NUME_SECUF	CHAR(3) NOT NULL,	/*C  3  0 //Secuencia de Factura*/
   NUM_ITEM  	NUMERIC(4,0) NOT NULL,	/*N  4  0 //Secuencia de Item por Factura*/
   USO       	CHAR(3)  DEFAULT '',	/*C  3  0 //Uso*/
   MATERIAL  	CHAR(2)  DEFAULT '',	/*C  2  0 //Material de Carcasa 1*/
   MATERIAL2 	CHAR(2)  DEFAULT '',	/*C  2  0 //Material de Carcasa 2*/
   NOMENCLA  	CHAR(2)  DEFAULT '',	/*C  2  0 //Tipo de Nomenclatura*/
   ANCHO01   	DECIMAL(7,2) DEFAULT 0.00,	/*N  7  2 //Ancho de la Seccion Numerica*/
   ANCHO02   	CHAR(1)  DEFAULT '',	/*C  1    //Ancho de la Seccion Alfanumerica*/
   ANCHO03   	DECIMAL(8,2) DEFAULT 0.00,	/*N  8  2 //Ancho de la Seccion Milimetrica*/
   SERIE     	NUMERIC(4,2) DEFAULT 0,	/*N  3  0 //Serie o Relacion de Aspecto*/
   DIAMETRO  	DECIMAL(6,2) DEFAULT 0.00,	/*N  6  2 //Diametro del Aro*/
   CONSTRUC  	CHAR(3)  DEFAULT '',	/*C  3  0 //Tipo de Construccion*/
   INDICE    	CHAR(3)  DEFAULT '',	/*C  3  0 //Indice de Carga*/
   VELOCIDAD 	CHAR(1)  DEFAULT '',	/*C  1  0 //Codigo de Velocidad*/
   SEGURIDAD 	CHAR(90)  DEFAULT '',	/*C  8  0 //Codigo de Seguridad*/
   OBSERVAC1 	VARCHAR(100)  DEFAULT '',	/*C100  0 //Observaciones*/
   ANCHO        VARCHAR(25)  DEFAULT '',
   DES_MAT1     VARCHAR(25)  DEFAULT '',
   DES_MAT2     VARCHAR(25)  DEFAULT '',
   DES_INDICE   VARCHAR(25)  DEFAULT '',
   DES_VELOC    VARCHAR(25)  DEFAULT '',
   PRIMARY KEY(N_ORDEN,NUME_SECUP,NUME_SECUF,NUM_ITEM),
   CONSTRAINT FK_NEU_ADA FOREIGN KEY(N_ORDEN,NUME_SECUP,NUME_SECUF,NUM_ITEM) REFERENCES ADA(N_ORDEN,NUME_SECUP,NUME_SECUF,NUM_ITEM));
   CREATE INDEX NEU ON NEU(N_ORDEN);

/* PIL(DESCRIPCIONES MINIMAS PARA PILAS Y BATERIAS)*/
CREATE TABLE IF NOT EXISTS PIL(
   N_ORDEN   	CHAR(11) NOT NULL,	/*C  9  0 //Numero de Orden*/
   NUME_SECUP	CHAR(3) NOT NULL,	/*C  2  0 //Secuencia de Proveedor*/
   NUME_SECUF	CHAR(3) NOT NULL,	/*C  3  0 //Secuencia de Factura*/
   NUM_ITEM  	NUMERIC(4,0) NOT NULL,	/*N  4  0 //Secuencia de Item por Factura*/
   NOMBRE    	VARCHAR(30)  DEFAULT '',	/*C 30  0 //Nombre*/
   COD_TIPO  	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Tipo*/
   TIPO      	VARCHAR(20)  DEFAULT '',	/*C 20  0 //Tipo*/
   COD_FORMA 	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Forma*/
   FORMA     	VARCHAR(20)  DEFAULT '',	/*C 20  0 //Forma*/
   COD_DESIG 	CHAR(4)  DEFAULT '',	/*C  3  0 //Codigo de Designacion*/
   DESIGNA   	VARCHAR(20)  DEFAULT '',	/*C 20  0 //Designacion*/
   DIMENSIO  	VARCHAR(15)  DEFAULT '',	/*C 15  0 //Dimensiones*/
   VOLTAJE   	DECIMAL(5,2) DEFAULT 0.00,	/*N  5  2 //Voltaje*/
   OBSERVAC  	VARCHAR(100)  DEFAULT '',	/*C100  0 //Observaciones*/
   PRIMARY KEY(N_ORDEN,NUME_SECUP,NUME_SECUF,NUM_ITEM),
   CONSTRAINT FK_PIL_ADA FOREIGN KEY(N_ORDEN,NUME_SECUP,NUME_SECUF,NUM_ITEM) REFERENCES ADA(N_ORDEN,NUME_SECUP,NUME_SECUF,NUM_ITEM));
   CREATE INDEX PIL ON PIL(N_ORDEN);

/*OJT(DESCRICIONES MINIMAS PARA ANILLOS,OJALILLOS Y OJETES )*/
CREATE TABLE IF NOT EXISTS OJT(
   N_ORDEN   	CHAR(11) NOT NULL,	/*C  9  0 //Numero de Orden*/
   NUME_SECUP	CHAR(3) NOT NULL,	/*C  2  0 //Secuencia de Proveedor*/
   NUME_SECUF	CHAR(3) NOT NULL,	/*C  3  0 //Secuencia de Factura*/
   NUM_ITEM  	NUMERIC(4,0) NOT NULL,	/*N  4  0 //Secuencia de Item por Factura*/
   NOMBRE    	VARCHAR(30)  DEFAULT '',	/*C 30  0 //Nombre*/
   COD_TIPO  	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Tipo*/
   TIPO      	VARCHAR(20)  DEFAULT '',	/*C 20  0 //Tipo*/
   COD_ACABA 	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Acabado*/
   ACABADO   	VARCHAR(20)  DEFAULT '',	/*C 20  0 //Acabado*/
   COD_USO   	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Uso*/
   USO       	VARCHAR(20)  DEFAULT '',	/*C 20  0 //Uso*/
   DIMENSIO  	VARCHAR(17)  DEFAULT '',	/*C 17  0 //Dimensiones*/
   COD_MAT   	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Material*/
   MATERIAL  	VARCHAR(20)  DEFAULT '',	/*C 20  0 //Material*/
   OBSERVAC  	VARCHAR(100)  DEFAULT '',	/*C100  0 //Observaciones*/
   PRIMARY KEY(N_ORDEN,NUME_SECUP,NUME_SECUF,NUM_ITEM),	
   CONSTRAINT FK_OJT_ADA FOREIGN KEY(N_ORDEN,NUME_SECUP,NUME_SECUF,NUM_ITEM) REFERENCES ADA(N_ORDEN,NUME_SECUP,NUME_SECUF,NUM_ITEM));
   CREATE INDEX OJT ON OJT(N_ORDEN);

/* COM(DESCRIPCIONES MINIMAS PARA COMPUTADORAS Y PARTES DE COMPUTADORAS)*/
CREATE TABLE IF NOT EXISTS COM(
   N_ORDEN   	CHAR(11) NOT NULL,	/*C  9  0 //Numero de Orden*/
   NUME_SECUP	CHAR(3) NOT NULL,	/*C  2  0 //Secuencia de Proveedor*/
   NUME_SECUF	CHAR(3) NOT NULL,	/*C  3  0 //Secuencia de Factura*/
   NUM_ITEM  	NUMERIC(4,0) NOT NULL,	/*N  4  0 //Secuencia de Item por Factura*/
   TTIPO     	CHAR(1)  DEFAULT '',	/*C  1  0 //TIPO : Computadora Otros*/
   COD_NOMBRE	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de nombre*/
   NOMBRE    	VARCHAR(30)  DEFAULT '',	/*C 30  0 //Nombre*/
   COD_MARCA 	CHAR(4)  DEFAULT '',	/*C  4  0 //Codigo de Marca*/
   MARCA     	VARCHAR(30)  DEFAULT '',	/*C 30  0 //Marca*/
   CODTIPO   	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Tipo*/
   TIPO      	VARCHAR(30)  DEFAULT '',	/*C 30  0 //Tipo*/
   CODPROCESA	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Procesador*/
   PROCESADOR	VARCHAR(30)  DEFAULT '',	/*C 30  0 //Procesador*/
   CODMONITOR	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Monitor*/
   MONITOR   	VARCHAR(30)  DEFAULT '',	/*C 30  0 //Monitor*/
   CODTECLADO	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Teclado*/
   TECLADO   	VARCHAR(30)  DEFAULT '',	/*C 30  0 //Teclado*/
   CODVELPROC	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Velocidad Procesador*/
   VELPROCESA	VARCHAR(30)  DEFAULT '',	/*C 30  0 //Velocidad Procesador*/
   CODVELECTO	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Velocidad Lectora*/
   VELECTORA 	VARCHAR(30)  DEFAULT '',	/*C 30  0 //Velocidad Lectora*/
   CODVELDVD 	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Velocidad DVD*/
   VELDVD    	VARCHAR(30)  DEFAULT '',	/*C 30  0 //Velocidad DVD*/
   CODCAPRAM 	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Capacidad RAM*/
   CAPRAM    	VARCHAR(30)  DEFAULT '',	/*C 30  0 //Capacidad RAM*/
   CODCAPDD  	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Capacidad Disco Duro*/
   CAPDD     	VARCHAR(30)  DEFAULT '',	/*C 30  0 //Capacidad Disco Duro*/
   CODTAMONIT	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Tamano de Monitor*/
   TAMONITO  	VARCHAR(30)  DEFAULT '',	/*C 30  0 //Tamano de Monitor*/
   CODVELBUS 	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Velocidad del Bus*/
   VELBUS    	VARCHAR(30)  DEFAULT '',	/*C 30  0 //Velocidad de Bus*/
   CODVELTRAN	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Velocidad de la Transfe*/
   VELTRANS  	VARCHAR(30)  DEFAULT '',	/*C 30  0 //Velocidad de Transferencia*/
   CODCAPACID	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Capacidad*/
   CAPACIDAD 	VARCHAR(30)  DEFAULT '',	/*C 30  0 //Capacidad*/
   CODANCOL  	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Ancho de la columna*/
   ANCHOCOL  	VARCHAR(30)  DEFAULT '',	/*C 30  0 //Ancho de la columna*/
   CODRESOL  	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Resolucion*/
   RESOLUCION	VARCHAR(30)  DEFAULT '',	/*C 30  0 //Resolucion*/
   CODCOLOR  	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de color*/
   COLOR     	VARCHAR(30)  DEFAULT '',	/*C 30  0 //Color*/
   CODTAMANO 	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Tamano*/
   TAMANO    	VARCHAR(30)  DEFAULT '',	/*C 30  0 //Tamano*/
   CODTAMPTO 	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Tamano del Punto*/
   TAMPUNTO  	VARCHAR(30)  DEFAULT '',	/*C 30  0 //Tamano del Punto*/
   CODPROFCOL	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Profundidad del color*/
   PROFCOLOR 	VARCHAR(30)  DEFAULT '',	/*C 30  0 //Profundidad del color*/
   CODPINES  	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Pines*/
   PINES     	VARCHAR(30)  DEFAULT '',	/*C 30  0 //Pines*/
   CODMODULO 	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Modulo*/
   MODULO    	VARCHAR(30)  DEFAULT '',	/*C 30  0 //Modulo*/
   CODFORMATO	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Formato*/
   FORMATO   	VARCHAR(30)  DEFAULT '',	/*C 30  0 //Formato*/
   CODINTERF 	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Interfase*/
   INTERFASE 	VARCHAR(30)  DEFAULT '',	/*C 30  0 //Interfase*/
   CODCONEXIO	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Conexion*/
   CONEXION  	VARCHAR(30)  DEFAULT '',	/*C 30  0 //Conexion*/
   CODRAM    	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Tipo Memoria RAM*/
   RAM       	VARCHAR(30)  DEFAULT '',	/*C 30  0 //Memoria RAM*/
   CODVIMPCOL	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Velocidad Imp. Color*/
   VELIMPCOL 	VARCHAR(30)  DEFAULT '',	/*C 30  0 //Velocidad Impresion Color*/
   CODREGRAB 	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Regrabacion*/
   REGRABAC  	VARCHAR(30)  DEFAULT '',	/*C 30  0 //Regrabacion*/
   PRIMARY KEY(N_ORDEN,NUME_SECUP,NUME_SECUF,NUM_ITEM),
   CONSTRAINT FK_COM_ADA FOREIGN KEY(N_ORDEN,NUME_SECUP,NUME_SECUF,NUM_ITEM) REFERENCES ADA(N_ORDEN,NUME_SECUP,NUME_SECUF,NUM_ITEM));
   CREATE INDEX COM ON COM(N_ORDEN);

/* DAT(DESCRIPCIONES MINIMAS PARA REPRODUCTORES DE AUDIO Y VIDEO)*/
CREATE TABLE IF NOT EXISTS DAT(
   N_ORDEN   	CHAR(11) NOT NULL,	/*C  9  0 //Numero de Orden*/
   NUME_SECUP	CHAR(3) NOT NULL,	/*C  2  0 //Secuencia de Proveedor*/
   NUME_SECUF	CHAR(3) NOT NULL,	/*C  3  0 //Secuencia de Factura*/
   NUM_ITEM  	NUMERIC(4,0) NOT NULL,	/*N  4  0 //Secuencia de Item por Factura*/
   COD_NOMBRE	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de nombre*/
   NOMBRE    	VARCHAR(30)  DEFAULT '',	/*C 30  0 //Nombre*/
   C_TIPODISC	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Tipo de disco*/
   TIPO_DISCO	VARCHAR(30)  DEFAULT '',	/*C 30  0 //Tipo de disco*/
   C_LONGDIA 	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Longitud de diametro*/
   LONG_DIAME	VARCHAR(30)  DEFAULT '',	/*C 30  0 //Longitud de diametro*/
   CCAP_ALMA 	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Capacidad de Almacenamiento*/
   CAP_ALMACE	VARCHAR(30)  DEFAULT '',	/*C 30  0 //Capacidad de Almacenamiento*/
   CTIPOMAT  	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Tipo de Material*/
   TIPO_MATER	VARCHAR(30)  DEFAULT '',	/*C 30  0 //Tipo de Material*/
   CODTIPO   	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Tipo*/
   TIPO      	VARCHAR(30)  DEFAULT '',	/*C 30  0 //Tipo*/
   CAP_MAXIMA	NUMERIC(3,0) DEFAULT 0,	/*N  3  0 //Capacidad Maxima*/
   NUMAX_DRIV	NUMERIC(3,0) DEFAULT 0,	/*N  3  0 //Numero Maximo de Drives*/
   CAP_DDURO 	NUMERIC(3,0) DEFAULT 0,	/*N  3  0 //Capacidad de Disco Duro*/
   CEMP_PRES 	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Empaque de Presentacion*/
   EMP_PRESEN	VARCHAR(30)  DEFAULT '',	/*C 30  0 //Empaque de Presentacion*/
   DISCXEMPAQ	NUMERIC(4,0) DEFAULT 0,	/*N  4  0 //Discos por Empaque*/
   NUMEMPAQ  	NUMERIC(6,0) DEFAULT 0,	/*N  6  0 //Numero de Empaques*/
   CTIEMGRAB 	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Tiempo de Grabacion*/
   TIEM_GRAB 	VARCHAR(30)  DEFAULT '',	/*C 30  0 //Tiempo de Grabacion*/
   NUM_LECTCD	NUMERIC(3,0) DEFAULT 0,	/*N  3  0 //Numero de Lectores de CD*/
   NUM_LECDVD	NUMERIC(3,0) DEFAULT 0,	/*N  3  0 //Numero de Lectores de DVD*/
   CFORMATO  	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Formato*/
   FORMATO   	VARCHAR(30)  DEFAULT '',	/*C 30  0 //Formato*/
   CCARACTE  	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Caracteristica CD*/
   CARACTERIS	VARCHAR(30)  DEFAULT '',	/*C 30  0 //Caracteristica CD*/
   CAR_DVD   	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Caracteristica DVD*/
   CARACDVD  	VARCHAR(20)  DEFAULT '',	/*C 20  0 //Caracteristica DVD*/
   CVGRABCD  	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Velocidad de Grabacion CD*/
   VELGRABCD 	VARCHAR(30)  DEFAULT '',	/*C 30  0 //Velocidad de Grabacion CD*/
   CVGRABDVD 	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Velocidad de Grabacion DVD*/
   VELGRABDVD	VARCHAR(30)  DEFAULT '',	/*C 30  0 //Velocidad de Grabacion DVD*/
   PRIMARY KEY(N_ORDEN,NUME_SECUP,NUME_SECUF,NUM_ITEM),
   CONSTRAINT FK_DAT_ADA FOREIGN KEY(N_ORDEN,NUME_SECUP,NUME_SECUF,NUM_ITEM) REFERENCES ADA(N_ORDEN,NUME_SECUP,NUME_SECUF,NUM_ITEM));
   CREATE INDEX DAT ON DAT(N_ORDEN);

/* VEH(DESCRIPCIONES MINIMAS PARA VEHICULOS Y MOTOS) */
CREATE TABLE IF NOT EXISTS VEH(
   N_ORDEN   	CHAR(11) NOT NULL,	/*C  9  0 //Numero de Orden*/
   NUME_SECUP	CHAR(3) NOT NULL,	/*C  2  0 //Secuencia de Proveedor*/
   NUME_SECUF	CHAR(3) NOT NULL,	/*C  3  0 //Secuencia de Factura*/
   NUM_ITEM  	NUMERIC(4,0) NOT NULL,	/*N  4  0 //Secuencia de Item por Factura*/
   COD_NOMBRE	CHAR(4)  DEFAULT '',	/*C  4  0 //Codigo de Nombre de Vehiculo*/
   N_NOMBRE  	VARCHAR(27)  DEFAULT '',	/*C 27  0 //Nombre de Vehiculo*/
   COD_MARCA 	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Marca de Vehiculo*/
   N_MARCA   	VARCHAR(27)  DEFAULT '',	/*C 27  0 //Nombre de Marca de Vehiculo*/
   MODELO    	VARCHAR(27)  DEFAULT '',	/*C 27  0 //modelo    (modelo)*/
   ARO_ANIO  	CHAR(4)  DEFAULT '',	/*C  4  0 //aro a�o*/
   COD_CARROC	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Carroceria de Vehiculo*/
   N_CARROC  	VARCHAR(27)  DEFAULT '',	/*C 27  0 //Nombre de Carroceria de Vehiculo*/
   COD_COLOR 	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Color de Vehiculo*/
   N_COLOR   	VARCHAR(27)  DEFAULT '',	/*C 27  0 //Nombre de Color de Vehiculo*/
   COD_COMBUS	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Combustible de Vehiculo*/
   N_COMBUS  	VARCHAR(27)  DEFAULT '',	/*C 27  0 //Nombre de Combustible de Vehiculo*/
   CILIND    	CHAR(6)  DEFAULT '',	/*C  6  0 //Cilindrada*/
   CHASIS    	VARCHAR(20)  DEFAULT '',	/*C 20  0 //Chasis*/
   VIN       	VARCHAR(18)  DEFAULT '',	/*C 18  0 //VIN*/
   MOTOR     	VARCHAR(20)  DEFAULT '',	/*C 20  0 //NUMERO DEL MOTOR*/
   ASIENTOS  	NUMERIC(2,0) DEFAULT 0,	/*N  2  0 //NUMERO DE ASIENTOS*/
   EJES      	NUMERIC(2,0) DEFAULT 0,	/*N  2  0 //NUMERO DE EJES*/
   COD_TRACC 	CHAR(4)  DEFAULT '',	/*C  4  0 //Codigo de Tracci�n de Vehiculo*/
   N_TRACC   	VARCHAR(27)  DEFAULT '',	/*C 27  0 //Nombre de Tracci�n de Vehiculo*/
   COD_TRANS 	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Transmisi�n de Vehiculo*/
   N_TRANS   	VARCHAR(27)  DEFAULT '',	/*C 27  0 //Nombre de Transmisi�n de Vehiculo*/
   PUERTAS   	NUMERIC(2,0) DEFAULT 0,	/*N  2  0 //Cantidad de Puertas del Vehiculo*/
   CILINDROS 	NUMERIC(2,0) DEFAULT 0,	/*N  2  0 //Cantidad de Cilindros del Vehiculo*/
   VELOCIDAD 	NUMERIC(2,0) DEFAULT 0,	/*N  2  0 //Cantidad de Velocidades del Vehiculo*/
   EXCEPCION 	CHAR(2)  DEFAULT '',	/*C  2  0 //Codigo de Exepcion del VIN*/
   COD_MODELO	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Modelo*/
   VERSION   	CHAR(22) DEFAULT '',	/*C  8  0 //Version*/
   COD_COLOR2	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de color 2*/
   N_COLOR2  	VARCHAR(15)  DEFAULT '',	/*C 15  0 //Nombre de color 2*/
   PASAJEROS 	NUMERIC(2,0) DEFAULT 0,	/*N  2  0 //Pasajeros*/
   POTENCIA1 	DECIMAL(7,2) DEFAULT 0.00,	/*N  7  2 //Potencia motor kW @rpm*/
   POTENCIA2 	NUMERIC(5,0) DEFAULT 0,	/*N  5  0 //Potencia motor kW @rpm*/
   REL_POTEN 	DECIMAL(6,2) DEFAULT 0.00,	/*N  6  2 //Relaci�n Potencia - Peso Bruto*/
   LARGO     	NUMERIC(5,0) DEFAULT 0,	/*N  5  0 //Largo del vehiculo en mm*/
   ANCHO     	NUMERIC(5,0) DEFAULT 0,	/*N  5  0 //Ancho del vehiculo en mm*/
   ALTURA    	NUMERIC(5,0) DEFAULT 0,	/*N  5  0 //Altura del vehiculo en mm*/
   PESO_COMBI	DECIMAL(6,2) DEFAULT 0.00 ,	/*N  6  2 //Peso Bruto Vehicular Combinado Maximo*/
   PESO_VEHIC	NUMERIC(6,0) DEFAULT 0,	/*N  6  0 //Peso Bruto Vehicular en kilogramos*/
   PESO_NETO 	NUMERIC(6,0) DEFAULT 0,	/*N  6  0 //Peso Neto*/
   CARGA_UTIL	NUMERIC(6,0) DEFAULT 0,	/*N  6  0 //Carga util en kilogramos*/
   EJE_DELANT	NUMERIC(6,0) DEFAULT 0,	/*N  6  0 //Peso maximo por Eje delantero en kilogramos*/
   EJE_POST1 	NUMERIC(6,0) DEFAULT 0,	/*N  6  0 //Peso maximo por Eje posterior 1 en kilogramos*/
   EJE_POST2 	NUMERIC(6,0) DEFAULT 0,	/*N  6  0 //Peso maximo por Eje posterior 2 en kilogramos*/
   EJE_POST3 	NUMERIC(6,0) DEFAULT 0,	/*N  6  0 //Peso maximo por Eje posterior 3 en kilogramos*/
   DISTANCIA 	NUMERIC(5,0) DEFAULT 0,	/*N  5  0 //Distancia entre Ejes en mm*/
   MARCA_CARR	VARCHAR(18)  DEFAULT '',	/*C 18  0 //Marca de carroceria*/
   SERIE_CARR	VARCHAR(18)  DEFAULT '',	/*C 18  0 //Numero d Serie de carroceria*/
   NUM_RUEDAS	NUMERIC(2,0) DEFAULT 0,	/*N  2  0 //Numero de ruedas*/
   AROS      	CHAR(5)  DEFAULT '',	/*C  4  0 //Medida de Aros en pulgadas*/
   NEUMAT_1  	CHAR(10)  DEFAULT '',	/*C 10  0 //Medidas de Neumaticos 1*/
   NEUMAT_2  	CHAR(10)  DEFAULT '',	/*C 10  0 //Medidas de Neumaticos 2*/
   SUSP_DELAN	VARCHAR(22)  DEFAULT '',	/*C 22  0 //Tipo de Suspension Delantera*/
   SUSP_POSTE	VARCHAR(22)  DEFAULT '',	/*C 22  0 //Tipo de Suspension Posterior*/
   REVISA1   	VARCHAR(16)  DEFAULT '',	/*C 16  0 //Numero de Revisa1*/
   FOB_EXPORT	NUMERIC(9,2) DEFAULT 0,	/*N  6  0 Valor FOB en pais de exportaci�n en d�lares*/
   GTOS_REPAR	NUMERIC(6,0) DEFAULT 0,	/*N  6  0 Gtos.  de color 2*/
   SNTT      	CHAR(1)  DEFAULT '',	/*C  1  0 Indicador de SNTT*/
   HOMOLOGAC 	VARCHAR(12)  DEFAULT '',	/*C 12  0 //Numero de registro de homologacion*/
   FABRICANTE	VARCHAR(20)  DEFAULT '',	/*C 20  0 //Nombre del fabricante*/
   ANIO_MODEL	CHAR(4)  DEFAULT '',	/*C  4  0 //A�o del modelo*/
   OBSERVACIO	VARCHAR(90)  DEFAULT '',	/*C 90  0 //Observaciones*/
   EXTENSION 	VARCHAR(15)  DEFAULT '',	/*C 15  0 //Extension*/
   COD_COLOR3   CHAR(3) DEFAULT "",             /*Codigo de color 3*/
   N_COLOR3     VARCHAR(15) DEFAULT "",         /*Nombre de color 3 */
   COD_COLOR4   CHAR(3) DEFAULT "",             /*Codigo de color 4*/
   N_COLOR4     VARCHAR(15) DEFAULT "",         /* Nombre de color 4*/
   ESTADO       CHAR(2) DEFAULT "",             /* C  2  0 //Estado de la Mercancia*/
   ENCENDIDO    CHAR(3) DEFAULT "",             /*C  3  0 //Tipo de Encendido*/
   KILOMETRA    DECIMAL(10,2) DEFAULT 0.00,     /*Kilometraje*/
   N_ENCENDI    VARCHAR(27) DEFAULT "",         /* 0 Nombre de Encendido*/
   REVISA2      VARCHAR(40) DEFAULT "",         /*C 40  0 Numero de Revisa2 (Pedido de James)*/
   CERTI_REG    VARCHAR(25) DEFAULT "",         /*  0Numero de Certificado (Pedido de James)*/
   SUBPARTIDA   CHAR(2)   DEFAULT '',           /*C  2  0 //Subpartida*/
   CHASIS_TEC   VARCHAR(19) DEFAULT '',         /*C 19  0 //Chasis para Tecadasa*/
   VIN_TEC      VARCHAR(19) DEFAULT '',         /*C 19  0 //Vin para Tecadsa*/
   MOTOR_TEC    VARCHAR(20) DEFAULT '',         /*C 20  0 //Motor para Tecadsa*/
   AROS2        CHAR(5) DEFAULT "",             /* Solo para las Americas */
   N_PUERTAS 	NUMERIC(2,0) DEFAULT 0,	        /*N  2  0 */
   COD_REFRI	CHAR(3)  DEFAULT '',       	/* C  3  1 */
   FRENO_DEL 	CHAR(3)  DEFAULT '',	        /*C  3  1 */
   FRENO_POS	CHAR(3)  DEFAULT '',	        /* C  3  1 */
   TIPO_MOTO	CHAR(3)  DEFAULT '',	        /* C  3  1 */
   CAMBIOS  	NUMERIC(2,0) DEFAULT 0,	        /* N  2  0 */
   PESO_UNITA   VARCHAR(20) DEFAULT '',         /*C 20  0 */
   MODELO_FAB   VARCHAR(30) DEFAULT '',         /*Modelo de Fabricacion*/
   PRIMARY KEY(N_ORDEN,NUME_SECUP,NUME_SECUF,NUM_ITEM),
   CONSTRAINT FK_VEH_ADA FOREIGN KEY(N_ORDEN,NUME_SECUP,NUME_SECUF,NUM_ITEM) REFERENCES ADA(N_ORDEN,NUME_SECUP,NUME_SECUF,NUM_ITEM));
   CREATE INDEX VEH ON VEH(N_ORDEN);

/*ACC (ACCESORIOS DE VEHICULOS DETALLADOS EN DESCRIPCIONES MINIMAS DE VEHICULOS)*/
CREATE TABLE IF NOT EXISTS ACC(	
   N_ORDEN   	CHAR(11) NOT NULL,	/*C  9  0 //Numero de Orden*/
   NUME_SECUP	CHAR(3) NOT NULL,	/*C  2  0 //Secuencia de Proveedor*/
   NUME_SECUF	CHAR(3) NOT NULL,	/*C  3  0 //Secuencia de Factura*/
   NUM_ITEM  	NUMERIC(4,0) NOT NULL,	/*N  4  0 //Secuencia de Item por Factura*/
   CORREL       CHAR(2) NOT NULL,           /* CORRELACION DE CLAVES */
   COD_ACC   	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Carroceria de Vehiculo*/
   NOM_ACC   	CHAR(27) DEFAULT '',	/*C 27  0 //Nombre de Carroceria de Vehiculo*/
   PRIMARY KEY(N_ORDEN,NUME_SECUP,NUME_SECUF,NUM_ITEM,CORREL),
   CONSTRAINT FK_ACC_ADA FOREIGN KEY(N_ORDEN,NUME_SECUP,NUME_SECUF,NUM_ITEM) REFERENCES ADA(N_ORDEN,NUME_SECUP,NUME_SECUF,NUM_ITEM));
   CREATE INDEX ACC ON ACC(N_ORDEN);

/* SAN(DESCRIPCIONES MINIMAS PARA SANITARIOS) */
CREATE TABLE IF NOT EXISTS SAN(	
   N_ORDEN   	CHAR(11) NOT NULL,	    /*C  9  0 //Numero de Orden*/
   NUME_SECUP	CHAR(3) NOT NULL,  	    /*C  2  0 //Secuencia de Proveedor*/
   NUME_SECUF	CHAR(3) NOT NULL,	    /*C  3  0 //Secuencia de Factura*/
   NUM_ITEM  	NUMERIC(4,0) NOT NULL,     /*N  4  0 //Secuencia de Item por Factura*/
   COD_NOMBRE	CHAR(3) DEFAULT "",         /*  0 //Codigo de Nombre de Sanitarios*/
   NOMBRE       VARCHAR(30) DEFAULT "",     /*  0 //Nombre de Sanitarios*/
   COD_TIPO  	CHAR(3) DEFAULT "",         /*  0 //Codigo de Tipo*/
   TIPO         VARCHAR(20) DEFAULT "",     /*  0 //Nombre de Tipo*/
   COD_TARO  	CHAR(3) DEFAULT "",         /* //Codigo de Tipo de Aro*/
   TARO         VARCHAR(20) DEFAULT "",     /*  0 //Nombre de Tipo de Aro*/
   COD_USO   	CHAR(3) DEFAULT "",         /*  0 //Codigo de Tipo de Usuario*/
   TUSUARIO     VARCHAR(20) DEFAULT "",     /*  0 //Nombre de Tipo de Usuario*/
   COD_ACCION	CHAR(3) DEFAULT "",         /*  0 //Si es blando: CON � DES*/
   TACCIONA     VARCHAR(20) DEFAULT "",     /*  0 //Numero de foco*/
   COD_VALV  	CHAR(3) DEFAULT "",         /*  0 //Si es monofocales:ESF, CIL � COM*/
   TVALVULA     VARCHAR(20) DEFAULT "",     /*  0 //Tipo de Color*/
   COD_ASTO  	CHAR(3) DEFAULT "",         /*  0 //Tratamiento*/
   TASIENTO     VARCHAR(20) DEFAULT "",     /*  0 //Acabado*/
   COD_MASTO 	CHAR(3) DEFAULT "",         /*  0 //Asiento de Material de Asiento*/
   TMASIENTO    VARCHAR(20) DEFAULT "",     /*  0 //Nombre de Material de Asiento*/
   COD_CALIDA	CHAR(3) DEFAULT "",         /*  0 //Codigo de Calidad*/
   CALIDAD      VARCHAR(20) DEFAULT "",     /*  0 //Nombre de Calidad*/
   COD_COLOR 	CHAR(3) DEFAULT "",         /*  0 //Codigo de Color*/
   COLOR        VARCHAR(20) DEFAULT "",     /*  0 //Nombre de Color*/
   COD_MAT   	CHAR(3) DEFAULT "",         /*  0 //Codigo de Material*/
   MATERIAL     VARCHAR(20) DEFAULT "",     /*  0 //Nombre de Material*/
   COD_CONSU 	CHAR(3) DEFAULT "",         /*  0 //Codigo de Consumo*/
   CONSUMO      VARCHAR(20) DEFAULT "",     /*  0 //Nombre de Consumo */
   OBSERVAC1    VARCHAR(90) DEFAULT "",     /*  0 //Observaciones*/
   Tipo_func    CHAR(3) DEFAULT "",
   Tipo_long    CHAR(3) DEFAULT "",
   LONGITUD     VARCHAR(25) DEFAULT "",
   PRIMARY KEY(N_ORDEN,NUME_SECUP,NUME_SECUF,NUM_ITEM),
   CONSTRAINT FK_SAN_ADA FOREIGN KEY(N_ORDEN,NUME_SECUP,NUME_SECUF,NUM_ITEM) REFERENCES ADA(N_ORDEN,NUME_SECUP,NUME_SECUF,NUM_ITEM));
   CREATE INDEX SAN ON SAN(N_ORDEN);

/* BLD(DESCRIPCIONES PARA BALDOSAS Y CERAMICOS) */
CREATE TABLE IF NOT EXISTS BLD(	
   N_ORDEN   	CHAR(11) NOT NULL,	    /*C  9  0 //Numero de Orden*/
   NUME_SECUP	CHAR(3) NOT NULL,  	    /*C  2  0 //Secuencia de Proveedor*/
   NUME_SECUF	CHAR(3) NOT NULL,	    /*C  3  0 //Secuencia de Factura*/
   NUM_ITEM  	NUMERIC(4,0) NOT NULL,     /*N  4  0 //Secuencia de Item por Factura*/
   COD_NOMBRE	CHAR(4) DEFAULT "",         /*  0 //Codigo de Nombre de Sanitarios*/
   NOMBRE       VARCHAR(30) DEFAULT "",     /*  0 //Nombre de Sanitarios*/
   COD_ACABAD	CHAR(3) DEFAULT "",         /*  0 //Codigo de Acabado*/
   ACABADO      VARCHAR(20) DEFAULT "",     /*  0 //Acabado*/
   COD_MATER 	CHAR(3) DEFAULT "",         /*  0 //Codigo de Materia*/
   MATERIA      VARCHAR(20) DEFAULT "",     /*  0 //Materia*/
   COD_MOLDEO	CHAR(3) DEFAULT "",         /*  0 //Codigo de Moldeo*/
   MOLDEO       VARCHAR(20) DEFAULT "",     /*  0 //Moldeo*/
   COD_USO   	CHAR(3) DEFAULT "",         /*  0 //Codigo del Uso*/
   USO          VARCHAR(20) DEFAULT "",     /*  0 //Uso*/
   COD_COCC  	CHAR(3) DEFAULT "",         /*  0 //Codigo de coccion*/
   COCCION      VARCHAR(20) DEFAULT "",   /*  0 //Coccion*/
   COD_COLOR 	CHAR(3) DEFAULT "",         /*  0 //Codigo del Color*/
   COLOR        VARCHAR(20) DEFAULT "",     /*  0 //Color*/
   LARGO        NUMERIC(9,2) DEFAULT 0,	    /*  0 //Largo en cm*/
   ANCHO        NUMERIC(9,2) DEFAULT 0,     /*  0 //Ancho en cm*/
   ESPESOR      NUMERIC(9,2) DEFAULT 0,	    /*  0 //Espesor en mm*/
   OBSERVAC1    VARCHAR(90) DEFAULT "",     /*  0 //Observaciones*/
   COD_MATER2	CHAR(3) DEFAULT "",         /*C  3  0*/
   MATERIA2     VARCHAR(20) DEFAULT "",     /*C 20  0*/
   COD_MATER3	CHAR(3) DEFAULT "",         /*C  3  0*/
   MATERIA3     VARCHAR(20) DEFAULT "",     /* C 20  0*/
   COD_MATER4	CHAR(3) DEFAULT "",         /*C  3  0*/
   MATERIA4     VARCHAR(20) DEFAULT "",     /*C 20  0*/
   COD_MATER5	CHAR(3) DEFAULT "",         /*C  3  0*/
   MATERIA5     VARCHAR(20) DEFAULT "",     /*C 20  0*/
   ABSORCION 	CHAR(3) DEFAULT "",         /*C  3  0*/
   PRIMARY KEY(N_ORDEN,NUME_SECUP,NUME_SECUF,NUM_ITEM),
   CONSTRAINT FK_BLD_ADA FOREIGN KEY(N_ORDEN,NUME_SECUP,NUME_SECUF,NUM_ITEM) REFERENCES ADA(N_ORDEN,NUME_SECUP,NUME_SECUF,NUM_ITEM));
   CREATE INDEX BLD ON BLD(N_ORDEN);

/* AVJ(DESCRIPCIONES DE ARTICULOS DE VIAJE) */
CREATE TABLE IF NOT EXISTS AVJ(	
   N_ORDEN   	CHAR(11) NOT NULL,	    /*C  9  0 //Numero de Orden*/
   NUME_SECUP	CHAR(3) NOT NULL,  	    /*C  2  0 //Secuencia de Proveedor*/
   NUME_SECUF	CHAR(3) NOT NULL,	    /*C  3  0 //Secuencia de Factura*/
   NUM_ITEM  	NUMERIC(4,0) NOT NULL,     /*N  4  0 //Secuencia de Item por Factura*/
   COD_NOMBRE	CHAR(3) DEFAULT "",         /*  0 //Codigo de Nombre de Sanitarios*/
   NOMBRE       VARCHAR(30) DEFAULT "",     /*  0 //Nombre de Sanitarios*/
   COD_TMAT  	CHAR(3) DEFAULT "",         /*C  3  0 //Codigo de Tipo de Material*/
   TIP_MAT      VARCHAR(20) DEFAULT "",     /*C 20  0 //Tipo de Material*/
   COD_MAT1  	CHAR(3) DEFAULT "",         /*C  3  0 //Codigo de Material 1*/
   MATERIAL1    VARCHAR(20) DEFAULT "",     /*C 20  0 //Material 1*/
   POR_MAT1     NUMERIC(3,0) DEFAULT 0,	    /*Porcentaje Material 1*/
   COD_MAT2  	CHAR(3) DEFAULT "",         /*C  3  0 //Codigo de Material 2*/
   MATERIAL2    VARCHAR(20) DEFAULT "",     /*C 20  0 //Material 2*/
   POR_MAT2     NUMERIC(3,0) DEFAULT 0,	    /*Porcentaje Material 2*/
   COD_MAT3  	CHAR(3) DEFAULT "",         /*C  3  0 //Codigo de Material 3*/
   MATERIAL3    VARCHAR(20) DEFAULT "",     /*C 20  0 //Material 3*/
   POR_MAT3     NUMERIC(3,0) DEFAULT 0,	    /*Porcentaje Material 3*/
   COD_FORRO 	CHAR(3) DEFAULT "",         /*C  3  0 //Codigo del Forro*/
   FORRO        VARCHAR(20) DEFAULT "",     /*C 20  0 //Forro*/
   COD_ACAB1 	CHAR(3) DEFAULT "",         /*C  3  0 //Codigo de Acabado 1*/
   ACABADO1     VARCHAR(20) DEFAULT "",     /*C 20  0 //Acabado 1*/
   COD_ACAB2 	CHAR(3) DEFAULT "",         /*C  3  0 //Codigo de Acabado 2*/
   ACABADO2     VARCHAR(20) DEFAULT "",     /*C 20  0 //Acabado 2*/
   COD_ACC1  	CHAR(3) DEFAULT "",         /*C  3  0 //Codigo accesorio1*/
   ACCESORIO1   VARCHAR(20) DEFAULT "",     /*C 20  0 //Accesorio1*/
   COD_ACC2  	CHAR(3) DEFAULT "",         /*C  3  0 //Codigo accesorio2*/
   ACCESORIO2   VARCHAR(20) DEFAULT "",     /*C 20  0 //Accesorio2*/
   COD_ACC3  	CHAR(3) DEFAULT "",         /*C  3  0 //Codigo accesorio3*/
   ACCESORIO3   VARCHAR(20) DEFAULT "",     /*C 20  0 //Accesorio3*/
   COD_APLI1 	CHAR(3) DEFAULT "",         /*C  3  0 //Codigo Aplicacion1*/
   APLICAC1     VARCHAR(20) DEFAULT "",     /*C 20  0 //Aplicacion1*/
   NUM_APLIC1   NUMERIC(3,0) DEFAULT 0,	    /*0 //Cantidad Aplicacion1*/
   COD_APLI2 	CHAR(3) DEFAULT "",         /*C  3  0 //Aplicacion2*/
   APLICAC2     VARCHAR(20) DEFAULT "",     /*C 20  0 //Aplicacion2*/
   NUM_APLIC2   NUMERIC(3,0) DEFAULT 0,	    /*Cantidad Aplicacion2*/
   COD_APLI3 	CHAR(3) DEFAULT "",         /*C  3  0 //Codigo Aplicacion3*/
   APLICAC3     VARCHAR(20) DEFAULT "",     /*C 20  0 //Aplicacion3*/
   NUM_APLIC3   NUMERIC(3,0) DEFAULT 0,	    /*Cantidad Aplicacion3*/
   ALTO         NUMERIC(7,1) DEFAULT 0.0,   /*Alto  en pulgadas*/
   LARGO        NUMERIC(7,1) DEFAULT 0.0,   /*Largo en pulgadas*/
   ANCHO        NUMERIC(7,1) DEFAULT 0.0,   /*Ancho en pulgadas*/
   COD_PRESE 	CHAR(3) DEFAULT "",         /*C  3  0 //Codigo de Presentacion*/
   PRESENTAC    VARCHAR(20) DEFAULT "",     /*C 20  0 //Presentacion*/
   PESO         NUMERIC(15,3) DEFAULT 0.000,/* //Peso*/
   COD_USO   	CHAR(3) DEFAULT "",         /*C  3  0 //Codigo de uso*/
   USO          VARCHAR(20) DEFAULT "",     /*C 20  0 //Uso*/
   OBSERVAC1    VARCHAR(90) DEFAULT "",     /*  0 //Observaciones*/
   COD_TMAT2 	CHAR(3) DEFAULT "",         /*C  3  0*/
   TIP_MAT2     VARCHAR(20) DEFAULT "",     /*C 20  0*/
   COD_TMAT3 	CHAR(3) DEFAULT "",         /*C  3  0*/
   TIP_MAT3     VARCHAR(20) DEFAULT "",     /*C 20  0*/
   CANT_ACC1    NUMERIC(3,0) DEFAULT 0.000, /*N  3  0*/
   CANT_ACC2    NUMERIC(3,0) DEFAULT 0.000, /*N  3  0*/
   CANT_ACC3    NUMERIC(3,0) DEFAULT 0.000, /*N  3  0*/
   PRIMARY KEY(N_ORDEN,NUME_SECUP,NUME_SECUF,NUM_ITEM),
   CONSTRAINT FK_AVJ_ADA FOREIGN KEY(N_ORDEN,NUME_SECUP,NUME_SECUF,NUM_ITEM) REFERENCES ADA(N_ORDEN,NUME_SECUP,NUME_SECUF,NUM_ITEM));
   CREATE INDEX AVJ ON AVJ(N_ORDEN);

/* VHT(DESCRIPCIONES MINIMAS DE VAJILLAS) */
CREATE TABLE IF NOT EXISTS VHT(	
   N_ORDEN   	CHAR(11) NOT NULL,	    /*C  9  0 //Numero de Orden*/
   NUME_SECUP	CHAR(3) NOT NULL,  	    /*C  2  0 //Secuencia de Proveedor*/
   NUME_SECUF	CHAR(3) NOT NULL,	    /*C  3  0 //Secuencia de Factura*/
   NUM_ITEM  	NUMERIC(4,0) NOT NULL,     /*N  4  0 //Secuencia de Item por Factura*/
   COD_NOMBRE	CHAR(3) DEFAULT "",         /*  0 //Codigo de Nombre de Sanitarios*/
   NOMBRE       VARCHAR(30) DEFAULT "",     /*  0 //Nombre de Sanitarios*/
   COD_COMPO1	CHAR(3) DEFAULT "",         /*C  3  0 //Codigo de Componente 1*/
   COMPO1       VARCHAR(20) DEFAULT "",     /*C 20  0 //Componente 1*/
   POR_COMPO1   NUMERIC(5,0) DEFAULT 0,	    /* //% del Componente 1*/
   COD_COMPO2	CHAR(3) DEFAULT "",         /*C  3  0 //Codigo de Componente 2*/
   COMPO2       VARCHAR(20) DEFAULT "",     /*C 20  0 //Componente 2*/
   POR_COMPO2   NUMERIC(5,0) DEFAULT 0,	    /*% del Componente 2*/
   COD_COMPO3	CHAR(3) DEFAULT "",         /*C  3  0 //Codigo de Componente 3*/
   COMPO3       VARCHAR(20) DEFAULT "",     /*C 20  0 //Componente 3*/
   POR_COMPO3   NUMERIC(5,0) DEFAULT 0,	    /*% del Componente 3*/
   COD_ACAB  	CHAR(3) DEFAULT "",         /*C  3  0 //Codigo de Acabado*/
   ACABADO      VARCHAR(20) DEFAULT "",     /*C 20  0 //Acabado*/
   COD_COLOR 	CHAR(3) DEFAULT "",         /*C  3  0 //Codigo del Color*/
   COLOR        VARCHAR(20) DEFAULT "",     /*C 20  0 //Color*/
   COD_CALID 	CHAR(3) DEFAULT "",         /*C  3  0 //Codigo de Calidad*/
   CALIDAD      VARCHAR(20) DEFAULT "",     /*C 20  0 //Calidad*/
   COD_PROCE 	CHAR(3) DEFAULT "",         /*C  3  0 //Codigo de Proceso*/
   PROCESO      VARCHAR(20) DEFAULT "",     /*C 20  0 //Proceso*/
   COD_ACC1  	CHAR(3) DEFAULT "",         /*C  3  0 //Codigo accesorio1*/
   ACCESORIO1   VARCHAR(20) DEFAULT "",     /*C 20  0 //Accesorio1*/
   COD_ACC2  	CHAR(3) DEFAULT "",         /*C  3  0 //Codigo accesorio2*/
   ACCESORIO2   VARCHAR(20) DEFAULT "",     /*C 20  0 //Accesorio2*/
   COD_ACC3  	CHAR(3) DEFAULT "",         /*C  3  0 //Codigo accesorio3*/
   ACCESORIO3   VARCHAR(20) DEFAULT "",     /*C 20  0 //Accesorio3*/
   PRESENTAC    VARCHAR(20) DEFAULT "",     /*C 20  0 //Presentacion*/
   PESO         NUMERIC(15,3) DEFAULT 0.000,/* //Peso*/
   OBSERVAC1    VARCHAR(90) DEFAULT "",     /*  0 //Observaciones*/
   UNI_PESO     CHAR(3) DEFAULT "",
   dimension    VARCHAR(25) DEFAULT "", 
   PRIMARY KEY(N_ORDEN,NUME_SECUP,NUME_SECUF,NUM_ITEM),
   CONSTRAINT FK_VHT_ADA FOREIGN KEY(N_ORDEN,NUME_SECUP,NUME_SECUF,NUM_ITEM) REFERENCES ADA(N_ORDEN,NUME_SECUP,NUME_SECUF,NUM_ITEM));
   CREATE INDEX VHT ON VHT(N_ORDEN);

/* JUG(DESCRIPCIONES MINIMAS DE JUGUETES) */
CREATE TABLE IF NOT EXISTS JUG(	
   N_ORDEN   	CHAR(11) NOT NULL,	    /*C  9  0 //Numero de Orden*/
   NUME_SECUP	CHAR(3) NOT NULL,  	    /*C  2  0 //Secuencia de Proveedor*/
   NUME_SECUF	CHAR(3) NOT NULL,	    /*C  3  0 //Secuencia de Factura*/
   NUM_ITEM  	NUMERIC(4,0) NOT NULL,      /*N  4  0 //Secuencia de Item por Factura*/
   COD_NOMBRE	CHAR(3) DEFAULT "",         /*  0 //Codigo de Nombre de Sanitarios*/
   NOMBRE       VARCHAR(30) DEFAULT "",     /*  0 //Nombre de Sanitarios*/
   COD_DIGESA	CHAR(10) DEFAULT "",        /*C 10  0 //Codigo de Tipo*/
   COD_COMPO1	CHAR(3) DEFAULT "",         /*C  3  0 //Codigo de Composicion 1*/
   COMPO1       VARCHAR(40) DEFAULT "",     /*C 40  0 //Nombre de Composicion 1*/
   POR_COMPO1   NUMERIC(4,0) DEFAULT 0,     /*N  4  0 //Porcentaje de Composicion 1*/
   COD_COMPO2	CHAR(3) DEFAULT "",         /*C  3  0 //Codigo de Composicion 2*/
   COMPO2       VARCHAR(40) DEFAULT "",     /*C 40  0 //Nombre de Composicion 2*/
   POR_COMPO2   NUMERIC(4,0) DEFAULT 0,     /*N  4  0 //Porcentaje de Composicion 2*/
   COD_COMPO3	CHAR(3) DEFAULT "",         /*C  3  0 //Codigo de Composicion 3*/
   COMPO3       VARCHAR(40) DEFAULT "",     /*C 40  0 //Nombre de Composicion 3*/
   POR_COMPO3   NUMERIC(4,0) DEFAULT 0,     /*N  4  0 //Porcentaje de Composicion 3*/
   DIMENSION    VARCHAR(30) DEFAULT "",     /*C 15  0 //Largo X Ancho X Altura*/
   COD_TIPO  	CHAR(3) DEFAULT "",         /*C  3  0 //Codigo de Tipo de Juguete*/
   TIPO         VARCHAR(25) DEFAULT "",     /*C 25  0 //Tipo de Juguete*/
   N_PZ_ARM     NUMERIC(4,0) DEFAULT 0,     /*N  4  0 //Numero de piezas de armas*/
   COD_PROY  	CHAR(3) DEFAULT "",         /*C  3  0 //Codigo de Proyectil*/
   TIPO_PROY    VARCHAR(20) DEFAULT "",     /*C 20  0 //Tipo de Proyectil*/
   ACCESORIOS   VARCHAR(50) DEFAULT "",     /*C 50  0 //Accesorios*/
   COD_MOV   	CHAR(3) DEFAULT "",         /*C  3  0 //Codigo de Movimiento*/
   MOVIMIENTO   VARCHAR(45) DEFAULT "",     /*C 45  0 //Movimiento*/
   COD_USUAR 	CHAR(3) DEFAULT "",         /*C  3  0 //Codigo de Usuario*/
   USUARIO      VARCHAR(20) DEFAULT "",     /*C 20  0 //Usuario*/
   COD_PRESEN	CHAR(3) DEFAULT "",         /*C  3  0 //Codigo de PresentacionV*/
   PRESENTAC    VARCHAR(20) DEFAULT "",     /*C 20  0 //Presentacion*/
   OBSERVAC1    VARCHAR(90) DEFAULT "",     /*C 90  0 //Observaciones*/
   N_PZ_PRE     NUMERIC(4,0) DEFAULT 0,     /*N  4  0 //Numero de piezas de presentacion*/
   PRIMARY KEY(N_ORDEN,NUME_SECUP,NUME_SECUF,NUM_ITEM),
   CONSTRAINT FK_JUG_ADA FOREIGN KEY(N_ORDEN,NUME_SECUP,NUME_SECUF,NUM_ITEM) REFERENCES ADA(N_ORDEN,NUME_SECUP,NUME_SECUF,NUM_ITEM));
   CREATE INDEX JUG ON JUG(N_ORDEN);

/* UTI(DESCRIPCIONES MINIMAS DE UTILES) */
CREATE TABLE IF NOT EXISTS UTI(	
   N_ORDEN   	CHAR(11) NOT NULL,	    /*C  9  0 //Numero de Orden*/
   NUME_SECUP	CHAR(3) NOT NULL,  	    /*C  2  0 //Secuencia de Proveedor*/
   NUME_SECUF	CHAR(3) NOT NULL,	    /*C  3  0 //Secuencia de Factura*/
   NUM_ITEM  	NUMERIC(4,0) NOT NULL,      /*N  4  0 //Secuencia de Item por Factura*/
   COD_NOMBRE	CHAR(3) DEFAULT "",         /*  0 //Codigo de Nombre de Sanitarios*/
   NOMBRE       VARCHAR(40) DEFAULT "",     /*  0 //Nombre de Sanitarios*/
   COD_COMPO1	CHAR(3) DEFAULT "",         /*C  3  0 //Codigo de Composicion 1*/
   COMPO1       VARCHAR(30) DEFAULT "",     /*C 40  0 //Nombre de Composicion 1*/
   COD_COMPO2	CHAR(3) DEFAULT "",         /*C  3  0 //Codigo de Composicion 2*/
   COMPO2       VARCHAR(30) DEFAULT "",     /*C 40  0 //Nombre de Composicion 2*/
   COD_COMPO3	CHAR(3) DEFAULT "",         /*C  3  0 //Codigo de Composicion 3*/
   COMPO3       VARCHAR(30) DEFAULT "",     /*C 40  0 //Nombre de Composicion 3*/
   COD_COLOR 	CHAR(3) DEFAULT "",         /*C  3  0 //Codigo de Color*/
   COLOR        VARCHAR(30) DEFAULT "",     /*C 30  0 //Color*/
   COD_ACAB  	CHAR(3) DEFAULT "",         /*C  3  0 //Codigo de Acabado*/
   ACABADO      VARCHAR(30) DEFAULT "",     /*C 30  0 //Acabado*/
   DIMENSION    VARCHAR(40) DEFAULT "",     /*C 40  0 //Dimension*/
   PESO_VOL     NUMERIC(15,2) DEFAULT 0,    /*N 15  0 //Peso o volumen*/
   COD_USO   	CHAR(3) DEFAULT "",         /*C  2  0 //Codigo de uso*/
   USO          VARCHAR(30) DEFAULT "",     /*C 30  0 //Uso*/
   COD_PRESEN	CHAR(3) DEFAULT "",         /*C  3  0 //Codigo de Presentacion*/
   PRESENTAC    VARCHAR(30) DEFAULT "",     /*C 30  0 //Presentacion*/
   COD_MATEXT	CHAR(3) DEFAULT "",         /*C  3  0 //Codigo de Material Externo*/
   MATER_EXT    VARCHAR(30) DEFAULT "",     /*C 30  0 //Material Externo*/
   COD_MATINT	CHAR(3) DEFAULT "",         /*C  3  0 //Codigo de Material Interno*/
   MATER_INT    VARCHAR(30) DEFAULT "",     /*C 30  0 //Material interno*/
   COD_TIPO  	CHAR(3) DEFAULT "",         /*C  3  0 //Codigo de Tipo*/
   TIPO         VARCHAR(30) DEFAULT "",     /*C 30  0 //Tipo o dureza de la punta*/
   COD_DISPO 	CHAR(3) DEFAULT "",         /*C  3  0 //Codigo de Dispositivo*/
   DISPOSITI    VARCHAR(30) DEFAULT "",     /*C 30  0 //Dispositivo*/
   COD_ACCES 	CHAR(3) DEFAULT "",         /*C  3  0 //Codigo de Accesorios*/
   ACCESORIO    VARCHAR(30) DEFAULT "",     /*C 30  0 //Accesorios*/
   NRO_PZAS     NUMERIC(15,0) DEFAULT 0,    /*N 15  0 //Nro. Piezas*/
   OBSERVAC1    VARCHAR(100) DEFAULT "",    /*C100  0 // Observaciones*/
   VOLUMEN      NUMERIC(15,0) DEFAULT 0,    /*N 15  0 // Peso*/
   ADICIONAL    VARCHAR(30) DEFAULT "",     /* Adicionales a la presentacion*/
   TIPO_UTIL 	CHAR(3) DEFAULT "",         /*C  3  0*/
   DIMENSION1   DECIMAL(6,2) DEFAULT 0.00,  /* 6  2 //Dimension1	*/
   DIMENSION2   DECIMAL(6,2) DEFAULT 0.00,  /* 6  2 //Dimension2	*/
   DIMENSION3   DECIMAL(6,2) DEFAULT 0.00,  /* 6  2 //Dimension3	*/
   PRIMARY KEY(N_ORDEN,NUME_SECUP,NUME_SECUF,NUM_ITEM),
   CONSTRAINT FK_UTI_ADA FOREIGN KEY(N_ORDEN,NUME_SECUP,NUME_SECUF,NUM_ITEM) REFERENCES ADA(N_ORDEN,NUME_SECUP,NUME_SECUF,NUM_ITEM));
   CREATE INDEX UTI ON UTI(N_ORDEN);

/* PCL(DESCRIPCIONES MINIMAS DE PROTECTORES DE CELULARES) */
CREATE TABLE IF NOT EXISTS PCL(	
   N_ORDEN   	CHAR(11) NOT NULL,	    /*C  9  0 //Numero de Orden*/
   NUME_SECUP	CHAR(3) NOT NULL,  	    /*C  2  0 //Secuencia de Proveedor*/
   NUME_SECUF	CHAR(3) NOT NULL,	    /*C  3  0 //Secuencia de Factura*/
   NUM_ITEM  	NUMERIC(4,0) NOT NULL,      /*N  4  0 //Secuencia de Item por Factura*/
   COD_NOMBRE	CHAR(3) DEFAULT "",         /*  0   //Codigo de Nombre de Sanitarios*/
   NOMBRE       VARCHAR(30) DEFAULT "",     /*  0   //Nombre */
   MATERIAL  	VARCHAR(30) DEFAULT "",     /*C  3  0 //Material*/
   USO          VARCHAR(30) DEFAULT "",     /*C 40  0 //Uso*/
   TIPO      	VARCHAR(30) DEFAULT "",     /*C  3  0 //Tipo*/
   DISENO       VARCHAR(30) DEFAULT "",     /*C 40  0 //Dise�o*/
   ESPESOR   	DECIMAL(6,2) DEFAULT 0.00,  /*C  3  0 //Espesor*/
   CURVATURA    VARCHAR(30) DEFAULT "",     /*C 40  0 //Curvatura*/
   PRESENTAC 	VARCHAR(30) DEFAULT "",     /*C  3  0 //Presentacion*/
   PRIMARY KEY(N_ORDEN,NUME_SECUP,NUME_SECUF,NUM_ITEM),
   CONSTRAINT FK_PCL_ADA FOREIGN KEY(N_ORDEN,NUME_SECUP,NUME_SECUF,NUM_ITEM) REFERENCES ADA(N_ORDEN,NUME_SECUP,NUME_SECUF,NUM_ITEM));
   CREATE INDEX PCL ON PCL(N_ORDEN);

/* DMT(DESCRIPCIONES MINIMAS DE DIAMANTES) */
CREATE TABLE IF NOT EXISTS DMT(	
   N_ORDEN   	CHAR(11) NOT NULL,	    /*C  9  0 //Numero de Orden*/
   NUME_SECUP	CHAR(3) NOT NULL,  	    /*C  2  0 //Secuencia de Proveedor*/
   NUME_SECUF	CHAR(3) NOT NULL,	    /*C  3  0 //Secuencia de Factura*/
   NUM_ITEM  	NUMERIC(4,0) NOT NULL,      /*N  4  0 //Secuencia de Item por Factura*/
   TIPO      	VARCHAR(30) DEFAULT "",         /*  0   //Tipo de Diamante*/
   FORMA        VARCHAR(30) DEFAULT "",     /*  0   //Forma */
   CORTE      	VARCHAR(30) DEFAULT "",     /*C  3  0 //Corte*/
   COLOR        VARCHAR(30) DEFAULT "",     /*C 40  0 //Color*/
   CLARIDAD  	VARCHAR(30) DEFAULT "",     /*C  3  0 //Claridad*/
   PESO         DECIMAL(6,2) DEFAULT 0.00,   /*C 40  0 //Peso*/
   PRIMARY KEY(N_ORDEN,NUME_SECUP,NUME_SECUF,NUM_ITEM),
   CONSTRAINT FK_DMT_ADA FOREIGN KEY(N_ORDEN,NUME_SECUP,NUME_SECUF,NUM_ITEM) REFERENCES ADA(N_ORDEN,NUME_SECUP,NUME_SECUF,NUM_ITEM));
   CREATE INDEX DMT ON DMT(N_ORDEN);

/* DJR(DECLARACIONES JURADA PARA DHL) */
CREATE TABLE IF NOT EXISTS DJR(	
   N_ORDEN   	CHAR(11) NOT NULL,	    /*C  9  0 //Numero de Orden*/
   NUME_SECUP	CHAR(3) NOT NULL,  	    /*C  2  0 //Secuencia de Proveedor*/
   NUME_SECUF	CHAR(3) NOT NULL,	    /*C  3  0 //Secuencia de Factura*/
   NUM_ITEM  	NUMERIC(4,0) NOT NULL,      /*N  4  0 //Secuencia de Item por Factura*/
   PRESENTAC    VARCHAR(20) DEFAULT "",     /* Adicionales a la presentacion*/
   NRO_REG 	VARCHAR(12) DEFAULT "",     /*C  3  0*/
   FECH_INI     DATE,                       /* 6  2 //Dimension1	*/
   FECH_VCTO    DATE,                       /* 6  2 //Dimension1	*/
   PRIMARY KEY(N_ORDEN,NUME_SECUP,NUME_SECUF,NUM_ITEM),
   CONSTRAINT FK_DJR_ADA FOREIGN KEY(N_ORDEN,NUME_SECUP,NUME_SECUF,NUM_ITEM) REFERENCES ADA(N_ORDEN,NUME_SECUP,NUME_SECUF,NUM_ITEM));
   CREATE INDEX DJR ON DJR(N_ORDEN);

/* LOT (LOTES DE LA DECLARACION JURADA PARA DHL) */
CREATE TABLE IF NOT EXISTS LOT(	
   N_ORDEN   	CHAR(11) NOT NULL,	    /*C  9  0 //Numero de Orden*/
   NUME_SECUP	CHAR(3) NOT NULL,  	    /*C  2  0 //Secuencia de Proveedor*/
   NUME_SECUF	CHAR(3) NOT NULL,	    /*C  3  0 //Secuencia de Factura*/
   NUM_ITEM  	NUMERIC(4,0) NOT NULL,      /*N  4  0 //Secuencia de Item por Factura*/
   CORREL       CHAR(3) NOT NULL,           /*C  2  0 //correaltivo de Lotes */ 
   NUMERO       CHAR(15) DEFAULT "",        /*C  2  0 //Numero del Lote*/
   FECH_INI     DATE,                       /*6  2    //Fecha de Inicio	*/
   FECH_VCTO    DATE,                       /*6  2    //Fecha de Vencimiento	*/
   PRIMARY KEY(N_ORDEN,NUME_SECUP,NUME_SECUF,NUM_ITEM,CORREL),
   CONSTRAINT FK_LOT_DJR FOREIGN KEY(N_ORDEN,NUME_SECUP,NUME_SECUF,NUM_ITEM) REFERENCES DJR(N_ORDEN,NUME_SECUP,NUME_SECUF,NUM_ITEM));
   CREATE INDEX LOT ON LOT(N_ORDEN);

/*HOJ (HOJA ADICIONAL PARA DESCRIPCIONES MINIMAS DE VEHICULOS PARA CETICOS)*/
CREATE TABLE IF NOT EXISTS HOJ(
   N_ORDEN   	CHAR(11) NOT NULL,	/*C  9  0   N� de Orden de despacho - DATOS PRINCIPALES -*/
   NUME_ITEM 	NUMERIC(4,0) DEFAULT 0,	/*N  4  0   N�mero de Item del B*/
   TNOM_LIBRO	VARCHAR(20)  DEFAULT '',	/*C 20  0   Nombre de la Publicaci�n*/
   CCOD_EJEMP	CHAR(1)  DEFAULT '',	/*C  1  0   Ejemplar de la Publicaci�n*/
   FANO_VEHIC	CHAR(4)  DEFAULT '',	/*C  4  0   A�o de la publicaci�n*/
   NMES_PUBLI	CHAR(2)  DEFAULT '',	/*C  2  0   Mes de la Publicaci�n*/
   NNUM_PAGIN	NUMERIC(4,0) DEFAULT 0,	/*N  4  0   N�mero de P�gina*/
   NFAC_CONVE	DECIMAL(11,6) DEFAULT 0.000000,	/*N 11  6   Factor de conversion*/
   MONEDA    	CHAR(3)  DEFAULT '',	/*C  3  0   Codigo de Moneda*/
   MPUBLICA_T	DECIMAL(17,6) DEFAULT 0.000,	/*N 17  6   Monto consignado en la publicacion*/
   MPUBLICA  	DECIMAL(17,6) DEFAULT 0.000,	/*N 17  6   Monto en US$ consignado en la publicacion*/
   MTRANS_T  	DECIMAL(17,6) DEFAULT 0.000,	/*N 17  6   Monto por cambio de transmision*/
   MTRANS    	DECIMAL(17,6) DEFAULT 0.000,	/*N 17  6   Monto en US$ por cambio de transmision*/
   MOPCPU_T  	DECIMAL(17,6) DEFAULT 0.000,	/*N 17  6   Monto ajuste provisionales transmision*/
   MOPCPU    	DECIMAL(17,6) DEFAULT 0.000,	/*N 17  6   Monto en US$ ajuste provisionales transmision*/
   MROOF_T   	DECIMAL(17,6) DEFAULT 0.000,	/*N 17  6   Monto por sun roof*/
   MROOF     	DECIMAL(17,6) DEFAULT 0.000,	/*N 17  6   Monto en US$ por sun roof*/
   MEQUICD_T 	DECIMAL(17,6) DEFAULT 0.000,	/*N 17  6   Equipo con CD*/
   MEQUICD   	DECIMAL(17,6) DEFAULT 0.000,	/*N 17  6   Equipo en US$ con CD*/
   MNVCD_T   	DECIMAL(17,6) DEFAULT 0.000,	/*N 17  6   Monto navigator con CD*/
   MNVCD     	DECIMAL(17,6) DEFAULT 0.000,	/*N 17  6   Monto en US$ navigator con CD*/
   MNVDVD_T  	DECIMAL(17,6) DEFAULT 0.000,	/*N 17  6   Monto navigator con DVD*/
   MNVDVD    	DECIMAL(17,6) DEFAULT 0.000,	/*N 17  6   Monto en US$ navigator con DVD*/
   MOTPUB_T  	DECIMAL(17,6) DEFAULT 0.000,	/*N 17  6   Monto otros segun publicacion*/
   MOTPUB    	DECIMAL(17,6) DEFAULT 0.000,	/*N 17  6   Monto en US$ otros segun publicacion*/
   MPUAJU_T  	DECIMAL(17,6) DEFAULT 0.000,	/*N 17  6   Monto publicacion mas ajustes*/
   MPUAJU    	DECIMAL(17,6) DEFAULT 0.000,	/*N 17  6   Monto en US$ publicacion mas ajustes*/
   MFOBFACT_T	DECIMAL(17,6) DEFAULT 0.000,	/*N 17  6   Monto consignado en la factura comercial*/
   MFOBFACT  	DECIMAL(17,6) DEFAULT 0.000,	/*N 17  6   Monto en US$ consignado en la factura comercial*/
   CODFACT   	CHAR(3)  DEFAULT '',	/*C  3  0   Codigo de moneda de la factura comercial*/
   FACFACT   	DECIMAL(13,10) DEFAULT 0.0000000000,	/*N 13 10   Factor de moneda de la factura comercial*/
   MREPARA   	DECIMAL(17,6) DEFAULT 0.000,	/*N 17  6   Monto por reparacion*/
   MBUECO    	DECIMAL(17,6) DEFAULT 0.000,	/*N 17  6   Monto vehiculo buenas condiciones*/
   MMAXIM_T  	DECIMAL(17,6) DEFAULT 0.000,	/*N 17  6   Monto maximo publicacion y vehiculo buena condiciones*/
   MMAXIM    	DECIMAL(17,6) DEFAULT 0.000,	/*N 17  6   Monto US$ maximo publicacion y vehiculo buena condiciones*/
   MCTIMON   	DECIMAL(17,6) DEFAULT 0.000,	/*N 17  6   Monto US$ por cambio de timon*/
   MFLETE    	DECIMAL(17,6) DEFAULT 0.000,	/*N 17  6   Monto US$ por flete internacional*/
   MSEGURO   	DECIMAL(17,6) DEFAULT 0.000,	/*N 17  6   Monto US$ por seguro*/
   MTASA     	DECIMAL(17,6) DEFAULT 0.000,	/*N 17  6   Monto US$ por tasa*/
   MTRANEX   	DECIMAL(17,6) DEFAULT 0.000,	/*N 17  6   Gasto de transporte interno en el Pa�s de Exportaci�n*/
   MTRANIN   	DECIMAL(17,6) DEFAULT 0.000,	/*N 17  6   Gasto de transporte interno en el Per�*/
   MTRASLA   	DECIMAL(17,6) DEFAULT 0.000,	/*N 17  6   Monto US$ por traslado de vehiculos de un CETICOS a otro*/
   MUVENTA   	DECIMAL(17,6) DEFAULT 0.000,	/*N 17  6   Monto US$ utilidad por �ltima venta*/
   MOTROST   	DECIMAL(17,6) DEFAULT 0.000,	/*N 17  6   Monto US$ por otros gastos incurridos antes de nacionalizar*/
   MNVTV     	DECIMAL(17,6) DEFAULT 0.000,	/*N 17  6   Monto US$ TV*/
   MNVDVDTV  	DECIMAL(17,6) DEFAULT 0.000,	/*N 17  6   Monto US$ equipo con TV-DVD*/
   MAIRE     	DECIMAL(17,6) DEFAULT 0.000,	/*N 17  6   Monto US$ por aire acondicionado*/
   MTAPIZ    	DECIMAL(17,6) DEFAULT 0.000,	/*N 17  6   Monto US$ por tapiz de asiento y alfombra*/
   MCCOLOR   	DECIMAL(17,6) DEFAULT 0.000,	/*N 17  6   Monto US$ por cambio de color*/
   MARO      	DECIMAL(17,6) DEFAULT 0.000,	/*N 17  6   Monto US$ por aros de aluminio, magnesio, aleaci�n u otros*/
   MCTRANS   	DECIMAL(17,6) DEFAULT 0.000,	/*N 17  6   Monto US$ por cambio de transmisi�n*/
   MADAPTA   	DECIMAL(17,6) DEFAULT 0.000,	/*N 17  6   Monto US$ por adaptaci�n*/
   MOTROS    	DECIMAL(17,6) DEFAULT 0.000,	/*N 17  6   Monto US$ por otros opcionales*/
   MROOFA    	DECIMAL(17,6) DEFAULT 0.000,	/*N 17  6   Monto US$ por sun roof*/
   MEQUICDA  	DECIMAL(17,6) DEFAULT 0.000,	/*N 17  6   Monto US$ por equipo con CD*/
   MNVCDA    	DECIMAL(17,6) DEFAULT 0.000,	/*N 17  6   Monto US$ navigator con CD*/
   MNVDVDA   	DECIMAL(17,6) DEFAULT 0.000,	/*N 17  6   Monto US$ navigator con dvd*/
   MFOBCALC  	DECIMAL(17,6) DEFAULT 0.000,	/*N 17  6   Fob US$ calculado*/
   MVADUAN   	DECIMAL(17,6) DEFAULT 0.000,	/*N 17  6   Valor en Aduana*/
   FACTOR    	DECIMAL(13,10) DEFAULT 0.0000000000,	/*N 13 10   Factor de conversion de la publicacion*/
   FECH_VEHIC   DATE, 
   PRIMARY KEY(N_ORDEN,NUME_ITEM),
   CONSTRAINT FK_HOJ_APE FOREIGN KEY(N_ORDEN) REFERENCES APE(N_ORDEN));
   CREATE INDEX HOJ ON HOJ(N_ORDEN);


/********************************************************************************************/
/****          TABLA DE REGIMENES MENORES                                                ****/
/********************************************************************************************/
/***************************************************************************************/
/******************            DUIM DE CARGA               *****************************/
CREATE TABLE IF NOT EXISTS DUM(
   N_ORDEN     CHAR(11) NOT NULL,
   VIA_TRANS   CHAR(1) DEFAULT '',
   EMPR_MENSA  CHAR(4) DEFAULT '',
   PASW_MENSA  CHAR(4) DEFAULT '',
   EMPR_TRANS  CHAR(4) DEFAULT '',
   CANT_BULTO  DECIMAL(15,3) DEFAULT 0.000,
   TPESO_BRUT  DECIMAL(15,3) DEFAULT 0.000,
   CANT_BRECI  DECIMAL(15,3) DEFAULT 0.000,
   TPESO_RECI  DECIMAL(15,3) DEFAULT 0.000,
   TPESO_TARA  DECIMAL(15,3) DEFAULT 0.000,
   NODETA      NUMERIC(4,0) DEFAULT 0, 
   FECH_INREC  DATETIME,
   NUMMANIF    VARCHAR(14) DEFAULT '', 
   MCCODI_TER  CHAR(4) DEFAULT '',
   NUMGUIA     VARCHAR(25) DEFAULT '',    
   NUM_ACTPOS  CHAR(13) DEFAULT '',
   NUME_MC     CHAR(14) DEFAULT '',
   TIPO_ENVIO  CHAR(1) DEFAULT '',
   FECH_TEREC  DATETIME,
   NUME_DUA    CHAR(15) DEFAULT '',
   ALMACEN     CHAR(6) DEFAULT '',   
   NOMBRE_D    VARCHAR(40) DEFAULT '',
   VCTOREG     DATETIME,
   PLAZO_NUM   NUMERIC(3,0) DEFAULT 0, 
   VARIACION   CHAR(1) DEFAULT '',
   EST_MANIF   CHAR(1) DEFAULT '',
   TIPO_INFO   CHAR(1) DEFAULT '',	
   TIPACTMEST  CHAR(1) DEFAULT '',	
   FECACTAINV  DATETIME,
   CONEMBAL    CHAR(33) DEFAULT '',
   TIPEMBAL    CHAR(35) DEFAULT '',
   DESCRIP     CHAR(70) DEFAULT '',
   NUMCONTVIO  CHAR(15) DEFAULT '',
   TIPPRECVIO  CHAR(1) DEFAULT '',
   NUMPRECVIO  CHAR(30) DEFAULT '',	
   NUMCONM     CHAR(25) DEFAULT '',	
   FLAG_REGIM  CHAR(1) DEFAULT '',
   ORDEN_ASOC  CHAR(11) DEFAULT "",
   PRIMARY KEY(N_ORDEN),
   CONSTRAINT FK_DUM_APE  FOREIGN KEY(N_ORDEN) REFERENCES APE(N_ORDEN));
   CREATE INDEX DUM ON DUM(N_ORDEN);
INSERT INTO DUM(N_ORDEN) VALUES("");

/*DUG(DETALLE DE LAS GUIAS DE LA DUIM DE CARGA */
CREATE TABLE IF NOT EXISTS DUG(
   N_ORDEN     CHAR(11) NOT NULL,
   N_SERIE     NUMERIC(4,0) NOT NULL,   
   NUMBLGUIA   VARCHAR(25) DEFAULT '',
   NUMDET      CHAR(5) DEFAULT '',
   VIA_TRANS   CHAR(1) DEFAULT '',
   PUER_EMBAR  CHAR(5) DEFAULT '',
   PUER_DESCA  CHAR(5) DEFAULT '',
   PUER_DESTI  CHAR(5) DEFAULT '',
   CANT_BULTO  DECIMAL(15,3) DEFAULT 0.000,
   CANT_BBUEN  DECIMAL(15,3) DEFAULT 0.000,
   CANT_BMALE  DECIMAL(15,3) DEFAULT 0.000,
   TPESO_BRUT  DECIMAL(15,3) DEFAULT 0.000,
   TPESO_BUEN  DECIMAL(15,3) DEFAULT 0.000,
   TPESO_MALE  DECIMAL(15,3) DEFAULT 0.000,
   EMBARCA     VARCHAR(50) DEFAULT '',
   CONSIGNA    CHAR(5) DEFAULT '',      /* Codigo del Consignatario cuando es Importacion */ 
   DESCRIP     VARCHAR(70) DEFAULT '',
   FOB_CONO    DECIMAL(12,2) DEFAULT 0.00,
   PART_NANDI  CHAR(10) DEFAULT '',
   OBS1        VARCHAR(70) DEFAULT '',
   OBS2        VARCHAR(70) DEFAULT '',
   NUMCONM     VARCHAR(25) DEFAULT '',
   CANT_EMPA   NUMERIC(10,0) DEFAULT 0,
   CANT_REMPA  NUMERIC(10,0) DEFAULT 0,
   TPESO_TARA  DECIMAL(15,3) DEFAULT 0.000,
   MARNUM      VARCHAR(25) DEFAULT '',
   COD_EMBAR   CHAR(4) DEFAULT '',  /* Codigo del embarcador para una Duim cuando es Agencia de Aduana */
   TIPO_CONDI  CHAR(3) DEFAULT '',
   T_CARGA     CHAR(1) DEFAULT '',
   COD_UBI1    CHAR(6) DEFAULT '',
   COD_UBI2    CHAR(6) DEFAULT '',
   COD_UBI3    CHAR(6) DEFAULT '',
   REGI_ADICI  NUMERIC (2,0) DEFAULT 0,
   NRODOCIN    CHAR(6) DEFAULT '',
   FECDOCIN    DATE,
   NUM_ACTMAL  VARCHAR(12) DEFAULT '',
   CLASEBULTO  CHAR(3) DEFAULT '',
   PLACA       VARCHAR(15) DEFAULT '', 
   CARRETA     VARCHAR(15) DEFAULT '',
   COD_P_EMB   CHAR(6) DEFAULT '',
   COD_P_DESC  CHAR(6) DEFAULT '',
   COD_P_DEST  CHAR(6) DEFAULT '',
   PTOACTINMO  CHAR(4) DEFAULT '',
   NROACTINMO  CHAR(10) DEFAULT '',
   OBSERVAC1   VARCHAR (90) DEFAULT "",  
   OBSERVAC2   VARCHAR (90) DEFAULT "",  
   FLAG        NUMERIC(1,0) DEFAULT 0, 	/* Flag para saber que documento envia */
   FCH_RPTA    DATE,                       /* Fecha de la Rpta de Aduanas*/
   NUMCON2     VARCHAR(25) DEFAULT '',        /* Nuevo numero de Guia*/
   NOM_CONS    VARCHAR(80) DEFAULT '', 
   DIR_CONS    VARCHAR(60) DEFAULT '',
   TIPO_DOC    CHAR(4) DEFAULT "GUIA",
   CANT_GUIA   NUMERIC(5,0) DEFAULT 1, 
   PROV_EXT    CHAR(4) DEFAULT '',   /* Codigo del Consignatario cuando es Exportacion */ 
   FLAG_ENV    NUMERIC(2,0) DEFAULT 1,
   ORDEN_SIMP  CHAR(11) DEFAULT "",
   GENERA_ORD  NUMERIC(4,0) DEFAULT 0, /*Flag que indica las ordens que se van a generar para ingreso*/
   SERIE_SIMP  NUMERIC(4,0) DEFAULT 0, /*Numero de Serie de la Dua asociada para la Exportacion */
   NUME_SECUD  CHAR(3) DEFAULT "", 
   COD_EMBARC  CHAR(10) DEFAULT '',     /*Codigo del embargador cuando es una Duim para Agencia de Carga operador 6 */   
   PRIMARY KEY(N_ORDEN,N_SERIE),
   CONSTRAINT FK_DUG_CLI  FOREIGN KEY(CONSIGNA) REFERENCES CLI(CODIGO),
   CONSTRAINT FK_DUG_DGA  FOREIGN KEY(ORDEN_SIMP) REFERENCES DGA(N_ORDEN),
   CONSTRAINT FK_DUG_DUM  FOREIGN KEY(N_ORDEN) REFERENCES DUM(N_ORDEN));
   CREATE INDEX DUG ON DUG(N_ORDEN);
   CREATE INDEX DUG_NUMBLGUIA ON DUG(NUMBLGUIA);

/*DTR(DETALLE DE LOS DOCUMENTOS DE TRANSPORTE */
CREATE TABLE IF NOT EXISTS DTR(
   NUME_SECUD  CHAR(3)  NOT NULL,
   MCNUMCONM   VARCHAR(25) DEFAULT '',
   N_ORDEN     CHAR(11) NOT NULL,
   CANT_BMANI  DECIMAL(15,3) DEFAULT 0.000,
   PESO_BMANI  DECIMAL(15,3) DEFAULT 0.000,
   VIA_TRANSC  CHAR(1) DEFAULT '',
   TIPO_DOCTM  CHAR(1) DEFAULT '',
   COD_EMPVT   CHAR(4) DEFAULT '',
   COD_PORIGC  CHAR(5) DEFAULT '',
   COD_PEMBC   CHAR(5) DEFAULT '',
   MCNUMCONM2  CHAR(25) DEFAULT '',
   CANT_BRECI  DECIMAL(15,3) DEFAULT 0.000,
   TPESO_RECI  DECIMAL(15,3) DEFAULT 0.000,
   FLAG        DECIMAL(1) DEFAULT 0,
   FCH_RPTA    DATE,
   COD_ADUMC   CHAR(3) DEFAULT "",
   NUM_VUELO   CHAR(4) DEFAULT "",
   FECH_EMBAR  DATE,
   MCANNO      CHAR(4) DEFAULT "",
   MCNUME_MC   CHAR(5) DEFAULT "",
   CANT_GUIAS  NUMERIC(4,0) DEFAULT 0,
   PRIMARY KEY(N_ORDEN,NUME_SECUD),
   CONSTRAINT FK_DTR_DUM  FOREIGN KEY(N_ORDEN) REFERENCES DUM(N_ORDEN),
   CONSTRAINT UQ_DTR UNIQUE(N_ORDEN,MCNUMCONM));
   CREATE INDEX DTR ON DTR(N_ORDEN);

/*DUD(DETALLE DE LAS GUIAS DE LA DUIM DE CARGA */   
CREATE TABLE IF NOT EXISTS DUD(
   N_ORDEN     CHAR(11) NOT NULL,
   N_SERIE     NUMERIC(4,0) NOT NULL,   
   CORREL      NUMERIC(2,0) NOT NULL,   
   EMBARCA     VARCHAR(33) DEFAULT '',
   CONSIGNA    VARCHAR(33) DEFAULT '',
   MARNUM      VARCHAR(35) DEFAULT '',
   DESCRIP     VARCHAR(70) DEFAULT '',
   PRIMARY KEY(N_ORDEN,N_SERIE,CORREL),
   CONSTRAINT FK_DUD_DUG  FOREIGN KEY(N_ORDEN,N_SERIE) REFERENCES DUG(N_ORDEN,N_SERIE));
   CREATE INDEX DUD ON DUD(N_ORDEN,N_SERIE);

/******************        AUTOLIQUIDACION DE ADEUDOS           *****************************/

/*AUT(DATOS GENERALES DE LA AUTOLIQUIDACION */
CREATE TABLE IF NOT EXISTS AUT(
   N_ORDEN	CHAR(11) NOT NULL,
   MONEDA 	NUMERIC(1,0) DEFAULT 1,
   ORDEN_ASOC	CHAR(11) DEFAULT '',
   COD_MODALI 	CHAR(4) DEFAULT '',
   T_DEUDOR 	CHAR(1) DEFAULT '',
   ADU_ASOC 	CHAR(3) DEFAULT '',
   REG_ASOC 	CHAR(2) DEFAULT '',
   NDOC_ASOC 	CHAR(6) DEFAULT '',
   FDOC_ASOC 	DATE,
   V_TRANSP 	CHAR(1) DEFAULT '',
   NCDA_ASOC 	CHAR(2) DEFAULT '',
   DIGI_ASOC 	CHAR(1) DEFAULT '',
   CONO_EMBAR 	VARCHAR(25) DEFAULT '',
   NUMDET 	CHAR(5) DEFAULT '',
   FECH_INFRA 	DATE,
   FECH_PRESE 	DATE,
   MOTIVO_1 	VARCHAR(100) DEFAULT '',
   MOTIVO_2 	VARCHAR(170) DEFAULT '',
   MOTIVO_3 	VARCHAR(100) DEFAULT '',
   MOTIVO_4 	VARCHAR(100) DEFAULT '',
   BASE_LEG1 	CHAR(3) DEFAULT '',
   BASE_LEG2 	CHAR(3) DEFAULT '',
   BASE_LEG3 	CHAR(3) DEFAULT '',
   REG_INCEN 	CHAR(1) DEFAULT '',
   PORC_INCEN 	CHAR(1) DEFAULT '',
   REG_GRADU 	CHAR(1) DEFAULT '',
   PORC_GRADU 	CHAR(1) DEFAULT '',
   TDPIGV 	DECIMAL (12,2) DEFAULT 0.000,
   TIPO_DECLA 	CHAR(1) DEFAULT '',
   CALINTERES   NUMERIC(1,0) DEFAULT 0,
   COD_SUSTEN 	CHAR(2) DEFAULT '',
   DES_SUSTEN   VARCHAR(47) DEFAULT '',
   FECH_ANEX2   DATE,
   TOTAL_NETO	DECIMAL (13,3) DEFAULT 0.000,
   TOTAL_GRAD	DECIMAL (13,3) DEFAULT 0.000,
   TOTAL_INCE	DECIMAL (13,3) DEFAULT 0.000,
   TOTAL_INTE	DECIMAL (13,3) DEFAULT 0.000,
   TOTAL_GEN	DECIMAL (13,3) DEFAULT 0.000,
   OBSERVAC1 	VARCHAR(47) DEFAULT '',	
   OBSERVAC2 	VARCHAR(47) DEFAULT '',
   FCH_PRELIQ   DATE,
   TOT_ADV      DECIMAL(10,3) DEFAULT 0.000,  	 
   TOT_ISC      DECIMAL(10,3) DEFAULT 0.000, 	 
   TOT_IGV      DECIMAL(10,3) DEFAULT 0.000, 	 
   TOT_IPM      DECIMAL(10,3) DEFAULT 0.000, 	 
   STADV_DOL    DECIMAL(12,2) DEFAULT 0.00, 	 
   STISC_DOL    DECIMAL(12,2) DEFAULT 0.00, 	 
   STIGV_DOL    DECIMAL(12,2) DEFAULT 0.00, 	 
   STIPM_DOL    DECIMAL(12,2) DEFAULT 0.00, 	 
   STDES_DOL    DECIMAL(12,2) DEFAULT 0.00, 	 
   STANT_DOL    DECIMAL(12,2) DEFAULT 0.00, 	 
   STSOB_DOL    DECIMAL(12,2) DEFAULT 0.00, 	 
   STDER_DOL    DECIMAL(12,2) DEFAULT 0.00, 	 
   SLTADV_DOL   DECIMAL(12,2) DEFAULT 0.00,	 
   SLTISC_DOL   DECIMAL(12,2) DEFAULT 0.00,	 
   SLTIGV_DOL   DECIMAL(12,2) DEFAULT 0.00, 	 
   SLTIPM_DOL   DECIMAL(12,2) DEFAULT 0.00, 	 
   SLTDES_DOL   DECIMAL(12,2) DEFAULT 0.00, 	 
   SLTANT_DOL   DECIMAL(12,2) DEFAULT 0.00, 	 
   SLTSOB_DOL   DECIMAL(12,2) DEFAULT 0.00, 	 
   SLTDER_DOL   DECIMAL(12,2) DEFAULT 0.00, 	 
   NRO_CDA_LC	CHAR(18) DEFAULT '',
   FTRANFORD    CHAR(1) DEFAULT '',
   ANO_PRESE 	NUMERIC(4,0) DEFAULT 0,
   CIFDOL 	DECIMAL (13,3) DEFAULT 0.00,
   REP_LEGAL    CHAR(2) DEFAULT "",
   TIPO_GRA     CHAR(1) DEFAULT "",
   PRIMARY KEY(N_ORDEN),
   CONSTRAINT FK_AUT_APE  FOREIGN KEY(N_ORDEN) REFERENCES APE(N_ORDEN));
   CREATE INDEX AUT ON AUT(N_ORDEN);

/*DAU(TABLA DE DETALLE DE IMPUESTOS A PAGAR DE LA AUTOLIQUIDACION */
CREATE TABLE IF NOT EXISTS DAU(
   N_ORDEN     CHAR(11) NOT NULL,            /* NUMERO DE ORDEN DE LA AUTOLIQUIDACION  */
   CORREL      CHAR(2) NOT NULL,             /* ORDEN FISICO X ORDEN COMODIN */
   COD_DERE    CHAR(4) DEFAULT '',           /* CODIGO DE DERECHO A PAGAR  */
   DES_DERE    VARCHAR(60) DEFAULT '',       /* DESCRIPCION DE DERECHO A PAGAR */
   IMPORTE     DECIMAL(13,3) DEFAULT 0.000,  /* IMPORTE A PAGAR */
   IMPOR_INCE  DECIMAL(13,3) DEFAULT 0.000,  /* IMPORTE CON INCENTIVO */
   IMPOR_GRAD  DECIMAL(13,3) DEFAULT 0.000,  /* IMPORTE CON GRADUALIDAD */
   PRIMARY KEY(N_ORDEN,CORREL),
   CONSTRAINT FK_DAU_AUT  FOREIGN KEY(N_ORDEN) REFERENCES AUT(N_ORDEN));
   CREATE INDEX DAU ON DAU(N_ORDEN);

/*SAU(SERIES DE LA ORDEN ASOCIADA DE LA AUTOLIQUIDACION A AJUSTAR*/
CREATE TABLE IF NOT EXISTS SAU(
   N_ORDEN    CHAR(11) NOT NULL,             /* NUMERO DE ORDEN DE LA AUTOLIQUIDACION  */
   N_SERIE    NUMERIC(4,0) NOT NULL,        /* Numero de Serie               */
   FOB_ORIG   DECIMAL(13,3) DEFAULT 0.000,  /* FOB ORIGINAL DE LA SERIE DE LA ORDEN ASOCIADA */
   FOB_AJUST  DECIMAL(17,6) DEFAULT 0.000,  /* FOB AJUSTADO DE LA SERIE DE LA ORDEN ASOCIADA */
   FOBUNI     DECIMAL(17,6) DEFAULT 0.000,  /* FOB UNITARIO DE LA SERIE DE LA ORDEN ORIGINAL*/
   FCH_EMB    DATE,                         /* Fecha de embarque  ************** */
   UNI_COMER  DECIMAL(13,3) DEFAULT 0.000,  /* Unidades comerciales */
   CLAS_COMER CHAR(3) DEFAULT '',           /* Clase de unidades comerciales */
   KNSER      DECIMAL(14,3) DEFAULT 0.000,  /* Kilo Neto */
   KBSER      DECIMAL(14,3) DEFAULT 0.000,  /* Kilo Bruto*/
   UFISICAS   DECIMAL(13,3) DEFAULT 0.000,  /* Unidades fisicas */
   TIPOUFIS   CHAR(12) DEFAULT '',          /* tipo de unidad fisica */
   PARTIDA    CHAR(10) DEFAULT '',          /* Partida Nandina */
   PAN        CHAR(10) DEFAULT '',          /* P.Naladisa � P.Nabandina */
   TIPO_MARGE CHAR(1) DEFAULT '',           /*C  1  0*      *     Tipo de margen*/
   COD_LIB    CHAR(4) DEFAULT '',           /*TPI, TPN o Cod.Lib */
   TRATO_PREF CHAR(4) DEFAULT '',           /*  TPI, TPN o Cod.Lib*/
   COD_P_PRO  CHAR(3) DEFAULT '',           /*  Pais de origen */
   FOBSER     DECIMAL(13,3) DEFAULT 0.000,  /* Fob    en transacci�n*/
   FOBSDOL    DECIMAL(13,3) DEFAULT 0.000,  /* Fob    en d�lares*/
   FOBGSER    DECIMAL(13,3) DEFAULT 0.000,  /* Gtos.  en transacci�n*/
   FOBGDOL    DECIMAL(13,3) DEFAULT 0.000,  /* Gtos.  en d�lares*/
   AJUSTE     DECIMAL(13,3) DEFAULT 0.000,  /* Monto del ajuste realizado por el Agente de aduanas en dolares*/
   VTA_SUCESI DECIMAL(13,3) DEFAULT 0.000,  /* Valor prorrateado por serie de la venta Sucesiva*/
   FLESER     DECIMAL(13,3) DEFAULT 0.000,  /* Flete en transacci�n*/
   FLESDOL    DECIMAL(13,3) DEFAULT 0.000,  /* Flete en d�lares*/
   SEGSER     DECIMAL(13,3) DEFAULT 0.000,  /* Seguro en transacci�n*/
   SEGSDOL    DECIMAL(13,3) DEFAULT 0.000,  /* Seguro en d�lares*/
   TIPO_SEG   CHAR(1) DEFAULT '',           /*C  1  0             Tipo de seguro por serie  */
   TNAN       CHAR(2) DEFAULT '', 	    /*C  2  0*    *     * Tipo de IGV e ISC por serie de acuerdo a la Partida*/
   CIFSER     DECIMAL(14,3) DEFAULT 0.000,  /*Cif en transacci�n */
   CIFSDOL    DECIMAL(14,3) DEFAULT 0.000,  /*Cif en d�lares */
   CEXPODUMP  CHAR(4) DEFAULT '',           /* Codigo de Antidumping para empresa exportadora */
   CPROD      CHAR(2) DEFAULT '',           /* Codigo de antidumping por producto */
   FOB_FACT   DECIMAL(17,6) DEFAULT 0.000,  /* N 17  6 Fob Fact.para Antidump.("10") en dolares */
   MPO        DECIMAL(9,3) DEFAULT 0.000,   /* Margen porcentual ------ SISTEMA ------  de liberacion de advalorem*/
   DOC_CANCEL CHAR(1) DEFAULT '',           /* Indica Acogimiento a Doc.Cancelat.4201,4202*/
   ADVALSER   DECIMAL(7,3) DEFAULT 0.000,   /*  N  7  3 Tasa de Advalorem*/
   ADVDOL     DECIMAL(12,2) DEFAULT 0.00,   /*N 12  2 Advalorem a pagar*/
   LADVDOL    DECIMAL(12,2) DEFAULT 0.00,   /*N 12  2 Advalores liquidado*/
   SOBRETSER  DECIMAL(7,3) DEFAULT 0.000,   /*N  7  3 Tasa de sobretasa*/
   SB10DOL    DECIMAL(13,2) DEFAULT 0.00,   /*N 13  2 Sobretasa a pagar*/
   LSB10DOL   DECIMAL(13,2) DEFAULT 0.00,   /*N 13  2 Sobretasa liquidada*/
   D_ESP      DECIMAL(10,2) DEFAULT 0.00,   /*N 10  2 Monto de derecho especifico de tabla*/
   DS16DOL    DECIMAL(13,2) DEFAULT 0.00,   /*N 13  2 Derecho espefico a pagar*/
   LDS16DOL   DECIMAL(13,2) DEFAULT 0.00,   /*N 13  2 Derecho espefico liquidado*/
   ISCSER     DECIMAL(7,3) DEFAULT 0.000,   /*N  7  3 Tasa de I.S.C.*/
   VAISCSER   DECIMAL(7,3) DEFAULT 0.000,   /*N  7  3 Tasa Variante de I.S.C. para algunas partidas, remplaza a la del arancel*/
   PRESOLISC  DECIMAL(12,2) DEFAULT 0.00,   /*N 12  2 Precio en soles por galon para calculo de I.S.C. para partidas de gasolina*/
   ISCDOL     DECIMAL(12,2) DEFAULT 0.00,   /*N 12  2 I.S.C. a pagar*/
   LISCDOL    DECIMAL(12,2) DEFAULT 0.00,   /*N 12  2 I.S.C. liquidado*/
   IGVSER     DECIMAL(7,3) DEFAULT 0.000,   /*N  7  3 Tasa de IGV*/
   VAIGVSER   DECIMAL(7,3) DEFAULT 0.000,   /*N  7  3 Tasa variante de I.G.V. para algunas partidas remplaza a la del Arancel para Libros etc.*/
   IGVDOL     DECIMAL(12,2) DEFAULT 0.00,   /*N 12  2 I.G.V. a pagar*/
   LIGVDOL    DECIMAL(12,2) DEFAULT 0.00,   /*N 12  2 I.G.V. liquidado*/
   IPMSER     DECIMAL(7,3) DEFAULT 0.000,   /*N  7  3 Tasa de IPM*/
   VAIPMSER   DECIMAL(7,3) DEFAULT 0.000,   /*N  7  3 Tasa variante de I.P.M. remplaza a la del Arancel para Libros etc.*/
   IPMDOL     DECIMAL(12,2) DEFAULT 0.00,   /*N 12  2 I.P.M. a pagar*/
   LIPMDOL    DECIMAL(12,2) DEFAULT 0.00,   /*N 12  2 I.P.M. liquidado*/
   ANTIDOL    DECIMAL(12,2) DEFAULT 0.00,   /*N 12  2 Monto de antidumping en dolares*/
   NUM_FACT1  VARCHAR(40) DEFAULT '',       /*   0 Para regimen (18,48) */
   FCH_FACT1  DATE,                         /*   D  8  0 Para regimen (18,48)*/
   PART_NABAN CHAR(8) DEFAULT '',           /*   C  8  0 Partida Nabandina */
   QUNIISC    DECIMAL(9,3) DEFAULT 0.000,   /* N 15  3 Cantidad de unidades de I.S.C.*/
   TUNIISC    CHAR(3) DEFAULT '',           /* C  3  0 Tipo de unidades de I.S.C.*/
   PIGVDOL    DECIMAL(12,2) DEFAULT 0.00,   /*N 12  2*            Importe del IGV en Dolares*/
   AADV_DOL   DECIMAL(9,3) DEFAULT 0.000,   /* N 12  2 Advalorem sin rebaja por Derecho Expecifico*/
   ASB10DOL   DECIMAL(9,3) DEFAULT 0.00,    /*N 13  2 Sobretasa sin rebaja por Derecho Expecifico*/
   NUMDET     CHAR(5) DEFAULT '',           /*C  3  0 Numero de detalle en caso de mas de un Bl/Guia*/
   NUMBULTOS  DECIMAL(9,3) DEFAULT 0.000,   /* N 14  3 Numero de bultos*/
   ESTADO     CHAR(2) DEFAULT '',           /* C  2  0 Estado de la Mercaderia*/
   MERCANCIA  VARCHAR(35) DEFAULT '',       /* Nombre generico de la Mercancia segun Item de la Orden Asociada */
   MARCA      VARCHAR(30) DEFAULT '',       /* Marca del productos segun Orden Asociada */
   MODELO     VARCHAR(27) DEFAULT '',       /* Modelo del producto segun Orden Asociada */
   NUM_ITEM   NUMERIC(4,0) DEFAULT 0,       /* Numeri de Item del producto segun Orden Asociada */
   PRIMARY KEY(N_ORDEN,N_SERIE),
   CONSTRAINT FK_SAU_AUT  FOREIGN KEY(N_ORDEN) REFERENCES AUT(N_ORDEN));
   CREATE INDEX SAU ON SAU(N_ORDEN);

/*SAJ(SERIES DE LA ORDEN ASOCIADA DE LA AUTOLIQUIDACION A AJUSTAR (DETALLADO PARA DHL)*/
CREATE TABLE IF NOT EXISTS SAJ(
   N_ORDEN    CHAR(11) NOT NULL,             /*C  9  0 N� de Orden de despacho --- DATOS PRINCIPALES*/
   N_SERIE    NUMERIC(4,0) NOT NULL,        /*N  4  0 N� Serie*/
   FCH_EMB    DATE,                         /*D  8  0 Fecha de embarque*/
   UNI_COMER  DECIMAL(13,3) DEFAULT 0.000,  /*N 13  3 Unidades comerciales*/
   CLAS_COMER CHAR(3) DEFAULT '',           /*C  3  0 clase de unidades comerciales*/
   KNSER      DECIMAL(14,3) DEFAULT 0.000,  /* Kilo Neto */
   KBSER      DECIMAL(14,3) DEFAULT 0.000,  /* Kilo Bruto*/
   UFISICAS   DECIMAL(13,3) DEFAULT 0.000,  /* Unidades fisicas */
   TIPOUFIS   CHAR(12) DEFAULT '',          /* tipo de unidad fisica */
   PARTIDA    CHAR(10) DEFAULT '',          /* Partida Nandina */
   PAN        CHAR(10) DEFAULT '',          /* P.Naladisa � P.Nabandina */
   TIPO_MARGE CHAR(1) DEFAULT '',           /*CSUNAD C  1  0*      *     Tipo de margen*/
   COD_LIB    CHAR(4) DEFAULT '',           /*TPI, TPN o Cod.Lib */
   TRATO_PREF CHAR(4) DEFAULT '',           /*  TPI, TPN o Cod.Lib*/
   COD_P_PRO  CHAR(3) DEFAULT '',           /*  Pais de origen */
   FOBSER     DECIMAL(13,3) DEFAULT 0.000,  /* Fob    en transacci�n*/
   FOBSDOL    DECIMAL(13,3) DEFAULT 0.000,  /* Fob    en d�lares*/
   FOBGSER    DECIMAL(13,3) DEFAULT 0.000,  /* Gtos.  en transacci�n*/
   FOBGDOL    DECIMAL(13,3) DEFAULT 0.000,  /* Gtos.  en d�lares*/
   AJUSTE     DECIMAL(13,3) DEFAULT 0.000,  /* Monto del ajuste realizado por el Agente de aduanas en dolares*/
   VTA_SUCESI DECIMAL(13,3) DEFAULT 0.000,  /* Valor prorrateado por serie de la venta Sucesiva*/
   FLESER     DECIMAL(13,3) DEFAULT 0.000,  /* Flete en transacci�n*/
   FLESDOL    DECIMAL(13,3) DEFAULT 0.000,  /* Flete en d�lares*/
   SEGSER     DECIMAL(13,3) DEFAULT 0.000,  /* Seguro en transacci�n*/
   SEGSDOL    DECIMAL(13,3) DEFAULT 0.000,  /* Seguro en d�lares*/
   TIPO_SEG   CHAR(1) DEFAULT '',           /* ENCON C  1  0             Tipo de seguro por serie  */
   TNAN       CHAR(2) DEFAULT '', 	    /* ENCON C  2  0*    *     * Tipo de IGV e ISC por serie de acuerdo a la Partida*/
   CIFSER     DECIMAL(14,3) DEFAULT 0.000,  /*Cif en transacci�n */
   CIFSDOL    DECIMAL(14,3) DEFAULT 0.000,  /*Cif en d�lares */
   DES1       VARCHAR(100) DEFAULT '',      /* C100  0 Descripci�n comercial*/
   CEXPODUMP  CHAR(4) DEFAULT '',           /* Codigo de Antidumping para empresa exportadora */
   CPROD      CHAR(2) DEFAULT '',           /* Codigo de antidumping por producto */
   FOB_FACT   DECIMAL(17,6) DEFAULT 0.000,  /* N 17  6 Fob Fact.para Antidump.("10") en dolares */
   MPO        DECIMAL(9,3) DEFAULT 0.000,   /* Margen porcentual ------ SISTEMA ------  de liberacion de advalorem*/
   DOC_CANCEL CHAR(1) DEFAULT '',           /* Indica Acogimiento a Doc.Cancelat.4201,4202*/
   ADVALSER   DECIMAL(7,3) DEFAULT 0.000,   /*  N  7  3 Tasa de Advalorem*/
   ADVDOL     DECIMAL(12,2) DEFAULT 0.00,   /*N 12  2 Advalorem a pagar*/
   LADVDOL    DECIMAL(12,2) DEFAULT 0.00,   /*N 12  2 Advalores liquidado*/
   SOBRETSER  DECIMAL(7,3) DEFAULT 0.000,   /*N  7  3 Tasa de sobretasa*/
   SB10DOL    DECIMAL(13,2) DEFAULT 0.00,   /*N 13  2 Sobretasa a pagar*/
   LSB10DOL   DECIMAL(13,2) DEFAULT 0.00,   /*N 13  2 Sobretasa liquidada*/
   D_ESP      DECIMAL(10,2) DEFAULT 0.00,   /*N 10  2 Monto de derecho especifico de tabla*/
   DS16DOL    DECIMAL(13,2) DEFAULT 0.00,   /*N 13  2 Derecho espefico a pagar*/
   LDS16DOL   DECIMAL(13,2) DEFAULT 0.00,   /*N 13  2 Derecho espefico liquidado*/
   ISCSER     DECIMAL(7,3) DEFAULT 0.000,   /*N  7  3 Tasa de I.S.C.*/
   VAISCSER   DECIMAL(7,3) DEFAULT 0.000,   /*N  7  3 Tasa Variante de I.S.C. para algunas partidas, remplaza a la del arancel*/
   PRESOLISC  DECIMAL(12,2) DEFAULT 0.00,   /*N 12  2 Precio en soles por galon para calculo de I.S.C. para partidas de gasolina*/
   ISCDOL     DECIMAL(12,2) DEFAULT 0.00,   /*N 12  2 I.S.C. a pagar*/
   LISCDOL    DECIMAL(12,2) DEFAULT 0.00,   /*N 12  2 I.S.C. liquidado*/
   IGVSER     DECIMAL(7,3) DEFAULT 0.000,   /*N  7  3 Tasa de IGV*/
   VAIGVSER   DECIMAL(7,3) DEFAULT 0.000,   /*N  7  3 Tasa variante de I.G.V. para algunas partidas remplaza a la del Arancel para Libros etc.*/
   IGVDOL     DECIMAL(12,2) DEFAULT 0.00,   /*N 12  2 I.G.V. a pagar*/
   LIGVDOL    DECIMAL(12,2) DEFAULT 0.00,   /*N 12  2 I.G.V. liquidado*/
   IPMSER     DECIMAL(7,3) DEFAULT 0.000,   /*N  7  3 Tasa de IPM*/
   VAIPMSER   DECIMAL(7,3) DEFAULT 0.000,   /*N  7  3 Tasa variante de I.P.M. remplaza a la del Arancel para Libros etc.*/
   IPMDOL     DECIMAL(12,2) DEFAULT 0.00,   /*N 12  2 I.P.M. a pagar*/
   LIPMDOL    DECIMAL(12,2) DEFAULT 0.00,   /*N 12  2 I.P.M. liquidado*/
   ANTIDOL    DECIMAL(12,2) DEFAULT 0.00,   /*N 12  2 Monto de antidumping en dolares*/
   NUM_FACT1  VARCHAR(40) DEFAULT '',       /*   0 Para regimen (18,48) */
   FCH_FACT1  DATE,                         /*   D  8  0 Para regimen (18,48)*/
   PART_NABAN CHAR(8) DEFAULT '',           /*   C  8  0 Partida Nabandina */
   QUNIISC    DECIMAL(9,3) DEFAULT 0.000,   /* N 15  3 Cantidad de unidades de I.S.C.*/
   TUNIISC    CHAR(3) DEFAULT '',           /* C  3  0 Tipo de unidades de I.S.C.*/
   AADV_DOL   DECIMAL(9,3) DEFAULT 0.000,   /* N 12  2 Advalorem sin rebaja por Derecho Expecifico*/
   ASB10DOL   DECIMAL(9,3) DEFAULT 0.00,    /*N 13  2 Sobretasa sin rebaja por Derecho Expecifico*/
   TOTSDER    DECIMAL(12,2) DEFAULT 0.00,    /*N 12  2 Total Derechos*/
   PPARTIDA   CHAR(10) DEFAULT '',           /*C 10  0 *********** VALORES PAGADOS*/
   PCOD_LIB   CHAR(4) DEFAULT '',            /*C  4  0 TPI, TPN o Cod.Lib*/
   PTRATO_PRE CHAR(4) DEFAULT '',           /*C  4  0 TPI, TPN o Cod.Lib*/
   PCOD_P_PRO CHAR(3) DEFAULT '',           /*C  3  0 Pais de origen*/
   PFOBSDOL   DECIMAL(13,3) DEFAULT 0.000,  /*N 13  3 Fob    en d�lares*/
   PFOBGDOL   DECIMAL(13,3) DEFAULT 0.000,  /*N 13  3 Gtos.  en d�lares*/
   PAJUSTE    DECIMAL(13,3) DEFAULT 0.000,  /*N 13  3 Monto del ajuste realizado por el Agente de aduanas en dolares*/
   PVTA_SUCES DECIMAL(13,3) DEFAULT 0.000,  /*N 13  3 Valor prorrateado por serie de la venta Sucesiva*/
   PFLESDOL   DECIMAL(13,3) DEFAULT 0.000,  /*N 13  3 Flete en d�lares*/
   PSEGSDOL   DECIMAL(13,3) DEFAULT 0.000,  /*N 13  3 Seguro en d�lares*/
   PCIFSDOL   DECIMAL(13,3) DEFAULT 0.000,  /*N 13  3 Cif en d�lares*/
   PADVDOL    DECIMAL(12,2) DEFAULT 0.000,  /*N 12  2 Advalorem a pagar*/
   PSB10DOL   DECIMAL(13,2) DEFAULT 0.000,  /*N 13  2 Sobretasa a pagar*/
   PDS16DOL   DECIMAL(13,2) DEFAULT 0.000,  /*N 13  2 Derecho espefico a pagar*/
   PISCDOL    DECIMAL(12,2) DEFAULT 0.000,  /*N 12  2 I.S.C. a pagar*/
   PIGVDOL    DECIMAL(12,2) DEFAULT 0.000,  /*N 12  2 I.G.V. a pagar*/
   PIPMDOL    DECIMAL(12,2) DEFAULT 0.000,  /*N 12  2 I.P.M. a pagar*/
   PANTIDOL   DECIMAL(12,2) DEFAULT 0.000,  /*N 12  2 Monto de antidumping en dolares*/
   PTOTSDER   DECIMAL(12,2) DEFAULT 0.000,  /*N 12  2 Total Derechos*/
   DFOBSDOL   DECIMAL(13,3) DEFAULT 0.000,  /*N 13  3 ********** DIFERENCIA DE VALORES PAGADOS VERSUS AJUSTADOS*/
   DFOBGDOL   DECIMAL(13,3) DEFAULT 0.000,  /*N 13  3 Gtos.  en d�lares*/
   DAJUSTE    DECIMAL(13,3) DEFAULT 0.000,  /*N 13  3 Monto del ajuste realizado por el Agente de aduanas en dolares*/
   DVTA_SUCES DECIMAL(13,3) DEFAULT 0.000,  /*N 13  3 Valor prorrateado por serie de la venta Sucesiva*/
   DFLESDOL   DECIMAL(13,3) DEFAULT 0.000,  /*N 13  3 Flete en d�lares*/
   DSEGSDOL   DECIMAL(13,3) DEFAULT 0.000,  /*N 13  3 Seguro en d�lares*/
   DCIFSDOL   DECIMAL(13,3) DEFAULT 0.000,  /*N 13  3 Cif en d�lares*/
   DADVDOL    DECIMAL(12,2) DEFAULT 0.000,  /*N 12  2 Advalorem a pagar*/
   DSB10DOL   DECIMAL(13,2) DEFAULT 0.000,  /*N 13  2 Sobretasa a pagar*/
   DDS16DOL   DECIMAL(13,2) DEFAULT 0.000,  /*N 13  2 Derecho espefico a pagar*/
   DISCDOL    DECIMAL(12,2) DEFAULT 0.000,  /*N 12  2 I.S.C. a pagar*/
   DIGVDOL    DECIMAL(12,2) DEFAULT 0.000,  /*N 12  2 I.G.V. a pagar*/
   DIPMDOL    DECIMAL(12,2) DEFAULT 0.000,  /*N 12  2 I.P.M. a pagar*/
   DANTIDOL   DECIMAL(12,2) DEFAULT 0.000,  /*N 12  2 Monto de antidumping en dolares*/
   DTOTSDER   DECIMAL(12,2) DEFAULT 0.000,  /*N 12  2 Total Derechos*/
   PRIMARY KEY(N_ORDEN,N_SERIE),
   CONSTRAINT FK_SAJ_AUT  FOREIGN KEY(N_ORDEN) REFERENCES AUT(N_ORDEN));
   CREATE INDEX SAJ ON SAJ(N_ORDEN);

/*RLG(REPRESENTATES LEGALES DE LA AGENCIA PARA LA AUTOLIQUIDACION*/
CREATE TABLE IF NOT EXISTS RLG(
   CODIGO  CHAR(2) not null,
   NOMBRE  VARCHAR(30) default '',
   DNI     VARCHAR(8) default '',
   CARGO   VARCHAR(25) DEFAULT '',	
   PRIMARY KEY(CODIGO),
   CONSTRAINT UQ_RLG UNIQUE(NOMBRE));
CREATE INDEX RLG ON RLG(CODIGO);

/********************************************************************************************/
/******************    NACIONALIZACION DE ADMISION TEMPORAL     *****************************/
/********************************************************************************************/
/*NDT(DETALLE DE LAS SERIES DE LA NACIONALIZACION*/
CREATE TABLE IF NOT EXISTS NDT(
   N_ORDEN      CHAR(11) NOT NULL,                 /* NUMERO DE ORDEN DEL DESPACHO */
   N_SERIE      NUMERIC(4,0) NOT NULL,       	   /*N  4  0*************N� Serie*/
   DES1      	VARCHAR(100) DEFAULT '', 	   /*C100  0*************Descripci�n comercial*/
   FCH_EMB    	DATE, 	                           /*D  8  0******   *** Fecha de embarque*/
   UNI_COMER  	DECIMAL(13,3) DEFAULT 0.000, 	   /*N 13  3*************Unidades comerciales*/
   CLAS_COMER 	CHAR(3) DEFAULT '', 	           /*C  3  0*************clase de unidades comerciales*/
   KNSER      	DECIMAL(14,3) DEFAULT 0.000, 	   /*N 14  3*************Kilo Neto*/
   KBSER      	DECIMAL(14,3) DEFAULT 0.000, 	   /*N 14  3*************Kilo Bruto*/
   UFISICAS   	DECIMAL(13,3) DEFAULT 0.000, 	   /*N 13  3*************unidades fisicas*/
   TIPOUFIS   	CHAR(12) DEFAULT '', 	           /*C 12  0*************tipo de unidad fisica*/
   PARTIDA    	CHAR(10) DEFAULT '',     	   /*C 10  0*************Partida Nandina*/
   PAN        	CHAR(10) DEFAULT '', 	           /*C 10  0*  *         P.Naladisa */
   COD_LIB    	CHAR(4) DEFAULT '', 	           /*C  4  0*  *       * TPI, TPN o Cod.Lib*/
   TRATO_PREF 	CHAR(4) DEFAULT '',     	   /*C  4  0*            TPI, TPN o Cod.Lib*/
   TIPO_MARGE 	CHAR(1) DEFAULT '',     	   /*C  1  0*      *     Tipo de margen*/
   COD_P_PRO  	CHAR(3) DEFAULT '',     	   /*C  3  0******   *** Pais de origen*/
   FOBSER     	DECIMAL(13,3) DEFAULT 0.000, 	   /*N 13  3*************Fob    en transacci�n*/
   FOBSDOL    	DECIMAL(13,3) DEFAULT 0.000, 	   /*N 13  3*************Fob    en d�lares*/
   FOBGSER    	DECIMAL(13,3) DEFAULT 0.000, 	   /*N 13  3*    *     * Gtos.  en transacci�n*/
   FOBGDOL    	DECIMAL(13,3) DEFAULT 0.000, 	   /*N 13  3*    *     * Gtos.  en d�lares*/
   AJUSTE     	DECIMAL(13,3) DEFAULT 0.000, 	   /*N 13  3*            Monto del ajuste realizado por el Agente de aduanas en dolares*/
   VTA_SUCESI 	DECIMAL(13,3) DEFAULT 0.000, 	   /*N 13  3*            Valor prorrateado por serie de la venta Sucesiva*/
   FLESER     	DECIMAL(13,3) DEFAULT 0.000, 	   /*N 13  3******** *** Flete en transacci�n*/
   FLESDOL    	DECIMAL(13,3) DEFAULT 0.000, 	   /*N 13  3******** *** Flete en d�lares*/
   SEGSER     	DECIMAL(13,3) DEFAULT 0.000, 	   /*N 13  3******   *** Seguro en transacci�n*/
   SEGSDOL    	DECIMAL(13,3) DEFAULT 0.000, 	   /*N 13  3******   *** Seguro en d�lares*/
   TIPO_SEG     CHAR(1) DEFAULT '',                /*C  1  0             Tipo de seguro por serie  */
   TNAN      	CHAR(2) DEFAULT '', 	           /*C  2  0*    *     * Tipo de IGV e ISC por serie de acuerdo a la Partida*/
   CIFSER     	DECIMAL(13,3) DEFAULT 0.000, 	   /*N 13  3*************Cif en transacci�n*/
   CIFSDOL    	DECIMAL(13,3) DEFAULT 0.000, 	   /*N 13  3*************Cif en d�lares*/
   CEXPODUMP  	CHAR(4) DEFAULT '',     	   /*C  4  0*            Codigo de Antidumping para empresa exportadora*/
   CPROD      	CHAR(2) DEFAULT '',     	   /*C  2  0*            Codigo de antidumping por producto*/
   FOB_FACT  	DECIMAL(17,6) DEFAULT 0.000000,    /*N 17  6*************Fob Fact.para Antidump.("10") en dolares*/
   MPO       	DECIMAL(9,3) DEFAULT 0.000, 	   /*N  9  3*  *       * Margen porcentual ------ SISTEMA ------  de liberacion de advalorem*/
   DOC_CANCEL 	CHAR(1) DEFAULT '', 	           /*C  1  0      **  *  Indica Acogimiento a Doc.Cancelat.4201,4202*/
   ADVALSER  	DECIMAL(7,3) DEFAULT 0.000, 	   /*N  7  3******   *** Tasa de Advalorem*/
   ADVDOL    	DECIMAL(12,2) DEFAULT 0.00, 	   /*N 12  2******   * * Advalorem a pagar*/
   LADVDOL   	DECIMAL(12,2) DEFAULT 0.00, 	   /*N 12  2******   *** Advalores liquidado*/
   SOBRETSER 	DECIMAL(7,3) DEFAULT 0.000, 	   /*N  7  3*  *       * Tasa de sobretasa*/
   SB10DOL   	DECIMAL(13,2) DEFAULT 0.00, 	   /*N 13  2*  *       * Sobretasa a pagar*/
   LSB10DOL  	DECIMAL(13,2) DEFAULT 0.00, 	   /*N 13  2*  *       * Sobretasa liquidada*/
   D_ESP     	DECIMAL(10,2) DEFAULT 0.00, 	   /*N 10  2             Monto de derecho especifico de tabla*/
   DS16DOL   	DECIMAL(13,2) DEFAULT 0.00, 	   /*N 13  2             Derecho espefico a pagar*/
   LDS16DOL  	DECIMAL(13,2) DEFAULT 0.00, 	   /*N 13  2             Derecho espefico liquidado*/
   ISCSER    	DECIMAL(7,3) DEFAULT 0.000, 	   /*N  7  3*  *         Tasa de I.S.C.*/
   VAISCSER  	DECIMAL(7,3) DEFAULT 0.000, 	   /*N  7  3*            Tasa Variante de I.S.C. para algunas partidas, remplaza a la del arancel*/
   PRESOLISC 	DECIMAL(12,2) DEFAULT 0.00, 	   /*N 12  2*            Precio en soles por galon para calculo de I.S.C. para partidas de gasolina*/
   ISCDOL    	DECIMAL(12,2) DEFAULT 0.00, 	   /*N 12  2*  *         I.S.C. a pagar*/
   LISCDOL   	DECIMAL(12,2) DEFAULT 0.00, 	   /*N 12  2*  *         I.S.C. liquidado*/
   IGVSER    	DECIMAL(7,3) DEFAULT 0.000, 	   /*N  7  3******   *** Tasa de IGV*/
   VAIGVSER  	DECIMAL(7,3) DEFAULT 0.000, 	   /*N  7  3*    *     * Tasa variante de I.G.V. para algunas partidas remplaza a la del Arancel para Libros etc.*/
   IGVDOL    	DECIMAL(12,2) DEFAULT 0.00, 	   /*N 12  2******   * * I.G.V. a pagar*/
   LIGVDOL   	DECIMAL(12,2) DEFAULT 0.00, 	   /*N 12  2******   *** I.G.V. liquidado*/
   IPMSER    	DECIMAL(7,3) DEFAULT 0.000, 	   /*N  7  3******   *** Tasa de IPM*/
   VAIPMSER  	DECIMAL(7,3) DEFAULT 0.000, 	   /*N  7  3*    *     * Tasa variante de I.P.M. remplaza a la del Arancel para Libros etc.*/
   IPMDOL    	DECIMAL(12,2) DEFAULT 0.00, 	   /*N 12  2******   * * I.P.M. a pagar*/
   LIPMDOL   	DECIMAL(12,2) DEFAULT 0.00, 	   /*N 12  2******   *** I.P.M. liquidado*/
   ANTIDOL   	DECIMAL(12,2) DEFAULT 0.00, 	   /*N 12  2             Monto de antidumping en dolares*/
   NUM_FACT1 	VARCHAR(40) DEFAULT '', 	   /*C 40  0*************Para regimen (18,48)*/
   FCH_FACT1 	DATE, 	                   /*D  8  0*************Para regimen (18,48)*/
   PART_NABAN 	CHAR(8) DEFAULT '',     	   /*C  8  0*            Partida Nabandina*/
   QUNIISC   	DECIMAL(15,3) DEFAULT 0.000, 	   /*N 15  3*            Cantidad de unidades de I.S.C.*/
   TUNIISC   	CHAR(3) DEFAULT '', 	           /*C  3  0*            Tipo de unidades de I.S.C.*/
   AADV_DOL  	DECIMAL(12,2) DEFAULT 0.00,        /*N 12  2             Advalorem sin rebaja por Derecho Expecifico*/
   ASB10DOL  	DECIMAL(13,2) DEFAULT 0.00,	   /*N 13  2             Sobretasa sin rebaja por Derecho Expecifico*/
   NUMDET     	CHAR(5) DEFAULT '', 	           /*C  3  0*  * *   *   Numero de detalle en caso de mas de un Bl/Guia*/
   NUMBULTOS  	DECIMAL(14,3) DEFAULT 0.000, 	   /*N 14  3*************Numero de bultos*/
   ESTADO    	CHAR(2) DEFAULT '', 	           /*C  2  0************ Estado de la mercancia*/
   TPROD      	CHAR(1) DEFAULT 'N',     	   /*C  2  0*************Codigo de autorizaci�n de mercancia restringida*/
   PIGVDOL   	DECIMAL(12,2) DEFAULT 0.00, 	   /*N 12  2*            Importe del IGV en Dolares*/
   NACI_EXCAD   CHAR(1) DEFAULT '', 	           /*C  1  0 //Para nacionalizacion de Admision(Insumo o desperdicios)*/
   CANT_SUJET   DECIMAL(15,3) DEFAULT 0.000, 	   /*N 15  3 //cantidad sujeta a regularizacion*/
   UNIMEDI      CHAR(4) DEFAULT '', 	           /*C  4  0 //Unidad de medida del insumo en admision, unid. de produccion en Imp. temp.*/
   CADU_TRA     CHAR(3) DEFAULT '', 	           /*C  3  0 //Aduana de la transferencia*/
   ANO_TRA      CHAR(4) DEFAULT '', 	           /*C  4  0 //A�o de la transferencia*/
   NUME_TRA     CHAR(9) DEFAULT '', 	           /*C  9  0 //Numero de la transfencia*/
   SERIE_TRA    CHAR(4) DEFAULT '', 	           /*C  4  0 //Numero de la serie de la transferencia*/
   PAJUSTE    	DECIMAL(13,3) DEFAULT 0.000, 	   /*N 13  3*/
   PVTA_SUCES 	DECIMAL(13,3) DEFAULT 0.000, 	   /*N 13  3*/
   PFOBSER    	DECIMAL(13,3) DEFAULT 0.000, 	   /*N 13  3*/
   PFLESER    	DECIMAL(13,3) DEFAULT 0.000, 	   /*N 13  3*/
   PSEGSER    	DECIMAL(13,3) DEFAULT 0.000, 	   /*N 13  3*/
   PFOBGSER   	DECIMAL(13,3) DEFAULT 0.000, 	   /*N 13  3*/
   PUFISICAS  	DECIMAL(13,3) DEFAULT 0.000, 	   /*N 13  3*/
   PUNI_COMER 	DECIMAL(13,3) DEFAULT 0.000, 	   /*N 13  3*/
   PCIFSER    	DECIMAL(13,3) DEFAULT 0.000, 	   /*N 13  3*/
   PKnSER     	DECIMAL(14,3) DEFAULT 0.000, 	   /*N 14  3*/
   PRIMARY KEY(N_ORDEN,N_SERIE),
   CONSTRAINT FK_NDT_DGA  FOREIGN KEY(N_ORDEN) REFERENCES DGA(N_ORDEN));
   CREATE INDEX NDT ON NDT(N_ORDEN,N_SERIE);

/********************************************************************************************/
/******************     MATERIAL DE USO AERONAUTICO             *****************************/
CREATE TABLE IF NOT EXISTS MOV(
   N_ORDEN     CHAR(11) NOT NULL,           /* NUMERO DE ORDEN DEL REPORTE DE MOVIMIENTOS MUA */
   ORDEN_ORIG  CHAR(11) NOT NULL,           /* ORDEN DE DMA */
   N_SERIE     CHAR(4) DEFAULT '',         /* NUMERO DE SERIE DE LA DMA */
   EMPTRANSP   CHAR(4) DEFAULT '',         /* EMPRESA DE TRANSPORTE */
   CODDEPO     CHAR(4) DEFAULT '',         /* CODIGO DE DEPOSITO DE DMA*/
   CODMUA      CHAR(10) DEFAULT '',        /* CODIGO DEL PRODUCTO MUA */
   UNI_MEDIDA  CHAR(3) DEFAULT '',         /* CODIGO DEL TIPO DE UNIDAD DE MEDIDA */
   FCHNUMER    DATE,                       /* FECHA DE NUMERACION DEL DMA */
   CODMODALI   CHAR(2) DEFAULT '',         /* CODIGO DE MODALIDAD (INGRESO/SALIDA/SALDO */
   CODI_ADUAN  CHAR(3) DEFAULT '',         /* CODIGO DE ADUANA DE NUMERACION DEL DMA */
   N_DECLAR    CHAR(6) DEFAULT '',         /* NUMERO DE DECLARACION DEL DMA */
   INGRESO     DECIMAL (14,3) DEFAULT 0.00, /* UNIDADES COMERCIALES QUE INGRESARON DEL DMA */
   SALIDA      DECIMAL (14,3) DEFAULT 0.00, /* UNIDADES COMERCIALES QUE SALIERON DEL DMA */
   SALDO       DECIMAL (14,3) DEFAULT 0.00, /* UNIDADES COMERCIALES PENDIENTES  */
   DES1        VARCHAR (70) DEFAULT '',     /* DESCRIPCION DEL PRODUCTO DEL MUA */
   OBSERVAC    VARCHAR (60) DEFAULT '',     /* OBSERVACIONES DEL CONSUMO */
   SEC         NUMERIC(4,0) DEFAULT 0,      /* SECUENCIA CORRELATIVA PARA EL ENVIO DEL REPORTE MENSUAL */
   COD_CLIEN   CHAR(5) DEFAULT '',          /* CODIGO DE CLIENTE DEL DMA */
   CONSUMO     DECIMAL(14,3) DEFAULT 0.00,  /* CANTIDAD DE UNIDADES COMERCIALES CONSUMIDAS EN EL MES */
   MARCA       NUMERIC(1,0) DEFAULT 0,      /* FLAG QUE DETERMINA LOS REGISTROS QUE VAN A SER ENVIADOS POR TELEDESPACHO */
   PRIMARY KEY(N_ORDEN,ORDEN_ORIG,N_SERIE,CODMUA,CODMODALI),
   CONSTRAINT FK_MOV_APE  FOREIGN KEY(N_ORDEN) REFERENCES APE(N_ORDEN),
   CONSTRAINT FK_MOV_TA281  FOREIGN KEY(CODMUA) REFERENCES softpad_tablas.TA281(CODIGO));
   CREATE INDEX MOV ON MOV(N_ORDEN);

/***************************************************************************************/
/*****  REINGRESO Y SALIDA DE BIENES A LA ZONA DEL AEROPUERTO INTERNACIONAL         ****/
CREATE TABLE IF NOT EXISTS SRA(
   N_ORDEN     CHAR(11) NOT NULL,
   CODMODALI   CHAR(1) DEFAULT '',
   EMPTRANSP   CHAR(4) DEFAULT '',
   NOMTRANSP   VARCHAR(40) DEFAULT '',
   PESO_BRUTO  DECIMAL(15,3) DEFAULT 0.000,
   CANT_BULTO  DECIMAL(15,3) DEFAULT 0.000,
   COD_MUA     CHAR(10) DEFAULT '',
   NRO_GUIA    VARCHAR(14) DEFAULT '',
   FECH_GUIA   DATE,
   NUMDECPRE1  VARCHAR(50) DEFAULT '',
   NUMDECPRE2  VARCHAR(50) DEFAULT '',
   NUMDECPRE3  VARCHAR(50) DEFAULT '',
   NUMDECPRE4  VARCHAR(50) DEFAULT '',
   NUMDECPRE5  VARCHAR(50) DEFAULT '',
   NUMDECPRE6  VARCHAR(50) DEFAULT '',
   NUMDECPRE7  VARCHAR(50) DEFAULT '',
   NUMDECPRE8  VARCHAR(50) DEFAULT '',
   NUMDECPRE9  VARCHAR(50) DEFAULT '',
   NUMDECPRE10 VARCHAR(50) DEFAULT '',
   NUMDECPRE11 VARCHAR(50) DEFAULT '',
   NUMDECPRE12 VARCHAR(50) DEFAULT '',
   DESCRIPC_1  VARCHAR(100) DEFAULT '',
   DESCRIPC_2  VARCHAR(100) DEFAULT '',
   DESCRIPC_3  VARCHAR(100) DEFAULT '',
   DESCRIPC_4  VARCHAR(100) DEFAULT '',
   DESCRIPC_5  VARCHAR(100) DEFAULT '',
   DESCRIPC_6  VARCHAR(100) DEFAULT '',
   DESCRIPC_7  VARCHAR(100) DEFAULT '',
   DESCRIPC_8  VARCHAR(100) DEFAULT '',
   DESCRIPC_9  VARCHAR(100) DEFAULT '',
   DESCRIPC_10 VARCHAR(100) DEFAULT '',
   DESCRIPC_11 VARCHAR(100) DEFAULT '',
   DESCRIPC_12 VARCHAR(100) DEFAULT '',
   COD_MUATRAN CHAR(4) DEFAULT '',
   PRIMARY KEY(N_ORDEN),
   CONSTRAINT FK_SRA_APE  FOREIGN KEY(N_ORDEN) REFERENCES APE(N_ORDEN));
   CREATE INDEX SRA ON SRA(N_ORDEN);

/**************************************************************************************************************/
/******************     RECEPCION DE ALMACENES/RELACION DETALLADA DE CARGA AEREA  *****************************/
CREATE TABLE IF NOT EXISTS RAL(
   N_ORDEN	CHAR(11) NOT NULL,
   TIPO_AFORO   CHAR(1) DEFAULT '', 
   ORDEN_ASOC	CHAR(11) DEFAULT '',
   REG_ASOC 	CHAR(2) DEFAULT '',
   V_TRANSP 	CHAR(1) DEFAULT '',
   NUM_ORDEMB 	CHAR(6) DEFAULT '',
   FDOC_ASOC 	DATE,
   TIPO_TRANS 	CHAR(2) DEFAULT '',
   ULTD_RECEP 	CHAR(1) DEFAULT '',
   N_ENVIOS     CHAR(10) DEFAULT '',
   F_REC_ALMA   DATETIME,
   NUME_CNT     VARCHAR(15) DEFAULT '',
   PRECINTO     VARCHAR(15) DEFAULT '',
   CANT_BULTO   DECIMAL(10,2) DEFAULT 0.00,
   PESO_BRUTO	DECIMAL(15,3) DEFAULT 0.000,
   DESC_MERC    VARCHAR(200) DEFAULT '',
   CODI_OPERA   CHAR(2) DEFAULT '',
   CONDI_CNT    CHAR(3) DEFAULT '',
   FAGENTE      DATETIME,
   MOTI_ANULA   VARCHAR(150) DEFAULT '',
   NUM_EMBAR    NUMERIC(2,0) DEFAULT 0,
   ADU_ASOC 	CHAR(3) DEFAULT '',
   TIPO_CNT     CHAR(1) DEFAULT '',
   PESO_NETO    DECIMAL(15,3) DEFAULT 0.000,
   TARA         DECIMAL(15,3) DEFAULT 0.000,
   N_PRE_OTRO   VARCHAR(15) DEFAULT '',
   TAMANO       CHAR(2) DEFAULT '',
   TIPO_INGRE   CHAR(1) DEFAULT '',
   NUMMANIF     VARCHAR(9) DEFAULT '',
   COD_ANULA    CHAR(3) DEFAULT '',
   FECH_SALI    DATETIME,
   PUER_DESTI   CHAR(5) DEFAULT '',
   NUM_BLM      VARCHAR(11) DEFAULT '',
   NUM_BLH      VARCHAR(12) DEFAULT '',
   CODI_LINEA   CHAR(4) DEFAULT '',
   NAVE         VARCHAR(10) DEFAULT '',
   FECH_VUELO   DATETIME,
   num_guia_t   varchar(15) default '',
   num_book     varchar(20) default '',
   ruc_transp   varchar(11) default '',
   placa_vehi   varchar(7) default '',
   dni_conduc   varchar(11) default '',
   num_guia_e   varchar(15) default '',
   c_camb_pre   char(2) default '',
   PRIMARY KEY(N_ORDEN),
   CONSTRAINT FK_RAL_APE  FOREIGN KEY(N_ORDEN) REFERENCES APE(N_ORDEN));
   CREATE INDEX RAL ON RAL(N_ORDEN);

/***************************************************************************************/
/******************       ACTA DE TRASLADO DE ENVIOS POSTALES   ************************/
/***************************************************************************************/
/*ACT(DATOS GENERALES DEL ACTA DE TRASLADO */
CREATE TABLE IF NOT EXISTS ACT(
   N_ORDEN    CHAR(11) NOT NULL,
   TIPO_DESPA CHAR(3) DEFAULT '',
   VIA_TRANS  CHAR(1) DEFAULT '',
   EMPR_TRANS CHAR(4) DEFAULT '',
   NOMTRANSP  VARCHAR(40) DEFAULT '',
   FECH_DESC  DATETIME,
   FECH_TRAS  DATE,
   ALMA_ORIGE CHAR(4) DEFAULT "",
   ALMA_DESTI CHAR(4) DEFAULT "",
   CANT_BULTO DECIMAL(14,3) DEFAULT 0.000,
   TPESO_BRUT DECIMAL(14,3) DEFAULT 0.000,
   NUMMANIF   VARCHAR(14) DEFAULT '',
   PUER_EMBAR CHAR(6) DEFAULT '',
   NUMGUIA    VARCHAR(25) DEFAULT '',
   NUMDET     CHAR(5) DEFAULT '',
   OBSERV     VARCHAR(75) DEFAULT '',
   PRIMARY KEY(N_ORDEN),
   CONSTRAINT FK_ACT_APE FOREIGN KEY(N_ORDEN) REFERENCES APE(N_ORDEN));
   CREATE INDEX ACT ON ACT(N_ORDEN);

/*DAC(DETALLE DEL ACTA DE TRASLADO */
CREATE TABLE IF NOT EXISTS DAC(
   N_ORDEN    CHAR(11) NOT NULL,
   NUM_PLACA  CHAR(9) DEFAULT '',
   CANT_BULTO DECIMAL(14,3) DEFAULT 0.000,
   NUME_PREC  VARCHAR(10) DEFAULT '',
   COND_EXTE  CHAR(3) DEFAULT '',
   PRIMARY KEY(N_ORDEN,NUM_PLACA),
   CONSTRAINT FK_DAC_ACT FOREIGN KEY(N_ORDEN) REFERENCES ACT(N_ORDEN));
   CREATE INDEX DAC ON DAC(N_ORDEN,NUM_PLACA);


/***************************************************************************************/
/****************** MANIFIESTO DESCONSOLIDADO PARA AGENCIAS DE CARGA  ******************/

/*PTP (PARTICIPANTES DEL MANIFIESTO DESCONSOLIDADO*/
CREATE TABLE IF NOT EXISTS PTP(
   CODIGO      CHAR(5) NOT NULL,    /* CODIGO DEL PARTICIPANTE  */
   NOMBRE      VARCHAR(175) DEFAULT "", /* NOMBRE O RAZON SOCIAL  */
   TIPO_DOCUM  CHAR(1) DEFAULT '',    /* CODIGO DE TIPO INDENTIFICACION */
   DOCUMENTO   CHAR(11) DEFAULT '',  /* NUMERO DE DOCUMENTO C(11) */
   COD_BAS     VARCHAR(15) DEFAULT "", /* CODIGO DE SE ASIGNACION DE OPERADOR CODIGO BAS */
   DIRECCION   VARCHAR(140) DEFAULT '', /* DIRECCION DEL PARTICIPANTE*/ 
   CIUDAD      VARCHAR(35) DEFAULT "", /* CIUDAD DEL PARTICIPANTE*/
   COD_PAIS    CHAR(2) DEFAULT "",     /* CODIGO DE PAIS*/
   TELEFONO    VARCHAR(16) DEFAULT "", /* TELEFONOS DEL PARTICIPANTE */ 
   FAX         VARCHAR(40) DEFAULT "", /* FAX DEL PARTICIPANTE */
   EMAIL_WEB   VARCHAR(100)DEFAULT "", /* E MAIL O PAGINA WEB DEL PARTICIPANTE*/
   ROL         CHAR(2) NOT NULL,    /* ROL DEL PARTICIPANTE  */
   PRIMARY KEY(ROL,CODIGO),
   CONSTRAINT FK_PTP_TA4 FOREIGN KEY(ROL) REFERENCES softpad_tablas.TA4(CODIGO));
   CREATE INDEX PTP ON PTP(ROL,CODIGO);

/* CONSTRAINT UQ_PTP_1   UNIQUE(ROL,TIPO_DOCUM,DOCUMENTO) */


/*MNF(DECLARACION DE MANIFIESTO */
CREATE TABLE IF NOT EXISTS MNF(
   N_ORDEN     CHAR(11) NOT NULL,           /*Numero de Orden con que se indentifica la operacion */
   NUM_VIAJE   VARCHAR(17) DEFAULT '',      /*Numero de Vaje */
   CANT_BULTO  NUMERIC(10,0) DEFAULT 0,     /*Cantidad de bultos  */
   FECHESTLLE  DATE,                        /*Fecha estimada de Llegada */  
   LUGAR_LLE   VARCHAR(13) DEFAULT "",      /*Lugar de Llegada de la Nave */ 
   TIPO_LULLE  CHAR(3) DEFAULT "",          /*Tipo de Lugar de Llegada */
   FECH_ZARPE  DATE,                        /*FEcha de Zarpe de la Nave */ 
   LUGAR_SAL   VARCHAR(13) DEFAULT "",      /*Lugar de Salida */  
   TIPO_LUSAL  CHAR(3) DEFAULT "",          /*Tipo de Lugar de Salida */
   PESO_CARGA  DECIMAL(13,3) DEFAULT 0.000, /*Peso de la Carga */ 
   EMPTRANSP   CHAR(4) DEFAULT "",          /*Empresa de Transporte */
   NUMMANIF    CHAR(14) DEFAULT "",         /*Aduana a�o y numero de Manifiesto */  
   TIPO_MANIF  CHAR(2) DEFAULT "",          /*Tipo de Manifiesto */
   TIPO_TRANS  CHAR(2) DEFAULT "",          /*Tipo de transaccion */  
   PRIMARY KEY(N_ORDEN),
   CONSTRAINT FK_MNF_APE FOREIGN KEY(N_ORDEN) REFERENCES APE(N_ORDEN));
   CREATE INDEX MNF ON MNF(N_ORDEN);

/*BLM(DOCUMENTOS DE TRANSPORTE MASTERS) */
CREATE TABLE IF NOT EXISTS BLM(
   NUME_SECUM  CHAR(2) NOT NULL,            /*Numero de Detalle o Secuencia del B/L Master */
   NDOC_TRANS  VARCHAR(70) DEFAULT "",      /*Numero de documento de Transporte*/
   NUMDET      NUMERIC(5,0) DEFAULT 0,      /*Numero de Detalle del Bl MASTER */
   N_ORDEN     CHAR(11) NOT NULL,           /*Numero de Orden con que se indentifica la operacion */
   PESO_CARGA  DECIMAL(13,3) DEFAULT 0.000, /*Peso de la Carga */ 
   VOLUMEN     DECIMAL(13,3) DEFAULT 0.000, /*Volumen de la Carga */ 
   CANT_BULTO  NUMERIC(10,0) DEFAULT 0,     /*Cantidad de bultos  */
   CANT_CONTE  NUMERIC(4,0) DEFAULT 0,      /*Cantidad de Contenedores */   
   TDOC_TRANS  CHAR(3) DEFAULT "",          /*Tipo de Documento de Transporte */
   FECH_TRANS  DATE,                        /*Fecha del Documento de Transporte   */
   LUGA_EMIS   CHAR(5) DEFAULT "",          /*Lugar de emision del Documento de transporte */
   PRIMARY KEY(N_ORDEN,NUME_SECUM), 
   CONSTRAINT UQ_BLM_1   UNIQUE(N_ORDEN,NDOC_TRANS),
   CONSTRAINT FK_BLM_MNF FOREIGN KEY(N_ORDEN) REFERENCES MNF(N_ORDEN));
   CREATE INDEX BLM ON BLM(N_ORDEN);

/*BLH(DOCUMENTOS DE TRANSPORTE HIJOS )*/
CREATE TABLE IF NOT EXISTS BLH(           
   NUME_SECUH  CHAR(3) NOT NULL,            /*Numero de Detalle o Secuencia del B/L Hijo */   
   NUME_SECUM  CHAR(2) NOT NULL,            /*Numero de Detalle o Secuencia del B/L Master */
   N_ORDEN     CHAR(11) NOT NULL,           /*Numero de Orden con que se indentifica la operacion */   
   NDOC_TRANS  VARCHAR(70) DEFAULT "",      /*Numero de documento de Transporte*/
   NUMDET      NUMERIC(5,0) DEFAULT 0,      /*Numero de Detalle del Bl Hijo */
   PESO_CARGA  DECIMAL(15,3) DEFAULT 0.000, /*Peso por Documentos de Transporte  KBSER*/
   VOLUMEN     DECIMAL(13,3) DEFAULT 0.000, /*Volumen de la Carga */ 
   CANT_BULTO  NUMERIC(10,0) DEFAULT 0,     /*Cantidad de bultos NUMBULTOS */
   CANT_CONTE  NUMERIC(4,0) DEFAULT 0,      /*Cantidad de Contenedores */   
   CONSIGNA    CHAR(5) DEFAULT "",          /*CODIGO DEL CONSIGNATARIO */
   TRANSPORT   CHAR(5) DEFAULT "",          /*CARRIER-TRANSPORTISTA */
   AGT_TRANS   CHAR(5) DEFAULT "",          /*CARRIER AGENT-AGENTE DEL TRANSPORTISTA */
   EMBARCA     CHAR(5) DEFAULT "",          /*SHIPPER-EMBARCADOR */
   NOTIFICA1   CHAR(5) DEFAULT "",          /*NOTIFY-NOTIFICAR 1*/
   NOTIFICA2   CHAR(5) DEFAULT "",          /*NOTIFY-NOTIFICAR 2*/
   CONSOLIDA   CHAR(5) DEFAULT "",          /*CONSOLIDADOR */
   C_ADUAN_S   CHAR(3) DEFAULT "",          /*Aduana Salida (acogimiento al regimen de transbordo)*/
   COD_P_DES   CHAR(5) DEFAULT "",          /*Codigo del Puerto de Descarga */ 
   COD_P_FIN   CHAR(5) DEFAULT "",          /*Codigo del Puerto Final */ 
   FECH_TRANS  DATE,                        /*Fecha de Emision del Documento de Transporte   */
   TDOC_TRANS  CHAR(3) DEFAULT "",          /*codigo de Tipo de Documento de Transporte */
   LUGA_EMIS   CHAR(5) DEFAULT "",          /*Lugar de emision del Documento de transporte */
   FECH_EMB    DATE,                        /*Fecha de Embarque */  
   COD_P_EMB   CHAR(5) DEFAULT "",          /*Codigo del Puerto de Embarque */ 
   FLAG_TRANS  CHAR(1) DEFAULT "N",         /*Flag para acogimiento al transbordo */
   VIA_TRANS   CHAR(1) DEFAULT "",          /*Codigo de via de transporte*/
   COD_MODALI  CHAR(1) DEFAULT "",          /*La modalidad de transbordo de la solicitud.*/
   RUC_OPERP   CHAR(13) DEFAULT "",         /*Operador portuario / lugar de salida*/
   LUG_OPERP   CHAR(3) DEFAULT "",          /*Tipo de lugar carga. */
   NOM_TRANSP  VARCHAR(70) DEFAULT "",      /*Nombre del medio de transporte*/
   RUC_TRANSP  CHAR(13) DEFAULT "",         /*RUC de la Empresa de Transporte o su representante en el pais quien declara el manifiesto de carga*/
   COD_P_ORIG  CHAR(2) DEFAULT "",           /*Pais de Origen de la Mercanderia */   
   TIPO_DEST   CHAR(3) DEFAULT "",           /*Destinacion de la carga*/   
   COD_CONT    CHAR(2) DEFAULT "",           /*Condiciones de contrato*/   
   REQ_SERV    CHAR(2) DEFAULT "",           /*Requerimiento de servicio*/   
   FLAG_ENVIO  NUMERIC(4,0) DEFAULT 0,       /*Flag de envio para rectificacion*/   
   ALAORDEN    CHAR(1) DEFAULT "",           /*Indicar si va a la Orden*/   
   PRIMARY KEY(N_ORDEN,NUME_SECUM,NUME_SECUH),
   CONSTRAINT FK_BLH_BLM FOREIGN KEY(N_ORDEN,NUME_SECUM) REFERENCES BLM(N_ORDEN,NUME_SECUM),
   CONSTRAINT UQ_BLH_1 UNIQUE(N_ORDEN,NDOC_TRANS));
   CREATE INDEX BLH ON BLH(N_ORDEN,NUME_SECUM,NUME_SECUH);

/*CZH(CODIGOS DE PUERTOS DE ZARPE )*/
CREATE TABLE IF NOT EXISTS CZH(
   N_ORDEN     CHAR(11) NOT NULL,            /*Numero de Orden con que se indentifica la operacion */   
   NUME_SECUM  CHAR(2) NOT NULL,             /*Numero de Detalle o Secuencia del B/L Master */
   NUME_SECUH  CHAR(3) NOT NULL,             /*Numero de Detalle o Secuencia del B/L Hijo */   
   NUME_SECUE  CHAR(4) NOT NULL,             /*Numero de Secuencia del Puertos de Zarpes */
   FECH_ZARPE  DATE,                         /*Fecha de Zarpe */   
   COD_P_EMB   CHAR(5) DEFAULT "",           /*Codigo de Puerto de Embarque */
   PRIMARY KEY(N_ORDEN,NUME_SECUM,NUME_SECUH,NUME_SECUE),
   CONSTRAINT FK_CZH_BLH FOREIGN KEY(N_ORDEN,NUME_SECUM,NUME_SECUH) REFERENCES BLH(N_ORDEN,NUME_SECUM,NUME_SECUH));
   CREATE INDEX CZH ON CZH(N_ORDEN,NUME_SECUM,NUME_SECUH,NUME_SECUE);

/*FLH(FLETES POR B/L HIJO)*/
CREATE TABLE IF NOT EXISTS FLH(
   N_ORDEN     CHAR(11) NOT NULL,            /*Numero de Orden con que se indentifica la operacion */   
   NUME_SECUM  CHAR(2) NOT NULL,             /*Numero de Detalle o Secuencia del B/L Master */
   NUME_SECUH  CHAR(3) NOT NULL,             /*Numero de Detalle o Secuencia del B/L Hijo */   
   NUME_SECUE  CHAR(2) NOT NULL,             /*Numero de Secuencia del Flete */   
   TIPO_FLETE  CHAR(6) DEFAULT "",           /*Tipo de Flete  */   
   IMPO_FLETE  NUMERIC(13,3) DEFAULT 0,      /*Importe del Flete */
   MON_FLETE   CHAR(3) DEFAULT "",           /*Moneda del Flete  */   
   TIPO_PAGO   CHAR(2) DEFAULT "",           /*Tipo de pago */   
   PRIMARY KEY(N_ORDEN,NUME_SECUM,NUME_SECUH,NUME_SECUE),
   CONSTRAINT FK_FLH_BLH FOREIGN KEY(N_ORDEN,NUME_SECUM,NUME_SECUH) REFERENCES BLH(N_ORDEN,NUME_SECUM,NUME_SECUH));
CREATE INDEX FLH ON FLH(N_ORDEN,NUME_SECUM,NUME_SECUH,NUME_SECUE);

/*DEH(DETALLE DE LA MERCANCIA DE LOS B/L HIJOS )*/
CREATE TABLE IF NOT EXISTS DEH(
   N_ORDEN     CHAR(11) NOT NULL,            /*Numero de Orden con que se indentifica la operacion */   
   NUME_SECUM  CHAR(2) NOT NULL,             /*Numero de Detalle o Secuencia del B/L Master */
   NUME_SECUH  CHAR(3) NOT NULL,             /*Numero de Detalle o Secuencia del B/L Hijo */   
   NUME_SECUE  CHAR(4) NOT NULL,             /*Numero de Secuencia del Detalle de la mercancia */
   COND_CARGA  CHAR(1) DEFAULT "",           /*Tipo de carga usada para determinar el abandono legal*/
   VAL_ADUAN   NUMERIC(15,2) DEFAULT 0,      /*Numero de Secuencia del Detalle de la mercancia */ 
   COD_MON     CHAR(3) DEFAULT "",           /*Codigo de Moneda */   
   PARTIDA     CHAR(10) DEFAULT "",          /*Clasificacion Arancelaria de la Carga */
   INCOTERM    CHAR(3) DEFAULT "",          /*Incoterm del B/L */
   PESO_CARGA  DECIMAL(15,3) DEFAULT 0.000,  /*Peso por Documentos de Transporte  KBSER*/
   VOLUMEN     DECIMAL(13,3) DEFAULT 0.000,  /*Volumen de la Carga */ 
   DESCRIPCIO  VARCHAR(250) DEFAULT "",      /*Descripcion de la Carga 1 */   
   NATU_CARG   CHAR(2) DEFAULT "",           /*Naturaleza de la Carga */   
   MARCAS      VARCHAR(250) DEFAULT "",      /*Marcas y numeros 1 */ 
   CANT_BULTO  NUMERIC(10,0) DEFAULT 0,      /*Cantidad de bultos NUMBULTOS */
   TIPO_BULTO  CHAR(2) DEFAULT "",           /*Tipo de bulto */
   UTMP_CARGA  CHAR(20) DEFAULT "",          /*Vin de Vehiculo */
   IDEN_PELIG  CHAR(4) DEFAULT "",           /*Indicador de Peligro */ 
   EMIS_PELIG  CHAR(3) DEFAULT "",           /*Entidad reguladora de mercanc?peligrosa*/
   CLAS_PELIG  CHAR(7) DEFAULT "",           /*Clasificacion de Peligrosidad */
   PAG_PELIG   CHAR(7) DEFAULT "",           /*N??o de p?na en documento de clasificaci?? */
   TEMP_PELIG  NUMERIC(4) DEFAULT 0,         /*Temperatura maxima en la cual deben estar los art?los inflamables */
   UNI_TEMPE   CHAR(3) DEFAULT "",           /*Unidad de temperatura asociada al Flashpoint de liquidos inflamables */
   CANT_CONTE  NUMERIC(4,0) DEFAULT 0,      /*Cantidad de Contenedores */   
   DESCRIPC2   VARCHAR(250) DEFAULT "",      /*Descripcion de la Carga 2 */   
   DESCRIPC3   VARCHAR(250) DEFAULT "",      /*Descripcion de la Carga 3 */   
   DESCRIPC4   VARCHAR(250) DEFAULT "",      /*Descripcion de la Carga 4 */   
   MARCAS2     VARCHAR(250) DEFAULT "",      /*Marcas y numeros 2 */ 
   MARCAS3     VARCHAR(250) DEFAULT "",      /*Marcas y numeros 3 */ 
   MARCAS4     VARCHAR(250) DEFAULT "",      /*Marcas y numeros 4 */ 
   DESCRIPC5   VARBINARY(3000) DEFAULT "",   /*Descripcion ADICIONAL DE de la Carga 5 */   
   PRIMARY KEY(N_ORDEN,NUME_SECUM,NUME_SECUH,NUME_SECUE),
   CONSTRAINT FK_DEH_BLH FOREIGN KEY(N_ORDEN,NUME_SECUM,NUME_SECUH) REFERENCES BLH(N_ORDEN,NUME_SECUM,NUME_SECUH));
   CREATE INDEX DEH ON DEH(N_ORDEN,NUME_SECUM,NUME_SECUH,NUME_SECUE);

/*CTH(CONTENEDORES POR B/L HIJO)*/
CREATE TABLE IF NOT EXISTS CTH(
   N_ORDEN     CHAR(11) NOT NULL,            /*Numero de Orden con que se indentifica la operacion */   
   NUME_SECUM  CHAR(2) NOT NULL,             /*Numero de Detalle o Secuencia del B/L Master */
   NUME_SECUH  CHAR(3) NOT NULL,             /*Numero de Detalle o Secuencia del B/L Hijo */   
   NUME_SECUE  CHAR(4) NOT NULL,             /*Numero de Secuencia del Detalle de la mercancia */
   NUME_SECUC  CHAR(4) NOT NULL,             /*Numero de Secuencia del los Contenedores por Mercancia */
   CONTENEDOR  CHAR(17) DEFAULT "",          /*Nro de Contenedor  */
   PRIMARY KEY(N_ORDEN,NUME_SECUM,NUME_SECUH,NUME_SECUE,NUME_SECUC),
   CONSTRAINT FK_CTH_DEH FOREIGN KEY(N_ORDEN,NUME_SECUM,NUME_SECUH,NUME_SECUE) REFERENCES DEH(N_ORDEN,NUME_SECUM,NUME_SECUH,NUME_SECUE));
CREATE INDEX CTH ON CTH(N_ORDEN,NUME_SECUM,NUME_SECUH,NUME_SECUE);

/***************************************************************************************/
/******************     OPERACIONES ASOCIADAS AL MANIFIESTO   ************************/

/*OPM(OPERACIONES ASOCIADAS AL MANIFIESTO)*/
CREATE TABLE IF NOT EXISTS OPM(
   N_ORDEN    CHAR(11) NOT NULL,
   ORDEN_ASOC CHAR(11) DEFAULT "",
   TIPO_ENVIO CHAR(1) DEFAULT "",
   FCH_INI_OP DATETIME,
   FCH_FIN_OP DATETIME,
   NUM_MANIF  CHAR(25) DEFAULT "", 
   TIPO_MANIF CHAR(2) DEFAULT "",
   CANT_DOC   NUMERIC(4,0) DEFAULT 0,
   PRIMARY KEY(N_ORDEN),
   CONSTRAINT FK_OPM_APE FOREIGN KEY(N_ORDEN) REFERENCES APE(N_ORDEN));
 CREATE INDEX OPM ON OPM(N_ORDEN);
 
/*CTN(CONTENEDORES POR BL MASTER)*/
CREATE TABLE IF NOT EXISTS CTN(
   N_ORDEN    CHAR(11) NOT NULL,
   SECUENCIA  NUMERIC(4,0) NOT NULL,   
   CONTENEDOR CHAR(17) DEFAULT "",         /* N� de Contenedor  */
   PESO_CARGA DECIMAL(15,3) DEFAULT 0.000, /*Peso del Contenedor con carga */
   ESTADO_CTN CHAR(3) DEFAULT "",          /*Estado del Contenedor */
   SITUACION  CHAR(1) DEFAULT "",          /*Situacion del Contenedor */
   PLACA_VEH  VARCHAR(10) DEFAULT "",      /*Placa del Vehiculo que realizo el traslado del contenedor al deposito */
   LICENCIA   VARCHAR(12) DEFAULT "",      /*Licencia de conducir del Chofer que realizo el traslado del contenedor al deposito */
   DNI_CHOFER VARCHAR(10) DEFAULT "",      /*Dni del Chofer que realizo el traslado del contenedor al deposito */
   ELEGIDO    NUMERIC(4,0) DEFAULT 0,      /*Flag para indicar que Contenedores se van a jalar o transferir */
   ESTACION   CHAR(2) DEFAULT "",          /*Numero de la estacion de trabajo que esta transfiriendo este Contenedor */
   PRIMARY KEY(N_ORDEN,SECUENCIA),
   CONSTRAINT FK_CTN_OPM FOREIGN KEY(N_ORDEN) REFERENCES OPM(N_ORDEN),
   CONSTRAINT UQ_CTN_1   UNIQUE(N_ORDEN,CONTENEDOR));
   CREATE INDEX CTN ON CTN(N_ORDEN,SECUENCIA);

/*PRE(PRECINTOS DEL CONTENEDOR)*/
CREATE TABLE IF NOT EXISTS PRE(
   N_ORDEN    CHAR(11) NOT NULL,
   SECUENCIA  NUMERIC(4,0) NOT NULL,   
   CORREL     CHAR(2) NOT NULL,
   PRECINTO   CHAR(15) DEFAULT "", 
   CONDICION  CHAR(1) DEFAULT "",
   ENTIDAD    CHAR(2) DEFAULT "",
   PRIMARY KEY(N_ORDEN,SECUENCIA,CORREL),
   CONSTRAINT FK_PRE_CTN FOREIGN KEY(N_ORDEN,SECUENCIA) REFERENCES CTN(N_ORDEN,SECUENCIA));
   CREATE INDEX PRE ON PRE(N_ORDEN,SECUENCIA);

/*BLS(B/L HIJOS )*/
CREATE TABLE IF NOT EXISTS BLS(
   N_ORDEN    CHAR(11) NOT NULL,
   N_SERIE    NUMERIC(4,0) NOT NULL,   
   NUMBLGUIA  VARCHAR(25) DEFAULT "",      /*N�mero de documento de transporte*/
   SITUACION  CHAR(1) DEFAULT "",          /*Situacion del documento de transporte CZONFRA */
   NUMDET     CHAR(5) DEFAULT "",  	   /*N�mero de detalle*/
   PESO_CARGA DECIMAL(15,3) DEFAULT 0.000, /*Peso por Documentos de Transporte  KBSER*/
   CANT_BULTO NUMERIC(10,0) DEFAULT 0,     /*Cantidad de bultos NUMBULTOS */
   FECH_OPERA DATE,                        /*Fecha de Operaci�n F_ROTULADO */
   CONSIGNA   CHAR(5) DEFAULT "",          /*Documento del operador o consignatario COD_CLIEN */
   NUM_VOLANT VARCHAR(15) DEFAULT "",      /*Numero de volante de despacho DNUM*/
   FCH_VOLANT DATE,                        /*Fecha de volante de despacho  FCH_EMB */
   NUM_ACTA   VARCHAR(15) DEFAULT "",      /*Numero de acta de Inventario  DMAR */
   DES_ACTA   VARCHAR(40) DEFAULT "",      /*Descripcion del acta de inventario*/
   FLAG_ENVIO CHAR(2) DEFAULT "",          /*Ultimo envio APL_ULTRA */
   TIPO_CARGA CHAR(3) DEFAULT "",          /*Tipo de carga FLAG_BASE */
   PRIMARY KEY(N_ORDEN,N_SERIE),
   CONSTRAINT FK_BLS_APE FOREIGN KEY(N_ORDEN) REFERENCES APE(N_ORDEN),
   CONSTRAINT FK_BLS_CLI  FOREIGN KEY(CONSIGNA) REFERENCES CLI(CODIGO),
   CONSTRAINT UQ_BLS_1   UNIQUE(N_ORDEN,NUMBLGUIA));
   CREATE INDEX BLS ON BLS(N_ORDEN,N_SERIE);

/*DEB(DETALLE DE LOS BLS HIJOS )*/
CREATE TABLE IF NOT EXISTS DEB(
   N_ORDEN    CHAR(11) NOT NULL,
   N_SERIE    NUMERIC(4,0) NOT NULL,   
   SECUENCIA  NUMERIC(3,0) NOT NULL,   
   CONTENEDOR CHAR(17) DEFAULT "",         /* N� de Contenedor  */
   PESO_CARGA DECIMAL(15,3) DEFAULT 0.000, /*Peso del Contenedor con carga */
   CANT_BULTO NUMERIC(10,0) DEFAULT 0,      /*Flag para indicar que Contenedores se van a jalar o transferir */
   COND_CODI  CHAR(17) DEFAULT "",         /*C  3  0 Condicion de codigo*/
   PRIMARY KEY(N_ORDEN,N_SERIE,SECUENCIA),
   CONSTRAINT FK_DEB_BLS FOREIGN KEY(N_ORDEN,N_SERIE) REFERENCES BLS(N_ORDEN,N_SERIE),
   CONSTRAINT UQ_DEB_1 UNIQUE(N_ORDEN,N_SERIE,CONTENEDOR));
   CREATE INDEX DEB ON DEB(N_ORDEN,N_SERIE,SECUENCIA);

/***************************************************************************************/
/******************     CUADROS ASOCIADOS A DESPACHOS TEMPORALES  **********************/
/***************************************************************************************/

/*CCU(CABECERAS DE CUADROS ASOCIADOS A LOS DESPACHOS TEMPORALES)*/
CREATE TABLE IF NOT EXISTS CCU(
   N_ORDEN    CHAR(11) NOT NULL,
   TDOC_IMPOR CHAR(1) DEFAULT "",          /*Tipo de Documento de Importador */
   NDOC_IMPOR CHAR(11) DEFAULT "",         /*Numero de Documento del Importador */
   NOM_IMPOR  VARCHAR(70) DEFAULT "",      /*Nombre del Importador */
   TDOC_EXPOR CHAR(1) DEFAULT "",          /*Tipo de Documento del Exportador */
   NDOC_EXPOR CHAR(11) DEFAULT "",         /*Numero del Documento del Exportador */
   NOM_EXPOR  VARCHAR(70) DEFAULT "",      /*Nombre del Exportador */
   SECT_COMP  VARCHAR(60) DEFAULT "",      /*Sector Competente */
   INDENT_SEC VARCHAR(40) DEFAULT "",      /*Identificacion Sectorial */
   VENCI_PAT  DATE,                        /*Vencimiento del Pedido de Adminsion Temporal*/
   FACT_EXPO  VARCHAR(40) DEFAULT "",      /*Factura de Exportacion */
   TIPO_TRANS CHAR(2) DEFAULT "",          /*Tipo de Transaccion */
   NRO_PAT    VARCHAR(25) DEFAULT "",      /*Numero de la Admision Temporal*/
   TIPO_TRANF CHAR(1) DEFAULT "",          /*Detalle de la Transferencia */
   N_ORDENEXP CHAR(11) DEFAULT "",         /*Orden de Exportacion para la Relacion de Insumo*/
   NORDEN_EMB VARCHAR(13) DEFAULT "",      /*Numero de la Orden de Embarque para la Relacion de Insumo*/
   VENC_GARAN DATE,                        /*Fecha de Vencimiento de la Garantia para el Regimen 29*/
   IMPO_GARAN DECIMAL(13,2) DEFAULT 0.000, /*Importe o Monto de la Garantia para el Regimen 29*/
   PRIMARY KEY(N_ORDEN),
   CONSTRAINT FK_CCU FOREIGN KEY(N_ORDEN) REFERENCES APE(N_ORDEN));
   CREATE INDEX CCU ON CCU(N_ORDEN);

/*CUA(CUADRO DE INSUMO PRODUCTO REGIMEN 25)*/
CREATE TABLE IF NOT EXISTS CUA(
   N_ORDEN    CHAR(11) NOT NULL,
   NUME_REG   NUMERIC(6,0) DEFAULT 0,	
   TIPO_ING   CHAR(1) DEFAULT "",
   CINSUMO    CHAR(6) DEFAULT "",
   CPRODUCTO  CHAR(6) DEFAULT "",
   DINSUMO    VARCHAR(120) DEFAULT "",
   DPRODUCTO  VARCHAR(120) DEFAULT "",
   UNIMEDI    CHAR(4) DEFAULT "",
   UNIMEDP    CHAR(4) DEFAULT "",
   ARANCELI   CHAR(10) DEFAULT "",
   ARANCELP   CHAR(10) DEFAULT "",
   COEF_TOTAL DECIMAL(20,10) DEFAULT 0.0000000000,
   COEF_NETO  DECIMAL(20,10) DEFAULT 0.0000000000,
   COEF_RESI  DECIMAL(20,10) DEFAULT 0.0000000000,
   COEF_DESP  DECIMAL(20,10) DEFAULT 0.0000000000,
   COEF_SUBP  DECIMAL(20,10) DEFAULT 0.0000000000,
   COEF_MERM  DECIMAL(20,10) DEFAULT 0.0000000000,
   NUME_SERIE CHAR(4) DEFAULT "",
   UNID_FIQTY DECIMAL(15,3) DEFAULT 0.000,
   CANT_COMPE DECIMAL(15,3) DEFAULT 0.000,
   DESP_SVC   DECIMAL(20,10) DEFAULT 0.0000000000,
   PRIMARY KEY(N_ORDEN,NUME_REG),
   CONSTRAINT FK_CUA FOREIGN KEY(N_ORDEN) REFERENCES CCU(N_ORDEN));
   CREATE INDEX CUA ON CUA(N_ORDEN,NUME_REG);

/*REL(RELACION DE INSUMO PRODUCTO REGIMEN 26)*/
CREATE TABLE IF NOT EXISTS REL(
   N_ORDEN    CHAR(11) NOT NULL,
   NUME_REG   NUMERIC(6,0) DEFAULT 0,	
   SERIEI     NUMERIC(4,0) DEFAULT 0,
   SERIEE     NUMERIC(4,0) DEFAULT 0,
   CINSUMO    CHAR(6) DEFAULT "",
   CPRODUCTO  CHAR(6) DEFAULT "",
   DINSUMO    VARCHAR(120) DEFAULT "",
   DPRODUCTO  VARCHAR(120) DEFAULT "",
   UNIMEDI    CHAR(4) DEFAULT "",
   UNIMEDP    CHAR(4) DEFAULT "",
   ARANCELI   CHAR(10) DEFAULT "",
   ARANCELP   CHAR(10) DEFAULT "",
   CANT_TOTAL DECIMAL(20,10) DEFAULT 0.0000000000,
   CANT_SUJ   DECIMAL(20,10) DEFAULT 0.0000000000,
   COEF_TOTAL DECIMAL(20,10) DEFAULT 0.0000000000,
   CANT_RESI  DECIMAL(20,10) DEFAULT 0.0000000000,
   CANT_DESP  DECIMAL(20,10) DEFAULT 0.0000000000,
   CANT_SUBP  DECIMAL(20,10) DEFAULT 0.0000000000,
   CANT_UTIL  DECIMAL(20,10) DEFAULT 0.0000000000,
   ADUANI     CHAR(3) DEFAULT "",
   ANDOCI     CHAR(4) DEFAULT "",
   NUDOCI     CHAR(6) DEFAULT "",	
   CADU_TRA   CHAR(3) DEFAULT "",
   ANO_TRA    NUMERIC(4,0) DEFAULT 0,
   NUME_TRA   NUMERIC(6,0) DEFAULT 0,
   NUME_TREG  NUMERIC(4,0) DEFAULT 0,
   C1INSUMO   CHAR(6) DEFAULT "",	
   UNI1INSUMO CHAR(4) DEFAULT "",
   NUME_SERIE NUMERIC(4,0) DEFAULT 0,
   QUNICOM1   DECIMAL(15,3) DEFAULT 0.000,
   DESCINSUMO VARCHAR(40) DEFAULT "",
   C2INSUMO   CHAR(6) DEFAULT "",
   UNI2INSUMO CHAR(4) DEFAULT "",
   QUNICOM2   DECIMAL(15,3) DEFAULT 0.000,
   QUNIEQUI   DECIMAL(15,3) DEFAULT 0.000,
   CNANEXP    VARCHAR(10) DEFAULT "",
   CTIPITEM   CHAR(2) DEFAULT "",
   PRIMARY KEY(N_ORDEN,NUME_REG),
   CONSTRAINT FK_REL FOREIGN KEY(N_ORDEN) REFERENCES CCU(N_ORDEN));
   CREATE INDEX REL ON REL(N_ORDEN,NUME_REG);

/*RPF(CUADRO DE REPOSICION Y FRANQUICIA)*/
CREATE TABLE IF NOT EXISTS RPF(
   N_ORDEN      CHAR(11) NOT NULL,                /*N� de orden del Cuadro*/
   NUME_SERIE	NUMERIC(6,0) DEFAULT 0,           /*Correlativo de Registro*/
   NSERI_EXPO	NUMERIC(4,0) DEFAULT 0,           /*Serie de la Exportacion*/
   CCODI_PROD	CHAR(6) DEFAULT "",	          /*Sub Serie de la Exportacion*/
   ORDEN_ING	CHAR(11) DEFAULT "",	          /*N� de Orden de Importacion*/
   NNUME_ING	CHAR(6) DEFAULT "",	          /*Dua de Importacion*/
   CADUA_ING	CHAR(3) DEFAULT "",	          /*Codigo de Aduana de la Importacion*/
   FANNO_ING	NUMERIC(4,0) DEFAULT 0,           /*A�o de la Importacion*/
   CREGI_ING	CHAR(2) DEFAULT "",	          /*Regimen de Importacion*/
   NSERI_ING	NUMERIC(4,0) DEFAULT 0,           /*Serie de la Importacion*/
   CCODI_ING	CHAR(6) DEFAULT "",	          /*Sub Serie de la Importacion*/
   TDESC_ING	VARCHAR(80) DEFAULT "",           /*Descripcion de la Serie de Importacion*/
   QIMPUNIFIS	DECIMAL(20,8) DEFAULT 0.00000000, /*Unidades Fisicas de la Importacion*/
   CIMPUNIFIS	CHAR(3) DEFAULT "", 	          /*Tipo de Unidades Fisicas de la Importacion*/
   QIMPUNIMED	DECIMAL(20,8) DEFAULT 0.00000000, /*Tipo de Unidades Comerciales de la Importacion*/
   CIMPUNIMED	CHAR(3) DEFAULT "",	          /*Cantidad de Unidades Comerciales de la Importacion*/
   COPER_EXPO	CHAR(2) DEFAULT "",	          /*Codigo de Operacion de la Exportacion*/
   NNUME_FACT	VARCHAR(20) DEFAULT "",           /*Numero de Factura*/
   FFECH_FACT	DATE,                             /*Fecha de Factura*/
   TDESC_PROD	VARCHAR(80) DEFAULT "",           /*Descripcion de la Serie de Exportacion*/
   QEXPUNIFIS	DECIMAL(20,8) DEFAULT 0.00000000, /*Unidades Fisicas de la Exportacion*/
   CEXPUNIFIS	CHAR(3) DEFAULT "",               /*Tipo de Unidades Fisicas de la Exportacion*/
   QEXPUNIMED	DECIMAL(20,8) DEFAULT 0.00000000, /*Tipo de Unidades Comerciales de la Exportacion*/
   CEXPUNIMED	CHAR(3) DEFAULT "",	          /*Tipo de Unidades Comerciales de la Exportacion*/
   VCOEF_NETO	DECIMAL(20,8) DEFAULT 0.00000000, /*Coeficiente Neto*/
   VCOEF_CATA	DECIMAL(20,8) DEFAULT 0.00000000, /*Coeficiente del Catalizador*/
   VCOEF_MSVC	DECIMAL(20,8) DEFAULT 0.00000000, /*Coeficiente sin Valor Comercial*/
   VCOEF_ECVC	DECIMAL(20,8) DEFAULT 0.00000000, /*Coeficiente Excedente con Valor Comercial*/
   VCOEF_TOTA	DECIMAL(20,8) DEFAULT 0.00000000, /*Coeficiente Total*/
   QCANT_REPO	DECIMAL(15,3) DEFAULT 0.00000000, /*Cantidad de Reponer*/
   COPER_IMPO	CHAR(2) DEFAULT "",	          /*Codigo de Operacion (Courier)*/
   CODI_ENTID	CHAR(2) DEFAULT "",	          /*Codigo de la Entidad Competente*/
   FR_ENT_COM	DATE,                             /*Fecha de Recepcion por parte la Entidad Competente*/
   NR_ENT_COM	VARCHAR(20) DEFAULT "",           /*Numero de Recepcion de Entidad Competente*/
   DETALLE	CHAR(1) DEFAULT "",	          /*Detalle de Importaciones*/
   PAB_ING	CHAR(10) DEFAULT "",              /*Partida Arancelaria de Ingreso*/
   PAB_EXPO	CHAR(10) DEFAULT "",              /*Partida Arancelaria de Exportacion*/
   TUNI_EXPO	CHAR(3) DEFAULT "",               /*Tipo de unidad a Reponer*/
   TDES_INSU1	VARCHAR(60) DEFAULT "",           /*Descripcion de datos especificos del detalle Insumo*/
   TDES_INSU2	VARCHAR(60) DEFAULT "",           /*Descripcion de datos especificos del detalle Insumo*/
   TDES_SALI1	VARCHAR(60) DEFAULT "",           /*Descripcion de datos especificos del detalle Salida*/
   TDES_SALI2	VARCHAR(60) DEFAULT "",           /*Descripcion de datos especificos del detalle Salida*/
   ITEMINSUMO	CHAR(6) DEFAULT "",	          /*Item del Insumo*/
   ITEMPRODUC	CHAR(6) DEFAULT "",	          /*Item del Producto*/
   PRIMARY KEY(N_ORDEN,NUME_SERIE),
   CONSTRAINT FK_RPF FOREIGN KEY(N_ORDEN) REFERENCES CCU(N_ORDEN));
   CREATE INDEX RPF ON RPF(N_ORDEN,NUME_SERIE);

/*DRF(SUBSERIES DEL INSUMO PRODUCTO)*/
CREATE TABLE IF NOT EXISTS DRF(
   N_ORDEN      CHAR(11) NOT NULL ,               /*N� de orden del Cuadro*/
   NNUME_ING	CHAR(6) DEFAULT "",	          /*Dua de Importacion*/
   NSERI_ING	NUMERIC(4,0) DEFAULT 0,           /*Serie de la Importacion*/
   CCODI_ING	CHAR(6) DEFAULT "",	          /*Sub Serie de la Importacion*/
   QIMPUNIFIS	DECIMAL(20,8) DEFAULT 0.00000000, /*Unidades Fisicas de la Importacion*/
   CIMPUNIFIS	CHAR(3) DEFAULT "", 	          /*Tipo de Unidades Fisicas de la Importacion*/
   QIMPUNIMED	DECIMAL(20,8) DEFAULT 0.00000000, /*Tipo de Unidades Comerciales de la Importacion*/
   CIMPUNIMED	CHAR(3) DEFAULT "",	          /*Cantidad de Unidades Comerciales de la Importacion*/
   PRIMARY KEY(N_ORDEN,NNUME_ING,NSERI_ING,CCODI_ING));
   CREATE INDEX DRF ON DRF(N_ORDEN,NNUME_ING,NSERI_ING,CCODI_ING);

/*TRA(TRANSFERENCIA DE ADMISION PARA PERFECCIONAMIENTO PASIVO O REEXPORTACION EN EL MISMO ESTADO)*/
CREATE TABLE IF NOT EXISTS TRA(
   N_ORDEN      CHAR(11) NOT NULL ,                  /*N� de orden del Cuadro*/
   N_SERIE      NUMERIC(4,0) NOT NULL,               /*Serie de la transferencia*/     
   TIPO_PROD    CHAR(2) DEFAULT "",                  /*Tipo de Producto*/ 
   ADMISION     VARCHAR(13) DEFAULT "",              /*Admision Temporal*/    
   SERIE_ADM    NUMERIC(4,0) DEFAULT 0,              /*Serie de la Admision Temporal*/ 
   ITEM_1INS    CHAR(6) DEFAULT "",                  /*Item Insumo del primer insumo*/ 
   UNI_1INS     CHAR(3) DEFAULT "",                  /*Unidad del primer insumo*/
   DESC_1INS    VARCHAR(120) DEFAULT "",             /*Descripcion del primer insumo*/
   ITEM_1PRO    CHAR(6) DEFAULT "",                  /*Item del producto del 1er.beneficiario*/
   UNI_1PRO     CHAR(3) DEFAULT "",                  /*Unidad de medida del producto del 1er.beneficiario*/
   DESC_1PRO    VARCHAR(120) DEFAULT "",             /*Descripcion del producto del 1er.beneficiario*/
   qPRODINT1    DECIMAL(20,10) DEFAULT 0.0000000000, /*Cantidad del producto segun unidad del 1er.beneficiario*/
   COEF_TOTAL   DECIMAL(20,10) DEFAULT 0.0000000000, /*Coeficiente total del CIP del 1er.beneficiario*/
   CANT_SUBP    DECIMAL(20,10) DEFAULT 0.0000000000, /*Cant.generada de subproductos*/
   CANT_RESI    DECIMAL(20,10) DEFAULT 0.0000000000, /*Cant.generada de residuos*/
   CANT_DESP    DECIMAL(20,10) DEFAULT 0.0000000000, /*Cant.generada de desperdicios*/
   CANT_UTILI   DECIMAL(20,10) DEFAULT 0.0000000000, /*Cant.utilizada de insumos*/
   QINSNETOTR   DECIMAL(20,10) DEFAULT 0.0000000000, /*Cant.Neta del insumo transferido segun unidad del 1er.beneficiario*/
   CPRODINT2    CHAR(6) DEFAULT "",                  /*Item del producto intermedio del 2do.beneficiario*/
   UMPROINT2    CHAR(3) DEFAULT "",                  /*Unidad de medida del producto intermedio del 2do.beneficiario*/
   DPRODINT2    VARCHAR(120) DEFAULT "",             /*Descripcion del producto intermedio del 2do.beneficiario*/
   QPRODINT2    DECIMAL(20,10) DEFAULT 0.00000000,   /*Cantidad Prod.Intermedio segun unidad del 2do.beneficiario*/
   TRAT_PREFE   NUMERIC(4,0) DEFAULT 0,              /*Codigo de Estabilidad Tributaria*/
   DESC_TIPO    VARCHAR(20) DEFAULT "",              /*Descripcion del Tipo*/
   PRIMARY KEY(N_ORDEN,N_SERIE),
   CONSTRAINT FK_TRA FOREIGN KEY(N_ORDEN) REFERENCES APE(N_ORDEN));
   CREATE INDEX TRA ON TRA(N_ORDEN,N_SERIE);

/*TRI(RELACION DE INSUMOS A TRANSFERIR)*/
CREATE TABLE IF NOT EXISTS TRI(
   N_ORDEN      CHAR(11) NOT NULL ,                  /*N� de orden del Cuadro*/
   NUME_REG     NUMERIC(6,0) NOT NULL,               /*Serie de la transferencia*/     
   C1INSUMO	CHAR(6) DEFAULT "",
   UNI1INSUMO	CHAR(4) DEFAULT "",	
   NUME_SERIE	NUMERIC(4,0) DEFAULT 0,              /*	4	0        */
   QUNICOM1  	DECIMAL(15,3) DEFAULT 0.000,         /* N	15	3*/
   DESCINSUMO	VARCHAR(40) DEFAULT "",              /*C	40	*/
   C2INSUMO  	CHAR(6) DEFAULT "",                  /*C	6	*/
   UNI2INSUMO	CHAR(4) DEFAULT "",                  /*C	4	*/
   QUNICOM2  	DECIMAL(15,3) DEFAULT 0.000,         /*N	15	3*/
   QUNIEQUI  	DECIMAL(15,3) DEFAULT 0.000,         /*N	15	3*/
   PRIMARY KEY(N_ORDEN,NUME_REG),
   CONSTRAINT FK_TRI FOREIGN KEY(N_ORDEN) REFERENCES APE(N_ORDEN));
   CREATE INDEX TRI ON TRI(N_ORDEN,NUME_REG);

/***************************************************************************************/
/******************     ARCHIVOS DE LISTADO DE CONTENEDORES       **********************/
/***************************************************************************************/

/*CNB(CABECERA DEL LISTADO DE CONTENEDORES)*/
CREATE TABLE IF NOT EXISTS CNB(
   N_ORDEN      CHAR(11) NOT NULL,            /*N� de orden del Cuadro*/
   TIPO_TRANS   CHAR(2) DEFAULT "",           /*C  2  0 Tipo de Transacion  */
   F_SALIDA   	DATETIME,                     /* D  8  0            Fecha de Salida*/
   F_ARRIBO   	DATE,                         /* D  8  0            Fecha de Arribo*/
   CODDEPO     	CHAR(6) DEFAULT "",           /*C  9  0             Terminal de Almacenamiento*/
   NUMMANIF     VARCHAR(25) DEFAULT "",  
   NUMBULTOS    DECIMAL(15,3) DEFAULT 0.000,
   NAVE         VARCHAR(10) DEFAULT "",
   ULT_TRANS    CHAR(2) DEFAULT "",
   PRIMARY KEY(N_ORDEN),
   CONSTRAINT FK_CNB FOREIGN KEY(N_ORDEN) REFERENCES APE(N_ORDEN));
   CREATE INDEX CNB ON CNB(N_ORDEN);

/*CNT(LISTADO DE CONTENEDORES)*/
CREATE TABLE IF NOT EXISTS CNT(
   N_ORDEN      CHAR(11) NOT NULL,                  /*N� de orden del Cuadro*/
   ORDEN     	CHAR(6) NOT NULL,             /*C  9  0             Orden*/
   TIPO_CNT  	CHAR(2) DEFAULT "",           /*C  2  0** * *   *   Tipo de transporte*/
   TRANSPORTE	VARCHAR(10) DEFAULT "",       /*C 10  0             Transporte*/
   NUME_CNT  	VARCHAR(15) DEFAULT "",       /*C 15  0*************Numero de Contenedor*/
   PESO_BRUTO	DECIMAL(15,3) DEFAULT 0.000,  /*N 15  3*************Peso Bruto*/
   TARA      	DECIMAL(15,3) DEFAULT 0.000,  /*N 15  3*************Tara*/
   N_PRE_ADUA	CHAR(15) DEFAULT "",          /*C 15  0*            Codigo de Presente Aduanero*/
   N_PRE_OTRO	CHAR(15) DEFAULT "",          /*C 15  0*************Codigo de Precinto externo*/
   TAMANO    	CHAR(2) DEFAULT "",           /*C  2  0*************Tipo de tamano del Contenedor*/
   TAMANOCON 	VARCHAR(20) DEFAULT "",       /* C 20  0             Tamano del Contenedor*/
   TIPO_INGRE	CHAR(1) DEFAULT "",           /*C  1  0*************Tipo de Ingreso del Contenedor*/
   INGRESO   	VARCHAR(20) DEFAULT "",       /*C 20  0             Ingreso*/
   CODI_CONDI	CHAR(3) DEFAULT "",           /*C  3  0**** ********Tipo de Condicion*/
   CONDICION 	VARCHAR(15) DEFAULT "",       /*C 15  0**** ********Condicion*/
   DESC_MERC 	VARCHAR(200) DEFAULT "",      /*C200  0** ***  *****Descripcion General de la carga*/
   C_ADUANA  	CHAR(3) DEFAULT "",           /*C  3  0             Codigo de la Aduana*/
   TIPOREG   	CHAR(2) DEFAULT "",           /*C  2  0             Tipo de Regimen*/
   NUMMANIF  	CHAR(12) DEFAULT "",          /*C 12  0             Numero de Manifiesto*/
   COD_CLIEN 	CHAR(5) DEFAULT "",           /*C  6  0             Codigo del cliente*/
   N_DUA     	CHAR(6) DEFAULT "",           /*C  6  0             Numero de Dua*/
   FCH_DUA   	DATE,                         /* D  8  0             Fecha de Dua*/
   NAVE      	VARCHAR(50) DEFAULT "",       /*C 50  0             Nave*/
   AUTORIZAC 	VARCHAR(30) DEFAULT "",       /*C 30  0             Autorizacion*/
   DESTINO   	CHAR(6) DEFAULT "",           /*C  6  0             Destino*/
   AD_DOCASOC	CHAR(3) DEFAULT "",           /*C  3  0             Codigo de Aduana Doc. Asociado*/
   PAIS_DESTI	CHAR(2) DEFAULT "",           /*C  2  0             Codigo de Pais Destino*/
   COD_ANULA 	CHAR(3) DEFAULT "",           /*C  3  0             Codigo del Motivo de Anulacion*/
   MOTIVO_ANUL  VARCHAR(100) DEFAULT "",      /*C 100 0             Motivo de Anulacion de */
   ELEGIDO   	NUMERIC(1,0) DEFAULT 0,       /*N  1  0             Elegido*/
   num_book  varchar(30) default '',
   cnt_refrig char(1) default '',
   dni_chofer   char(8) default '',
   placa_cam  char(6) default '',
   placa_remo char(6) default '',
   dni_despa  char(8) default '',
   ruc_transp char(11) default '',
   num_sergui char(4) default '',
   num_guiare char(7) default '',
   c_camb_pre char(2) default '',
   PRIMARY KEY(N_ORDEN,ORDEN),
   CONSTRAINT FK_CNT FOREIGN KEY(N_ORDEN) REFERENCES CNB(N_ORDEN));
   CREATE INDEX CNT ON CNT(N_ORDEN,ORDEN);


/***************************************************************************************/
/******************      CUENTA CORRIENTE DE OBSEQUIOS     *****************************/
/***************************************************************************************/

/*CNS(CUENTA CORRIENTE DE OBSEQUIOS*/
CREATE TABLE IF NOT EXISTS CNS(
   N_ORDEN_18   CHAR(11) NOT NULL,
   NUME_SERIE	NUMERIC(4,0)  NOT NULL,
   PARTIDA      CHAR(10) DEFAULT '',
   N_DECLA_18	CHAR(6) DEFAULT '',
   FCNUMER_18	DATETIME ,   
   CONSIGNA     CHAR(5) DEFAULT '',
   TIPO_DOCUM	CHAR(1) DEFAULT '',
   LIBR_TRIBU	VARCHAR(12) DEFAULT '',
   APELLIDOS 	VARCHAR(100) DEFAULT '',
   NOMBRES   	VARCHAR(50) DEFAULT '',
   DIRECCION 	VARCHAR(80) DEFAULT '',
   INCISO    	CHAR(1) DEFAULT '',
   DESC_MERC 	VARCHAR(100) DEFAULT '',
   OBSERVA   	VARCHAR(80) DEFAULT '',
   UNID_FIDES	CHAR(3) DEFAULT '',
   UNID_FIQTY   DECIMAL(14,3) DEFAULT 0.000,
   PESO_BRUTO   DECIMAL(14,3) DEFAULT 0.000,
   FOB_DOLPOL   DECIMAL(14,3) DEFAULT 0.000,
   FCHNUMER	DATETIME,
   N_DECLAR	CHAR(6) DEFAULT '',
   ARCH_RES_P 	VARCHAR(12) DEFAULT '',
   FUNC_RESUM	VARCHAR(40) DEFAULT '',
   MSG_NOTIF	VARCHAR(219) DEFAULT '',
   ELEGIDO      NUMERIC(1,0) DEFAULT 0,
   FLAG_ERROR   CHAR(1) DEFAULT '', 	
   PRIMARY KEY(N_ORDEN_18,NUME_SERIE),
   CONSTRAINT FK_CNS_CLI FOREIGN KEY(CONSIGNA) REFERENCES CLI(CODIGO),
   CONSTRAINT FK_CNS_SEA FOREIGN KEY(N_ORDEN_18,NUME_SERIE) REFERENCES SEA(N_ORDEN,N_SERIE));
CREATE INDEX CNS ON CNS(FCNUMER_18);

/*CNR(TABLA DE ERRORES DE ENVIO POR TELEDESPACHO PARA LA CUENTA CORRIENTE DE OBSEQUIOS )*/
CREATE TABLE IF NOT EXISTS CNR(
   N_ORDEN   	CHAR(11) NOT NULL,	/*C  9  0*/
   NUME_SERIE	NUMERIC(4,0) NOT NULL,	/*C  4  0*/
   FECHA     	DATETIME,	/*D  8  0*/
   CODI_ERROR	CHAR(4)  DEFAULT '',	/*C  4  0*/
   DESC_ADVER	VARCHAR(100)  DEFAULT '',	/*C100  0*/
   TIPO_ENVIO	CHAR(1)  DEFAULT '',	/*C  1  0*/
   NOMB_ADVER	VARCHAR(40)  DEFAULT '',	/*C 40  0*/
   CODI_ADUAN	CHAR(3)  DEFAULT '',	/*C  3  0*/
   ANO_ORDEN 	CHAR(4)  DEFAULT '',	/*C  4  0*/
   TIPO_ERROR	CHAR(1)  DEFAULT '',	/*C  1  0 && Flag que determina si es un error o una advertencia*/
   PRIMARY KEY(N_ORDEN,NUME_SERIE,FECHA,CODI_ERROR),
   CONSTRAINT FK_CNR_CNS FOREIGN KEY(N_ORDEN,NUME_SERIE) REFERENCES CNS(N_ORDEN_18,NUME_SERIE));
   CREATE INDEX CNR ON CNR(N_ORDEN,NUME_SERIE);


/*=========================================================================================*/
/*=============                    GUIA DE REMISION                      ==================*/
/*=========================================================================================*/

/*GRE(TABLA DE GUIAS DE REMISION)*/
CREATE TABLE IF NOT EXISTS GRE(
   N_DOC       CHAR(10),                    /* 0 Numero de la Guia de Remisi�n */
   FECHOPE     DATE,                        /*D  8  0 Fecha de Creacion de la Guia de Remision*/
   N_ORDEN     CHAR(11) DEFAULT "",         /*C  9  0 N� de Orden del Despacho */
   COD_CLIEN   CHAR(5) DEFAULT "",          /*C  5  0 Codigo de cliente*/
   MOTIVO_TRA  CHAR(2) DEFAULT "",          /*C  2  0 Motivo del Traslado de la Mercaderia*/
   DES_MOTIVO  VARCHAR(80) DEFAULT "",      /*C 20  0 Descripcion del motivo de Traslado de Mercaderia*/
   COD_TRANSP  CHAR(3) DEFAULT "",          /*C  2  0 Codigo de la Empresa de Transporte (Validada en el TA104)*/
   SOL_TRANSP  CHAR(7) DEFAULT "",          /*  0 Solicitante del transporte ( SOLO PARA DANZAS ) y Zona de Traslado (NEW WORLD) y Moneda del Importe del Traslado para World Company*/
   COD_CODUCT  CHAR(3) DEFAULT "",          /*C  2  0 codigo de Conductor*/
   MATR_VEHIC  VARCHAR(45) DEFAULT "",      /*50  0 Matricula del Vehiculo*/
   FCHINITRAS  DATE,                        /*D  8  0 Fecha de Inicio de Traslado*/
   CERTINSCRI  VARCHAR(45) DEFAULT "",      /*C  6  0 Certificado de Inscripcion*/
   FECH_EMIS   DATE,                        /*D  8  0 Fecha de emision de la guia de Remision*/
   FECH_VENC   DATE,                        /*D  8  0 Fecha de Vencimiento de la Guia (FAZIO)*/
   MARC_NUM1   VARCHAR(45) DEFAULT "",      /*C 45  0 Marcas y numeros*/
   MARC_NUM2   VARCHAR(45) DEFAULT "",      /*C 45  0 Marcas y numeros*/
   MARC_NUM3   VARCHAR(45) DEFAULT "",      /*C 45  0 Marcas y numeros*/
   MARC_NUM4   VARCHAR(45) DEFAULT "",      /*C 45  0 Marcas y numeros*/
   MARC_NUM5   VARCHAR(45) DEFAULT "",      /*C 45  0 Marcas y numeros*/
   MARC_NUM6   VARCHAR(45) DEFAULT "",      /*C 45  0 Marcas y numeros*/
   MARC_NUM7   VARCHAR(45) DEFAULT "",      /*C 45  0 Marcas y numeros*/
   CONT1       VARCHAR(105) DEFAULT "",     /*C105  0 Contenido de la Mercaderia*/
   CONT2       VARCHAR(105) DEFAULT "",     /*C105  0 Contenido de la Mercaderia*/
   CONT3       VARCHAR(105) DEFAULT "",     /*C105  0 Contenido de la Mercaderia*/
   CONT4       VARCHAR(105) DEFAULT "",     /*C105  0 Contenido de la Mercaderia*/
   CONT5       VARCHAR(105) DEFAULT "",     /*C105  0 Contenido de la Mercaderia*/
   CONT6       VARCHAR(105) DEFAULT "",     /*C105  0 Contenido de la Mercaderia*/
   CONT7       VARCHAR(105) DEFAULT "",     /*C105  0 Contenido de la Mercaderia*/
   CONT8       VARCHAR(105) DEFAULT "",     /*C105  0 Contenido de la Mercaderia*/
   CONT9       VARCHAR(105) DEFAULT "",     /*C105  0 Contenido de la Mercaderia*/
   CONT10      VARCHAR(105) DEFAULT "",     /*C105  0 Contenido de la Mercaderia*/
   CONT11      VARCHAR(105) DEFAULT "",     /*C105  0 Contenido de la Mercaderia*/
   CONT12      VARCHAR(105) DEFAULT "",     /*C105  0 Contenido de la Mercaderia*/
   CONT13      VARCHAR(105) DEFAULT "",     /*C105  0 Contenido de la Mercaderia*/
   CONT14      VARCHAR(105) DEFAULT "",     /*C105  0 Contenido de la Mercaderia*/
   CONT15      VARCHAR(105) DEFAULT "",     /*C105  0 Contenido de la Mercaderia*/
   CONT16      VARCHAR(105) DEFAULT "",     /*C105  0 Contenido de la Mercaderia*/
   CONT17      VARCHAR(105) DEFAULT "",     /*C105  0 Contenido de la Mercaderia*/
   CONT18      VARCHAR(105) DEFAULT "",     /*C105  0 Contenido de la Mercaderia*/
   CONT19      VARCHAR(105) DEFAULT "",     /*C105  0 Contenido de la Mercaderia*/
   CONT20      VARCHAR(105) DEFAULT "",     /*C105  0 Contenido de la Mercaderia*/
   CONT21      VARCHAR(105) DEFAULT "",     /*C105  0 Contenido de la Mercaderia*/
   CONT22      VARCHAR(105) DEFAULT "",     /*C105  0 Contenido de la Mercaderia*/
   CONT23      VARCHAR(105) DEFAULT "",     /*C105  0 Contenido de la Mercaderia*/
   CONT24      VARCHAR(105) DEFAULT "",     /*C105  0 Contenido de la Mercaderia*/
   CONT25      VARCHAR(105) DEFAULT "",     /*C105  0 Contenido de la Mercaderia*/
   OBSVE1      VARCHAR(60) DEFAULT "",      /*C 60  0 Observaciones de la Guia*/
   OBSVE2      VARCHAR(60) DEFAULT "",      /*C 60  0 Observaciones de la Guia*/
   OBSVE3      VARCHAR(60) DEFAULT "",      /*C 60  0 Observaciones de la Guia*/
   OBSVE4      VARCHAR(60) DEFAULT "",      /*C 60  0 Observaciones de la Guia*/
   OBSVE5      VARCHAR(60) DEFAULT "",      /*C 60  0 Observaciones de la Guia*/
   OBSVE6      VARCHAR(60) DEFAULT "",      /*C 60  0 Observaciones de la Guia*/
   OBSVE7      VARCHAR(60) DEFAULT "",      /*C 60  0 Observaciones de la Guia*/
   OBSVE8      VARCHAR(60) DEFAULT "",      /*C 60  0 Observaciones de la Guia*/
   OBSVE9      VARCHAR(60) DEFAULT "",      /*C 60  0 Observaciones de la Guia*/
   OBSVE10     VARCHAR(60) DEFAULT "",      /*C 60  0 Observaciones de la Guia*/
   OBSVE11     VARCHAR(60) DEFAULT "",      /*C 60  0 Observaciones de la Guia*/
   OBSVE12     VARCHAR(60) DEFAULT "",      /*C 60  0 Observaciones de la Guia*/
   OBSVE13     VARCHAR(60) DEFAULT "",      /*C 60  0 Observaciones de la Guia*/
   OBSVE14     VARCHAR(60) DEFAULT "",      /*C 60  0 Observaciones de la Guia*/
   OBSVE15     VARCHAR(60) DEFAULT "",      /*C 60  0 Observaciones de la Guia*/
   OBSVE16     VARCHAR(60) DEFAULT "",      /*C 60  0 Observaciones de la Guia*/
   OBSVE17     VARCHAR(60) DEFAULT "",      /*C 60  0 Observaciones de la Guia*/
   PP_CODIGO   CHAR(4) DEFAULT "",          /*C  4  0 Codigo de la Direccion del Docimicilio de Partida (ANTES COD_DIRECP)*/
   PP_DOMICIL  VARCHAR(45) DEFAULT "",      /*C 45  0 Razon social del punto de partida (antes DOMIC_PART)*/
   PP_DIRECC   VARCHAR(90) DEFAULT "",      /*C 90  0 Direcci�n de partida (antes DIREC_PART)*/
   PP_VIATIPO  CHAR(10) DEFAULT "",         /*0 Via Tipo de Punto de Partida*/
   PP_VIANOMB  VARCHAR(40) DEFAULT "",      /*0 Via Nombre de Punto de Partida*/
   PP_NUMERO   CHAR(10) DEFAULT "",         /*C 10  0 Numero de Punto de Partida*/
   PP_INTER    CHAR(5) DEFAULT "",          /*C  5  0 Interior de Punto de Partida*/
   PP_ZONA     VARCHAR(20) DEFAULT "",      /*C 20  0 Zona de Punto de Partida*/
   PP_DIST     VARCHAR(20) DEFAULT "",      /*C 20  0 Punto de Partida - Distrito*/
   PP_PROV     VARCHAR(15) DEFAULT "",      /*C 15  0 Punto de Partida - Provincia*/
   PP_DPTO     VARCHAR(15) DEFAULT "",      /*C 15  0 Punto de Partida - Departamento*/   
   LL_CODIGO   CHAR(4) DEFAULT "",          /*C  4  0 cODIGO DE lugar de Entrega de la Mercaderia al Cliente (antes LUG_ENTREG)*/
   LL_DIRECC   VARCHAR(90) DEFAULT "",      /* 0 Punto de Llegada (P_LLEGADA)*/
   LL_VIATIPO  VARCHAR(10) DEFAULT "",      /*C 10  0 Via Tipo de Punto de Llegada*/
   LL_VIANOMB  VARCHAR(40) DEFAULT "",      /*C 40  0 Via Nombre de Punto de Llegada*/
   LL_NUMERO   VARCHAR(10) DEFAULT "",      /*C 10  0 Numero de Punto de Llegada*/
   LL_INTER    VARCHAR(5) DEFAULT "",       /*C  5  0 Interior de Punto de Llegada*/
   LL_ZONA     VARCHAR(20) DEFAULT "",      /*C 20  0 Zona de Punto de Llegada*/
   LL_DIST     VARCHAR(20) DEFAULT "",      /*C 20  0 Punto de Llegada - Distrito*/
   LL_PROV     VARCHAR(15) DEFAULT "",      /*C 15  0 Punto de Llegada - Provincia*/
   LL_DPTO     VARCHAR(15) DEFAULT "",      /* C 15  0 Punto de Llegada - Departamento*/
   FLETE_MERC  DECIMAL(13,3) DEFAULT 0.000, /* N 15  3 Flete interno (ANTES FLETE_DOL)*/
   PESO        DECIMAL(13,3) DEFAULT 0.000,  /* N 13  3 Total Peso Bruto (ANTES KBR) */
   BULTOS      DECIMAL(14,3) DEFAULT 0.000, /* N 14  3 Total bultos (ANTES T_BULTOS) */
   CLASEBULTO  VARCHAR(20) DEFAULT "",      /*  C 20  0 Clase de Bultos*/
   COD_USER    CHAR(3) DEFAULT "",          /* C  2  0 Codigo de Usuario*/
   ANULADA     CHAR(5) DEFAULT "",          /*C  1  0 Indicador para saber si la guia es Anulada*/ 
   OBSER1      VARCHAR(30) DEFAULT "",      /* C 30  0 Observacion Adicional a la Guia*/
   PP_RUC      CHAR(11) DEFAULT "",         /* 0 Punto de Llegada (P_RUC)*/
   LL_NOMBRE   VARCHAR(90) DEFAULT "",      /* 0 Nombre del punto de Llegada */
   LL_RUC      CHAR(11) DEFAULT "",         /* 0 Nombre del punto de Llegada */   
   CODI_DEST   CHAR(4) DEFAULT "",          /* Codigo de Destinatarios diferente al cliente solo DHL*/
   PRIMARY KEY(N_DOC),
   CONSTRAINT FK_GRE_APE FOREIGN KEY(N_ORDEN) REFERENCES APE(N_ORDEN),
   CONSTRAINT FK_GRE_USU FOREIGN KEY(COD_USER) REFERENCES USU(CODIGO),
   CONSTRAINT FK_GRE_CLI FOREIGN KEY(COD_CLIEN) REFERENCES CLI(CODIGO));
CREATE INDEX GRE ON GRE(N_DOC);

/*******************************************************************************************/
/****          TABLA DE FACTURACION Y CUENTA CORRIENTE                                   ****/
/********************************************************************************************/

/*DOC(TABLA DE DOCUMENTOS DE VENTA)*/
CREATE TABLE IF NOT EXISTS DOC(
    DOC      	CHAR(2) NOT NULL ,              /*Tipo de Documento u Operacion (01-FACTURA, 02-BOLETA, ETC)	*/
    N_DOC	CHAR(10) NOT NULL,              /*Numero del Documento	*/
    FECHOPE 	DATE,                           /*Fecha de Creacion del Documento*/
    COD_CLIEN	CHAR(5) DEFAULT "",             /*Codigo del Cliente */
    MONEDA	CHAR(1) DEFAULT "D",            /*Moneda Original del documento	*/
    T_CAMBIO 	DECIMAL(7,3) DEFAULT 0.000,     /*TIPO DE CAMBIO DEL DOCUMENTO	*/
    N_ORDEN	CHAR(11) DEFAULT "",            /*N� de Orden ---- DATOS DEL DESPACHO -----	*/
    FOB_DOL     DECIMAL(13,3) DEFAULT 0.000,	/*Fob en dolares ajustado del despacho/ Sumatoria de Fob en Facturas Consolidadas*/ 
    FLETE_DOL   DECIMAL(13,3) DEFAULT 0.000,	/*Flete en dolares ajustado del despacho/Sumatoria de Fletes de Facturas Consolidadas*/
    SEGURO_DOL  DECIMAL(13,3) DEFAULT 0.000,	/*Seguro en Dolares Ajustado/Sumatoria de SEFletesd�lares/Valor Neto de entrega*/
    CIFDOL      DECIMAL(13,3) DEFAULT 0.000,	/*N 13  3*************Cif en d�lares/Valor Neto de entrega*/
    INCLUYE 	CHAR(1) DEFAULT "N",             /*Flag para incluir Derechos (Factura y Carta de Cobranza)documento	*/
    GUIAS 	VARCHAR(44) DEFAULT "",         /*Numero de la Guia de Remision/Numero de la Factura Asociada a la Carta de cobranza (14) y nota de debito y credito	*/
    N_PROF 	CHAR(8) DEFAULT "",             /*N� Proforma -- DATOS DE LA PROFORMA/FACTURA ---	*/
    COD_TRANS	CHAR(2) DEFAULT "",             /*Codigo de Transportista	*/
    ZONA_TRANS	CHAR(1) DEFAULT "",             /*Zona de transporte	*/
    TSDER  	DECIMAL(14,2) DEFAULT 0.00,	/*Total Derechos el Soles	*/
    TDDER 	DECIMAL(14,2) DEFAULT 0.00,	/*Total Derechos en Dolares	*/
    TSGAS 	DECIMAL(14,2) DEFAULT 0.00,	/*Importe Total de Gastos en Soles*/	
    TDGAS  	DECIMAL(14,2) DEFAULT 0.00,	/*Importe Total de Gastos en Dolares*/	
    SBASE	DECIMAL(14,2) DEFAULT 0.00,	/*Base Imponible en Soles	*/
    DBASE 	DECIMAL(14,2) DEFAULT 0.00,	/*Base imponible en Dolares	*/
    DCOMISION   DECIMAL(14,2) DEFAULT 0.00,     /*Comision en la Agencia en Dolares/Monto de la Factura Asociada a la Carta de Cobranza en dolares/Importe en dolares del documento a que hace referencia la nota de debito*/
    SCOMISION	DECIMAL(14,2) DEFAULT 0.00,     /*Comision de la Agencia en Soles/Monto de la Factura Asociada a la Carta de Cobranza en dolares'/Importe en Soles del documento a que hace referencia la nota de debito*/
    AFECTO_COM	CHAR(1) DEFAULT "",             /*ndicador para ver si la comision paga o no IGV /Moneda del documento a que hace referencia la nota de debito*/
    DBASENA	DECIMAL(14,2) DEFAULT 0.00,	/*BASE NO IMPONIBLE EN DOLARES*/
    SBASENA 	DECIMAL(14,2) DEFAULT 0.00,	/*BASE NO IMPONIBLE EN SOLES*/
    TIPO_BASE	CHAR(1) DEFAULT "",             /*Tipo de comision aplicada a la Factura	*/
    DIGV 	DECIMAL(14,2) DEFAULT 0.00,	/*IMPORTE DEL IGV EN DOLARES	*/
    SIGV	DECIMAL(14,2) DEFAULT 0.00,	/*IMPORTE DEL IGV EN SOLES	*/
    STOT_DOCU	DECIMAL(14,2) DEFAULT 0.00,	/*IMPORTE DEL DOCUMENTO EN SOLES	*/
    DTOT_DOCU	DECIMAL(14,2) DEFAULT 0.00,	/*IMPORTE DEL DOCUMENTO EN DOLARES	*/
    FECH_RECEP  DATE,                           /*Fecha de recepcion del Documento */ 
    FECH_VENC	DATE,   	                /*Fecha de Vencimiento de la factura	*/
    OBSVE1 	VARCHAR(75) DEFAULT "",         /*Observaciones del Documento 	*/
    OBSVE2	VARCHAR(75) DEFAULT "",         /*Observaciones del Documento 	*/
    OBSVE3	VARCHAR(75) DEFAULT "",         /*Observaciones del Documento 	*/
    OBSVE4	VARCHAR(75) DEFAULT "",         /*Observaciones del Documento 	*/
    OBSVE5	VARCHAR(75) DEFAULT "",         /*Observaciones del Documento 	*/
    OBSVE6	VARCHAR(75) DEFAULT "",         /*Observaciones del Documento 	*/
    OBSVE7	VARCHAR(75) DEFAULT "",         /*Observaciones del Documento 	*/ 	
    OBSVE8	VARCHAR(75) DEFAULT "",         /*Observaciones del Documento 	*/
    OBSVE9	VARCHAR(75) DEFAULT "",         /*Observaciones del Documento 	*/
    OBSVE10	VARCHAR(75) DEFAULT "",         /*Observaciones del Documento 	*/
    OBSVE11	VARCHAR(75) DEFAULT "",         /*Observaciones del Documento 	*/
    OBSVE12	VARCHAR(75) DEFAULT "",         /*Observaciones del Documento 	*/
    OBSVE13	VARCHAR(75) DEFAULT "",         /*Observaciones del Documento 	*/
    OBSVE14	VARCHAR(75) DEFAULT "",         /*Observaciones del Documento 	*/
    OBSVE15	VARCHAR(75) DEFAULT "",         /*Observaciones del Documento 	*/
    OBSVE16	VARCHAR(75) DEFAULT "",         /*Observaciones del Documento 	*/
    OBSVE17	VARCHAR(75) DEFAULT "",         /*Observaciones del Documento 	*/
    OBSVE18	VARCHAR(75) DEFAULT "",         /*Observaciones del Documento 	*/
    OBSVE19	VARCHAR(75) DEFAULT "",         /*Observaciones del Documento 	*/
    OBSVE20	VARCHAR(75) DEFAULT "",         /*Observaciones del Documento 	*/
    OBSVE21	VARCHAR(75) DEFAULT "",         /*Observaciones del Documento 	*/
    OBSVE22	VARCHAR(75) DEFAULT "",         /*Observaciones del Documento 	*/
    OBSVE23	VARCHAR(75) DEFAULT "",         /*Observaciones del Documento 	*/
    OBSVE24	VARCHAR(75) DEFAULT "",         /*Observaciones del Documento 	*/
    OBSVE25   	VARCHAR(75) DEFAULT "",         /*Observaciones del Documento 	*/
    COD_USER	CHAR(3) DEFAULT "",             /*Codigo de usuario del que hizo el documento	*/
    ENLA_CONTA	VARCHAR(24) DEFAULT "",         /*IDENTIFICACION DEL ASIENTO DE VENTAS	*/
    DOC_INCCOB	CHAR(1) DEFAULT "",             /*FLAG QUE INDICA SI LA FACTURA ESTA INCLUIDA EN LA CARTA DE COBRANZA POR LO QUE YA NO HIRA COMO DOCUMENTO PENDIENTE DE PAGO	*/
    ENUSO       VARCHAR(22) DEFAULT "",         /*Flag que indica que el Documento esta en uso*/	
    ANULADA	CHAR(1) DEFAULT "",             /*INDICADOR SI EL DOCUMENTO ESTA ANULADO	*/
    ESTADO_DOC  CHAR(1) DEFAULT "P",            /*Indicador del Estado del Documento (C=Cancelado,P =Pendiente)*/ 
    TCAMBIOCTA  DECIMAL(7,3) DEFAULT 0.000,     /*TIPO DE CAMBIO PARA LAS APLICACIONES DE ANTICIPO*/
    KBR       	DECIMAL(15,3) DEFAULT 0.000,	/*N 15  3 //KILOS BRUTO PARA PRORRATEAO POR FACTURA*/
    T_BULTOS    DECIMAL(15,3) DEFAULT 0.000,	 /*N 14  3*************Total Bultos / Cant.Bultos 43*/    
    REF_CLIE  	VARCHAR(200) DEFAULT '',	/*C 25  0  Referencia del Cliente*/
   PRIMARY KEY(DOC,N_DOC),
   CONSTRAINT FK_DOC_CLI  FOREIGN KEY(COD_CLIEN) REFERENCES CLI(CODIGO),
   CONSTRAINT FK_DOC_USU  FOREIGN KEY(COD_USER)  REFERENCES USU(CODIGO),
   CONSTRAINT FK_DOC_TS31 FOREIGN KEY(DOC)       REFERENCES softpad_sistema.TS31(COD),
   CONSTRAINT FK_DOC_PRO  FOREIGN KEY(N_PROF)    REFERENCES PRO(N_PROF),
   CONSTRAINT FK_DOC_APE  FOREIGN KEY(N_ORDEN)   REFERENCES APE(N_ORDEN));
CREATE INDEX DOC ON DOC(DOC,N_DOC);
CREATE INDEX DOC_GUIAS ON DOC(GUIAS); /*PARA QUE ESTE MAS RAPIDO LA CANCELACION DE DOCUMENTOS RELACIONADOS A UNA NOTA DE DEBITO O CREDITO */
insert into doc(doc,n_doc,cod_user,fechope) values("","","001","2011-01-01");
insert into doc(doc,n_doc,cod_user,fechope) values("00","","001","2011-01-01");
insert into doc(doc,n_doc,cod_user,fechope) values("99","","001","2011-01-01");
insert into doc(doc,n_doc,cod_user,fechope) values("01","","001","2011-01-01");
insert into doc(doc,n_doc,cod_user,fechope) values("03","","001","2011-01-01");
insert into doc(doc,n_doc,cod_user,fechope) values("14","","001","2011-01-01");


/*DET(DETALLE DE LOS GASTOS DE LOS DOCUMENTOS DE VENTA)*/
CREATE TABLE IF NOT EXISTS DET(
  DOC		CHAR(2) NOT NULL ,              /*TIPO DE DOCUMENTO U OPERACION	*/
  N_DOC		CHAR(10) NOT NULL ,             /*NUMERO DEL DOCUMENTO DEL CUAL SE HACER REFERENCIA EL DETALLE	*/
  N_SERIE	NUMERIC(4,0) NOT NULL,         /*Serie de item del detalle de la carta de cobranza	*/
  FECHGASTO	DATE,   	                /*FECHA EN QUE SE REALIZO EL GASTO PARA CARTA DE COBRANZA*/	
  CODGASTO	CHAR(3) DEFAULT "",             /*CODIGO DEL GASTO QUE SE DETALLA	*/
  CONCEPTO   	VARCHAR(70) DEFAULT "",         /*DESCRIPCION O CONCEPTO DEL GASTO	*/
  NUMCOMPR   	VARCHAR(23) DEFAULT "",         /*NUMERO DEL COMPROBANTE PARA LA CARTA DE COBRANZA	*/
  MON	        CHAR(1) DEFAULT "",             /*TIPO DE MONEDA DEL GASTO	*/
  T_CAMBIO	DECIMAL(7,3) DEFAULT 0.000,     /*TIPO DE CAMBIO DEL DOCUMENTO	*/
  SGASTO        DECIMAL(14,2) DEFAULT 0.00,	/*IMPORTE EN SOLES DEL GASTO	*/
  DGASTO	DECIMAL(14,2) DEFAULT 0.00,	/*IMPORTE EN DOLARES DEL GASTO	*/
  AFECTO	CHAR(1) DEFAULT "",             /*FLAG QUE IDENTIFICA SI ESTE IMPORTE ESTA AFECTO A IGV O NO	*/
  OSGASTO	DECIMAL(14,2) DEFAULT 0.00,	/*GASTO TRANSFERIDO DESDE LA PLANILLA DOC="01,02" (SOLES)  /IMPORTE NETO DEL GASTO EN DOLARES (CARTA DE COBRANZA)	*/
  ODGASTO	DECIMAL(14,2) DEFAULT 0.00,	/*GASTO TRANSFERIDO DESDE LA PLANILLA DOC="01,02" (DOLARES)/IMPORTE NETO DEL GASTO EN SOLES (CARTA DE COBRANZA)	*/
  PSGASTO 	DECIMAL(14,2) DEFAULT 0.00,	/*GASTO TRANSFERIDO DESDE LA PROFORMA DOC="01,02" (SOLES)  /IGV DEL IMPORTE NETO DEL GASTO EN DOLARES (CARTA DE COBRANZA)	*/
  PDGASTO 	DECIMAL(14,2) DEFAULT 0.00,	/*GASTO TRANSFERIDO DESDE LA PROFORMA DOC="01,02" (DOLARES)/IGV DEL IMPORTE NETO DEL GASTO EN SOLES (CARTA DE COBRANZA)	*/
  SUBNUMDOC	CHAR(10) DEFAULT "",            /*NUMERO DEL DOCUMENTO PARA FINANCIAMIENTOS	*/
  COD_PROV	CHAR(11) DEFAULT "",            /*Codigo del Proveedor	*/
  TIPO_DOCU	CHAR(2) DEFAULT "",             /*Para el tipo de documento del detalle de la Carta de Cobranza	*/
  CANCE_CLI	CHAR(1) DEFAULT "",             /*Flag que determina si el gasto lo ha cancelado el cliente	*/
  OBSERVAC   	VARCHAR(60) DEFAULT "",         /*Observaciones al concepto del Documento	*/
  ENLA_CONTA  	VARCHAR(24) DEFAULT "",         /*FLAG DE ENLACE CONTABLE ALIMENTADO POR CONTABILIDAD	*/
  CANTIDAD 	NUMERIC(4,0) DEFAULT 0,          /*CANTIDAD DE MERCANCIA PARA LA FACTURA DE TRANSPORTE	*/
  PRIMARY KEY(DOC,N_DOC,N_SERIE),
  CONSTRAINT FK_DET_DOC FOREIGN KEY(DOC,N_DOC) REFERENCES DOC(DOC,N_DOC),
  CONSTRAINT FK_DET_TGF FOREIGN KEY(CODGASTO) REFERENCES TGF(CODIGO));
CREATE INDEX DET ON DET(DOC,N_DOC);

/* OFC (ARCHIVO PARA FACTURAR VARIAS ORDENES EN UNA SOLA FACTURA O BOLETA (FACTURAS CONSOLIDADAS)*/
CREATE TABLE IF NOT EXISTS OFC(
   DOC       	CHAR(2) NOT NULL,            /*C  2  0 Tipo de Documento (01-Factura 14-Carta de Cobranza)*/
   N_DOC     	CHAR(10) NOT NULL,           /*C 10  0 Numero del la Factura de la Agencia*/
   CORREL       CHAR(3) NOT NULL,            /*C  3  0 Numero de correlacion de las Ordenes ingresadas */
   N_ORDEN   	CHAR(11) DEFAULT "",	     /*C  9  0 Numero de la Orden de despacho a que va a Afectar esta Factura*/
   ASIGNADA  	CHAR(1) DEFAULT "",	     /*C  1  0 Flag que indica que ya fue aceptada y relacionada con el DGA*/
   DCOMISION 	DECIMAL(12,2) DEFAULT 0.00,  /*N 12  2 Importe de la Comision en Dolares*/
   SCOMISION 	DECIMAL(12,2) DEFAULT 0.00,  /*N 12  2 Importe de la comision en Soles*/
   DETALLE   	CHAR(1) DEFAULT "",	     /*C  1  0 Flag que permite ingresar el detalle de los Gastos de cada Orden*/
   OBSERVAC  	VARCHAR(30) DEFAULT "",	     /*C 30  0 Observaciones de la Orden*/
   COD_TRANS 	CHAR(2) DEFAULT "",	     /*C  2  0 Codigo de Transportista*/
   ZONA_TRANS	CHAR(1) DEFAULT "",	     /*C  1  0 Zona de transporte*/
   TSDER     	DECIMAL(14,2) DEFAULT 0.00,  /*N 14  2 Total Derechos el Soles*/
   TDDER     	DECIMAL(14,2) DEFAULT 0.00,  /*N 14  2 Total Derechos en Dolares*/
   TSGAS     	DECIMAL(12,2) DEFAULT 0.00,  /*N 12  2 Importe Total de Gastos en Soles*/
   TDGAS     	DECIMAL(12,2) DEFAULT 0.00,  /*N 12  2 Importe Total de Gastos en Dolares*/
   PRIMARY KEY(DOC,N_DOC,CORREL),
   CONSTRAINT FK_OFC_DOC FOREIGN KEY(DOC,N_DOC) REFERENCES DOC(DOC,N_DOC),
   CONSTRAINT FK_OFC_APE FOREIGN KEY(N_ORDEN) REFERENCES APE(N_ORDEN));
   CREATE INDEX OFC ON OFC(DOC,N_DOC,CORREL);

/*(OFD) DETALLE DE LAS FACTURAS CONSOLIDADAS */
CREATE TABLE IF NOT EXISTS OFD(
   DOC       	CHAR(2) NOT NULL,	     /*C  2  0 Tipo de Documento (01-Factura 14-Carta de Cobranza)*/
   N_DOC     	CHAR(10) NOT NULL,	     /*C 10  0 Numero del la Factura de la Agencia*/
   CORREL       CHAR(3) NOT NULL,            /*C  3  0 Numero de correlacion en referencia al OFC */
   N_SERIE	NUMERIC(4,0) NOT NULL,       /*Serie de item del detalle de la carta de cobranza	*/
   CODGASTO     CHAR(3) DEFAULT "",          /*CODIGO DEL GASTO QUE SE DETALLA*/
   CONCEPTO     VARCHAR(40) DEFAULT "",      /*DESCRIPCION O CONCEPTO DEL GASTO*/
   SGASTO       DECIMAL(12,2) DEFAULT 0.00,  /*IMPORTE EN SOLES DEL GASTO*/
   DGASTO       DECIMAL(12,2) DEFAULT 0.00,  /*IMPORTE EN DOLARES DEL GASTO*/
   PRIMARY KEY(DOC,N_DOC,CORREL,N_SERIE),
   CONSTRAINT FK_OFD_OFC FOREIGN KEY(DOC,N_DOC,CORREL) REFERENCES OFC(DOC,N_DOC,CORREL), 
   CONSTRAINT FK_OFD_TGF FOREIGN KEY(CODGASTO) REFERENCES TGF(CODIGO));
create index OFD on OFD(DOC,N_DOC,CORREL,N_SERIE);

/* INF (ARCHIVO PARA LAS INCIDENCIA DE LA FACTURACION*/
CREATE TABLE IF NOT EXISTS INF(
  DOC		CHAR(2) NOT NULL ,              /*TIPO DE DOCUMENTO U OPERACION	*/
  N_DOC		CHAR(10) NOT NULL ,             /*NUMERO DEL DOCUMENTO DEL CUAL SE HACER REFERENCIA EL DETALLE	*/
  FECHA_INC	DATETIME,                       /*INF.FECHA_INC+INF.HORA	FECHA DE LA INCIDENCIA   */
  ESTADO 	CHAR(2) DEFAULT "",             /*INF.ESTADO	ESTADO DE LA INCIDENCIA*/
  INCIDENCIA	VARCHAR(55) DEFAULT "",         /*INF.INCIDENCIA	DETALLE DE LA INCIDENCIA*/
  AUTOMATICO	CHAR(1) DEFAULT "",             /*INF.AUTOMATICO	INDICADOR SI LA INCIDENCIA ES AUTOMATICA*/
  COD_USER	CHAR(3) DEFAULT "",             /*INF.COD_USER	CODIGO DE USUARIO QUE REALIZO LA FACTURA*/
  MARCA  	NUMERIC(1,0) DEFAULT 0,         /*SELECCIONA LAS INCIDENCIAS QUE VAN A SALIR EN EL REPORTE */
  PRIMARY KEY(DOC,N_DOC,FECHA_INC,ESTADO),
  CONSTRAINT FK_INF_DOC   FOREIGN KEY(DOC,N_DOC) REFERENCES DOC(DOC,N_DOC),
  CONSTRAINT FK_INF_USU   FOREIGN KEY(COD_USER)  REFERENCES USU(CODIGO),
  CONSTRAINT FK_INF_TS314 FOREIGN KEY(ESTADO)    REFERENCES softpad_sistema.TS314(COD));
CREATE INDEX INF ON INF(DOC,N_DOC);

/* ADF (ARCHIVO DE DOCUMENTOS ADJUNTOS A LA FACTURA*/
CREATE TABLE IF NOT EXISTS ADF(
  DOC		CHAR(2) NOT NULL ,              /*TIPO DE DOCUMENTO U OPERACION	*/
  N_DOC		CHAR(10) NOT NULL ,             /*NUMERO DEL DOCUMENTO DEL CUAL SE HACER REFERENCIA EL DETALLE	*/
  CORREL  	CHAR(02) DEFAULT "",		/*Correlativo de Documentos Adjuntos*/
  DOCUM_ADJ     VARCHAR(40) DEFAULT "",        /*Nombre del Documento Adjunto*/
  NUMDOC_ADJ	VARCHAR(25) DEFAULT "",         /*Numero del Documento Adjunto*/
  IMPORTE	DECIMAL(13,2) DEFAULT 0.00,     /*Importe del Documento Adjunto*/
  FLAG_ADJ	NUMERIC(1,0) DEFAULT 0,         /* Flag opcional*/
  AUTOMATICO	CHAR(1) DEFAULT "",             /* Indica si el registro a sido generado automaticamente*/
  PRIMARY KEY(DOC,N_DOC,CORREL),
  CONSTRAINT FK_ADF_DOC  FOREIGN KEY(DOC,N_DOC) REFERENCES DOC(DOC,N_DOC));
CREATE INDEX ADF ON ADF(DOC,N_DOC);

/*RDE (DERECHOS DE LA FACTURA Y BOLETA DE VENTA*/
CREATE TABLE IF NOT EXISTS RDE(
  DOC		CHAR(2) NOT NULL ,              /*TIPO DE DOCUMENTO U OPERACION	*/
  N_DOC		CHAR(10) NOT NULL ,             /*NUMERO DEL DOCUMENTO DEL CUAL SE HACER REFERENCIA EL DETALLE	*/
  COD_DERE	CHAR(2) DEFAULT "",             /*Codigo del Derecho  */
  SDERECHO	DECIMAL(12,2) DEFAULT 0.00,     /*Importe de los Derechos en Dolares*/
  DDERECHO	DECIMAL(12,2) DEFAULT 0.00,     /*Importe de los Derechos en Soles*/
  PRIMARY KEY(DOC,N_DOC,COD_DERE),
  CONSTRAINT FK_RDE_DOC  FOREIGN KEY(DOC,N_DOC) REFERENCES DOC(DOC,N_DOC),
  CONSTRAINT FK_RDE_TS35 FOREIGN KEY(COD_DERE) REFERENCES softpad_sistema.TS35(CODIGO));
CREATE INDEX RDE ON RDE(DOC,N_DOC);

/*CTA (ARCHIVOS DE CUENTAS BANCARIAS DE LA EMPRESA */
CREATE TABLE IF NOT EXISTS CTA(
  NUMERO_CTA  CHAR(25) NOT NULL,       /*NUMERO DE LA CUENTA BANCARIA DEL LA AGENCIA */
  MONEDA      CHAR(1) DEFAULT "S",     /*MONEDA DE LA CUENTA BANCARIA DE LA EMPRESA */
  COD_BANCO   CHAR(2) DEFAULT "",      /*BANCO AL QUE PERTENECE LA CUENTA BANCARIA */
  CUENTA      CHAR(8) DEFAULT "",      /*CUENTA CONTABLE DE LA CUENTA BANCARIA */
  SECTORISTA  VARCHAR(40) DEFAULT "",  /*SECTORISTA DE LA AGENCIA PARA DICHA CUENTA */
  PRIMARY KEY(NUMERO_CTA),
  CONSTRAINT FK_CTA_TS9 FOREIGN KEY(COD_BANCO) REFERENCES softpad_sistema.TS9(CODIGO),
  CONSTRAINT FK_CTA_TS258 FOREIGN KEY(MONEDA) REFERENCES softpad_sistema.TS258(CODIGO));
CREATE INDEX CTA ON CTA(NUMERO_CTA);
INSERT INTO CTA VALUES("","","","","");

/*PRC (ARCHIVOS DE PROVEEDORES DE CUENTA CORRIENTE Y FACTURACION */
CREATE TABLE IF NOT EXISTS PRC(
  COD_PROV    CHAR(11) NOT NULL,       /*CODIGO DEL PROVEEDOR */
  NOMBRE      VARCHAR(45) DEFAULT "",  /*NOMBRE DEL PROVEEDOR */
  DIRECCION   VARCHAR(60) DEFAULT "",  /*DIRECCION DEL PROVEEDOR */
  TELEFONO1   VARCHAR(8) DEFAULT "",   /*TELEFONO DEL PROVEEDOR */      
  TELEFONO2   VARCHAR(8) DEFAULT "",   /*TELEFONO DEL PROVEEDOR */      
  FAX         VARCHAR(10)DEFAULT "",   /*FAX DEL PROVEEDOR */      
  EMAIL       VARCHAR(30) DEFAULT "",  /*EMAIL DEL PROVEEDOR */
  FECING      DATE,                    /*FECHA DE INGRESO DEL PROVEEDOR */
  PRIMARY KEY(COD_PROV),
  CONSTRAINT UQ_PRC_1 UNIQUE(NOMBRE));
CREATE INDEX PRC_1 ON PRC(COD_PROV);
CREATE INDEX PRC_2 ON PRC(NOMBRE);
INSERT INTO PRC VALUES("","Z","","","","","","1900-01-01");

/*GAS(ARCHIVO DE GASTOS DE DESPACHO*/
CREATE TABLE IF NOT EXISTS GAS(
   N_ORDEN     CHAR(11) NOT NULL,           /*C  9  0 N� de Orden del Despacho */
   CORREL      CHAR(2) NOT NULL,            /*Correlacion de registros */
   CODGASTO    CHAR(3) DEFAULT "",          /*Codigo del Gasto de Despacho */
   FECHOPE     DATE,                        /*Fecha de el Gasto */
   MONEDA      CHAR(1) DEFAULT "S",         /*Moneda del gasto */	
   T_CAMBIO    DECIMAL(7,3) DEFAULT 0.000,  /*Tipo de Cambio del Gasto */
   N_CHEQUE    VARCHAR(15) DEFAULT "",      /*NUMERO DEL CHEQUE DEL VOUCHER */	
   N_CUENTA    CHAR(25) DEFAULT "",         /*NUMERO DE CUENTA BANCARIA */	
   T_FACTPROV  CHAR(2) DEFAULT "",          /*Tipo de Documento del Proveedor */
   N_FACTPROV  VARCHAR(23) DEFAULT "",      /*Numero de documento del Proveedor */	
   F_FACTPROV  DATE,                        /*Fecha del Documento del Proveedor */
   COD_PROV    CHAR(11) DEFAULT "",         /*Codigo del Proveedor (RUC) */
   OBSERVACIO  VARCHAR(25) DEFAULT "",      /*Observaciones Adicionales */	
   IMPORTE     DECIMAL(12,2) DEFAULT 0.000, /*Importe del Gasto */
   IMPOR_NETO  DECIMAL(12,2) DEFAULT 0.000, /*Importe neto del Gasto */
   NETO_IGV    DECIMAL(12,2) DEFAULT 0.000, /*igv del Gasto */
   DOC         CHAR(2) DEFAULT "",          /*TIPO DE DOCUMENTO ASOCIADO AL QUE HA TRANSFERIDO EL GASTO */
   N_DOC       CHAR(10) DEFAULT "",         /*NUMERO DE DOCUMENTO ASOCIADO AL QUE HA SIDO TRANSFERIDO LOS GASTOS*/
   ENLA_CONTA  VARCHAR(24) DEFAULT "",      /*FLAG DE ENLACE CONTABLE ALIMENTADO POR CONTABILIDAD	*/
  PRIMARY KEY(N_ORDEN,CORREL),                                                                                              
 CONSTRAINT FK_GAS_APE  FOREIGN KEY(N_ORDEN) REFERENCES APE(N_ORDEN),
 CONSTRAINT FK_GAS_PRC  FOREIGN KEY(COD_PROV) REFERENCES PRC(COD_PROV),
 CONSTRAINT FK_GAS_TGF  FOREIGN KEY(CODGASTO) REFERENCES TGF(CODIGO),
 CONSTRAINT FK_GAS_DOC  FOREIGN KEY(DOC,N_DOC) REFERENCES DOC(DOC,N_DOC),
 CONSTRAINT FK_GAS_TS258 FOREIGN KEY(MONEDA) REFERENCES softpad_sistema.TS258(CODIGO),
 CONSTRAINT FK_GAS_CTA  FOREIGN KEY(N_CUENTA) REFERENCES CTA(NUMERO_CTA));
CREATE INDEX GAS ON GAS(N_ORDEN,CORREL);

/*==========================================================================================*/

/*VOU (ARCHIVO DE CABECERA DEL VOUCHER DE INGRESOS Y/O EGRESOS */
CREATE TABLE IF NOT EXISTS VOU(
  N_VOUCHER   CHAR(10) NOT NULL,          /*NUMERO VOUCHER (A�o + NUMERO DE CORRELATIVO ) */ 
  TIPO_VOUCH  CHAR(2) NOT NULL,           /*TIPO DEL VOUCHER (01=INGRESOS / 02 =EGRESOS) */ 
  FECHOPE     DATE,                       /*FECHA DE REGISTRO DEL VOUCHER */
  COD_CLIEN   CHAR(5)	DEFAULT "",       /*COD.DEL CLIENTE DEL DEPOSITANTE*/
  MONEDA      CHAR(1)   DEFAULT "D",      /*MONEDA DEL VOUCHER */
  T_CAMBIO    DECIMAL(6,3) DEFAULT 0.000, /*TIPO DE CAMBIO PARA EL VOUCHER */
  NUMERO_CTA  VARCHAR(25)  DEFAULT  "",   /*NRO. DE LA CUENTA CORRIENTE DEL BANCO */
  T_PAGO      CHAR(3)   DEFAULT  "",      /*TIPO DE PAGO -CODIFICACION SUNAT - 001=DEPOSITO EN CUENTA / 112=CHEQUES BANCARIOS-COMERCIO EXTERIOR / 011=LETRAS DE CAMBIO */	
  BANCO	      CHAR(2)   DEFAULT  "",      /*CODIGO DE BANCO SUNAT, DE DONDE PROVIENE EL CHEQUE */	
  N_CHEQUE    VARCHAR(8)   DEFAULT  "",   /*NRO DE CHEQUE DEL BANCO DE DONDE PROVIENE EL ABONO */	
  SIMPORTE    DECIMAL(12,2) DEFAULT 0.00, /*IMPORTE TOTAL DEL VOUCHER EN SOLES */
  DIMPORTE    DECIMAL(12,2) DEFAULT 0.00, /*IMPORTE TOTAL DEL VOUCHER EN DOLARES */
  GLOSA       VARCHAR(60)  DEFAULT  "",    /*CONCEPTO, GLOSA � REFERENCIA GENERAL DEL VOUCHER */
  COD_USER    CHAR(3) DEFAULT "",          /*Codigo de usuario del que hizo el documento	*/
  FECH_EMIS   DATE,                        /*Fecha de Emision del voucher */ 
  ANULADA     CHAR(1) DEFAULT  	"",         /*ANULA VOUCHER */	
  PRIMARY KEY(TIPO_VOUCH,N_VOUCHER),
 CONSTRAINT FK_VOU_CLI  FOREIGN KEY(COD_CLIEN) REFERENCES CLI(CODIGO),
 CONSTRAINT FK_VOU_TS258 FOREIGN KEY(MONEDA) REFERENCES softpad_sistema.TS258(CODIGO),
 CONSTRAINT FK_VOU_TS638 FOREIGN KEY(T_PAGO) REFERENCES softpad_sistema.TS638(COD_TPAGO),
 CONSTRAINT FK_VOU_CTA  FOREIGN KEY(NUMERO_CTA) REFERENCES CTA(NUMERO_CTA));
CREATE INDEX VOU ON VOU(TIPO_VOUCH,N_VOUCHER);

/*VDE (ARCHIVO DE DETALLE DEL VOUCHER DE INGRESOS Y/O EGRESOS */
CREATE TABLE IF NOT EXISTS VDE(
  N_VOUCHER   CHAR(10) NOT NULL, /*NUMERO VOUCHER (A�o + MES + NUMERO DE CORRELATIVO POR MES) - SIEMPRE DEBE INICIALIZAR EL MES CON: 00001 */ 
  TIPO_VOUCH  CHAR(2) NOT NULL, /*TIPO DEL VOUCHER (01=INGRESOS / 02 =EGRESOS) */ 
  REG_VOUCH   NUMERIC(3,0) DEFAULT 0,/*CORRELATIVO DEL VOUCHER INTERNO */ 
  DIMPORTE    DECIMAL(12,2) DEFAULT 0.00,/*IMPORTE EN SOLES PARA LAS SALIDAS (DEBE ESTAR LLENO CON LOS IMPORTES ORIGINALES O SU CONVERSION  */ 
  SIMPORTE    DECIMAL(12,2) DEFAULT 0.00,/*IMPORTE EN DOLARES PARA LAS SALIDAS (DEBE ESTAR LLENO CON LOS IMPORTES ORIGINALES O SU CONVERSION */
  N_ORDEN     CHAR(11)  DEFAULT  "",/*NRO. DE LA ORDEN */
  DOC	      CHAR(2) DEFAULT  "",/*TIPO DE DOCUMENTO (01=FACTURA /  03= BOLETA  / 07= NOTA DE CREDITO /  08=NOTA DE DEBITO) */	
  N_DOC	      CHAR(10) DEFAULT "",/*NRO DE DOCUMENTO, SI BIEN ES CIERTO A NIVEL NACIONAL ES 10 CARACTERES, A NIVEL CONTABLE SUELE SER MAS */ 
  FECHA_DOC   DATE,               /*FECHA DE DOCUMENTO */
  REFER_DATO  VARCHAR(30) DEFAULT  "",/*OBSERVACIONES  �   REFERENCIA ADICIONAL POR REGISTRO */
  COD_CLIEN   CHAR(5) DEFAULT "",/* CLIENTE AL QUE LE PERTENECE LA ORDEN O EL DOCUMENTO */
  TCAMBIOCTA  DECIMAL(7,3) DEFAULT 0.000,     /*TIPO DE CAMBIO PARA LAS APLICACIONES DE ANTICIPO*/
  CLV_ENLACE  VARCHAR(24) DEFAULT "",
  PRIMARY KEY(TIPO_VOUCH,N_VOUCHER,REG_VOUCH),
 CONSTRAINT FK_VDE_VOU  FOREIGN KEY(TIPO_VOUCH,N_VOUCHER) REFERENCES VOU(TIPO_VOUCH,N_VOUCHER),
 CONSTRAINT FK_VDE_CLI  FOREIGN KEY(COD_CLIEN) REFERENCES CLI(CODIGO),
 CONSTRAINT FK_VDE_APE  FOREIGN KEY(N_ORDEN) REFERENCES APE(N_ORDEN),
 CONSTRAINT FK_VDE_DOC  FOREIGN KEY(DOC,N_DOC) REFERENCES DOC(DOC,N_DOC));
CREATE INDEX VDE ON VDE(TIPO_VOUCH,N_VOUCHER,REG_VOUCH);
CREATE INDEX VDE_CLV_ENLACE ON VDE(CLV_ENLACE);


/*==============================================================================================================*/
/*  ARCHIVOS DE FINANCIAMIENTOS DE DOCUMENTOS                                                                   */
/*==============================================================================================================*/

/*AVA (ARCHIVO DE FINANCIAMIENTO */
CREATE TABLE IF NOT EXISTS AVA(
  CODIGO      CHAR(4) NOT NULL,
  NOMBRE      VARCHAR(70) DEFAULT "",
  DIRECCION   VARCHAR(50) DEFAULT "",
  DISTRITO    VARCHAR(20) DEFAULT "", 
  RUC         CHAR(11) DEFAULT "",
  TELEFONO    CHAR(8) DEFAULT "",
  AVAL_PERMA  CHAR(1) DEFAULT "",
  COD_CLIEN   CHAR(5) NOT NULL,
  PRIMARY KEY(COD_CLIEN,CODIGO),
 CONSTRAINT FK_AVA_CLI FOREIGN KEY(COD_CLIEN) REFERENCES CLI(CODIGO),
 CONSTRAINT UQ_AVA_1 UNIQUE(NOMBRE));
CREATE INDEX AVA ON AVA(CODIGO);
INSERT INTO AVA VALUES("","Z","","","","","","");

/*FIN (ARCHIVO DE FINANCIAMIENTO */
CREATE TABLE IF NOT EXISTS FIN(
  NUM_FINAN    CHAR(8) NOT NULL,           /* Correlativo Interno que identifica el Financiamiento*/
  FECHOPE      DATE,                       /*Fecha de creacion del Financiamiento*/
  FECHGIRO     DATE,                       /*Fecha en que se realiza el Financiamiento*/
  COD_CLIEN    CHAR(5) DEFAULT "",         /*Codigo del cliente al que se le va hacer el financiamiento*/
  MONEDA       CHAR(1) DEFAULT "D",        /*Moneda en que se realiza el Financiamiento*/
  T_CAMBIO     DECIMAL(6,3) DEFAULT 0.000, /*Tipo de Cambio de la Fecha de Giro*/
  COD_AVAL     CHAR(4) DEFAULT "",         /*Codigo de Aval*/
  TIPO_TASA    CHAR(2) DEFAULT "22",       /*Tipo de Tasa a Financiar*/
  DPORTE       DECIMAL(6,2) DEFAULT 0.00,  /*Portes Bancarios en Dolares*/
  SPORTE       DECIMAL(6,2) DEFAULT 0.00,  /*Portes Bancarios en Soles*/
  TASA	       DECIMAL(7,3) DEFAULT 0.00,  /*Tasa de Interes aplicado*/
  N_DIAS       NUMERIC(4,0) DEFAULT 30,    /*Numero de Dias a Finaciar*/
  N_LET        NUMERIC(4,0) DEFAULT 1,     /*Cantidad de Letras a Generar*/
  DMONTO_FIN   DECIMAL(12,2) DEFAULT 0.00, /*Monto a Finaciar (Dolares)*/
  SMONTO_FIN   DECIMAL(12,2) DEFAULT 0.00, /*Monto a Financia (Soles)*/
  DINTERES     DECIMAL(12,2) DEFAULT 0.00, /*Interes Generado por el Financiamiento (Dolares)*/
  SINTERES     DECIMAL(12,2) DEFAULT 0.00, /*Interes Generado por el Financiamiento (Soles)*/
  TDPORTE      DECIMAL(12,2) DEFAULT 0.00, /*Total Portes bancarios en Dolares*/
  TSPORTE      DECIMAL(12,2) DEFAULT 0.00, /*Total Portes bancarios en Soles*/
  DIGV         DECIMAL(12,2) DEFAULT 0.00, /*I.G.V. Calculado por el Interes (Dolares)*/
  SIGV         DECIMAL(12,2) DEFAULT 0.00, /*I.G.V. Calculado por el Interes (Soles)*/
  DTOTAL_FIN   DECIMAL(12,2) DEFAULT 0.00, /*Monto del Financiamiento + Interes (Dolares)*/
  STOTAL_FIN   DECIMAL(12,2) DEFAULT 0.00, /*Monto del Financiamiento + Interes (Soles)*/
  PIGV         CHAR(1) DEFAULT "S",        /*Flag que determina si paga IGV*/
  PAGAINT      CHAR(1) DEFAULT "S",        /*Flag que determina si se va a calcular los Intereses*/
  N_DEBITO     CHAR(10) DEFAULT "",	   /*Numero de Nota de Debito ligada a al Financiamiento*/
  COD_USER     CHAR(3) DEFAULT "",         /*Codigo de Usuario */
  ANULADA      CHAR(1) DEFAULT "",         /*Indicador que el Finaciamiento esta Anulado*/
  PRIMARY KEY(NUM_FINAN),
 CONSTRAINT FK_FIN_CLI FOREIGN KEY(COD_CLIEN) REFERENCES CLI(CODIGO),
 CONSTRAINT FK_FIN_USU FOREIGN KEY(COD_USER) REFERENCES USU(CODIGO),
 CONSTRAINT FK_FIN_TS258 FOREIGN KEY(MONEDA) REFERENCES softpad_sistema.TS258(CODIGO),
 CONSTRAINT FK_FIN_TS77 FOREIGN KEY(TIPO_TASA) REFERENCES softpad_sistema.TS77(CODIGO));
CREATE INDEX FIN ON FIN(NUM_FINAN);

/*DFI (DOCUMENTOS A FINANCIAR */
CREATE TABLE IF NOT EXISTS DFI(				
  NUM_FINAN    CHAR(8) NOT NULL,           /* Numero de Financiamiento a que hace referencia*/
  CORREL       CHAR(2) NOT NULL,           /* Numero de correlativo de los documentos a Financiar */ 
  DOC          CHAR(2) DEFAULT "",         /* Tipo de Documento a Financiar*/
  N_DOC	       CHAR(10) DEFAULT "",        /* Numero de documentoa financiar*/
  N_PROF       CHAR(8) DEFAULT "",         /* Numero de Proforma a Financiar*/ 
  REFER        CHAR(25) DEFAULT "",        /* Numero de Orden asociado al documento a financiar*/
  DTOT_DOCU    DECIMAL(14,2) DEFAULT 0.00, /* Importe en dolares del documento a financiar*/
  STOT_DOCU    DECIMAL(14,2) DEFAULT 0.00, /* Importe en Soles del documento a Financiar*/
  TIPO_PROF    CHAR(1) DEFAULT "",         /* Tipo de proforma a financiar  */
  PRIMARY KEY(NUM_FINAN,CORREL),
 CONSTRAINT FK_DFI_FIN FOREIGN KEY(NUM_FINAN) REFERENCES FIN(NUM_FINAN),
 CONSTRAINT FK_DFI_TS31 FOREIGN KEY(DOC) REFERENCES softpad_sistema.TS31(COD),
 CONSTRAINT FK_DFI_PRO FOREIGN KEY(N_PROF) REFERENCES PRO(N_PROF),
 CONSTRAINT FK_DFI_DOC FOREIGN KEY(DOC,N_DOC) REFERENCES DOC(DOC,N_DOC));
CREATE INDEX DFI ON DFI(NUM_FINAN);

/*LET (LETRAS */
CREATE TABLE IF NOT EXISTS LET(				
  NUM_LETRA    CHAR(9) NOT NULL,                  /* NUMERO DE LA LETRA + NUMERO DE RENOVACION*/
  NUM_FINAN    CHAR(8) NOT NULL,                  /* Numero de Financiamiento a que hace referencia*/
  CORRE_LET    NUMERIC(3,0) NOT NULL,	          /* CORRELATIVO DE LAS LETRAS POR FINANCIAMIENTO*/
  FACTOR_INT   DECIMAL(12,10) DEFAULT 0.00000000, /* FACTOR DE INTERES APLICADO A LA LETRA*/
  N_DIAS       NUMERIC(4,0) DEFAULT 0,            /* NUMERO DE DIAS EN QUE SE PAGARA LA LETRA*/
  T_CAMBIO     DECIMAL(6,3) DEFAULT 0.000,	  /* TIPO DE CAMBIO DEL ABONO DE LAS LETRAS */
  DIMPORTE     DECIMAL(12,2) DEFAULT 0.00,        /*IMPORTE DE LA LETRA SIN LOS INTERESES (DOLARES)*/
  SIMPORTE     DECIMAL(12,2) DEFAULT 0.00,        /*IMPORTE DE LA LETRA SIN LOS INTERESES (SOLES)*/
  DINTERES     DECIMAL(12,2) DEFAULT 0.00,        /*INTERES DE LA LETRA EN DOLARES*/
  SINTERES     DECIMAL(12,2) DEFAULT 0.00,        /*INTERES DE LA LETRA EN SOLES*/
  DIGV         DECIMAL(12,2) DEFAULT 0.00,        /*IGV DEL INTERES DE LA LETRA (DOLARES)*/
  SIGV         DECIMAL(12,2) DEFAULT 0.00,        /*IGV DEL INTERES DE LA LETRA (SOLES)*/
  SPORTE       DECIMAL(12,2) DEFAULT 0.00,        /*PORTES BANCARIOS EN SOLES*/
  DPORTE       DECIMAL(12,2) DEFAULT 0.00,        /*PORTES BANCARIOS EN DOLARES*/
  DTOTLET      DECIMAL(12,2) DEFAULT 0.00,        /*MONTO TOTAL DE LA LETRA INCLUIDO INTERESES (DOLARES)*/
  STOTLET      DECIMAL(12,2) DEFAULT 0.00,        /*MONTO TOTAL DE LA LETRA INCLUIDO INTERESES (SOLES)*/
  FECH_VENC    DATE,                              /*FECHA DE VENCIMIENTO DE LA LETRA*/
  PORCRENOV    NUMERIC(2,0) DEFAULT 0,            /*PORCENTA A RENOVAR DE LA LETRA ORIGEN*/
  BANCO        CHAR(2) DEFAULT "",                /*CODIGO DEL BANCO EN EL QUE SE ABONO LAS LETRAS*/
  N_CUENTA     VARCHAR(25) DEFAULT "",            /*NUMERO DE LA CTA CTE DONDE SE HARA EL ABONO DE LA LETRA*/
  NUMLETBANC   VARCHAR(26) DEFAULT "",            /*NUMERO DE LA LETRA INTERNA DEL BANCO*/
  INT_BANC     DECIMAL(12,2) DEFAULT 0.00,        /*IMPORTE DEL INTERES APLICADO POR EL BANCO*/
  POR_BANC     DECIMAL(12,2) DEFAULT 0.00,        /*PORTES BANCARIOS DEL BANCO*/
  COM_BANC     DECIMAL(12,2) DEFAULT 0.00,        /*COMISIONES DEL BANCO*/
  ENLA_CONTA   VARCHAR(17) DEFAULT "",            /*IDENTIFICACION DEL ASIENTO DE VENTAS*/				
  PRIMARY KEY(NUM_LETRA),
 CONSTRAINT UQ_LET_1 UNIQUE(NUM_FINAN,CORRE_LET),
 CONSTRAINT FK_LET_FIN  FOREIGN KEY(NUM_FINAN) REFERENCES FIN(NUM_FINAN),
 CONSTRAINT FK_LET_CTA  FOREIGN KEY(N_CUENTA) REFERENCES CTA(NUMERO_CTA));
CREATE INDEX LET ON LET(NUM_LETRA);

/*LDE (ARCHIVO DE DETALLE DE APLICACION DE LETRAS */
CREATE TABLE IF NOT EXISTS LDE(
  NUM_LETRA   CHAR(9) NOT NULL,           /*NUMERO DE LA LETRA + NUMERO DE RENOVACION*/
  CORREL      NUMERIC(3,0) DEFAULT 0,     /*CORRELATIVO DEL VOUCHER INTERNO */ 
  DIMPORTE    DECIMAL(12,2) DEFAULT 0.00, /*IMPORTE EN SOLES PARA LAS SALIDAS (DEBE ESTAR LLENO CON LOS IMPORTES ORIGINALES O SU CONVERSION  */ 
  SIMPORTE    DECIMAL(12,2) DEFAULT 0.00, /*IMPORTE EN DOLARES PARA LAS SALIDAS (DEBE ESTAR LLENO CON LOS IMPORTES ORIGINALES O SU CONVERSION */
  N_ORDEN     CHAR(11)  DEFAULT  "",      /*NRO. DE LA ORDEN */
  DOC	      CHAR(2) DEFAULT  "",        /*TIPO DE DOCUMENTO (01=FACTURA /  03= BOLETA  / 07= NOTA DE CREDITO /  08=NOTA DE DEBITO) */	
  N_DOC	      CHAR(10) DEFAULT "",        /*NRO DE DOCUMENTO, SI BIEN ES CIERTO A NIVEL NACIONAL ES 10 CARACTERES, A NIVEL CONTABLE SUELE SER MAS */ 
  FECHA_DOC   DATE,                       /*FECHA DE DOCUMENTO */
  REFER_DATO  VARCHAR(30) DEFAULT  "",    /*OBSERVACIONES  �   REFERENCIA ADICIONAL POR REGISTRO */
  COD_CLIEN   CHAR(5) DEFAULT "",         /* CLIENTE AL QUE LE PERTENECE LA ORDEN O EL DOCUMENTO VALIDA PARA LA CUENTA CORRIENTE */
  TCAMBIOCTA  DECIMAL(7,3) DEFAULT 0.000, /*TIPO DE CAMBIO PARA LAS APLICACIONES DE ANTICIPO X DOCUMENTO*/
  PRIMARY KEY(NUM_LETRA,CORREL),
 CONSTRAINT FK_LDE_LET  FOREIGN KEY(NUM_LETRA) REFERENCES LET(NUM_LETRA),
 CONSTRAINT FK_LDE_CLI  FOREIGN KEY(COD_CLIEN) REFERENCES CLI(CODIGO),
 CONSTRAINT FK_LDE_APE  FOREIGN KEY(N_ORDEN) REFERENCES APE(N_ORDEN),
 CONSTRAINT FK_LDE_DOC  FOREIGN KEY(DOC,N_DOC) REFERENCES DOC(DOC,N_DOC));
CREATE INDEX LDE ON LDE(NUM_LETRA,CORREL);

/*LPT (ARCHIVO DE DETALLE DE PROTESTO DE LETRAS */
CREATE TABLE IF NOT EXISTS LPT(
  NUM_LETRA   CHAR(9) NOT NULL,           /*NUMERO DE LA LETRA + NUMERO DE RENOVACION*/
  SINT_BANC   DECIMAL(12,2) DEFAULT 0.00, /*INTERES DEL BANCO GENERADO POR EL PROTESTO  */ 
  DINT_BANC   DECIMAL(12,2) DEFAULT 0.00, /*INTERES DEL BANCO GENERADO POR EL PROTESTO  */ 
  SPOR_BANC   DECIMAL(12,2) DEFAULT 0.00, /*PORTES BANCARIOS EN SOLES*/ 
  DPOR_BANC   DECIMAL(12,2) DEFAULT 0.00, /*PORTES BANCARIOS EN DOLARES*/ 
  SINT_PROT   DECIMAL(12,2) DEFAULT 0.00, /*INTERES GENERADOS POR EL PROTESTO EN SOLES */ 
  DINT_PROT   DECIMAL(12,2) DEFAULT 0.00, /*INTERES GENERADOS POR EL PROTESTO EN DOLARES */ 
  SINT_AGEN   DECIMAL(12,2) DEFAULT 0.00, /*INTERES GENERADOS DE LA AGENCIA EN SOLES */ 
  DINT_AGEN   DECIMAL(12,2) DEFAULT 0.00, /*INTERES GENERADOS DE LA AGENCIA EN DOLARES */ 
  SOTR_GTOS   DECIMAL(12,2) DEFAULT 0.00, /*OTROS GASTOS EN SOLES */ 
  DOTR_GTOS   DECIMAL(12,2) DEFAULT 0.00, /*OTROS GASTOS EN DOLARES*/ 
  PRIMARY KEY(NUM_LETRA),
 CONSTRAINT FK_LPT_LET  FOREIGN KEY(NUM_LETRA) REFERENCES LET(NUM_LETRA));
CREATE INDEX LPT ON LPT(NUM_LETRA);

/*(INL) INCIDENCIAS DE LETRAS				*/
CREATE TABLE IF NOT EXISTS INL(				
  NUM_LETRA    CHAR(9) NOT NULL,        /* NUMERO DE LA LETRA + NUMERO DE RENOVACION*/
  FECHA_INC    DATETIME,              	/* FECHA DE LA INCIDENCIA*/
  ESTADO       CHAR(2) DEFAULT "",      /* ESTADO DE LA INCIDENCIA*/
  INCIDENCIA   VARCHAR(55) DEFAULT "",  /* DETALLE DE LA INCIDENCIA*/
  COD_USER     CHAR(3) DEFAULT "",      /* CODIGO DE USUARIO QUE REALIZO LA LETRA*/
  AUTOMATICO   CHAR(1) DEFAULT "",      /* AUTOMATICOC  */
  FECHA_OCURR  DATE,                    /* Fecha de la ocurrecia de la Incidencia*/
  PRIMARY KEY(NUM_LETRA,FECHA_INC),
 CONSTRAINT FK_INL_LET  FOREIGN KEY(NUM_LETRA) REFERENCES LET(NUM_LETRA),
 CONSTRAINT FK_INL_USU  FOREIGN KEY(COD_USER) REFERENCES USU(CODIGO),
 CONSTRAINT FK_INL_TS71 FOREIGN KEY(ESTADO) REFERENCES softpad_sistema.TS71(CODIGO));
CREATE INDEX INL ON INL(NUM_LETRA,FECHA_INC);

/*=============================================================================================*/
/*                           SOLICITUD DE CHEQUES                                              */
/*=============================================================================================*/

/* SCH (TABLA DE SOLICITUD DE CHEQUES)*/
CREATE TABLE IF NOT EXISTS SCH (
  NUM_SOL     CHAR(8) NOT NULL,           /*Numero de solicitud*/
  FECHOPE     DATETIME,                   /*Fecha y hora de Creacion de solicitud*/
  N_ORDEN     CHAR(11) DEFAULT '',        /*No. de Orden del Despacho*/
  COD_USER    CHAR(3) DEFAULT '',         /*Codigo del Usuario o liquidador que realizo la solicitud*/
  FCH_IMPRE   DATETIME,                   /*Fecha y hora de Impresion*/
  TIPO_GASTO  CHAR(1) DEFAULT '1',        /*Tipo de Gasto a Realizar (1-DESPACHO, 2-SERVICIOS)*/
  TIPO_SOLIC  CHAR(1) DEFAULT '1',        /*Tipo de Solicitud (Normal, Urgente)*/
  DESPACHA    CHAR(2) DEFAULT '',         /*Codigo de usuario a quien se le entrego el Cheque (tabla DSP)*/
  CODGASTO    CHAR(3) DEFAULT '',         /*Concepto de la Solicitud de Cheques*/
  COD_PROV    CHAR(11) DEFAULT '',        /*Codigo de la persona a que va dirigido la Solicitud*/
  MONEDA      CHAR(1) DEFAULT 'D',         /*Moneda [S]oles o [D]olares*/
  DMONTO_EST  DECIMAL(12,2) DEFAULT 0.00, /*Monto estimado del Cheque en Dolares*/
  SMONTO_EST  DECIMAL(12,2) DEFAULT 0.00, /*Monto estimado del Cheque en Soles*/
  DMONTO_DEF  DECIMAL(12,2) DEFAULT 0.00, /*Monto Definitivo del Cheque en Dolares*/
  SMONTO_DEF  DECIMAL(12,2) DEFAULT 0.00, /*Monto Definitivo del Cheque en Soles*/
  T_CAMBIO    DECIMAL(7,3) DEFAULT 0.00,  /*Tipo de Cambio*/
  OBSERVACIO  VARCHAR(90) DEFAULT '',     /*Observaciones adicionales*/
  OBSERVAC1   VARCHAR(90) DEFAULT '',     /*Observaciones adicionales*/
  OBSERVAC2   VARCHAR(90) DEFAULT '',     /*Observaciones adicionales*/
  EMAIL_DEST  VARCHAR(250) DEFAULT '',    /*Correo electronico de la persona que va a Autorizar la Solicitud*/
  ANULADA     CHAR(1) DEFAULT '',         /*Flag que indica si una Solicitud de Cheques esta Anulada*/
  CTA_CONTA   VARCHAR(16) DEFAULT '',     /*Fecha de emision y datos del Diario y Asiento Contable*/
  PRIMARY KEY (NUM_SOL),
 CONSTRAINT FK_SCH_APE  FOREIGN KEY(N_ORDEN) REFERENCES APE(N_ORDEN),
 CONSTRAINT FK_SCH_USU  FOREIGN KEY(COD_USER) REFERENCES USU(CODIGO),
 CONSTRAINT FK_SCH_DSP FOREIGN KEY(DESPACHA) REFERENCES DSP(CODIGO),
 CONSTRAINT FK_SCH_TGF FOREIGN KEY(CODGASTO) REFERENCES TGF(CODIGO),
 CONSTRAINT FK_SCH_TS10 FOREIGN KEY(TIPO_GASTO) REFERENCES softpad_sistema.TS10(CODIGO),
 CONSTRAINT FK_SCH_TS11 FOREIGN KEY(TIPO_SOLIC) REFERENCES softpad_sistema.TS11(CODIGO),
 CONSTRAINT FK_SCH_TS258 FOREIGN KEY(MONEDA) REFERENCES softpad_sistema.TS258(CODIGO));
CREATE INDEX SCH ON SCH(NUM_SOL);

/*===================================================================================================================*/
/*                                  OTROS ARCHIVOS                                                                   */
/*===================================================================================================================*/
    
/*GIA(TABLA DE TRANSFERENCIA DE GUIAS AEREAS PARA COURIES */
CREATE TABLE IF NOT EXISTS GIA(
   CODI_ADUAN  CHAR(3) NOT NULL, /* ESTRUCTURA DEL DUIMGUIA.TXT DONDE LLEGAN LAS GUIAS*/
   ANO_ORDEN   CHAR(4) NOT NULL, /*C  4 0 POR DESPACHOS MENORES O SIMPLIFICADOS .*/
   NUME_ORDEN  CHAR(6) NOT NULL,
   CODI_REGI   CHAR(2) NOT NULL,  
   VIA_TRANS   CHAR(1) DEFAULT "",
   NUMCON      VARCHAR(25) DEFAULT "",  
   NUMDET      NUMERIC(5,0) DEFAULT 0,
   PUER_EMBAR  CHAR(5) DEFAULT "",
   PUER_DESCA  CHAR(5) DEFAULT "",
   PUER_DESTI  CHAR(5) DEFAULT "",
   CANT_BULTO  DECIMAL(15,3) DEFAULT 0.00,  
   CANT_BRECI  DECIMAL(15,3) DEFAULT 0.00,
   CANT_BBUEN  DECIMAL(15,3) DEFAULT 0.00, 
   CANT_BMALE  DECIMAL(15,3) DEFAULT 0.00,
   TPESO_BRUT  DECIMAL(15,3) DEFAULT 0.00,
   TPESO_RECI  DECIMAL(15,3) DEFAULT 0.00,
   TPESO_BUEN  DECIMAL(15,3) DEFAULT 0.00,
   TPESO_MALE  DECIMAL(15,3) DEFAULT 0.00,
   EMBARCA     VARCHAR(50) DEFAULT "",
   CONSIGNA    VARCHAR(60) DEFAULT "",
   DIRECCION   VARCHAR(60) DEFAULT "",
   DESCRIP     VARCHAR(70) DEFAULT "",
   FOB_CONO    DECIMAL(12,2) DEFAULT 0.00,
   PART_NANDI  NUMERIC(10,0) DEFAULT 0,
   OBS1        VARCHAR(70) DEFAULT "",
   OBS2        VARCHAR(70) DEFAULT "",
   NUMCONM     VARCHAR(25) DEFAULT "",
   CANT_EMPA   NUMERIC(10,0) DEFAULT 0,
   CANT_REMPA  NUMERIC(10,0) DEFAULT 0,
   TPESO_TARA  DECIMAL(15,3) DEFAULT 0.00,
   MARNUM      VARCHAR(25) DEFAULT "",
   COD_EMBAR   CHAR(4) DEFAULT "",
   TIPO_CONDI  CHAR(3) DEFAULT "",
   T_CARGA     CHAR(1) DEFAULT "",
   COD_UBI1    CHAR(6) DEFAULT "",
   COD_UBI2    CHAR(6) DEFAULT "",
   COD_UBI3    CHAR(6) DEFAULT "",
   REGI_ADICI  NUMERIC(2,0) DEFAULT 0,
   NRODOCIN    CHAR(6) DEFAULT "",
   FECDOCIN    NUMERIC(8,0) DEFAULT 0,
   ANOACTMEST  CHAR(4) DEFAULT "",
   NUMACTMEST  CHAR(8) DEFAULT "",
   PTOACTINMO  CHAR(4) DEFAULT '',
   ANOACTINMO  CHAR(4) DEFAULT '',
   NUMACTINMO  CHAR(6) DEFAULT '',
   RUCCONSIG   CHAR(11) DEFAULT '',
   RUCCONSOL   CHAR(11) DEFAULT '',
   RUCEXPORT   CHAR(11) DEFAULT '',
   CANT_ITEM   DECIMAL(3) DEFAULT 0, 	
   COD_TCARGA  CHAR(2) DEFAULT '',
   COD_TEMB    CHAR(2) DEFAULT '', 
   DTIP_ENVIO  CHAR(1) DEFAULT '',
   COD_CATEG   CHAR(4) DEFAULT '',
   NUMCON2     CHAR(25) DEFAULT '',
   ANNO        CHAR(4) DEFAULT '',
   NUME_MC     CHAR(5) DEFAULT '',
   EMPR_TRANS  CHAR(4) DEFAULT '',
   MCCODI_TER  CHAR(4) DEFAULT '',
   ELEGIDO     NUMERIC(1,0) DEFAULT 0,
   PRIMARY KEY(ANO_ORDEN,NUME_ORDEN,NUMDET,NUMCON));
   CREATE INDEX GIA ON GIA(ANO_ORDEN,NUME_ORDEN,NUMDET,NUMCON);

/* GIC (CONSOLIDADO DE GUIAS COURIER TXT - PARA TNT)*/
CREATE TABLE IF NOT EXISTS GIC(
   ANIO_MANI  CHAR(4)  not null,        /*ESTRUCTURA DEL DUIMGUIA.TXT DONDE LLEGAN LAS GUIAS*/
   NUME_MANI  CHAR(8)  not null,        /*POR DESPACHOS MENORES O SIMPLIFICADOS*/
   NUME_GUIA  CHAR(12) not null,	/*NRO. DE GUIA*/	
   ANIO_VOLAN CHAR(4),			/*A�O DEL VOLANTE*/
   NUME_VOLAN CHAR(8),			/*NRO. DEL VOLANTE*/
   ADUA_MANIF CHAR(3),			/*ADUANA DEL MANIFIESTO*/
   ANIO_MANIF CHAR(4),			/*A�O DEL MANIFIESTO*/
   NUME_MANIF CHAR(6),			/*NRO. DE MANIFIESTO*/
   FECH_LLEGA DATE,			/*FECHA DE LLEGADA*/
   CONTENIDO  VARCHAR(100) default '',	/*CONTENIDO*/ 
   CONSIGNAT  VARCHAR(100) default '',	/*CONSIGNATARIO O CLIENTE*/
   N_BULTOS   NUMERIC(3,0),		/*NRO. DE BULTOS*/
   PESO_RECIB NUMERIC(8,3),		/*PESO RECIBIDO*/
   NUME_VUELO VARCHAR(32) default '',	/*NRO. DE VUELO*/
   COD_LINEA  CHAR(2),			/*CODIGO DE LINEA*/
   PAIS_ORIG  CHAR(2),			/*PAIS DE ORIGEN*/
   PAIS_DESTI CHAR(2),			/*PAIS DE DESTINO*/	
   COD_ALMAC  CHAR(4),			/*CODIGO DE ALMACEN*/
   N_ORDEN    CHAR(11),			/*NRO. DE ORDEN*/
   ELEGIDO    NUMERIC(1,0),		/*CAMPO PARA MARCAR DESPACHOS A GENERAR*/
   PRIMARY KEY(ANIO_MANI,NUME_MANI,NUME_GUIA));   
   CREATE INDEX GIC ON GIC(ANIO_MANI,NUME_MANI,NUME_GUIA);


/* CAJ (INVENTARIO DE CAJA ARCHIVISTICA) */
CREATE TABLE IF NOT EXISTS CAJ(
   NUME_CAJA   	CHAR(6)  NOT NULL,	 /*C  6  0*/
   OBSERVACIO   CHAR(50) DEFAULT "",     /*C 50  0*/
   FECHA_CAJA 	DATETIME,       	 /*D  8  0*/
   NUME_REGIS	NUMERIC(4,0) DEFAULT 0,	 /*N  4  0*/
   PRIMARY KEY(NUME_CAJA),
   CONSTRAINT UQ_CAJ_1 UNIQUE(NUME_CAJA));
   CREATE INDEX CAJ ON CAJ(NUME_CAJA);

/* CJD (DETALLE DE INVENTARIO DE CAJA ARCHIVISTICA) */
CREATE TABLE IF NOT EXISTS CJD(
   NUME_CAJA   	CHAR(6)  NOT NULL,	 /*C  6  0*/
   OBSERVACIO   CHAR(50) DEFAULT "",     /*C 50  0*/
   FOLIO     	CHAR(15) DEFAULT '',	 /*C 15  0*/
   N_ORDEN   	CHAR(11) NOT NULL,	 /*C  9  0*/
   NDOC_ASOC    CHAR(25) DEFAULT "",	 /*C 25  0*/
   NUME_FACTU   CHAR(40) DEFAULT "",     /*C 40  0*/
   NUMBLGUIA    CHAR(25) DEFAULT "",     /*C 25  0*/
   FECHA_ARCH 	DATETIME,       	 /*D  8  0*/
   PRIMARY KEY(NUME_CAJA,N_ORDEN),
   CONSTRAINT UQ_CJD_1 UNIQUE(N_ORDEN),
   CONSTRAINT FK_CJD_APE FOREIGN KEY(N_ORDEN) REFERENCES APE(N_ORDEN));
   CREATE INDEX CJD ON CJD(NUME_CAJA);

/*========================================================================*/
/*   ARCHIVOS PARA REPORTEADOR                                            */
/*========================================================================*/

/* RT2( TABLAS DE REPORTEADOR - CAMPOS DE CADA REPORTE )*/                    
CREATE TABLE IF NOT EXISTS RT2(                                               
   NOMBRE_REP  VARCHAR(15) NOT NULL,                                            
   CAMPO       CHAR(6) NOT NULL,                                                
   ORDEN       NUMERIC(3,0) DEFAULT 0,                                          
   PRIMARY KEY(NOMBRE_REP,CAMPO));                                              
CREATE INDEX RT2_1 ON RT2(NOMBRE_REP,CAMPO);                                
CREATE INDEX RT2_2 ON RT2(NOMBRE_REP,ORDEN);                              
                                                                                
/* RT3( TABLAS DE REPORTEADOR - GRUPOS DE CADA REPORTE )*/                    
CREATE TABLE IF NOT EXISTS RT3(                                               
   NOMBRE_REP  VARCHAR(15) NOT NULL,                                            
   CAMPO       VARCHAR(20) DEFAULT "",                                          
   DESCRIP     VARCHAR(30) DEFAULT "",                                          
   GRUPOEXCEL  VARCHAR(30) DEFAULT "",                                          
   PRIMARY KEY(NOMBRE_REP));                                                    
CREATE INDEX RT3_1 ON RT3(NOMBRE_REP);                                      
CREATE INDEX RT3_2 ON RT3(NOMBRE_REP,CAMPO);                                
              
                                                                                
/* RT1( TABLAS DE REPORTEADOR -RELACI�N DE REPORTES )*/                       
CREATE TABLE IF NOT EXISTS RT1(                                               
   NOMBRE_REP  VARCHAR(15) NOT NULL,                                            
   USUARIO     CHAR(35) NULL,
   FECH_CREAC  DATETIME NOT NULL,
   FECH_MODIF  DATETIME NOT NULL, 
   DER_SERIES  NUMERIC(1,0) DEFAULT 0,                                          
   PRIMARY KEY(NOMBRE_REP));                                                    
CREATE INDEX RT1 ON RT1(NOMBRE_REP);                                      

/*===============================================================================*/
/*   ARCHIVOS SOLO PARA ALERTAS DE VENCIMIENTOS DE TRANSBORDO PARA LAN CARGO     */
/*===============================================================================*/


/* VTR( TABLAS DE CONTROL DE ALERTAS PARA VENCIMIENTO DE TRANSBORDO )*/      
CREATE TABLE IF NOT EXISTS VTR(                                              
   NOMBREPC    VARCHAR(30) NOT NULL,                                            
   FECHA_PROC  CHAR(8) NOT NULL,                                                
   TIPO_HORA   CHAR(10) NOT NULL,                                               
   CODIGO_AGT  CHAR(4) NOT NULL,                                                
   HORA_REGI   CHAR(8) DEFAULT "",                                              
   HORA        CHAR(5) NOT NULL,                                                
   PRIMARY KEY(NOMBREPC,FECHA_PROC,TIPO_HORA,CODIGO_AGT));                      
CREATE INDEX VTR ON VTR(NOMBREPC,FECHA_PROC,TIPO_HORA,CODIGO_AGT);      


/*========================================================================*/
/*   ARCHIVOS SOLO PARA LAS AMERICAS                                       */
/*========================================================================*/

CREATE TABLE ctd (
  PEDIDO varchar(25) NOT NULL,
  NUMBLGUIA varchar(25) NOT NULL,
  NRO_FACTU varchar(40) NOT NULL,
  FECH_FACT char(8) DEFAULT '',
  MODELO char(3) DEFAULT '',
  VERSION varchar(20) DEFAULT '',
  CARROCERIA char(3) DEFAULT '',
  COD_PRODUC varchar(20) DEFAULT '',
  COD_VIN varchar(18) NOT NULL DEFAULT '',
  MOTOR varchar(20) NOT NULL DEFAULT '',
  COD_COLOR varchar(12) DEFAULT '',
  MAT_COLOR varchar(50) DEFAULT '',
  ANIO_MODEL char(4) DEFAULT '',
  ANIO_FABRI char(4) DEFAULT '',
  FOB_DOL decimal(13,3) DEFAULT '0.000',
  FLETE_DOL decimal(13,3) DEFAULT '0.000',
  CFR_DOL decimal(13,3) DEFAULT '0.000',
  SEGURO_DOL decimal(13,3) DEFAULT '0.000',
  CATEGORIA char(4) DEFAULT '',
  PARTIDA varchar(15) DEFAULT '',
  ANCHO decimal(5,0) DEFAULT '0',
  LARGO decimal(5,0) DEFAULT '0',
  AREA_M2 varchar(10) DEFAULT '',
  ALTURA decimal(5,0) DEFAULT '0',
  VOLUMEN_M3 varchar(10) DEFAULT '',
  KBR_VEHI decimal(6,0) DEFAULT '0',
  KNE_VEHI decimal(6,0) DEFAULT '0',
  CARGA_UTIL decimal(6,0) DEFAULT '0',
  CILINDRADA decimal(6,0) DEFAULT '0',
  CANT_EJES decimal(6,0) DEFAULT '0',
  DISTA_EJES decimal(6,0) DEFAULT '0',
  FORMUL_ROD varchar(27) DEFAULT '',
  MED_NEUDEL varchar(20) DEFAULT '',
  MED_NEUTRA varchar(20) DEFAULT '',
  ANCHO_AROD char(5) DEFAULT '',
  ANCHO_AROP char(5) DEFAULT '',
  DIAM_ARODE char(5) DEFAULT '',
  DIAM_AROPO char(5) DEFAULT '',
  NUM_CILIND decimal(2,0) DEFAULT '0',
  NUME_ASIEN decimal(2,0) DEFAULT '0',
  NUME_PASAJ decimal(2,0) DEFAULT '0',
  NUME_RUEDA decimal(2,0) DEFAULT '0',
  PMOTOR_HP varchar(20) DEFAULT '',
  PMOTOR_KW varchar(20) DEFAULT '',
  REL_PMOTOR decimal(6,2) DEFAULT '0.00',
  T_COMBUSTI char(3) DEFAULT '',
  T_TRANSMIS char(4) DEFAULT '',
  SUSP_DELAN varchar(60) DEFAULT '',
  SUSP_POSTE varchar(60) DEFAULT '',
  PBRVEH_COM decimal(8,2) DEFAULT '0.00',
  PE_EJE_DEL decimal(6,0) DEFAULT '0',
  PE_EJE_PO1 decimal(6,0) DEFAULT '0',
  PE_EJE_PO2 decimal(6,0) DEFAULT '0',
  PE_EJE_PO3 decimal(6,0) DEFAULT '0',
  ACCESORIOS varchar(115) DEFAULT '',
  ESTAD_MERC char(2) DEFAULT '',
  MARCA char(3) DEFAULT '',
  COD_PROVEE varchar(10) DEFAULT '',
  COD_CLIEN char(5) DEFAULT '',
  COD_REPRES char(2) DEFAULT '',
  NATURALEZA char(2) DEFAULT '',
  INTERMEDIA char(1) DEFAULT '',
  FORM_ENVIO char(1) DEFAULT '',
  NRO_ENVIOS decimal(8,0) DEFAULT '0',
  TIPO_SEG char(1) DEFAULT '',
  NOMBRE_TXT varchar(35) NOT NULL DEFAULT '',
  N_ORDEN char(11) DEFAULT '',
  ELEGIDO decimal(1,0) DEFAULT '0',
  cif_dol decimal(13,3) DEFAULT '0.000',
  incoterm char(3) DEFAULT '',
  encendido char(3) DEFAULT '',
  cambios decimal(2,0) DEFAULT '0',
  n_puertas decimal(2,0) DEFAULT '0',
  PRIMARY KEY (`NOMBRE_TXT`,`PEDIDO`,`NUMBLGUIA`,`NRO_FACTU`,`COD_VIN`,`MOTOR`),
  KEY `CTD` (`NOMBRE_TXT`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE ctr (
  NOMBRE_TXT varchar(25) NOT NULL ,
  FECHA_TXT date,
  TIPOREGTXT char(2) DEFAULT '',
  FECHA_PROC date DEFAULT NULL,
  CANT_REGI decimal(5,0) DEFAULT '0',
  REGI_PROC decimal(5,0) DEFAULT '0',
  REGI_PEND decimal(5,0) DEFAULT '0',
  PRIMARY KEY (`NOMBRE_TXT`),
  KEY `CTR` (`NOMBRE_TXT`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


/*load data local infile "ta57.txt" into table PRA lines terminated by "\r\n";*/

/*CABE_TRACAC (CABECERA DEL ARCHIVO TRANSFERENCIA TRACAC)*/
create table if not exists CABE_TRACAC(
   NRO_TRAMITE  char(11) not null,
   C_ADUANA     char(3) default "",
   COD_ENVIO    char(2) default "",
   TIPO_DOCUM   char(1) default "",
   DOCUMENTO    char(11) default "",
   NOMBRE       varchar(90) default "",
   C_ADUAN_S    char(2) default "",
   V_TRANSP     char(1) default "",
   CONT1        varchar(75) default "",
   T_BULTOS     decimal(15,3) default 0.000,
   TOTUFIS      decimal(15,3) default 0.000,
   KNE          decimal(14,3) default 0.000,
   KBR          decimal(14,3) default 0.000,
   FOB          decimal(13,3) default 0.000,
   FOB_GASTOS   decimal(13,3) default 0.000,
   N_SERIE      decimal(4,0) not null,
   N_GUIA 	char(9) default "",
   primary key(NRO_TRAMITE));
   create index CAB_TRA on CABE_TRACAC(NRO_TRAMITE);

/*DETA_TRACAC (DETALLE DEL ARCHIVO TRANSFERENCIA TRACAC)*/
create table if not exists DETA_TRACAC(
   NRO_TRAMITE  char(11) not null,
   NROREG       decimal(4,0) not null,
   PARTIDA      char(10) default "",
   COD_P_PRO    char(2) default "",
   COD_PRODUC   char(4) default "",
   FOBSER       decimal(13,3) default 0.000,
   KNESER       decimal(14,3) default 0.000,
   KBRSER       decimal(14,3) default 0.000,
   NUMBULTOS    decimal(15,3) default 0.000,
   CLASEBULTO   char(3) default "",
   UFISICAS     decimal(15,3) default 0.000,
   NUM_FACT1    varchar(40) default "",
   DES1         varchar(90) default "",
   DES2         varchar(90) default "",
   DES3         varchar(90) default "",
   DES4         varchar(90) default "",
   DES5         varchar(90) default "",
   primary key(NRO_TRAMITE,NROREG),
   constraint FK_DET_TRA foreign key(NRO_TRAMITE) references CABE_TRACAC(NRO_TRAMITE));
   create index DET_TRA on DETA_TRACAC(NRO_TRAMITE,NROREG);


/**********************************************************************************/
/*****************           DESPACHOS EXTERNOS                    ****************/
/**********************************************************************************/

/*DGE (DATOS GENEREALES DE DESPACHOS EXTERNOS/EXPEDIENTES)      */
CREATE TABLE IF NOT EXISTS DGE(
   N_ORDEN    CHAR(11) NOT NULL,	         /**************       N� de Orden --- PRINCIPAL---*/
   REG_ASOC   CHAR(2) DEFAULT "",
   ADUA_ASOC  CHAR(3) DEFAULT "", 
   CONT1      VARCHAR(75)  DEFAULT '',	/*C 75  0  Descripci�n Gen�rica de la Mercader�a*/
   NUMBLGUIA  CHAR(25) DEFAULT '', 	           /*C 25  0*************N� de BL/Guia*/
   PRIMARY KEY(N_ORDEN),
   CONSTRAINT FK_DGE_APE FOREIGN KEY(N_ORDEN) REFERENCES APE(N_ORDEN));
   create index dge on dge(n_orden);
   insert into dge(n_orden) values("");

/* SEE (SERIES DE LOS DESPACHOS EXTERNOS/EXPEDIENTES)         */
CREATE TABLE IF NOT EXISTS SEE(
   N_ORDEN    	CHAR(11) NOT NULL,	           /*C  9  0*************N� de Orden de despacho --- DATOS PRINCIPALES*/
   CORREL    	CHAR(4) NOT NULL,       	   /*N  4  0*************N� Serie*/
   SERITEM   	NUMERIC(4,0) DEFAULT 0,	           /*N  5  0             Numero de serie de la declaraci�n precedente para (18,48)*/
   PARTIDA    	CHAR(10) DEFAULT '',     	   /*C 10  0*************Partida Nandina*/
   DES1      	VARCHAR(100) DEFAULT '', 	   /*C100  0*************Descripci�n comercial*/
   UNI_COMER  	DECIMAL(13,3) DEFAULT 0.000, 	   /*N 13  3*************Unidades comerciales*/
   CLAS_COMER 	CHAR(3) DEFAULT '', 	           /*C  3  0*************clase de unidades comerciales*/
   NUMBULTOS  	DECIMAL(14,3) DEFAULT 0.000, 	   /*N 14  3*************Numero de bultos*/
   CLASEBULTO 	CHAR(3) DEFAULT '', 	           /*C  3  0*************Clase de bultos*/
   UFISICAS   	DECIMAL(13,3) DEFAULT 0.000, 	   /*N 13  3*************unidades fisicas*/
   TIPOUFIS   	CHAR(12) DEFAULT '', 	           /*C 12  0*************tipo de unidad fisica*/
   CIFSER     	DECIMAL(13,3) DEFAULT 0.000, 	   /*N 13  3*************Cif en transacci�n*/
   CIFSDOL    	DECIMAL(13,3) DEFAULT 0.000, 	   /*N 13  3*************Cif en d�lares*/
   PRIMARY KEY(N_ORDEN,CORREL),
   CONSTRAINT FK_SEA_DGE FOREIGN KEY(N_ORDEN) REFERENCES DGE(N_ORDEN));
   create index see on see(n_orden,correl);

/*======================================================================*/

/* ORT (ORDENES DE TRABAJO DE TRANSAMERICAN)         */
CREATE TABLE IF NOT EXISTS ORT(
   NRO_OT       CHAR(8) NOT NULL,
   NRO_ORD_INT  VARCHAR(10) DEFAULT "",
   FLAG         CHAR(1) DEFAULT "",
   PRIMARY KEY(NRO_OT));
   create index ORT on ORT(NRO_OT);

/*======================================================================*/

/* PRP (PRODUCTOS DE PETROPERU)         */
CREATE TABLE IF NOT EXISTS PRP(
  CODIGO       CHAR(6) NOT NULL,
  DES1         VARCHAR(100) DEFAULT "",
  PARTIDA      CHAR(10) DEFAULT "", 
  PRECIO       DECIMAL(14,3) DEFAULT 0.00,
  DES2         VARCHAR(100) DEFAULT "",
  DES3         VARCHAR(100) DEFAULT "",
  DES4         VARCHAR(100) DEFAULT "",
  DES5         VARCHAR(100) DEFAULT "",
  INFORMAC1    VARCHAR(60) DEFAULT "",
  INFORMAC2    VARCHAR(60) DEFAULT "",
  INFORMAC3    VARCHAR(60) DEFAULT "",
  INFORMAC4    VARCHAR(60) DEFAULT "",
  INFORMAC5    VARCHAR(60) DEFAULT "",
 PRIMARY KEY(CODIGO));
create index PRP on PRP(CODIGO);

/*=============================================================*/
/* TABLA DE CONTACTOS DE DECLARANTES DE LA UIF
/*=============================================================*/

CREATE TABLE IF NOT EXISTS CTO(
  CODIGO	CHAR(4)NOT NULL, 	/* CODIGO DEL DECLARNTE */
  APELLIDO_P	VARCHAR(25) DEFAULT "",	/* APELLIDO PATERNO DEL DECLARANTE */			
  APELLIDO_M	VARCHAR(25) DEFAULT "",	/* APELLIDO MATERNO DEL DECLARANTE */			
  NOMBRES	VARCHAR(30) DEFAULT "",	/* NOMBRES DEL DECLARANTE */			
  TIPO_DECLA	CHAR(01) DEFAULT "",	/* DECLARANTE QUE ACTUA EN REPRESENTACION DE (1)Consigante/exportador  (2)Consignatario/Importador */
  COND_DECLA	CHAR(01) DEFAULT "",	/* CONDICION DE RESIDENCIA DEL DECLARANTE  (1)Residente o (2)No residente */
  TDOC_DECLA	CHAR(03) DEFAULT "",	/* TIPO DE DOCUMENTO DEL DECLARANTE. CONSIDERAR EL CODIGO DE ACUERDO A LA TABLA 01 */
  NDOC_DECLA	VARCHAR(20) DEFAULT "",	/*  NUMERO DE DOCUMENTO DEL DECLARANTE */
  PAIS_DECLA	CHAR(2) DEFAULT "",	/*  PAIS DE EMISION DEL DOCUMENTO DEL DECLRANTE, EN CASO SEA UN DOCUMENTO EMITIDO EN EL EXTRANJERO. USAR LA CODIFICACION PUBLICADA POR LA SBS  */
  NACI_DECLA	CHAR(2) DEFAULT "",	/*  NACIONALIDAD DEL DECLARANTE. USAR LA CODIFICACION PUBLICADA POR LA SBS  */
  OCUP_DECLA	CHAR(3) DEFAULT "",	/*  OCUPACION DEL DECLARANTE. CONSIGNAR LOS CODIGOS DE ACUERDO A LA TABLA 02  */
  DIR_DECLA	VARCHAR(90) DEFAULT "",	/*  NOMBRE Y NUMERO DE LA VIA DE LA DIRECCION DEL DECLARANTE  */
  UBI_DECLA	CHAR(6) DEFAULT "",	/*  CODIGO UBIGEO DEL DEPARTAMENTO, PROVINCIA y DISTRITO DE LA DIRECCION DEL DECLARANTE DE ACUERDO A LA CODIFICACION VIGENTE y PUBLICADA POR EL INEI */
  TLF_DECLA	CHAR(15) DEFAULT "",	/*  TELEFONO DEL DECLARANTE */
  PRIMARY KEY(CODIGO),
  CONSTRAINT UQ_CTO_1 UNIQUE(APELLIDO_P,APELLIDO_M,NOMBRES));
CREATE INDEX CTO ON CTO(CODIGO)


/*PRD(TABLA DE PRODUCTOS X CLIENTE)*/
create table if not exists prd(	
   marca 	varchar(30) not null, /*C 30  0*/
   modelo    	varchar(27) not null, /*C 27  0*/
   n_parte      varchar(25) not null,
   mercancia 	varchar(35) not null, /*C 35  0*/
   n_orden      char(11) not null,
   nume_secup   char(3) not null,
   nume_secuf   char(3) not null,
   num_item     numeric(4,0) not null,
   primary key(marca,modelo,n_parte,mercancia),
constraint fk_prd_ada foreign key(n_orden,nume_secup,nume_secuf,num_item) references ada(n_orden,nume_secup,nume_secuf,num_item));
create index prd_1 on prd(marca,modelo,n_parte,mercancia);
create index prd_2 on prd(marca);
create index prd_3 on prd(modelo);
create index prd_4 on prd(n_parte);
create index prd_5 on prd(mercancia);

/*PEX(TABLA DE PRODUCTOS DE EXPORTACION )*/
create table if not exists pex(	
   des1     varchar(100) not null, /*C 30  0*/
   n_orden  char(11) not null,
   n_serie  numeric(4,0) not null,
   primary key(des1),
constraint fk_pex_sea foreign key(n_orden,n_serie) references sea(n_orden,n_serie));
create index pex_1 on pex(des1);
create index pex_2 on pex(n_orden,n_serie);

/*CIS(TABLA DE INSUMOS PARA CUADRO Y RELACION DE INSUMOS)*/
create table if not exists cis(
   cinsumo    char(6) not null,
   n_orden    char(11) not null,
   nume_reg   numeric(6,0) default 0,	
   c_aduana   char(3) not null,
   cod_clien  char(5) not null,
   primary key(cod_clien,cinsumo),
   constraint fk_cis_cli foreign key(cod_clien) references cli(codigo),
   constraint fk_cis_ta1 foreign key(c_aduana) references softpad_tablas.ta1(cod),
   constraint fk_cis_ape foreign key(n_orden) references ape(n_orden))
create index cis ON cis(cod_clien,codigo);

/*=========================================*/

/* PDM (TABLA DE PRODUCTOS DEL DMA POR NUMERO DE PARTE)*/
create table if not exists pdm(
   n_parte     varchar(25) not null,
   n_orden  char(11) not null,
   n_serie  numeric(4,0) not null,
   c_aduana char(3) not null,
   tiporeg  char(2) not null, 
   primary key(c_aduana,tiporeg,n_parte),
constraint fk_pdm_sea foreign key(n_orden,n_serie) references sea(n_orden,n_serie));
create index pdm_1 on pdm(c_aduana,tiporeg,n_parte);
create index pdm_2 on pdm(n_orden,n_serie);


/*REL(RELACION DE INSUMO PRODUCTO REGIMEN 26)*/
CREATE TABLE IF NOT EXISTS REL(
   N_ORDEN    CHAR(11) NOT NULL,
   NUME_REG   NUMERIC(6,0) DEFAULT 0,	
   SERIEI     NUMERIC(4,0) DEFAULT 0,
   SERIEE     NUMERIC(4,0) DEFAULT 0,
   CINSUMO    CHAR(6) DEFAULT "",
   CPRODUCTO  CHAR(6) DEFAULT "",
   DINSUMO    VARCHAR(120) DEFAULT "",
   DPRODUCTO  VARCHAR(120) DEFAULT "",
   UNIMEDI    CHAR(4) DEFAULT "",
   UNIMEDP    CHAR(4) DEFAULT "",
   ARANCELI   CHAR(10) DEFAULT "",
   ARANCELP   CHAR(10) DEFAULT "",
   CANT_TOTAL DECIMAL(20,10) DEFAULT 0.0000000000,
   CANT_SUJ   DECIMAL(20,10) DEFAULT 0.0000000000,
   COEF_TOTAL DECIMAL(20,10) DEFAULT 0.0000000000,
   CANT_RESI  DECIMAL(20,10) DEFAULT 0.0000000000,
   CANT_DESP  DECIMAL(20,10) DEFAULT 0.0000000000,
   CANT_SUBP  DECIMAL(20,10) DEFAULT 0.0000000000,
   CANT_UTIL  DECIMAL(20,10) DEFAULT 0.0000000000,
   ADUANI     CHAR(3) DEFAULT "",
   ANDOCI     CHAR(4) DEFAULT "",
   NUDOCI     CHAR(6) DEFAULT "",	
   CADU_TRA   CHAR(3) DEFAULT "",
   ANO_TRA    NUMERIC(4,0) DEFAULT 0,
   NUME_TRA   NUMERIC(6,0) DEFAULT 0,
   NUME_TREG  NUMERIC(4,0) DEFAULT 0,
   C1INSUMO   CHAR(6) DEFAULT "",	
   UNI1INSUMO CHAR(4) DEFAULT "",
   NUME_SERIE NUMERIC(4,0) DEFAULT 0,
   QUNICOM1   DECIMAL(15,3) DEFAULT 0.000,
   DESCINSUMO VARCHAR(40) DEFAULT "",
   C2INSUMO   CHAR(6) DEFAULT "",
   UNI2INSUMO CHAR(4) DEFAULT "",
   QUNICOM2   DECIMAL(15,3) DEFAULT 0.000,
   QUNIEQUI   DECIMAL(15,3) DEFAULT 0.000,
   CNANEXP    VARCHAR(10) DEFAULT "",
   CTIPITEM   CHAR(2) DEFAULT "",
   PRIMARY KEY(N_ORDEN,NUME_REG),
   CONSTRAINT FK_REL FOREIGN KEY(N_ORDEN) REFERENCES CCU(N_ORDEN));
   CREATE INDEX REL ON REL(N_ORDEN,NUME_REG);
