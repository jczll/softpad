/* DJA (DECLARACION JURADA POR CADA PROVEEDOR DEL DESPACHO)*/
CREATE TABLE IF NOT EXISTS DJA(
   NUME_SECUP	CHAR(3) NOT NULL,	/*C  2  0 //Numero de secuencia de DVA*/
   COD_PROV  	CHAR(10) DEFAULT '',	/*C 10  0 //codigo del proveedor*/
   N_ORDEN   	CHAR(11) NOT NULL,	/*C  9  0 //Numero de orden*/
   NATURALEZA	CHAR(2) DEFAULT '11',	/*C  2  0 //naturaleza*/
   TERM1     	CHAR(3) DEFAULT '',	/*C  3  0 //Codigo incoterm*/
   TERM2     	VARCHAR(25) DEFAULT '',	/*C 25  0 //Lugar incoterm*/
   FORM_ENVIO	CHAR(1) DEFAULT '1',	/*C  1  0 //forma de envio*/
   NUME_ENVIO	NUMERIC(8,0) DEFAULT 1,	/*N  8  0 //numero de envios*/
   VINCULAC  	CHAR(1) DEFAULT '',	/*C  1  0 //Vinc.con proveedor extranjero*/
   INFL_VINCU	CHAR(1) DEFAULT '',	/*C  1  0 //Influencia de la vinculacion en precio*/
   PVATR12B  	CHAR(1) DEFAULT '',	/*C  1  0*Aprox.valor transac.a Art. 1.2 B) OMC*/
   PRECE1    	CHAR(1) DEFAULT '1',	/*C  1  0*Restricciones cesion/utilizacion art 1 OMC*/
   PCONMCIA  	CHAR(1) DEFAULT '2',	/*C  1  0*Depende venta o precio con mercancias a valorar*/
   PDECOND   	CHAR(1) DEFAULT '2',	/*C  1  0*Puede determinarse valor con condiciones*/
   SPAG_INDIR	CHAR(1) DEFAULT '2',	/*C  1  0*Pago indirecto de las mercancias*/
   PDESRET   	CHAR(1) DEFAULT '2',	/*C  1  0*descuentos retroactivos*/
   SDER_LICEN	CHAR(1) DEFAULT '2',	/*C  1  0*canones y derechos de licencia de mercancia*/
   VENT_CONDI	CHAR(1) DEFAULT '2',	/*C  1  0*Venta condicionada por un acuerdo*/
   CONTMCIA  	CHAR(1) DEFAULT '2',	/*C  1  0*contrato relativo a las mercancias*/
   CONTSUMI  	CHAR(1) DEFAULT '2',	/*C  1  0*contrato global de suministro larga duracion*/
   CLAUREVI  	CHAR(1) DEFAULT '2',	/*C  1  0*clausula de revisi�n de precio*/
   INTIMPCLI 	CHAR(1) DEFAULT '2',	/*C  1  0*Inetemediario imp. a solicitud cliente*/
   DIFVALASI 	CHAR(1) DEFAULT '2',	/*C  1  0*Diferente valor asignado emp.verificadora*/
   COND16    	CHAR(1) DEFAULT '',	/*C  1  0*OTros*/
   COND17    	CHAR(1) DEFAULT '',	/*C  1  0*OTros*/
   COND18    	CHAR(1) DEFAULT '',	/*C  1  0*OTros*/
   COND19    	CHAR(1) DEFAULT '',	/*C  1  0*OTros*/
   COND20    	CHAR(1) DEFAULT '',	/*C  1  0*OTros*/
   CANT_FACTU	NUMERIC(4,0) DEFAULT 1,	/*N  4  0*Total facturas*/
   PRED_FACT 	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6*Precio neto segun factura en dolares*/
   VTA_SUCESI	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6*Monto total de venta sucesiva*/
   FLETE_FACT	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //Flete  de la factura*/
   SEGUR_FACT	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //Seguro de la factura*/
   DGASTO1   	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //815 Gastos de transporte decarga y manipulacion*/
   DGASTO2   	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6// 816 Otros gastos Diferencias*/
   DGASTO3   	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //812 Otros gastos de la Factura*/
   DGASTO4   	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //813 Otros gastos de la Factura*/
   DGASTO5   	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //814 Otros gastos de la Factura*/
   DADIC1    	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //821  Adiciones 1*/
   DADIC2    	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //822  Adiciones 2*/
   DADIC3    	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //823  Adiciones 3*/
   DADIC4    	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //8231 Adiciones 4*/
   DADIC5    	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //8232 Adiciones 5*/
   DADIC6    	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //8233 Adiciones 6*/
   DADIC7    	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //8234 Adiciones 7*/
   DADIC8    	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //824  Adiciones 8*/
   DADIC9    	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //825  Adiciones 9*/
   DDEDUC1   	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //851 Otros gastos de la Factura*/
   DDEDUC2   	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //852 Otros Gastos de la Factura*/
   DDEDUC3   	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //853 Otros Gastos de la Factura*/
   DDEDUC4   	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //854 Otros gastos de la Factura*/
   DDEDUC5   	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //855 Otros gastos de la factura*/
   DFLETE2   	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //831*/
   COD_P_ADQ 	CHAR(2) DEFAULT '',	/*C  2  0 //Pais de Adquisicion de Productos del Pacto Andino*/
   CANT_DAV  	NUMERIC(4,0) DEFAULT 0,	/*N  4  0 //Correlacion de Facturas del Pacto Andino*/
   FOB_FACT  	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //Fob de la Factura acumulado por DAV*/
   CARACESTIM	CHAR(1) DEFAULT '',     	/*C  1  0 //Pregunta para DAV Casillero (80) Tiene caracter estimativo*/
   CONT_OTRO    CHAR(1) DEFAULT "N",            /*C  1  0 //Pregunta si lleva contrato u Otro Docuemento */   
   NUM_CONTRA   VARCHAR(20) DEFAULT '',     	/* C 20  0 //Numero de Contrato*/
   FCH_CONTRA   DATE,                           /* D  8  0 //Fecha de Contrato*/
   OTRODOC      VARCHAR(20) DEFAULT '',     	/*C 20  0 //Tipo de Otro Documento*/
   FORMAPAGO    CHAR(2) DEFAULT '',     	/*C  2  0 //Codigo de forma de Pago*/
   OTROFORMA    VARCHAR(20) DEFAULT '',     	/*C 20  0 //Otros en forma de pago*/
   MEDIOPAGO    CHAR(2) DEFAULT '',     	/*C  2  0 //Codigo de medio de pago*/
   OTROMEDIO    VARCHAR(20) DEFAULT '',     	/*C 20  0 //Otros en medio de pago*/
   OTRONATURA   VARCHAR(20) DEFAULT '',     	/*C 20  0 //Otros en Naturaleza de Transaccion*/
   COD_RESTRI   CHAR(2) DEFAULT '',     	/*C  2  0 //Codigo de Tipo de Restriccion*/
   COD_CONDI    CHAR(2) DEFAULT '',     	/*C  2  0 //Codigo de condicion o contraprestacion*/
   OTR_CONDI    VARCHAR(20) DEFAULT '',     	/*C 20  0 //Otros en condicion o contraprestacion*/
   COD_VINC     CHAR(4) DEFAULT '',     	/*C  2  0 //Codigo de Tipo de Vinculacion*/
   C_DOCORI     CHAR(4) DEFAULT '',     	/*C  4  0 //Codigo del Comprador Inicial*/
   T_DOCORI     CHAR(1) DEFAULT '',     	/*C  1  0 //tipo de documento del comprador inicial/tipo de Documento del Importador(33)/Pregunta si tiene Anexo 1 (40)*/
   N_DOCORI     CHAR(11) DEFAULT '',     	/*C 11  0 //Numero del documento del comprador inicial/Numero de Documento del Importador(33)*/
   D_DOCORI     VARCHAR(60) DEFAULT '',     	/*C 60  0 //Razon social del comprador inicial  / Descripcion de Nota de Embarque (40,41) y Volante de Despacho/Descripcion del Material de Guerra/Sector Competente (25)*/
   COD_INTERM   CHAR(4) DEFAULT '',     	/*C  4  0 //Codigo de Intermediario*/
   PAIS_PROV    CHAR(2) DEFAULT '',     	/*C  2  0 //Pais del Proveedor*/
   CANT_ITEMS	NUMERIC(4,0) DEFAULT 1,  /*N  4 0*Cantidad de Items*/
   PRE_FACT     DECIMAL(17,6) DEFAULT 0.000000, /*N 17  6*Precio neto segun factura*/
   AJUSTE    	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //Total Ajuste (Suma todos los gastos del 8.2)*/
   TOT_DEDUC 	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //Total deducciones (Suma de todos los gastos 8.5)*/
   TERM3        CHAR(1) DEFAULT "",             /*A�o del Incoterm */
   NIVEL_COM 	CHAR(1) DEFAULT '',	        /*C  1  0 NIVEL COMERCIAL PARA LA DECLARACION DE VALOR*/
   OTR_NIVC     VARCHAR(20) DEFAULT "",         /*  C 20  0 //Otro Nivel Comercial del Importador*/
   CONDI_PRO    CHAR(1) DEFAULT "",             /*C  1  0 //Condicion del Proveedor */
   OTR_CONDP    VARCHAR(20) DEFAULT "",         /*C 20  0 //otras Condiciones del Proveedor */
   TPROVIS    	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //Total provisional solo para DHL */
   NUME_ENVP    NUMERIC(8,0) DEFAULT 0,         /* N  8  0 //NUMERO DE ENVIO PARCIAL PARA FORM_ENVIO 2*/
   PRIMARY KEY(N_ORDEN,NUME_SECUP),
   CONSTRAINT UQ_DJA_1 UNIQUE(N_ORDEN,COD_PROV,TERM1,NATURALEZA));
   CREATE INDEX DJA ON DJA(N_ORDEN);

/* DVF(FACTURAS POR PROVEEDOR Y ORDEN )*/
CREATE TABLE IF NOT EXISTS DVF(
   NUME_SECUF	CHAR(3) NOT NULL,	/*C  3  0 //Numero de Secuencia de la FACTURA*/
   NUM_FACT  	VARCHAR(40) DEFAULT '',	/*C 40  0 //Numero de factura*/
   N_ORDEN   	CHAR(11) NOT NULL,/*C  9  0 //N� de Orden de despacho*/
   NUME_SECUP	CHAR(3) NOT NULL,	/*C  2  0 //Numero de Secuencia de la DVA*/
   FCH_FACT  	DATE,	/*D  8  0 //fecha de factura*/
   CODFOB    	CHAR(3) DEFAULT 'USD',	/*C  3  0 //Codigo de moneda*/
   FACTOR    	DECIMAL(13,10) DEFAULT 1.0000000000,	/*N 13 10 //factor para otra moneda*/
   PRE_FACT  	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //Precio segun factura en moneda original*/
   PRED_FACT 	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //Precio segun factura en Dolares*/
   TVAL_ITEMD	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //Precio de factura para Aduanas, para impresion y envio*/
   FLAG_GAST 	CHAR(1) DEFAULT 'N',	/*C  1  0 //Flag que permite editar los gastos,ajustes u otros*/
   DGASTO1   	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //815 Gastos de transporte decarga y manipulacion*/
   DGASTO2   	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6// 816 Otros gastos Diferencias*/
   DGASTO3   	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //812 Otros gastos de la Factura*/
   DGASTO4   	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //813 Otros gastos de la Factura*/
   DGASTO5   	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //814 Otros gastos de la Factura*/
   DADIC1    	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //821  Adiciones 1*/
   DADIC2    	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //822  Adiciones 2*/
   DADIC3    	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //823  Adiciones 3*/
   DADIC4    	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //8231 Adiciones 4*/
   DADIC5    	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //8232 Adiciones 5*/
   DADIC6    	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //8233 Adiciones 6*/
   DADIC7    	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //8234 Adiciones 7*/
   DADIC8    	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //824  Adiciones 8*/
   DADIC9    	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //825  Adiciones 9*/
   DDEDUC1   	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //851 Otros gastos de la Factura*/
   DDEDUC2   	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //852 Otros Gastos de la Factura*/
   DDEDUC3   	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //853 Otros Gastos de la Factura*/
   DDEDUC4   	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //854 Otros gastos de la Factura*/
   DDEDUC5   	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6// 855 Otros gastos de la factura*/
   DFLETE2   	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //831*/
   VTA_SUCESI	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //Total Vta. Sucesiva por Factura (suma de lo prorrateado por Item)*/
   FOB_FACT  	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //Fob de la factura (le falta venta sucesiva)*/
   FLETE_FACT	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //Total flete por Factura (Suma prorrateada de los items de esta factura )*/
   SEGUR_FACT	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //Total Seguro por Factura (Suma prorrateada o de arancel de los items de esta factura )*/
   AJUSTE    	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //Total Ajuste (Suma todos los gastos del 8.2)*/
   TOT_DEDUC 	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //Total deducciones (Suma de todos los gastos 8.5)*/
   UNI_COMER 	DECIMAL(18,3) DEFAULT 0.000,	/*N 18  3 //Total unidades comerciales*/
   COD_P_ADQ 	CHAR(3) DEFAULT '',	/*C  3  0 //Pais de Embarque*/
   COD_P_PRO 	CHAR(3) DEFAULT '',	/*C  3  0 //Pais de Origen*/
   CANT_ITEM 	NUMERIC(4,0) DEFAULT 1,	/*N  4  0"//Total items de la factura*/
   FLETE_TRAN	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //Flete de la factura en transaccion*/
   SEGUR_TRAN	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //Seguro de la factura en transaccion*/
   AJUST_INF 	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //Diferencia entre el Fob del C.I. y la Factura*/
   TVAL_ITEM 	DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //Valor total de los items en moneda de Transaccion*/
   PRORRAJUST	NUMERIC(1,0) DEFAULT 1,	/*N  1  0 //Flag que determina si se van a prorratear los Ajustes*/
   PRORRGASTO	NUMERIC(1,0) DEFAULT 1,	/*N  1  0*/
   FLAG_AJUST	CHAR(1) DEFAULT 'N',	/*C  1  0 //Flag que determina si hay ajustes*/
   FLAG_DEDUC	CHAR(1) DEFAULT 'N',	/*C  1  0 //Flag que determina si hay deducciones*/
   KBR       	DECIMAL(15,3) DEFAULT 0.000,	/*N 15  3 //KILOS BRUTO PARA PRORRATEAO POR FACTURA*/
   KNE       	DECIMAL(15,3) DEFAULT 0.000,	/*N 15  3 //KILOS NETO PARA PRORRRATEO POR FACTURA*/
   COD_PROV  	CHAR(10) DEFAULT '',	/*C 10  0 ******** CAMPOS PARA LA DECLARACION DE FACTURAS PARA SIMPLIFICADAS*/
   FECH_EXPO 	DATE,	                /*D  8  0 //FECHA DE EMBARQUE DE MERCANCIA*/
   TIPO_ENVIO	CHAR(1) DEFAULT '1',	/*C  1  0 //FLAG QUE INDICA TIPO DE DOCUMENTO: '1' FACTURA, '2' DECLARACION JURADA*/
   PROVEE_A  	CHAR(1) DEFAULT '',	/*C  1  0 //TIENE USTED VINCULACION CON SU PROVEEDOR EXTRANJERO? '1':SI '0':NO*/
   PROVEE_B  	CHAR(1) DEFAULT '',	/*C  1  0 //HA INFLUIDO LA VINCULACION EN EL PRECIO? '1':SI '0':NO*/
   PROVEE_C  	CHAR(1) DEFAULT '',	/*C  1  0 //EXISTEN PAGOS INDIRECTOS RELATIVOS A LAS MERCANCIAS QUE SE IMPORTAN? '1':SI '0':NO*/
   PROVEE_D  	CHAR(1) DEFAULT '',	/*C  1  0 //EXISTEN CANONES O DERECHOS DE LICENCIAS RELATIVAS A && LAS MERCANCIAS IMPORTADAS QUE UD. ESTA OBL*/
   PROVEE_E  	CHAR(1) DEFAULT '',	/*C  1  0 //ESTA LA VENTA CONDICIONADA POR UN ACUERDO SEGUN LA CUAL UNA PARTE DEL PRODUCTO DE CUALQUIER VENTA*/
   CANT_DAV  	NUMERIC(4,0) DEFAULT 0,	/*N  4  0 //Correlacion de Facturas de la Declaracion Andina de Valor*/
   NUMBLGUIA 	CHAR(25) DEFAULT '',	/*C 25  0 //N� de BL/Guia*/
   NUMDET    	CHAR(3) DEFAULT '',	/*C  3  0 **Numero de detalle en caso de mas de un Bl/Guia*/
   FCH_EMB   	DATE,            	/*D  8  0 **Fecha de embarque*/
   COD_P_EMB 	CHAR(6) DEFAULT '',	/*C  6  0 //Codigo de puerto de Embarque*/
   CODPAISADQ	CHAR(3) DEFAULT '',	/*C  3  0 //Codigo del Pais de Adquisici�n*/
   PRORR_GTO1	CHAR(1) DEFAULT 'S',	/*C  1  0 //Indica si prorratea el Gasto1 a los items*/
   PRORR_GTO2	CHAR(1) DEFAULT 'S',	/*C  1  0 //Indica si prorratea el Gasto2 a los items*/
   PRORR_GTO3	CHAR(1) DEFAULT 'S',	/*C  1  0 //Indica si prorratea el Gasto3 a los items*/
   PRORR_GTO4	CHAR(1) DEFAULT 'S',	/*C  1  0 //Indica si prorratea el Gasto4 a los items*/
   PRORR_GTO5	CHAR(1) DEFAULT 'S',	/*C  1  0 //Indica si prorratea el Gasto5 a los items*/
   PRORR_ADI1	CHAR(1) DEFAULT 'S',	/*C  1  0 //Indica si prorratea la Adicion 1 a los items*/
   PRORR_ADI2	CHAR(1) DEFAULT 'S',	/*C  1  0 //Indica si prorratea la Adicion 2 a los items*/
   PRORR_ADI3	CHAR(1) DEFAULT 'S',	/*C  1  0 //Indica si prorratea la Adicion 3 a los items*/
   PRORR_ADI4	CHAR(1) DEFAULT 'S',	/*C  1  0 //Indica si prorratea la Adicion 4 a los items*/
   PRORR_ADI5	CHAR(1) DEFAULT 'S',	/*C  1  0 //Indica si prorratea la Adicion 5 a los items*/
   PRORR_ADI6	CHAR(1) DEFAULT 'S',	/*C  1  0 //Indica si prorratea la Adicion 6 a los items*/
   PRORR_ADI7	CHAR(1) DEFAULT 'S',	/*C  1  0 //Indica si prorratea la Adicion 7 a los items*/
   PRORR_ADI8	CHAR(1) DEFAULT 'S',	/*C  1  0 //Indica si prorratea la Adicion 8 a los items*/
   PRORR_ADI9	CHAR(1) DEFAULT 'S',	/*C  1  0 //Indica si prorratea la Adicion 9 a los items*/
   PRORR_DED1	CHAR(1) DEFAULT 'S',	/*C  1  0 //Indica si prorratea la Deduccion 1 a los items*/
   PRORR_DED2	CHAR(1) DEFAULT 'S',	/*C  1  0 //Indica si prorratea la Deduccion 2 a los items*/
   PRORR_DED3	CHAR(1) DEFAULT 'S',	/*C  1  0 //Indica si prorratea la Deduccion 3 a los items*/
   PRORR_DED4	CHAR(1) DEFAULT 'S',	/*C  1  0 //Indica si prorratea la Deduccion 4 a los items*/
   PRORR_DED5	CHAR(1) DEFAULT 'S',	/*C  1  0 //Indica si prorratea la Deduccion 5 a los items*/
   NFAC_VTASU	VARCHAR(40) DEFAULT '',	/*C 40  0 //Numero de la Factura de la Venta Sucesiva*/
   FFAC_VTASU	DATE,            	/*D  8  0 //Fecha de la Factura de la Venta Sucesiva*/
   INDI_FACDD	CHAR(1) DEFAULT '',	/*C  1  0 //Indicador del Documento si es factura o declaracion Jurada*/
   CODGASTO1    CHAR(3) DEFAULT '',             /*  0 //Codigo de moneda*/
   GASTO1       DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6 //815 Gastos de transporte decarga y manipulacion*/
   FACTORGTO1   DECIMAL(13,10) DEFAULT 1.0000000000,	/*13 10 //factor para otra moneda*/
   CODGASTO2    CHAR(3) DEFAULT '',             /*C  3  0 //Codigo de moneda*/
   FACTORGTO2   DECIMAL(13,10) DEFAULT 1.0000000000,	/* N 13 10 //factor para otra moneda*/
   GASTO2       DECIMAL(17,6) DEFAULT 0.000000,	/*N 17  6// 816 Otros gastos Diferencias*/
   CARPET_EXP   VARCHAR(12) DEFAULT '',         /* Campos para registrar el Numero de Carpeta de Reipley (EXPEDITOR) */
   PRIMARY KEY(N_ORDEN,NUME_SECUP,NUME_SECUF),
   CONSTRAINT UQ_DVF_1 UNIQUE(N_ORDEN,NUME_SECUP,NUM_FACT));
   CREATE INDEX DVF_N_ORDEN ON DVF(N_ORDEN);
   CREATE INDEX DVF_NUM_FACT ON DVF(NUM_FACT);

/* ADA (ITEMS DEL DESPACHO POR FACTURA,PROVEEDOR Y ORDEN )*/
CREATE TABLE IF NOT EXISTS ADA(
   N_ORDEN   	CHAR(11) NOT NULL,               /*C  9  0     N� de Orden de despacho - DATOS PRINCIPALES -*/
   NUME_SECUP 	CHAR(3) NOT NULL,                /*C  2  0  // C�digo del  proveedor -- DATOS DE LOS ITEMS ---*/
   NUME_SECUF 	CHAR(3) NOT NULL,       	 /*C  3  0  // Numero de Secuencia de la Factura*/
   NUM_ITEM  	NUMERIC(4,0) NOT NULL, 	         /*N  4  0  // Nro. de Item secuencial por Factura*/
   NUM_ITEMP 	NUMERIC(4,0) NOT NULL, 	         /*N  4  0  // Nro. de Item secuencial por Proveedor*/
   NUM_ITEMO 	NUMERIC(4,0) NOT NULL, 	         /*N  4  0  // Nro. de Item secuencial por Orden*/
   PARTIDA   	CHAR(10)  DEFAULT '', 	         /*C 10  0   //Partida Nandina*/
   CODIGO    	CHAR(6)  DEFAULT '', 	         /*C  6  0   //Codigo de producto*/
   COD_P_PRO 	CHAR(3)  DEFAULT '', 	         /*C  3  0   //Pais de origen*/
   MERCANCIA 	VARCHAR(35)  DEFAULT '', 	 /*C 35  0   //mercancia (Nombre comercial)*/
   MARCA     	VARCHAR(30)  DEFAULT '', 	 /*C 30  0   //marca     (Marca )*/
   MODELO    	VARCHAR(27)  DEFAULT '', 	 /*C 27  0   //modelo    (modelo)*/
   DETACARACT   CHAR(1)      DEFAULT 'C',        /*Flag acceder a la pantalla de las Caracteristicas  */
   CARACTERI1 	VARCHAR(150)  DEFAULT '', 	 /*C150  0   //Caracteristica 1*/
   CARACTERI2 	VARCHAR(150)  DEFAULT '', 	 /*C150  0   //Caracteristica 2*/
   CARACTERI3 	VARCHAR(150)  DEFAULT '', 	 /*C150  0   //Caracteristica 3*/
   CARACTERI4 	VARCHAR(150)  DEFAULT '', 	 /*C150  0   //Caracteristica 4*/
   IDENTSOFT 	CHAR(1)  DEFAULT '', 	         /*C  1  0  //Identificador de software*/
   POSINFVERI 	CHAR(1)  DEFAULT '0', 	         /*C  1  0  //Posici�n frente al Inf.Verificaci�n*/
   TIPO_VALOR 	CHAR(1)  DEFAULT '1', 	         /*C  1  0  //Tipo de VAlor*/
   FVAL_PROVI 	DATE, 	                         /*D  8  0   //Fecha estimada de valor provisional*/
   VALOR_ESTI 	DECIMAL(17,6) DEFAULT 0.000000,  /*N 17  6   //Valor definitivo estimado*/
   DEDUCDISTI 	CHAR(1)  DEFAULT '2', 	         /*C  1  0  //Deducciones distinguidas*/
   VAL_ITEM  	DECIMAL(17,6) DEFAULT 0.000000,  /*N 17  6   //Precio del item segun Factura*/
   VAL_ITEMD 	DECIMAL(17,6) DEFAULT 0.000000,  /*N 17  6   //Precio en dolares del Item segun Factura*/
   PRED_FACT 	DECIMAL(17,6) DEFAULT 0.000000,  /*N 17  6   //Precio segun factura x Item en Dolares*/
   FOB_ITEM  	DECIMAL(17,6) DEFAULT 0.000000,  /*N 17  6   //Fob del Item en Dolares*/
   FOBUNI    	DECIMAL(17,6) DEFAULT 0.000000,  /*N 17  6   //Fob Unitario*/
   AJUSTE    	DECIMAL(17,6) DEFAULT 0.000,	 /*N 13  3 Monto del ajuste realizado por el Agente de aduanas en dolares*/
   VTA_SUCESI 	DECIMAL(17,6) DEFAULT 0.000000,	 /*N 17  6   //Valor prorrateado por serie de la venta Sucesiva*/
   FLESDOL   	DECIMAL(17,6) DEFAULT 0.000, 	 /*N 17  6   //Flete en d�lares Prorrateado de los Kilos Netos Ingresado por la B*/
   SEGSDOL   	DECIMAL(17,6) DEFAULT 0.000, 	 /*N 17  6   //Seguro en d�lares Prorrateado del Valor del Item cuando la Factura esta en CFR o CIF*/
   NSERIE_A  	NUMERIC(4,0) DEFAULT 0, 	 /*N  4  0   //Numero de serie en el A al cual pertenece el Item*/
   FLAG_BASE 	CHAR(3)  DEFAULT '001',	         /*C  3  0   //Indicador para Agrupamiento de Ordenes*/
   OBSERVAC1 	VARCHAR(150)  DEFAULT '', 	 /*C150        Observaciones de cada Item*/
   OBSERVAC2 	VARCHAR(150)  DEFAULT '', 	 /*C150        Observaciones de cada Item*/
   OBSERVAC3 	VARCHAR(150)  DEFAULT '', 	 /*C150        Observaciones de cada Item*/
   NUME_FFCO 	CHAR(5)  DEFAULT '', 	         /*C  5  0     Numero de Firmas de Certificado de Origen*/
   OBSERVAC4 	VARCHAR(150)  DEFAULT '', 	 /*C150        Observaciones de cada Item*/
   N_PARTE   	VARCHAR(25)  DEFAULT '', 	 /*C 20        Numero de parte*/
   TPROD     	CHAR(2)  DEFAULT 'N', 	         /*C  2  0   //Codigo de autorizaci�n de mercancia restringida*/
   DES_MINIMA 	CHAR(3)  DEFAULT '',  	         /*C  3        Identificacion para las Descripciones minimas*/
   KNSER     	DECIMAL(14,3) DEFAULT 0.000, 	 /*N 14  3   //Kilo Neto*/
   KBSER     	DECIMAL(14,3) DEFAULT 0.000, 	 /*N 14  3   //Kilo Bruto*/
   UNI_COMER  	DECIMAL(17,6) DEFAULT 0.000, 	 /*N 13  3*************Unidades comerciales*/
   CLAS_COMER 	CHAR(3)  DEFAULT '', 	         /*C  3  0   //clase de unidades comerciales*/
   ESTADO    	CHAR(2)  DEFAULT '',             /*C  2  0   //Estado de la mercancia*/
   NUMBLGUIA 	CHAR(25) DEFAULT '',	         /*C 25  0 //N� de BL/Guia*/
   NUMDET    	CHAR(3) DEFAULT '',       	 /*C  3  0 **Numero de detalle en caso de mas de un Bl/Guia*/
   FCH_EMB   	DATE,	                         /*D  8  0 **Fecha de embarque*/
   COD_P_EMB 	CHAR(6) DEFAULT '',	         /*C  6  0 //Codigo de puerto de Embarque*/
   NUMBULTOS 	DECIMAL(14,3) DEFAULT 0.000, 	 /*N 14  3   //Numero de bultos*/
   CLASEBULTO 	CHAR(3)  DEFAULT '', 	         /*C  3  0   //Clase de bultos*/
   UFISICAS  	DECIMAL(14,3) DEFAULT 0.000, 	 /*N 13  3   //unidades fisicas*/
   TIPOUFIS  	CHAR(12)  DEFAULT '',     	 /*C 12  0   //tipo de unidad fisica*/
   PRORR_PESO	CHAR(1)  DEFAULT '2', 	         /*C  1  0***  Para importacion indica el tipo de prorrateo para el Flete y para Exportacion indica si el peso es prorrateado*/
   FLAGKBRKNE	CHAR(1)  DEFAULT '', 	         /*C  1  0     Si esta vacio indica que peso bruto debe ser prorrateado si esta lleno Peso Bruto ingresado y ademas ("S"=Debe Prorratear el neto basado en el Bruto,"N"=No debe prorratear el Neto)*/
   GASTO1   	DECIMAL(17,6) DEFAULT 0.000000,  /*N 17  6     815 Gastos de transporte decarga y manipulacion en Transaccion*/
   DGASTO1   	DECIMAL(17,6) DEFAULT 0.000000,  /*N 17  6     815 Gastos de transporte decarga y manipulacion*/
   GASTO2   	DECIMAL(17,6) DEFAULT 0.000000,  /*N 17  6     816 Otros gastos Diferencias en Transaccion*/
   DGASTO2   	DECIMAL(17,6) DEFAULT 0.000000,  /*N 17  6     816 Otros gastos Diferencias*/
   DGASTO3   	DECIMAL(17,6) DEFAULT 0.000000,  /*N 17  6     812 Otros gastos de la Factura*/
   DGASTO4   	DECIMAL(17,6) DEFAULT 0.000000,  /*N 17  6     813 Otros gastos de la Factura*/
   DGASTO5   	DECIMAL(17,6) DEFAULT 0.000000,  /*N 17  6     814 Otros gastos de la Factura*/
   DADIC1    	DECIMAL(17,6) DEFAULT 0.000000,  /*N 17  6     821  Adiciones 1*/
   DADIC2    	DECIMAL(17,6) DEFAULT 0.000000,  /*N 17  6     822  Adiciones 2*/
   DADIC3    	DECIMAL(17,6) DEFAULT 0.000000,  /*N 17  6     823  Adiciones 3*/
   DADIC4    	DECIMAL(17,6) DEFAULT 0.000000,  /*N 17  6     8231 Adiciones 4*/
   DADIC5    	DECIMAL(17,6) DEFAULT 0.000000,  /*N 17  6     8232 Adiciones 5*/
   DADIC6    	DECIMAL(17,6) DEFAULT 0.000000,  /*N 17  6     8233 Adiciones 6*/
   DADIC7    	DECIMAL(17,6) DEFAULT 0.000000,  /*N 17  6     8234 Adiciones 7*/
   DADIC8    	DECIMAL(17,6) DEFAULT 0.000000,  /*N 17  6     824  Adiciones 8*/
   DADIC9    	DECIMAL(17,6) DEFAULT 0.000000,  /*N 17  6     825  Adiciones 9*/
   DDEDUC1   	DECIMAL(17,6) DEFAULT 0.000000,  /*N 17  6     851 Otros gastos de la Factura*/
   DDEDUC2   	DECIMAL(17,6) DEFAULT 0.000000,  /*N 17  6     852 Otros Gastos de la Factura*/
   DDEDUC3   	DECIMAL(17,6) DEFAULT 0.000000,  /*N 17  6     853 Otros Gastos de la Factura*/
   DDEDUC4   	DECIMAL(17,6) DEFAULT 0.000000,  /*N 17  6     854 Otros gastos de la Factura*/
   DDEDUC5   	DECIMAL(17,6) DEFAULT 0.000000,  /*N 17  6     855 Otros gastos de la factura*/
   TOT_DEDUC 	DECIMAL(17,6) DEFAULT 0.000000,  /*N 17  6 //Total deducciones (Suma de todos los gastos 8.5)*/
   DFLETE2   	DECIMAL(17,6) DEFAULT 0.000000,  /*N 17  6     831*/
   TIPO_MERCA	VARCHAR(25)  DEFAULT '', 	 /*C 25  0     Tipo de mercancia para la Andina de Valor*/
   RIESGOSAN 	CHAR(2)  DEFAULT '', 	         /*C  2  0     Codigo de riesgo Sanitario para Importacion*/
   FMON_PROVI	CHAR(3)  DEFAULT '', 	         /*C  3  0     codigo de moneda del valor provisional*/
   FTCA_PROVI   DATE,	                         /*D  8  0     Fecha del tipo de cambio del Valor provisional*/
   FLESER   	DECIMAL(17,6) DEFAULT 0.000, 	 /*N 17  6   //Flete en Transaccion x Item B*/
   NUME_SERPR 	CHAR(6) DEFAULT '',     	 /*C  6  0* *  Numero item CIP*/
   SUBPARTIDA   CHAR(2) DEFAULT '',              /*C  2  0  SUBPARTIDA PARA VEHICULOS */
   SEGSER       DECIMAL(17,6) DEFAULT 0.000,     /* Seguro en transacci�n*/
   MARCA_REG    NUMERIC(4,0) DEFAULT 0,          /* Para marcar los registros que seran borrados (nunca se graba)*/
   ARO_ANIO     VARCHAR(21) DEFAULT "",          /*Aro y a�o del Vehiculo, Maquinaria o Becicletas */             
   CEXCNAN   	CHAR(1) DEFAULT '',     	 /*C  1  0* /* Indicador de Desechos y desperdicios*/
   CANT_EQUIV 	DECIMAL(14,3) DEFAULT 0.000, 	 /*N 14  3* /* Cantidad de unidades equivalentes a la Prod.  para ordenes que preceden de una admisi�n*/
   TIPO_EQUIV 	CHAR(3) DEFAULT '',     	 /*C  3  0* /* tipo de unidades equivalente a la prod. para ordenes que preceden de una admisi�n*/
   REFER_ITEM   VARCHAR(15) DEFAULT "",          /*Referencia de item para las Americas */
   PRIMARY KEY(N_ORDEN,NUME_SECUP,NUME_SECUF,NUM_ITEM));
   CREATE INDEX ADA           ON ADA(N_ORDEN);
   CREATE INDEX ADA_1         ON ADA(MARCA,MODELO,MERCANCIA,N_PARTE);
   CREATE INDEX ADA_MARCA     ON ADA(MARCA);
   CREATE INDEX ADA_MODELO    ON ADA(MODELO);
   CREATE INDEX ADA_MERCANCIA ON ADA(MERCANCIA);
   CREATE INDEX ADA_N_PARTE   ON ADA(N_PARTE);
   CREATE INDEX ADA_2         ON ADA(N_ORDEN,NUME_SECUP,NUME_SECUF);


/*OCS (TABLA DE DOCUMENTOS ASOCIADOS AL DESPACHO)*/
CREATE TABLE IF NOT EXISTS OCS(
   N_ORDEN   	CHAR(11) NOT NULL,	/*C  9  0   N� de Orden de despacho*/
   NUME_SERIE	NUMERIC(4,0) DEFAULT 0,	/*N  4  0   Numero de serie*/
   NUME_SECUP	CHAR(3) DEFAULT "",	/*C  2  0   Numero de secuencia del proveedor*/
   NUME_SECUF	CHAR(3) DEFAULT "",	/*C  3  0   Numero de Secuencia de la Factura*/
   NUM_ITEM  	NUMERIC(4,0) DEFAULT 0,	/*N  4  0   Numero del Item de la Factura*/
   TIPO_PROCE	CHAR(1) DEFAULT '',	/*C  1  0   Tipo de operaci�n/proceso*/
   TIPO_DOCAS	CHAR(2) DEFAULT '',	/*C  2  0   Tipo de documento asociado*/
   ANNO_DOCAS	CHAR(4) DEFAULT '',	/*C  4  0   A�o de documento asociado*/
   NUME_DOCAS	VARCHAR(25) DEFAULT '',	/*C 15  0   Numero de documento asociado*/
   FECH_DOCAS	DATE,	/*D  8  0   Fecha documento asociado*/
   FECH_VENCI	DATE,	/*D  8  0   Fecha Vcto plazo*/
   ENTI_EMISO	VARCHAR(40) DEFAULT '',	/*C 40  0   Nombre de Entidad Emisora*/
   CODLUG    	CHAR(3) DEFAULT '',	/*C  3  0   Codigo de Aduana de la Autorizacion*/
   TPROD     	CHAR(2) DEFAULT '',	/*C  2  0   Tipo de Autorizacion*/
   AUT_RESTRI   CHAR(1) DEFAULT '',     /*C  1  0   Flag para Autorizacion de Mercancia Restringido ("X") caso contrario (" ") Blanco */
   GCUSTODIA    CHAR(1) DEFAULT '',     /*C  1  0   Guarda Custodia (1 tiene blanco no tiene )*/
   TDOC_ENTI    CHAR(2) DEFAULT "",     /* C  2  0   Tipo de Documento de la Entidad Autorizante*/
   NDOC_ENTI    VARCHAR(11) DEFAULT "", /*  Numero de documento de la Autoridad autorizante*/
   TIPO_ENTI    CHAR(1) DEFAULT "",     /*C  1  0   Tipo de Entidad Emisora*/
   NUM_ITEAUT   NUMERIC(4,0) DEFAULT 0,	/*N  4  0   Numero de Item de Autorizacion de IQBF*/
   MARCA_REG    NUMERIC(4,0) DEFAULT 0,          /* Para marcar los registros que seran borrados (nunca se graba)*/
   SUBTIPOAUT   CHAR(2) DEFAULT "",     /*C  2  0   C�digo de subtipo asociado al tipo de documento de soporte*/
   NROITEMAUT   NUMERIC(6,0) DEFAULT 0,  /* N  6  0   N�mero de �tem del documento de soporte*/
   SUBENTIDAD   CHAR(4) DEFAULT "",     /*C  4  0   C�digo de sub entidad asociada a entidad, banco u otros*/
   PRIMARY KEY(N_ORDEN,TIPO_PROCE,NUME_SERIE,NUME_SECUP,NUME_SECUF,NUM_ITEM,ANNO_DOCAS,NUME_DOCAS,TIPO_DOCAS,TPROD));
   CREATE INDEX OCS ON OCS(n_orden);

/* CONSTRAINT FK_OCS_SEA FOREIGN KEY(N_ORDEN,NUME_SERIE) REFERENCES SEA(N_ORDEN,N_SERIE),*/
/* CONSTRAINT FK_OCS_ADA FOREIGN KEY(N_ORDEN,NUME_SECUP,NUME_SECUF,NUM_ITEM) REFERENCES ADA(N_ORDEN,NUME_SECUP,NUME_SECUF,NUM_ITEM))*/


/* TEX(DESCRIPCIONES MINIMAS PARA TELAS,TEJIDOS,CONFECCION,FIBRAS Y OTROS CONFECCIONES)*/
CREATE TABLE IF NOT EXISTS TEX(
   N_ORDEN      CHAR(11) NOT NULL,      /*  9  0  N� de Orden de despacho - DATOS PRINCIPALES -*/
   NUME_SECUP   CHAR(3) NOT NULL,      /*  C  2  0  C�digo del  proveedor -- DATOS DE LOS ITEMS ---*/
   NUME_SECUF   CHAR(3) NOT NULL,      /*  C  3  0  Numero de Secuencia de la Factura */
   NUM_ITEM     NUMERIC(4,0) NOT NULL,     /*  N  4  0  Nro. de Item secuencial por Factura */
   TIPO_TEJID   CHAR(3)  DEFAULT '',      /*  C  3  0  Tipo de tejido */
   COD_NOMBRE   CHAR(3)  DEFAULT '',      /*  3  0  Codigo del nombre*/
   NOMBRE       CHAR(30)  DEFAULT '',      /*C 30  0 Nombre */
   COD_TIPO     CHAR(3)  DEFAULT '',      /* C  3  0   //Codigo de Tipo*/
   TIPO         VARCHAR(20)  DEFAULT '',  /* C 20  0   //Tipo */
   COD_HILADO   CHAR(3)  DEFAULT '',      /*  0   //Codigo de Tipo de Hilado**/
   HILADO       VARCHAR(20)  DEFAULT '',  /* 20   //Tipo de Hilado */
   COD_COMPO1   CHAR(3)  DEFAULT '',      /*C  3  0   //Codigo de Componente 1*/
   COMPO1       VARCHAR(20)  DEFAULT '',  /*C 20  0   //Componente 1*/
   PORCENT_1    CHAR(3)  DEFAULT '',      /*C  3  0   //Porcentaje de Componente 1*/
   COD_COMPO2   CHAR(3)  DEFAULT '',      /*3  0   //Codigo de Componente 2*/
   COMPO2       VARCHAR(20)  DEFAULT '',  /*C 20  0   //Componente 2*/
   PORCENT_2    CHAR(3)  DEFAULT '',      /*C  3  0   //Porcentaje de Componente 2*/
   COD_COMPO3   CHAR(3)  DEFAULT '',      /*C  3  0   //Codigo de Componente 3*/
   COMPO3       VARCHAR(20)  DEFAULT '',  /*C 20  0   //Componente 3*/
   PORCENT_3    CHAR(3)  DEFAULT '',      /* C  3  0   //Porcentaje de Componente 3*/
   COD_COMPO4   CHAR(3)  DEFAULT '',      /* C  3  0   //Codigo de Componente 4*/
   COMPO4       VARCHAR(20)  DEFAULT '',  /* C 20  0   //Componente 4*/
   PORCENT_4    CHAR(3)  DEFAULT '',      /*C  3  0   //Porcentaje de Componente 4*/
   COD_ACAB1    CHAR(3)  DEFAULT '',      /*C  3  0   //Codigo de Acabado 1*/
   ACABADO1     VARCHAR(20)  DEFAULT '',  /*C 20  0   //Acabado 1*/
   COD_ACAB2    CHAR(3)  DEFAULT '',      /*C  3  0  //Codigo de Acabado 2 */
   ACABADO2     VARCHAR(20)  DEFAULT '',  /*C 20  0   //Acabado 2 */
   COD_PREP     CHAR(3)  DEFAULT '',      /*C  3  0   //Codigo de Preparacion/Grado de Elaboracion*/
   PREPARAC     VARCHAR(20)  DEFAULT '',  /* 20  0   //Preparacion/Grado de Elaboracion */
   COD_PRESEN   CHAR(3)  DEFAULT '',      /*3  0   //Codigo de Presentacion*/
   PRESENTAC    VARCHAR(20)  DEFAULT '',  /*C 20  0   //Presentacion*/
   ESTR_FIS     VARCHAR(90)  DEFAULT '',  /*C 90  0   //Estructura fisica de la Fibra*/
   CLASE        VARCHAR(45)  DEFAULT '',  /*C 45  0   //Clase */
   USO          VARCHAR(45)  DEFAULT '',  /* C 45  0   //Uso*/
   DENSIDAD     DECIMAL(6,2) DEFAULT 0.00, /*N  6  2   //Densidad */
   ESPESOR      DECIMAL(5,2) DEFAULT 0.00, /*N  5  2   //Espesor */
   GRAMAJE      NUMERIC(4,0) DEFAULT 0,     /* N  4  0   //Gramaje */
   COD_MATPL    CHAR(3)  DEFAULT '',      /*C  3  0   //Codigo de Materia plastica*/
   MAT_PLAST    VARCHAR(20)  DEFAULT '',  /*C 20  0   //Materia Plastica */
   COMPLEMENT   VARCHAR(90)  DEFAULT '',  /*C 90  0   //Complementos */
   CARACTERIS   VARCHAR(90)  DEFAULT '',  /*C 90  0   //Caracteristicas */
   OBSERVAC1    VARCHAR(90)  DEFAULT '',  /*C 90  0   //Observaciones */
   CODMNGSUP    CHAR(4)  DEFAULT '',      /*C  4  0 */
   MANGA_SUP    VARCHAR(20)  DEFAULT '',  /*C 20  0 */
   CODCUESUP    CHAR(3)  DEFAULT '',      /*C  3  0 */
   CUELLO_SUP   VARCHAR(20)  DEFAULT '',  /*C 20  0 */
   COD_P_EXT    CHAR(3)  DEFAULT '',      /*C  3  0 */
   PARTE_EXT    VARCHAR(20)  DEFAULT '',  /*C 20  0 */
   COD_P_INT    CHAR(4)  DEFAULT '',      /*C  3  0 */
   PARTE_INT    VARCHAR(20)  DEFAULT '',  /*C 20  0 */
   CODLAR_SUP   CHAR(4)  DEFAULT '',      /*C  4  0 */
   LARGO_SUP    VARCHAR(20)  DEFAULT '',  /*C 20  0 */
   COD_BOL_S    CHAR(3)  DEFAULT '',      /*C  3  0 */
   BOLSIL_SUP   VARCHAR(20)  DEFAULT '',  /*C 20  0 */
   COD_CINT_S   CHAR(3)  DEFAULT '',      /*C  3  0 */
   CINTURA_S    VARCHAR(20)  DEFAULT '',  /*C 20  0 */
   CODLAR_INF   CHAR(3)  DEFAULT '',      /*C  3  0 */
   LARGO_INF    VARCHAR(20)  DEFAULT '',  /*C 20  0 */
   CODPIE_INF   CHAR(3)  DEFAULT '',      /*C  3  0 */
   PIE_INF      VARCHAR(20)  DEFAULT '',  /*C 20  0 */
   CODABE_INF   CHAR(3)  DEFAULT '',      /*C  3  0 */
   ABERTU_INF   CHAR(3)  DEFAULT '',      /*C 20  0 */
   COD_BOL_I    CHAR(3)  DEFAULT '',      /*C  3  0 */
   BOLSIL_INF   VARCHAR(20)  DEFAULT '',  /*C 20  0 */
   COD_CINT_I   CHAR(3)  DEFAULT '',      /*C  3  0 */
   CINTURA_I    VARCHAR(20)  DEFAULT '',  /*C 20  0 */
   COD_PETO     CHAR(3)  DEFAULT '',      /*C  3  0 */
   PETO_INF     VARCHAR(20)  DEFAULT '',  /*C 20  0 */
   COD_CARAS    CHAR(3)  DEFAULT '',      /*C  3  0 */
   CARAS        VARCHAR(20)  DEFAULT '',  /*C 20  0 */
   COD_ELASTI   CHAR(3)  DEFAULT '',      /*C  3  0 */
   ELASTICO     VARCHAR(20)  DEFAULT '',  /*C 20  0 */
   COD_FORMA    CHAR(3)  DEFAULT '',      /*C  3  0 */
   FORMA        VARCHAR(20)  DEFAULT '',  /*C 20  0 */
   COD_RELLEN   CHAR(3)  DEFAULT '',      /*C  3  0 */
   RELLENO      VARCHAR(20)  DEFAULT '',  /*C 20  0 */
   COD_APLIC    CHAR(4)  DEFAULT '',      /*C  3  0 */
   APLICACION   VARCHAR(20)  DEFAULT '',  /*C 20  0 */
   COD_COMPL    CHAR(3)  DEFAULT '',      /*C  3  0 */
   COD_PRES2    CHAR(3)  DEFAULT '',      /*C  3  0 */
   PRESENTAC2   VARCHAR(20)  DEFAULT '',  /*C 20  0 */
   COD_PZA1_S   CHAR(3)  DEFAULT '',      /*C  3  0 */
   PZA_1_SUP    VARCHAR(20)  DEFAULT '',  /*C 20  0 */
   COD_PZA2_S   CHAR(3)  DEFAULT '',      /*C  3  0 */
   PZA_2_SUP    VARCHAR(20)  DEFAULT '',  /*C 20  0 */
   COD_PZA3_S   CHAR(3)  DEFAULT '',      /*C  3  0 */
   PZA_3_SUP    VARCHAR(20)  DEFAULT '',  /*C 20  0 */
   COD_PZA4_S   CHAR(3)  DEFAULT '',      /*C  3  0 */
   PZA_4_SUP    VARCHAR(20)  DEFAULT '',  /*C 20  0 */
   COD_PZA5_S   CHAR(3)  DEFAULT '',      /*C  3  0 */
   PZA_5_SUP    VARCHAR(20)  DEFAULT '',  /*C 20  0 */
   COD_PZA1_I   CHAR(3)  DEFAULT '',      /*C  3  0 */
   PZA_1_INF    VARCHAR(20)  DEFAULT '',  /*C 20  0 */
   COD_PZA2_I   CHAR(3)  DEFAULT '',      /*C  3  0 */
   PZA_2_INF    VARCHAR(20)  DEFAULT '',  /*C 20  0 */
   COD_PZA3_I   CHAR(3)  DEFAULT '',      /*C  3  0 */
   PZA_3_INF    VARCHAR(20)  DEFAULT '',  /*C 20  0 */
   COD_PZA4_I   CHAR(3)  DEFAULT '',      /*C  3  0 */
   PZA_4_INF    VARCHAR(20)  DEFAULT '',  /*C 20  0 */
   COD_PZA5_I   CHAR(3)  DEFAULT '',      /*C  3  0 */
   PZA_5_INF    VARCHAR(20)  DEFAULT '',  /*C 20  0 */
   PZAS_CJTO    VARCHAR(20)  DEFAULT '',  /*C 20  0 */
   PZACJTOSUP   VARCHAR(20)  DEFAULT '',  /*C 20  0 */
   PZACJTOINF   VARCHAR(20)  DEFAULT '',  /*C 20  0 */
   PESO_UNITA   VARCHAR(20)  DEFAULT '',  /*C 20  0 */
   PRIMARY KEY(N_ORDEN,NUME_SECUP,NUME_SECUF,NUM_ITEM));
   CREATE INDEX TEX ON TEX(N_ORDEN);

/* CRR(DESCRIPCIONES MIMINAS PARA CIERRES Y PARTES DE CIERRES)*/
CREATE TABLE IF NOT EXISTS CRR(
   N_ORDEN   	CHAR(11) NOT NULL,    	/*C  9*/
   NUME_SECUP	CHAR(3) NOT NULL,	/*C  2*/
   NUME_SECUF	CHAR(3) NOT NULL,	/*C  3*/
   TIPO_C    	CHAR(1)  NOT NULL,	/*C  1*/
   NUM_ITEM  	NUMERIC(4,0) NOT NULL,	/*N  4*/
   NOMBRE    	CHAR(3)  DEFAULT '',	/*C  3*/
   N_NOMBRE  	VARCHAR(22)  DEFAULT '',	/*C 22*/
   TIPO      	CHAR(3)  DEFAULT '',	/*C  3*/
   COMPOS    	CHAR(3)  DEFAULT '',	/*C  3*/
   N_COMPOS  	VARCHAR(20)  DEFAULT '',	/*C 20*/
   PRESENTAC 	CHAR(3)  DEFAULT '',	/*C  3*/
   TIPO_LLAVE	CHAR(3)  DEFAULT '',	/*C  3*/
   MAT_LLAVE 	CHAR(3)  DEFAULT '',	/*C  3*/
   NMAT_LLAVE	VARCHAR(20)  DEFAULT '',	/*C 20*/
   TAM_CREMAL	CHAR(3)  DEFAULT '',	/*C  3*/
   MAT_DIEN  	CHAR(3)  DEFAULT '',	/*C  3*/
   NMAT_DIEN 	VARCHAR(20)  DEFAULT '',	/*C 20*/
   NUM_DIENTE	CHAR(3)  DEFAULT '',	/*C  3*/
   OBSERVAC1 	VARCHAR(90)  DEFAULT '',	/*C 90*/
   PRIMARY KEY(N_ORDEN,NUME_SECUP,NUME_SECUF,NUM_ITEM));
   CREATE INDEX CRR ON CRR(N_ORDEN);


/* ZAP(DESCRIPCIONES MINIMAS PARA CALZADO)*/
CREATE TABLE IF NOT EXISTS ZAP(
   N_ORDEN   	CHAR(11) NOT NULL,	/*C  9  0*/
   NUME_SECUP	CHAR(3) NOT NULL,	/*C  2  0*/
   NUME_SECUF	CHAR(3) NOT NULL,	/*C  3  0*/
   NUM_ITEM  	NUMERIC(4,0) NOT NULL,	/*N  4  0*/
   NOMBRE    	CHAR(3)  DEFAULT '',	/*C  3  0*/
   SUPERIOR  	CHAR(3)  DEFAULT '',	/*C  3  0*/
   ORIGEN    	CHAR(3)  DEFAULT '',	/*C  3  0*/
   N_ORIGEN  	VARCHAR(20)  DEFAULT '',	/*C 20  0*/
   ACABADO   	CHAR(3)  DEFAULT '',	/*C  3  0*/
   N_ACABADO 	VARCHAR(20)  DEFAULT '',	/*C 20  0*/
   COMPOS1   	CHAR(3)  DEFAULT '',	/*C  3  0*/
   N_COMPOS1 	VARCHAR(20)  DEFAULT '',	/*C 20  0*/
   PORCENT1  	CHAR(3)  DEFAULT '',	/*C  3  0*/
   COMPOS2   	CHAR(3)  DEFAULT '',	/*C  3  0*/
   N_COMPOS2 	VARCHAR(20)  DEFAULT '',	/*C 20  0*/
   PORCENT2  	CHAR(3)  DEFAULT '',	/*C  3  0*/
   TIPO      	CHAR(3)  DEFAULT '',	/*C  3  0*/
   N_TIPO    	VARCHAR(20)  DEFAULT '',	/*C 20  0*/
   SUELA     	CHAR(3)  DEFAULT '',	/*C  3  0*/
   FORRO     	CHAR(3)  DEFAULT '',	/*C  3  0*/
   USUARIO   	CHAR(3)  DEFAULT '',	/*C  3  0*/
   TALLA     	CHAR(11)  DEFAULT '',	/*C 11  0*/
   OBSERVAC1 	VARCHAR(90)  DEFAULT '',	/*C 90  0*/
   CONSTRUCC 	CHAR(3)  DEFAULT '',	/*C  3  0*/
   OTR_CONSTR	VARCHAR(20)  DEFAULT '',	/*C 20  0*/
   P_ORIG_CUE	NUMERIC(3,0) default 0,	/*N  3  0 */
   P_ACAB_CUE	NUMERIC(3,0) DEFAULT 0,	/*N  3  0 */
   COMPOS3   	CHAR(3)  DEFAULT '',	/*C  3  0 */
   N_COMPOS3 	VARCHAR(20)  DEFAULT '',/*C 20  0 */
   PORCENT3  	CHAR(3)  DEFAULT '',	/*C  3  0 */
   COM_TEJ   	CHAR(3)  DEFAULT '',	/*C  3  0 */
   NCOM_TEJ  	VARCHAR(20)  DEFAULT '',/*C 20  0 */
   PCOM_TEJ  	CHAR(3)  DEFAULT '',	/*C  3  0 */
   PORCEN_TEX	CHAR(3)  DEFAULT '',	/*C  3  0 */
   PRIMARY KEY(N_ORDEN,NUME_SECUP,NUME_SECUF,NUM_ITEM));
   CREATE INDEX ZAP ON ZAP(N_ORDEN);


/* GAF(DESCRIPCIONES MINIMAS PARA LETES Y GAFAS)*/
CREATE TABLE IF NOT EXISTS GAF(
   N_ORDEN   	CHAR(11) NOT NULL,	/*C  9  0 //Numero de Orden*/
   NUME_SECUP	CHAR(3) NOT NULL,	/*C  2  0 //Secuencia de Proveedor*/
   NUME_SECUF	CHAR(3) NOT NULL,	/*C  3  0 //Secuencia de Factura*/
   NUM_ITEM  	NUMERIC(4,0) NOT NULL,	/*N  4  0 //Secuencia de Item por Factura*/
   COD_NOMBRE	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Nombre de Lentes*/
   N_NOMBRE  	VARCHAR(30)  DEFAULT '',	/*C 30  0 //Nombre de Lentes*/
   CODMATMERC	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Material de Mercancia*/
   N_MATMERC 	VARCHAR(30)  DEFAULT '',	/*C 30  0 //Nombre de Material de Mercanc�a*/
   CODMATLENT	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Material del Lente*/
   COD_MEDIDA	CHAR(2)  DEFAULT '',	/*C  2  0 //Codigo de Medida*/
   MEDIDA    	CHAR(9)  DEFAULT '',	/*C  9  0 //Medida*/
   TIPO      	CHAR(3)  DEFAULT '',	/*C  3  0 //Tipo de Lente*/
   BLANDO    	CHAR(3)  DEFAULT '',	/*C  3  0 //Si es blando: CON � DES*/
   N_FOCO    	CHAR(3)  DEFAULT '',	/*C  3  0 //Numero de foco*/
   MONOFOCAL 	CHAR(3)  DEFAULT '',	/*C  3  0 //Si es monofocales:ESF, CIL � COM*/
   COLOR     	CHAR(3)  DEFAULT '',	/*C  3  0 //Tipo de Color*/
   TRATAMIEN 	CHAR(3)  DEFAULT '',	/*C  3  0 //Tratamiento*/
   ACABADO   	CHAR(3)  DEFAULT '',	/*C  3  0 //Acabado*/
   OBSERVAC1 	VARCHAR(90)  DEFAULT '',	/*C 90  0 //Observaciones*/
   PRIMARY KEY(N_ORDEN,NUME_SECUP,NUME_SECUF,NUM_ITEM));
   CREATE INDEX GAF ON GAF(N_ORDEN);

/*PLT(DESCRIPCIONES MIMINAS PARA PILAS)*/
CREATE TABLE IF NOT EXISTS PLT(
   N_ORDEN   	CHAR(11) NOT NULL,	/*C  9  0 //Numero de Orden*/
   NUME_SECUP	CHAR(3) NOT NULL,	/*C  2  0 //Secuencia de Proveedor*/
   NUME_SECUF	CHAR(3) NOT NULL,	/*C  3  0 //Secuencia de Factura*/
   NUM_ITEM  	NUMERIC(4,0) NOT NULL,	/*N  4  0 //Secuencia de Item por Factura*/
   GRAD_PROD1	CHAR(3)  DEFAULT '',	/*C  3  0 //Grado de Elaboraci�n del producto 1*/
   GRAD_PROD2	CHAR(3)  DEFAULT '',	/*C  3  0 //Grado de Elaboraci�n del producto 2*/
   GRAD_PROD3	CHAR(3)  DEFAULT '',	/*C  3  0 //Grado de Elaboraci�n del producto 3*/
   C_COM_PLT1	CHAR(2)  DEFAULT '',	/*C  2  0 //Codigo del componente plastico 1*/
   N_COM_PLT1	VARCHAR(26)  DEFAULT '',	/*C 26  0 //Nombre del componente plastico 1*/
   P_COM_PLT1	NUMERIC(3,0) DEFAULT 0,	/*N  3  0 //Porcentaje del componente plastico 1*/
   C_COM_PLT2	CHAR(2)  DEFAULT '',	/*C  2  0 //Codigo del componente plastico 2*/
   N_COM_PLT2	VARCHAR(27)  DEFAULT '',	/*C 27  0 //Nombre del componente plastico 2*/
   P_COM_PLT2	NUMERIC(2,0) DEFAULT 0,	/*N  2  0 //Porcentaje del componente plastico 2*/
   COD_SOPORT	CHAR(2)  DEFAULT '',	/*C 2  0 //Soporte*/
   N_SOPORTE 	VARCHAR(25)  DEFAULT '',	/*C 25  0 //Nombre de Marca de Vehiculo*/
   COD_TNT1  	CHAR(2)  DEFAULT '',	/*C  2  0 //Codigo del Tejido y no Tejido 1*/
   N_TNT1    	VARCHAR(25)  DEFAULT '',	/*C 25  0 //Nombre del Tejido y no Tejido 1*/
   P_TNT1    	CHAR(2)  DEFAULT '',	/*C  2  0 //Porcentaje del Tejido y no Tejido 1*/
   COD_TNT2  	CHAR(2)  DEFAULT '',	/*C  2  0 //Codigo del Tejido y no Tejido 2*/
   N_TNT2    	VARCHAR(25)  DEFAULT '',	/*C 25  0 //Nombre del Tejido y no Tejido 2*/
   P_TNT2    	CHAR(2)  DEFAULT '',	/*C  2  0 //Porcentaje del Tejido y no Tejido 2*/
   GRADO_ELAB	CHAR(2)  DEFAULT '',	/*C  2  0 //Grado de Elaboracion*/
   C_COLOR   	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo del Color*/
   N_COLOR   	VARCHAR(27)  DEFAULT '',	/*C 27  0 //Nombre del Color*/
   C_ACABADO 	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo del Acabado*/
   N_ACABADO 	VARCHAR(27)  DEFAULT '',	/*C 27  0 //Nombre del Acabado*/
   C_CALIDAD 	CHAR(2)  DEFAULT '',	/*C  2  0 //Codigo del Calidad*/
   N_CALIDAD 	VARCHAR(27)  DEFAULT '',	/*C 27  0 //Nombre del Calidad*/
   ESPESOR1  	DECIMAL(6,3) DEFAULT 0.000,	/*N  6  3 //Espesor 1*/
   ESPESOR2  	DECIMAL(6,3) DEFAULT 0.000,	/*N  6  3 //Espesor 2*/
   GRAMAJE   	DECIMAL(7,2) DEFAULT 0.00,	/*N  7  2 //Gramaje*/
   ANCHO       	DECIMAL(7,3) DEFAULT 0.000,	/*N  7  3 //Ancho*/
   UNIDAD    	CHAR(3)  DEFAULT '',	/*C  3  0 //Unidad de Medida*/
   PLASTIFIC 	NUMERIC(3,0) DEFAULT 0,	/*N  3  0 //Plastificante*/
   OBSERVAC1 	VARCHAR(100)  DEFAULT '',	/*C100  0 //Observaciones*/
   PRIMARY KEY(N_ORDEN,NUME_SECUP,NUME_SECUF,NUM_ITEM));
   CREATE INDEX PLT ON PLT(N_ORDEN);

/* NEU(DESCRIPCIONES MINIMIAS PARA NEUMATICOS)*/
CREATE TABLE IF NOT EXISTS NEU(
   N_ORDEN   	CHAR(11) NOT NULL,	/*C  9  0 //Numero de Orden*/
   NUME_SECUP	CHAR(3) NOT NULL,	/*C  2  0 //Secuencia de Proveedor*/
   NUME_SECUF	CHAR(3) NOT NULL,	/*C  3  0 //Secuencia de Factura*/
   NUM_ITEM  	NUMERIC(4,0) NOT NULL,	/*N  4  0 //Secuencia de Item por Factura*/
   USO       	CHAR(3)  DEFAULT '',	/*C  3  0 //Uso*/
   MATERIAL  	CHAR(2)  DEFAULT '',	/*C  2  0 //Material de Carcasa 1*/
   MATERIAL2 	CHAR(2)  DEFAULT '',	/*C  2  0 //Material de Carcasa 2*/
   NOMENCLA  	CHAR(2)  DEFAULT '',	/*C  2  0 //Tipo de Nomenclatura*/
   ANCHO01   	DECIMAL(7,2) DEFAULT 0.00,	/*N  7  2 //Ancho de la Seccion Numerica*/
   ANCHO02   	CHAR(1)  DEFAULT '',	/*C  1    //Ancho de la Seccion Alfanumerica*/
   ANCHO03   	DECIMAL(8,2) DEFAULT 0.00,	/*N  8  2 //Ancho de la Seccion Milimetrica*/
   SERIE     	NUMERIC(3,0) DEFAULT 0,	/*N  3  0 //Serie o Relacion de Aspecto*/
   DIAMETRO  	DECIMAL(6,2) DEFAULT 0.00,	/*N  6  2 //Diametro del Aro*/
   CONSTRUC  	CHAR(3)  DEFAULT '',	/*C  3  0 //Tipo de Construccion*/
   INDICE    	CHAR(3)  DEFAULT '',	/*C  3  0 //Indice de Carga*/
   VELOCIDAD 	CHAR(1)  DEFAULT '',	/*C  1  0 //Codigo de Velocidad*/
   SEGURIDAD 	CHAR(90)  DEFAULT '',	/*C  8  0 //Codigo de Seguridad*/
   OBSERVAC1 	VARCHAR(100)  DEFAULT '',	/*C100  0 //Observaciones*/
   PRIMARY KEY(N_ORDEN,NUME_SECUP,NUME_SECUF,NUM_ITEM));
   CREATE INDEX NEU ON NEU(N_ORDEN);

/* PIL(DESCRIPCIONES MINIMAS PARA PILAS Y BATERIAS)*/
CREATE TABLE IF NOT EXISTS PIL(
   N_ORDEN   	CHAR(11) NOT NULL,	/*C  9  0 //Numero de Orden*/
   NUME_SECUP	CHAR(3) NOT NULL,	/*C  2  0 //Secuencia de Proveedor*/
   NUME_SECUF	CHAR(3) NOT NULL,	/*C  3  0 //Secuencia de Factura*/
   NUM_ITEM  	NUMERIC(4,0) NOT NULL,	/*N  4  0 //Secuencia de Item por Factura*/
   NOMBRE    	VARCHAR(30)  DEFAULT '',	/*C 30  0 //Nombre*/
   COD_TIPO  	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Tipo*/
   TIPO      	VARCHAR(20)  DEFAULT '',	/*C 20  0 //Tipo*/
   COD_FORMA 	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Forma*/
   FORMA     	VARCHAR(20)  DEFAULT '',	/*C 20  0 //Forma*/
   COD_DESIG 	CHAR(4)  DEFAULT '',	/*C  3  0 //Codigo de Designacion*/
   DESIGNA   	VARCHAR(20)  DEFAULT '',	/*C 20  0 //Designacion*/
   DIMENSIO  	VARCHAR(15)  DEFAULT '',	/*C 15  0 //Dimensiones*/
   VOLTAJE   	DECIMAL(5,2) DEFAULT 0.00,	/*N  5  2 //Voltaje*/
   OBSERVAC  	VARCHAR(100)  DEFAULT '',	/*C100  0 //Observaciones*/
   PRIMARY KEY(N_ORDEN,NUME_SECUP,NUME_SECUF,NUM_ITEM));
   CREATE INDEX PIL ON PIL(N_ORDEN);

/*OJT(DESCRICIONES MINIMAS PARA ANILLOS,OJALILLOS Y OJETES )*/
CREATE TABLE IF NOT EXISTS OJT(
   N_ORDEN   	CHAR(11) NOT NULL,	/*C  9  0 //Numero de Orden*/
   NUME_SECUP	CHAR(3) NOT NULL,	/*C  2  0 //Secuencia de Proveedor*/
   NUME_SECUF	CHAR(3) NOT NULL,	/*C  3  0 //Secuencia de Factura*/
   NUM_ITEM  	NUMERIC(4,0) NOT NULL,	/*N  4  0 //Secuencia de Item por Factura*/
   NOMBRE    	VARCHAR(30)  DEFAULT '',	/*C 30  0 //Nombre*/
   COD_TIPO  	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Tipo*/
   TIPO      	VARCHAR(20)  DEFAULT '',	/*C 20  0 //Tipo*/
   COD_ACABA 	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Acabado*/
   ACABADO   	VARCHAR(20)  DEFAULT '',	/*C 20  0 //Acabado*/
   COD_USO   	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Uso*/
   USO       	VARCHAR(20)  DEFAULT '',	/*C 20  0 //Uso*/
   DIMENSIO  	VARCHAR(17)  DEFAULT '',	/*C 17  0 //Dimensiones*/
   COD_MAT   	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Material*/
   MATERIAL  	VARCHAR(20)  DEFAULT '',	/*C 20  0 //Material*/
   OBSERVAC  	VARCHAR(100)  DEFAULT '',	/*C100  0 //Observaciones*/
   PRIMARY KEY(N_ORDEN,NUME_SECUP,NUME_SECUF,NUM_ITEM));
   CREATE INDEX OJT ON OJT(N_ORDEN);

/* COM(DESCRIPCIONES MINIMAS PARA COMPUTADORAS Y PARTES DE COMPUTADORAS)*/
CREATE TABLE IF NOT EXISTS COM(
   N_ORDEN   	CHAR(11) NOT NULL,	/*C  9  0 //Numero de Orden*/
   NUME_SECUP	CHAR(3) NOT NULL,	/*C  2  0 //Secuencia de Proveedor*/
   NUME_SECUF	CHAR(3) NOT NULL,	/*C  3  0 //Secuencia de Factura*/
   NUM_ITEM  	NUMERIC(4,0) NOT NULL,	/*N  4  0 //Secuencia de Item por Factura*/
   TTIPO     	CHAR(1)  DEFAULT '',	/*C  1  0 //TIPO : Computadora Otros*/
   COD_NOMBRE	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de nombre*/
   NOMBRE    	VARCHAR(30)  DEFAULT '',	/*C 30  0 //Nombre*/
   COD_MARCA 	CHAR(4)  DEFAULT '',	/*C  4  0 //Codigo de Marca*/
   MARCA     	VARCHAR(30)  DEFAULT '',	/*C 30  0 //Marca*/
   CODTIPO   	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Tipo*/
   TIPO      	VARCHAR(30)  DEFAULT '',	/*C 30  0 //Tipo*/
   CODPROCESA	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Procesador*/
   PROCESADOR	VARCHAR(30)  DEFAULT '',	/*C 30  0 //Procesador*/
   CODMONITOR	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Monitor*/
   MONITOR   	VARCHAR(30)  DEFAULT '',	/*C 30  0 //Monitor*/
   CODTECLADO	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Teclado*/
   TECLADO   	VARCHAR(30)  DEFAULT '',	/*C 30  0 //Teclado*/
   CODVELPROC	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Velocidad Procesador*/
   VELPROCESA	VARCHAR(30)  DEFAULT '',	/*C 30  0 //Velocidad Procesador*/
   CODVELECTO	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Velocidad Lectora*/
   VELECTORA 	VARCHAR(30)  DEFAULT '',	/*C 30  0 //Velocidad Lectora*/
   CODVELDVD 	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Velocidad DVD*/
   VELDVD    	VARCHAR(30)  DEFAULT '',	/*C 30  0 //Velocidad DVD*/
   CODCAPRAM 	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Capacidad RAM*/
   CAPRAM    	VARCHAR(30)  DEFAULT '',	/*C 30  0 //Capacidad RAM*/
   CODCAPDD  	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Capacidad Disco Duro*/
   CAPDD     	VARCHAR(30)  DEFAULT '',	/*C 30  0 //Capacidad Disco Duro*/
   CODTAMONIT	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Tamano de Monitor*/
   TAMONITO  	VARCHAR(30)  DEFAULT '',	/*C 30  0 //Tamano de Monitor*/
   CODVELBUS 	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Velocidad del Bus*/
   VELBUS    	VARCHAR(30)  DEFAULT '',	/*C 30  0 //Velocidad de Bus*/
   CODVELTRAN	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Velocidad de la Transfe*/
   VELTRANS  	VARCHAR(30)  DEFAULT '',	/*C 30  0 //Velocidad de Transferencia*/
   CODCAPACID	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Capacidad*/
   CAPACIDAD 	VARCHAR(30)  DEFAULT '',	/*C 30  0 //Capacidad*/
   CODANCOL  	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Ancho de la columna*/
   ANCHOCOL  	VARCHAR(30)  DEFAULT '',	/*C 30  0 //Ancho de la columna*/
   CODRESOL  	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Resolucion*/
   RESOLUCION	VARCHAR(30)  DEFAULT '',	/*C 30  0 //Resolucion*/
   CODCOLOR  	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de color*/
   COLOR     	VARCHAR(30)  DEFAULT '',	/*C 30  0 //Color*/
   CODTAMANO 	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Tamano*/
   TAMANO    	VARCHAR(30)  DEFAULT '',	/*C 30  0 //Tamano*/
   CODTAMPTO 	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Tamano del Punto*/
   TAMPUNTO  	VARCHAR(30)  DEFAULT '',	/*C 30  0 //Tamano del Punto*/
   CODPROFCOL	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Profundidad del color*/
   PROFCOLOR 	VARCHAR(30)  DEFAULT '',	/*C 30  0 //Profundidad del color*/
   CODPINES  	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Pines*/
   PINES     	VARCHAR(30)  DEFAULT '',	/*C 30  0 //Pines*/
   CODMODULO 	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Modulo*/
   MODULO    	VARCHAR(30)  DEFAULT '',	/*C 30  0 //Modulo*/
   CODFORMATO	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Formato*/
   FORMATO   	VARCHAR(30)  DEFAULT '',	/*C 30  0 //Formato*/
   CODINTERF 	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Interfase*/
   INTERFASE 	VARCHAR(30)  DEFAULT '',	/*C 30  0 //Interfase*/
   CODCONEXIO	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Conexion*/
   CONEXION  	VARCHAR(30)  DEFAULT '',	/*C 30  0 //Conexion*/
   CODRAM    	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Tipo Memoria RAM*/
   RAM       	VARCHAR(30)  DEFAULT '',	/*C 30  0 //Memoria RAM*/
   CODVIMPCOL	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Velocidad Imp. Color*/
   VELIMPCOL 	VARCHAR(30)  DEFAULT '',	/*C 30  0 //Velocidad Impresion Color*/
   CODREGRAB 	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Regrabacion*/
   REGRABAC  	VARCHAR(30)  DEFAULT '',	/*C 30  0 //Regrabacion*/
   PRIMARY KEY(N_ORDEN,NUME_SECUP,NUME_SECUF,NUM_ITEM));
   CREATE INDEX COM ON COM(N_ORDEN);

/* DAT(DESCRIPCIONES MINIMAS PARA REPRODUCTORES DE AUDIO Y VIDEO)*/
CREATE TABLE IF NOT EXISTS DAT(
   N_ORDEN   	CHAR(11) NOT NULL,	/*C  9  0 //Numero de Orden*/
   NUME_SECUP	CHAR(3) NOT NULL,	/*C  2  0 //Secuencia de Proveedor*/
   NUME_SECUF	CHAR(3) NOT NULL,	/*C  3  0 //Secuencia de Factura*/
   NUM_ITEM  	NUMERIC(4,0) NOT NULL,	/*N  4  0 //Secuencia de Item por Factura*/
   COD_NOMBRE	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de nombre*/
   NOMBRE    	VARCHAR(30)  DEFAULT '',	/*C 30  0 //Nombre*/
   C_TIPODISC	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Tipo de disco*/
   TIPO_DISCO	VARCHAR(30)  DEFAULT '',	/*C 30  0 //Tipo de disco*/
   C_LONGDIA 	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Longitud de diametro*/
   LONG_DIAME	VARCHAR(30)  DEFAULT '',	/*C 30  0 //Longitud de diametro*/
   CCAP_ALMA 	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Capacidad de Almacenamiento*/
   CAP_ALMACE	VARCHAR(30)  DEFAULT '',	/*C 30  0 //Capacidad de Almacenamiento*/
   CTIPOMAT  	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Tipo de Material*/
   TIPO_MATER	VARCHAR(30)  DEFAULT '',	/*C 30  0 //Tipo de Material*/
   CODTIPO   	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Tipo*/
   TIPO      	VARCHAR(30)  DEFAULT '',	/*C 30  0 //Tipo*/
   CAP_MAXIMA	NUMERIC(3,0) DEFAULT 0,	/*N  3  0 //Capacidad Maxima*/
   NUMAX_DRIV	NUMERIC(3,0) DEFAULT 0,	/*N  3  0 //Numero Maximo de Drives*/
   CAP_DDURO 	NUMERIC(3,0) DEFAULT 0,	/*N  3  0 //Capacidad de Disco Duro*/
   CEMP_PRES 	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Empaque de Presentacion*/
   EMP_PRESEN	VARCHAR(30)  DEFAULT '',	/*C 30  0 //Empaque de Presentacion*/
   DISCXEMPAQ	NUMERIC(4,0) DEFAULT 0,	/*N  4  0 //Discos por Empaque*/
   NUMEMPAQ  	NUMERIC(6,0) DEFAULT 0,	/*N  6  0 //Numero de Empaques*/
   CTIEMGRAB 	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Tiempo de Grabacion*/
   TIEM_GRAB 	VARCHAR(30)  DEFAULT '',	/*C 30  0 //Tiempo de Grabacion*/
   NUM_LECTCD	NUMERIC(3,0) DEFAULT 0,	/*N  3  0 //Numero de Lectores de CD*/
   NUM_LECDVD	NUMERIC(3,0) DEFAULT 0,	/*N  3  0 //Numero de Lectores de DVD*/
   CFORMATO  	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Formato*/
   FORMATO   	VARCHAR(30)  DEFAULT '',	/*C 30  0 //Formato*/
   CCARACTE  	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Caracteristica CD*/
   CARACTERIS	VARCHAR(30)  DEFAULT '',	/*C 30  0 //Caracteristica CD*/
   CAR_DVD   	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Caracteristica DVD*/
   CARACDVD  	VARCHAR(20)  DEFAULT '',	/*C 20  0 //Caracteristica DVD*/
   CVGRABCD  	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Velocidad de Grabacion CD*/
   VELGRABCD 	VARCHAR(30)  DEFAULT '',	/*C 30  0 //Velocidad de Grabacion CD*/
   CVGRABDVD 	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Velocidad de Grabacion DVD*/
   VELGRABDVD	VARCHAR(30)  DEFAULT '',	/*C 30  0 //Velocidad de Grabacion DVD*/
   PRIMARY KEY(N_ORDEN,NUME_SECUP,NUME_SECUF,NUM_ITEM));
   CREATE INDEX DAT ON DAT(N_ORDEN);

/* VEH(DESCRIPCIONES MINIMAS PARA VEHICULOS Y MOTOS) */
CREATE TABLE IF NOT EXISTS VEH(
   N_ORDEN   	CHAR(11) NOT NULL,	/*C  9  0 //Numero de Orden*/
   NUME_SECUP	CHAR(3) NOT NULL,	/*C  2  0 //Secuencia de Proveedor*/
   NUME_SECUF	CHAR(3) NOT NULL,	/*C  3  0 //Secuencia de Factura*/
   NUM_ITEM  	NUMERIC(4,0) NOT NULL,	/*N  4  0 //Secuencia de Item por Factura*/
   COD_NOMBRE	CHAR(4)  DEFAULT '',	/*C  4  0 //Codigo de Nombre de Vehiculo*/
   N_NOMBRE  	VARCHAR(27)  DEFAULT '',	/*C 27  0 //Nombre de Vehiculo*/
   COD_MARCA 	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Marca de Vehiculo*/
   N_MARCA   	VARCHAR(27)  DEFAULT '',	/*C 27  0 //Nombre de Marca de Vehiculo*/
   MODELO    	VARCHAR(27)  DEFAULT '',	/*C 27  0 //modelo    (modelo)*/
   ARO_ANIO  	CHAR(4)  DEFAULT '',	/*C  4  0 //aro a�o*/
   COD_CARROC	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Carroceria de Vehiculo*/
   N_CARROC  	VARCHAR(27)  DEFAULT '',	/*C 27  0 //Nombre de Carroceria de Vehiculo*/
   COD_COLOR 	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Color de Vehiculo*/
   N_COLOR   	VARCHAR(27)  DEFAULT '',	/*C 27  0 //Nombre de Color de Vehiculo*/
   COD_COMBUS	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Combustible de Vehiculo*/
   N_COMBUS  	VARCHAR(27)  DEFAULT '',	/*C 27  0 //Nombre de Combustible de Vehiculo*/
   CILIND    	CHAR(6)  DEFAULT '',	/*C  6  0 //Cilindrada*/
   CHASIS    	VARCHAR(20)  DEFAULT '',	/*C 20  0 //Chasis*/
   VIN       	VARCHAR(18)  DEFAULT '',	/*C 18  0 //VIN*/
   MOTOR     	VARCHAR(20)  DEFAULT '',	/*C 20  0 //NUMERO DEL MOTOR*/
   ASIENTOS  	NUMERIC(2,0) DEFAULT 0,	/*N  2  0 //NUMERO DE ASIENTOS*/
   EJES      	NUMERIC(2,0) DEFAULT 0,	/*N  2  0 //NUMERO DE EJES*/
   COD_TRACC 	CHAR(4)  DEFAULT '',	/*C  4  0 //Codigo de Tracci�n de Vehiculo*/
   N_TRACC   	VARCHAR(27)  DEFAULT '',	/*C 27  0 //Nombre de Tracci�n de Vehiculo*/
   COD_TRANS 	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Transmisi�n de Vehiculo*/
   N_TRANS   	VARCHAR(27)  DEFAULT '',	/*C 27  0 //Nombre de Transmisi�n de Vehiculo*/
   PUERTAS   	NUMERIC(2,0) DEFAULT 0,	/*N  2  0 //Cantidad de Puertas del Vehiculo*/
   CILINDROS 	NUMERIC(2,0) DEFAULT 0,	/*N  2  0 //Cantidad de Cilindros del Vehiculo*/
   VELOCIDAD 	NUMERIC(2,0) DEFAULT 0,	/*N  2  0 //Cantidad de Velocidades del Vehiculo*/
   EXCEPCION 	CHAR(2)  DEFAULT '',	/*C  2  0 //Codigo de Exepcion del VIN*/
   COD_MODELO	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Modelo*/
   VERSION   	CHAR(22) DEFAULT '',	/*C  8  0 //Version*/
   COD_COLOR2	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de color 2*/
   N_COLOR2  	VARCHAR(15)  DEFAULT '',	/*C 15  0 //Nombre de color 2*/
   PASAJEROS 	NUMERIC(2,0) DEFAULT 0,	/*N  2  0 //Pasajeros*/
   POTENCIA1 	DECIMAL(7,2) DEFAULT 0.00,	/*N  7  2 //Potencia motor kW @rpm*/
   POTENCIA2 	NUMERIC(5,0) DEFAULT 0,	/*N  5  0 //Potencia motor kW @rpm*/
   REL_POTEN 	DECIMAL(6,2) DEFAULT 0.00,	/*N  6  2 //Relaci�n Potencia - Peso Bruto*/
   LARGO     	NUMERIC(5,0) DEFAULT 0,	/*N  5  0 //Largo del vehiculo en mm*/
   ANCHO     	NUMERIC(5,0) DEFAULT 0,	/*N  5  0 //Ancho del vehiculo en mm*/
   ALTURA    	NUMERIC(5,0) DEFAULT 0,	/*N  5  0 //Altura del vehiculo en mm*/
   PESO_COMBI	DECIMAL(6,2) DEFAULT 0.00 ,	/*N  6  2 //Peso Bruto Vehicular Combinado Maximo*/
   PESO_VEHIC	NUMERIC(6,0) DEFAULT 0,	/*N  6  0 //Peso Bruto Vehicular en kilogramos*/
   PESO_NETO 	NUMERIC(6,0) DEFAULT 0,	/*N  6  0 //Peso Neto*/
   CARGA_UTIL	NUMERIC(6,0) DEFAULT 0,	/*N  6  0 //Carga util en kilogramos*/
   EJE_DELANT	NUMERIC(6,0) DEFAULT 0,	/*N  6  0 //Peso maximo por Eje delantero en kilogramos*/
   EJE_POST1 	NUMERIC(6,0) DEFAULT 0,	/*N  6  0 //Peso maximo por Eje posterior 1 en kilogramos*/
   EJE_POST2 	NUMERIC(6,0) DEFAULT 0,	/*N  6  0 //Peso maximo por Eje posterior 2 en kilogramos*/
   EJE_POST3 	NUMERIC(6,0) DEFAULT 0,	/*N  6  0 //Peso maximo por Eje posterior 3 en kilogramos*/
   DISTANCIA 	NUMERIC(5,0) DEFAULT 0,	/*N  5  0 //Distancia entre Ejes en mm*/
   MARCA_CARR	VARCHAR(18)  DEFAULT '',	/*C 18  0 //Marca de carroceria*/
   SERIE_CARR	VARCHAR(18)  DEFAULT '',	/*C 18  0 //Numero d Serie de carroceria*/
   NUM_RUEDAS	NUMERIC(2,0) DEFAULT 0,	/*N  2  0 //Numero de ruedas*/
   AROS      	CHAR(5)  DEFAULT '',	/*C  4  0 //Medida de Aros en pulgadas*/
   NEUMAT_1  	CHAR(10)  DEFAULT '',	/*C 10  0 //Medidas de Neumaticos 1*/
   NEUMAT_2  	CHAR(10)  DEFAULT '',	/*C 10  0 //Medidas de Neumaticos 2*/
   SUSP_DELAN	VARCHAR(22)  DEFAULT '',	/*C 22  0 //Tipo de Suspension Delantera*/
   SUSP_POSTE	VARCHAR(22)  DEFAULT '',	/*C 22  0 //Tipo de Suspension Posterior*/
   REVISA1   	VARCHAR(16)  DEFAULT '',	/*C 16  0 //Numero de Revisa1*/
   FOB_EXPORT	NUMERIC(9,2) DEFAULT 0,	/*N  6  0 Valor FOB en pais de exportaci�n en d�lares*/
   GTOS_REPAR	NUMERIC(6,0) DEFAULT 0,	/*N  6  0 Gtos.  de color 2*/
   SNTT      	CHAR(1)  DEFAULT '',	/*C  1  0 Indicador de SNTT*/
   HOMOLOGAC 	VARCHAR(12)  DEFAULT '',	/*C 12  0 //Numero de registro de homologacion*/
   FABRICANTE	VARCHAR(20)  DEFAULT '',	/*C 20  0 //Nombre del fabricante*/
   ANIO_MODEL	CHAR(4)  DEFAULT '',	/*C  4  0 //A�o del modelo*/
   OBSERVACIO	VARCHAR(90)  DEFAULT '',	/*C 90  0 //Observaciones*/
   EXTENSION 	VARCHAR(15)  DEFAULT '',	/*C 15  0 //Extension*/
   COD_COLOR3   CHAR(3) DEFAULT "",             /*Codigo de color 3*/
   N_COLOR3     VARCHAR(15) DEFAULT "",         /*Nombre de color 3 */
   COD_COLOR4   CHAR(3) DEFAULT "",             /*Codigo de color 4*/
   N_COLOR4     VARCHAR(15) DEFAULT "",         /* Nombre de color 4*/
   ESTADO       CHAR(2) DEFAULT "",             /* C  2  0 //Estado de la Mercancia*/
   ENCENDIDO    CHAR(3) DEFAULT "",             /*C  3  0 //Tipo de Encendido*/
   KILOMETRA    DECIMAL(10,2) DEFAULT 0.00,     /*Kilometraje*/
   N_ENCENDI    VARCHAR(27) DEFAULT "",         /* 0 Nombre de Encendido*/
   REVISA2      VARCHAR(40) DEFAULT "",         /*C 40  0 Numero de Revisa2 (Pedido de James)*/
   CERTI_REG    VARCHAR(25) DEFAULT "",         /*  0Numero de Certificado (Pedido de James)*/
   SUBPARTIDA   CHAR(2)   DEFAULT '',           /*C  2  0 //Subpartida*/
   CHASIS_TEC   VARCHAR(19) DEFAULT '',         /*C 19  0 //Chasis para Tecadasa*/
   VIN_TEC      VARCHAR(19) DEFAULT '',         /*C 19  0 //Vin para Tecadsa*/
   MOTOR_TEC    VARCHAR(20) DEFAULT '',         /*C 20  0 //Motor para Tecadsa*/
   AROS2        CHAR(5) DEFAULT "",             /* Solo para las Americas */
   N_PUERTAS 	NUMERIC(2,0) DEFAULT 0,	        /*N  2  0 */
   COD_REFRI	CHAR(3)  DEFAULT '',       	/* C  3  1 */
   FRENO_DEL 	CHAR(3)  DEFAULT '',	        /*C  3  1 */
   FRENO_POS	CHAR(3)  DEFAULT '',	        /* C  3  1 */
   TIPO_MOTO	CHAR(3)  DEFAULT '',	        /* C  3  1 */
   CAMBIOS  	NUMERIC(2,0) DEFAULT 0,	        /* N  2  0 */
   PESO_UNITA   VARCHAR(20) DEFAULT '',         /*C 20  0 */
   MODELO_FAB   VARCHAR(30) DEFAULT '',         /*Modelo de Fabricacion*/
   PRIMARY KEY(N_ORDEN,NUME_SECUP,NUME_SECUF,NUM_ITEM));
   CREATE INDEX VEH ON VEH(N_ORDEN);

/*ACC (ACCESORIOS DE VEHICULOS DETALLADOS EN DESCRIPCIONES MINIMAS DE VEHICULOS)*/
CREATE TABLE IF NOT EXISTS ACC(	
   N_ORDEN   	CHAR(11) NOT NULL,	/*C  9  0 //Numero de Orden*/
   NUME_SECUP	CHAR(3) NOT NULL,	/*C  2  0 //Secuencia de Proveedor*/
   NUME_SECUF	CHAR(3) NOT NULL,	/*C  3  0 //Secuencia de Factura*/
   NUM_ITEM  	NUMERIC(4,0) NOT NULL,	/*N  4  0 //Secuencia de Item por Factura*/
   CORREL       CHAR(2) NOT NULL,           /* CORRELACION DE CLAVES */
   COD_ACC   	CHAR(3)  DEFAULT '',	/*C  3  0 //Codigo de Carroceria de Vehiculo*/
   NOM_ACC   	CHAR(27) DEFAULT '',	/*C 27  0 //Nombre de Carroceria de Vehiculo*/
   PRIMARY KEY(N_ORDEN,NUME_SECUP,NUME_SECUF,NUM_ITEM,CORREL));
   CREATE INDEX ACC ON ACC(N_ORDEN);

/* SAN(DESCRIPCIONES MINIMAS PARA SANITARIOS) */
CREATE TABLE IF NOT EXISTS SAN(	
   N_ORDEN   	CHAR(11) NOT NULL,	    /*C  9  0 //Numero de Orden*/
   NUME_SECUP	CHAR(3) NOT NULL,  	    /*C  2  0 //Secuencia de Proveedor*/
   NUME_SECUF	CHAR(3) NOT NULL,	    /*C  3  0 //Secuencia de Factura*/
   NUM_ITEM  	NUMERIC(4,0) NOT NULL,     /*N  4  0 //Secuencia de Item por Factura*/
   COD_NOMBRE	CHAR(3) DEFAULT "",         /*  0 //Codigo de Nombre de Sanitarios*/
   NOMBRE       VARCHAR(30) DEFAULT "",     /*  0 //Nombre de Sanitarios*/
   COD_TIPO  	CHAR(3) DEFAULT "",         /*  0 //Codigo de Tipo*/
   TIPO         VARCHAR(20) DEFAULT "",     /*  0 //Nombre de Tipo*/
   COD_TARO  	CHAR(3) DEFAULT "",         /* //Codigo de Tipo de Aro*/
   TARO         VARCHAR(20) DEFAULT "",     /*  0 //Nombre de Tipo de Aro*/
   COD_USO   	CHAR(3) DEFAULT "",         /*  0 //Codigo de Tipo de Usuario*/
   TUSUARIO     VARCHAR(20) DEFAULT "",     /*  0 //Nombre de Tipo de Usuario*/
   COD_ACCION	CHAR(3) DEFAULT "",         /*  0 //Si es blando: CON � DES*/
   TACCIONA     VARCHAR(20) DEFAULT "",     /*  0 //Numero de foco*/
   COD_VALV  	CHAR(3) DEFAULT "",         /*  0 //Si es monofocales:ESF, CIL � COM*/
   TVALVULA     VARCHAR(20) DEFAULT "",     /*  0 //Tipo de Color*/
   COD_ASTO  	CHAR(3) DEFAULT "",         /*  0 //Tratamiento*/
   TASIENTO     VARCHAR(20) DEFAULT "",     /*  0 //Acabado*/
   COD_MASTO 	CHAR(3) DEFAULT "",         /*  0 //Asiento de Material de Asiento*/
   TMASIENTO    VARCHAR(20) DEFAULT "",     /*  0 //Nombre de Material de Asiento*/
   COD_CALIDA	CHAR(3) DEFAULT "",         /*  0 //Codigo de Calidad*/
   CALIDAD      VARCHAR(20) DEFAULT "",     /*  0 //Nombre de Calidad*/
   COD_COLOR 	CHAR(3) DEFAULT "",         /*  0 //Codigo de Color*/
   COLOR        VARCHAR(20) DEFAULT "",     /*  0 //Nombre de Color*/
   COD_MAT   	CHAR(3) DEFAULT "",         /*  0 //Codigo de Material*/
   MATERIAL     VARCHAR(20) DEFAULT "",     /*  0 //Nombre de Material*/
   COD_CONSU 	CHAR(3) DEFAULT "",         /*  0 //Codigo de Consumo*/
   CONSUMO      VARCHAR(20) DEFAULT "",     /*  0 //Nombre de Consumo */
   OBSERVAC1    VARCHAR(90) DEFAULT "",     /*  0 //Observaciones*/
   PRIMARY KEY(N_ORDEN,NUME_SECUP,NUME_SECUF,NUM_ITEM));
   CREATE INDEX SAN ON SAN(N_ORDEN);

/* BLD(DESCRIPCIONES PARA BALDOSAS Y CERAMICOS) */
CREATE TABLE IF NOT EXISTS BLD(	
   N_ORDEN   	CHAR(11) NOT NULL,	    /*C  9  0 //Numero de Orden*/
   NUME_SECUP	CHAR(3) NOT NULL,  	    /*C  2  0 //Secuencia de Proveedor*/
   NUME_SECUF	CHAR(3) NOT NULL,	    /*C  3  0 //Secuencia de Factura*/
   NUM_ITEM  	NUMERIC(4,0) NOT NULL,     /*N  4  0 //Secuencia de Item por Factura*/
   COD_NOMBRE	CHAR(4) DEFAULT "",         /*  0 //Codigo de Nombre de Sanitarios*/
   NOMBRE       VARCHAR(30) DEFAULT "",     /*  0 //Nombre de Sanitarios*/
   COD_ACABAD	CHAR(3) DEFAULT "",         /*  0 //Codigo de Acabado*/
   ACABADO      VARCHAR(20) DEFAULT "",     /*  0 //Acabado*/
   COD_MATER 	CHAR(3) DEFAULT "",         /*  0 //Codigo de Materia*/
   MATERIA      VARCHAR(20) DEFAULT "",     /*  0 //Materia*/
   COD_MOLDEO	CHAR(3) DEFAULT "",         /*  0 //Codigo de Moldeo*/
   MOLDEO       VARCHAR(20) DEFAULT "",     /*  0 //Moldeo*/
   COD_USO   	CHAR(3) DEFAULT "",         /*  0 //Codigo del Uso*/
   USO          VARCHAR(20) DEFAULT "",     /*  0 //Uso*/
   COD_COCC  	CHAR(3) DEFAULT "",         /*  0 //Codigo de coccion*/
   COCCION      VARCHAR(20) DEFAULT "",   /*  0 //Coccion*/
   COD_COLOR 	CHAR(3) DEFAULT "",         /*  0 //Codigo del Color*/
   COLOR        VARCHAR(20) DEFAULT "",     /*  0 //Color*/
   LARGO        NUMERIC(9,2) DEFAULT 0,	    /*  0 //Largo en cm*/
   ANCHO        NUMERIC(9,2) DEFAULT 0,     /*  0 //Ancho en cm*/
   ESPESOR      NUMERIC(9,2) DEFAULT 0,	    /*  0 //Espesor en mm*/
   OBSERVAC1    VARCHAR(90) DEFAULT "",     /*  0 //Observaciones*/
   COD_MATER2	CHAR(3) DEFAULT "",         /*C  3  0*/
   MATERIA2     VARCHAR(20) DEFAULT "",     /*C 20  0*/
   COD_MATER3	CHAR(3) DEFAULT "",         /*C  3  0*/
   MATERIA3     VARCHAR(20) DEFAULT "",     /* C 20  0*/
   COD_MATER4	CHAR(3) DEFAULT "",         /*C  3  0*/
   MATERIA4     VARCHAR(20) DEFAULT "",     /*C 20  0*/
   COD_MATER5	CHAR(3) DEFAULT "",         /*C  3  0*/
   MATERIA5     VARCHAR(20) DEFAULT "",     /*C 20  0*/
   ABSORCION 	CHAR(3) DEFAULT "",         /*C  3  0*/
   PRIMARY KEY(N_ORDEN,NUME_SECUP,NUME_SECUF,NUM_ITEM));
   CREATE INDEX BLD ON BLD(N_ORDEN);

/* AVJ(DESCRIPCIONES DE ARTICULOS DE VIAJE) */
CREATE TABLE IF NOT EXISTS AVJ(	
   N_ORDEN   	CHAR(11) NOT NULL,	    /*C  9  0 //Numero de Orden*/
   NUME_SECUP	CHAR(3) NOT NULL,  	    /*C  2  0 //Secuencia de Proveedor*/
   NUME_SECUF	CHAR(3) NOT NULL,	    /*C  3  0 //Secuencia de Factura*/
   NUM_ITEM  	NUMERIC(4,0) NOT NULL,     /*N  4  0 //Secuencia de Item por Factura*/
   COD_NOMBRE	CHAR(3) DEFAULT "",         /*  0 //Codigo de Nombre de Sanitarios*/
   NOMBRE       VARCHAR(30) DEFAULT "",     /*  0 //Nombre de Sanitarios*/
   COD_TMAT  	CHAR(3) DEFAULT "",         /*C  3  0 //Codigo de Tipo de Material*/
   TIP_MAT      VARCHAR(20) DEFAULT "",     /*C 20  0 //Tipo de Material*/
   COD_MAT1  	CHAR(3) DEFAULT "",         /*C  3  0 //Codigo de Material 1*/
   MATERIAL1    VARCHAR(20) DEFAULT "",     /*C 20  0 //Material 1*/
   POR_MAT1     NUMERIC(3,0) DEFAULT 0,	    /*Porcentaje Material 1*/
   COD_MAT2  	CHAR(3) DEFAULT "",         /*C  3  0 //Codigo de Material 2*/
   MATERIAL2    VARCHAR(20) DEFAULT "",     /*C 20  0 //Material 2*/
   POR_MAT2     NUMERIC(3,0) DEFAULT 0,	    /*Porcentaje Material 2*/
   COD_MAT3  	CHAR(3) DEFAULT "",         /*C  3  0 //Codigo de Material 3*/
   MATERIAL3    VARCHAR(20) DEFAULT "",     /*C 20  0 //Material 3*/
   POR_MAT3     NUMERIC(3,0) DEFAULT 0,	    /*Porcentaje Material 3*/
   COD_FORRO 	CHAR(3) DEFAULT "",         /*C  3  0 //Codigo del Forro*/
   FORRO        VARCHAR(20) DEFAULT "",     /*C 20  0 //Forro*/
   COD_ACAB1 	CHAR(3) DEFAULT "",         /*C  3  0 //Codigo de Acabado 1*/
   ACABADO1     VARCHAR(20) DEFAULT "",     /*C 20  0 //Acabado 1*/
   COD_ACAB2 	CHAR(3) DEFAULT "",         /*C  3  0 //Codigo de Acabado 2*/
   ACABADO2     VARCHAR(20) DEFAULT "",     /*C 20  0 //Acabado 2*/
   COD_ACC1  	CHAR(3) DEFAULT "",         /*C  3  0 //Codigo accesorio1*/
   ACCESORIO1   VARCHAR(20) DEFAULT "",     /*C 20  0 //Accesorio1*/
   COD_ACC2  	CHAR(3) DEFAULT "",         /*C  3  0 //Codigo accesorio2*/
   ACCESORIO2   VARCHAR(20) DEFAULT "",     /*C 20  0 //Accesorio2*/
   COD_ACC3  	CHAR(3) DEFAULT "",         /*C  3  0 //Codigo accesorio3*/
   ACCESORIO3   VARCHAR(20) DEFAULT "",     /*C 20  0 //Accesorio3*/
   COD_APLI1 	CHAR(3) DEFAULT "",         /*C  3  0 //Codigo Aplicacion1*/
   APLICAC1     VARCHAR(20) DEFAULT "",     /*C 20  0 //Aplicacion1*/
   NUM_APLIC1   NUMERIC(3,0) DEFAULT 0,	    /*0 //Cantidad Aplicacion1*/
   COD_APLI2 	CHAR(3) DEFAULT "",         /*C  3  0 //Aplicacion2*/
   APLICAC2     VARCHAR(20) DEFAULT "",     /*C 20  0 //Aplicacion2*/
   NUM_APLIC2   NUMERIC(3,0) DEFAULT 0,	    /*Cantidad Aplicacion2*/
   COD_APLI3 	CHAR(3) DEFAULT "",         /*C  3  0 //Codigo Aplicacion3*/
   APLICAC3     VARCHAR(20) DEFAULT "",     /*C 20  0 //Aplicacion3*/
   NUM_APLIC3   NUMERIC(3,0) DEFAULT 0,	    /*Cantidad Aplicacion3*/
   ALTO         NUMERIC(7,1) DEFAULT 0.0,   /*Alto  en pulgadas*/
   LARGO        NUMERIC(7,1) DEFAULT 0.0,   /*Largo en pulgadas*/
   ANCHO        NUMERIC(7,1) DEFAULT 0.0,   /*Ancho en pulgadas*/
   COD_PRESE 	CHAR(3) DEFAULT "",         /*C  3  0 //Codigo de Presentacion*/
   PRESENTAC    VARCHAR(20) DEFAULT "",     /*C 20  0 //Presentacion*/
   PESO         NUMERIC(15,3) DEFAULT 0.000,/* //Peso*/
   COD_USO   	CHAR(3) DEFAULT "",         /*C  3  0 //Codigo de uso*/
   USO          VARCHAR(20) DEFAULT "",     /*C 20  0 //Uso*/
   OBSERVAC1    VARCHAR(90) DEFAULT "",     /*  0 //Observaciones*/
   COD_TMAT2 	CHAR(3) DEFAULT "",         /*C  3  0*/
   TIP_MAT2     VARCHAR(20) DEFAULT "",     /*C 20  0*/
   COD_TMAT3 	CHAR(3) DEFAULT "",         /*C  3  0*/
   TIP_MAT3     VARCHAR(20) DEFAULT "",     /*C 20  0*/
   CANT_ACC1    NUMERIC(3,0) DEFAULT 0.000, /*N  3  0*/
   CANT_ACC2    NUMERIC(3,0) DEFAULT 0.000, /*N  3  0*/
   CANT_ACC3    NUMERIC(3,0) DEFAULT 0.000, /*N  3  0*/
   PRIMARY KEY(N_ORDEN,NUME_SECUP,NUME_SECUF,NUM_ITEM));
   CREATE INDEX AVJ ON AVJ(N_ORDEN);

/* VHT(DESCRIPCIONES MINIMAS DE VAJILLAS) */
CREATE TABLE IF NOT EXISTS VHT(	
   N_ORDEN   	CHAR(11) NOT NULL,	    /*C  9  0 //Numero de Orden*/
   NUME_SECUP	CHAR(3) NOT NULL,  	    /*C  2  0 //Secuencia de Proveedor*/
   NUME_SECUF	CHAR(3) NOT NULL,	    /*C  3  0 //Secuencia de Factura*/
   NUM_ITEM  	NUMERIC(4,0) NOT NULL,     /*N  4  0 //Secuencia de Item por Factura*/
   COD_NOMBRE	CHAR(3) DEFAULT "",         /*  0 //Codigo de Nombre de Sanitarios*/
   NOMBRE       VARCHAR(30) DEFAULT "",     /*  0 //Nombre de Sanitarios*/
   COD_COMPO1	CHAR(3) DEFAULT "",         /*C  3  0 //Codigo de Componente 1*/
   COMPO1       VARCHAR(20) DEFAULT "",     /*C 20  0 //Componente 1*/
   POR_COMPO1   NUMERIC(5,0) DEFAULT 0,	    /* //% del Componente 1*/
   COD_COMPO2	CHAR(3) DEFAULT "",         /*C  3  0 //Codigo de Componente 2*/
   COMPO2       VARCHAR(20) DEFAULT "",     /*C 20  0 //Componente 2*/
   POR_COMPO2   NUMERIC(5,0) DEFAULT 0,	    /*% del Componente 2*/
   COD_COMPO3	CHAR(3) DEFAULT "",         /*C  3  0 //Codigo de Componente 3*/
   COMPO3       VARCHAR(20) DEFAULT "",     /*C 20  0 //Componente 3*/
   POR_COMPO3   NUMERIC(5,0) DEFAULT 0,	    /*% del Componente 3*/
   COD_ACAB  	CHAR(3) DEFAULT "",         /*C  3  0 //Codigo de Acabado*/
   ACABADO      VARCHAR(20) DEFAULT "",     /*C 20  0 //Acabado*/
   COD_COLOR 	CHAR(3) DEFAULT "",         /*C  3  0 //Codigo del Color*/
   COLOR        VARCHAR(20) DEFAULT "",     /*C 20  0 //Color*/
   COD_CALID 	CHAR(3) DEFAULT "",         /*C  3  0 //Codigo de Calidad*/
   CALIDAD      VARCHAR(20) DEFAULT "",     /*C 20  0 //Calidad*/
   COD_PROCE 	CHAR(3) DEFAULT "",         /*C  3  0 //Codigo de Proceso*/
   PROCESO      VARCHAR(20) DEFAULT "",     /*C 20  0 //Proceso*/
   COD_ACC1  	CHAR(3) DEFAULT "",         /*C  3  0 //Codigo accesorio1*/
   ACCESORIO1   VARCHAR(20) DEFAULT "",     /*C 20  0 //Accesorio1*/
   COD_ACC2  	CHAR(3) DEFAULT "",         /*C  3  0 //Codigo accesorio2*/
   ACCESORIO2   VARCHAR(20) DEFAULT "",     /*C 20  0 //Accesorio2*/
   COD_ACC3  	CHAR(3) DEFAULT "",         /*C  3  0 //Codigo accesorio3*/
   ACCESORIO3   VARCHAR(20) DEFAULT "",     /*C 20  0 //Accesorio3*/
   PRESENTAC    VARCHAR(20) DEFAULT "",     /*C 20  0 //Presentacion*/
   PESO         NUMERIC(15,3) DEFAULT 0.000,/* //Peso*/
   OBSERVAC1    VARCHAR(90) DEFAULT "",     /*  0 //Observaciones*/
   UNI_PESO     CHAR(3) DEFAULT "",
   PRIMARY KEY(N_ORDEN,NUME_SECUP,NUME_SECUF,NUM_ITEM));
   CREATE INDEX VHT ON VHT(N_ORDEN);

/* JUG(DESCRIPCIONES MINIMAS DE JUGUETES) */
CREATE TABLE IF NOT EXISTS JUG(	
   N_ORDEN   	CHAR(11) NOT NULL,	    /*C  9  0 //Numero de Orden*/
   NUME_SECUP	CHAR(3) NOT NULL,  	    /*C  2  0 //Secuencia de Proveedor*/
   NUME_SECUF	CHAR(3) NOT NULL,	    /*C  3  0 //Secuencia de Factura*/
   NUM_ITEM  	NUMERIC(4,0) NOT NULL,      /*N  4  0 //Secuencia de Item por Factura*/
   COD_NOMBRE	CHAR(3) DEFAULT "",         /*  0 //Codigo de Nombre de Sanitarios*/
   NOMBRE       VARCHAR(30) DEFAULT "",     /*  0 //Nombre de Sanitarios*/
   COD_DIGESA	CHAR(10) DEFAULT "",        /*C 10  0 //Codigo de Tipo*/
   COD_COMPO1	CHAR(3) DEFAULT "",         /*C  3  0 //Codigo de Composicion 1*/
   COMPO1       VARCHAR(40) DEFAULT "",     /*C 40  0 //Nombre de Composicion 1*/
   POR_COMPO1   NUMERIC(4,0) DEFAULT 0,     /*N  4  0 //Porcentaje de Composicion 1*/
   COD_COMPO2	CHAR(3) DEFAULT "",         /*C  3  0 //Codigo de Composicion 2*/
   COMPO2       VARCHAR(40) DEFAULT "",     /*C 40  0 //Nombre de Composicion 2*/
   POR_COMPO2   NUMERIC(4,0) DEFAULT 0,     /*N  4  0 //Porcentaje de Composicion 2*/
   COD_COMPO3	CHAR(3) DEFAULT "",         /*C  3  0 //Codigo de Composicion 3*/
   COMPO3       VARCHAR(40) DEFAULT "",     /*C 40  0 //Nombre de Composicion 3*/
   POR_COMPO3   NUMERIC(4,0) DEFAULT 0,     /*N  4  0 //Porcentaje de Composicion 3*/
   DIMENSION    VARCHAR(15) DEFAULT "",     /*C 15  0 //Largo X Ancho X Altura*/
   COD_TIPO  	CHAR(3) DEFAULT "",         /*C  3  0 //Codigo de Tipo de Juguete*/
   TIPO         VARCHAR(25) DEFAULT "",     /*C 25  0 //Tipo de Juguete*/
   N_PZ_ARM     NUMERIC(4,0) DEFAULT 0,     /*N  4  0 //Numero de piezas de armas*/
   COD_PROY  	CHAR(3) DEFAULT "",         /*C  3  0 //Codigo de Proyectil*/
   TIPO_PROY    VARCHAR(20) DEFAULT "",     /*C 20  0 //Tipo de Proyectil*/
   ACCESORIOS   VARCHAR(50) DEFAULT "",     /*C 50  0 //Accesorios*/
   COD_MOV   	CHAR(3) DEFAULT "",         /*C  3  0 //Codigo de Movimiento*/
   MOVIMIENTO   VARCHAR(45) DEFAULT "",     /*C 45  0 //Movimiento*/
   COD_USUAR 	CHAR(3) DEFAULT "",         /*C  3  0 //Codigo de Usuario*/
   USUARIO      VARCHAR(20) DEFAULT "",     /*C 20  0 //Usuario*/
   COD_PRESEN	CHAR(3) DEFAULT "",         /*C  3  0 //Codigo de PresentacionV*/
   PRESENTAC    VARCHAR(20) DEFAULT "",     /*C 20  0 //Presentacion*/
   OBSERVAC1    VARCHAR(90) DEFAULT "",     /*C 90  0 //Observaciones*/
   N_PZ_PRE     NUMERIC(4,0) DEFAULT 0,     /*N  4  0 //Numero de piezas de presentacion*/
   PRIMARY KEY(N_ORDEN,NUME_SECUP,NUME_SECUF,NUM_ITEM));
   CREATE INDEX JUG ON JUG(N_ORDEN);

/* UTI(DESCRIPCIONES MINIMAS DE UTILES) */
CREATE TABLE IF NOT EXISTS UTI(	
   N_ORDEN   	CHAR(11) NOT NULL,	    /*C  9  0 //Numero de Orden*/
   NUME_SECUP	CHAR(3) NOT NULL,  	    /*C  2  0 //Secuencia de Proveedor*/
   NUME_SECUF	CHAR(3) NOT NULL,	    /*C  3  0 //Secuencia de Factura*/
   NUM_ITEM  	NUMERIC(4,0) NOT NULL,      /*N  4  0 //Secuencia de Item por Factura*/
   COD_NOMBRE	CHAR(3) DEFAULT "",         /*  0 //Codigo de Nombre de Sanitarios*/
   NOMBRE       VARCHAR(40) DEFAULT "",     /*  0 //Nombre de Sanitarios*/
   COD_COMPO1	CHAR(3) DEFAULT "",         /*C  3  0 //Codigo de Composicion 1*/
   COMPO1       VARCHAR(30) DEFAULT "",     /*C 40  0 //Nombre de Composicion 1*/
   COD_COMPO2	CHAR(3) DEFAULT "",         /*C  3  0 //Codigo de Composicion 2*/
   COMPO2       VARCHAR(30) DEFAULT "",     /*C 40  0 //Nombre de Composicion 2*/
   COD_COMPO3	CHAR(3) DEFAULT "",         /*C  3  0 //Codigo de Composicion 3*/
   COMPO3       VARCHAR(30) DEFAULT "",     /*C 40  0 //Nombre de Composicion 3*/
   COD_COLOR 	CHAR(3) DEFAULT "",         /*C  3  0 //Codigo de Color*/
   COLOR        VARCHAR(30) DEFAULT "",     /*C 30  0 //Color*/
   COD_ACAB  	CHAR(3) DEFAULT "",         /*C  3  0 //Codigo de Acabado*/
   ACABADO      VARCHAR(30) DEFAULT "",     /*C 30  0 //Acabado*/
   DIMENSION    VARCHAR(40) DEFAULT "",     /*C 40  0 //Dimension*/
   PESO_VOL     NUMERIC(15,2) DEFAULT 0,    /*N 15  0 //Peso o volumen*/
   COD_USO   	CHAR(3) DEFAULT "",         /*C  2  0 //Codigo de uso*/
   USO          VARCHAR(30) DEFAULT "",     /*C 30  0 //Uso*/
   COD_PRESEN	CHAR(3) DEFAULT "",         /*C  3  0 //Codigo de Presentacion*/
   PRESENTAC    VARCHAR(30) DEFAULT "",     /*C 30  0 //Presentacion*/
   COD_MATEXT	CHAR(3) DEFAULT "",         /*C  3  0 //Codigo de Material Externo*/
   MATER_EXT    VARCHAR(30) DEFAULT "",     /*C 30  0 //Material Externo*/
   COD_MATINT	CHAR(3) DEFAULT "",         /*C  3  0 //Codigo de Material Interno*/
   MATER_INT    VARCHAR(30) DEFAULT "",     /*C 30  0 //Material interno*/
   COD_TIPO  	CHAR(3) DEFAULT "",         /*C  3  0 //Codigo de Tipo*/
   TIPO         VARCHAR(30) DEFAULT "",     /*C 30  0 //Tipo o dureza de la punta*/
   COD_DISPO 	CHAR(3) DEFAULT "",         /*C  3  0 //Codigo de Dispositivo*/
   DISPOSITI    VARCHAR(30) DEFAULT "",     /*C 30  0 //Dispositivo*/
   COD_ACCES 	CHAR(3) DEFAULT "",         /*C  3  0 //Codigo de Accesorios*/
   ACCESORIO    VARCHAR(30) DEFAULT "",     /*C 30  0 //Accesorios*/
   NRO_PZAS     NUMERIC(15,0) DEFAULT 0,    /*N 15  0 //Nro. Piezas*/
   OBSERVAC1    VARCHAR(100) DEFAULT "",    /*C100  0 // Observaciones*/
   VOLUMEN      NUMERIC(15,0) DEFAULT 0,    /*N 15  0 // Peso*/
   ADICIONAL    VARCHAR(30) DEFAULT "",     /* Adicionales a la presentacion*/
   TIPO_UTIL 	CHAR(3) DEFAULT "",         /*C  3  0*/
   DIMENSION1   DECIMAL(6,2) DEFAULT 0.00,  /* 6  2 //Dimension1	*/
   DIMENSION2   DECIMAL(6,2) DEFAULT 0.00,  /* 6  2 //Dimension2	*/
   DIMENSION3   DECIMAL(6,2) DEFAULT 0.00,  /* 6  2 //Dimension3	*/
   PRIMARY KEY(N_ORDEN,NUME_SECUP,NUME_SECUF,NUM_ITEM));
   CREATE INDEX UTI ON UTI(N_ORDEN);

/* FVS (FACTURA DE VENTA SUCESIVA PARA XML)*/
CREATE TABLE IF NOT EXISTS FVS(
   N_ORDEN     CHAR(11) NOT NULL,	/*C  9  0*/
   NUME_SECUP  CHAR(3)  DEFAULT '',
   NUME_SECUF  CHAR(3)  DEFAULT '',
   NFAC_VTASU  CHAR(40) DEFAULT '',
   FFAC_VTASU  DATE,
   IMPO_VTASU  NUMERIC(13,3) DEFAULT 0,
   PRIMARY KEY(N_ORDEN,NUME_SECUP,NUME_SECUF,NFAC_VTASU));
create index FVS on FVS(n_orden,NUME_SECUP,NUME_SECUF,NFAC_VTASU);
