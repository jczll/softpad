/*======================================================================*/
/*******    TABLAS DEL MENU DEL SISTEMA ADUANERO SAD           **********/ 
/*=======================================================================*/
/* BASES( MAESTRO DE TABLAS DE MOVIMIENTOS )*/                                                   
create table if not exists bases(       
   base         char(3) not null,
   etiqueta     char(3) not null,
   clave        varchar(130) default "",
   descripcio   char(35) default "",
   uso          varchar(150) default "",
   dua          char(3) default "",
   dua_item     char(1) default "",
   due          char(3) default "",
   dma          char(3) default "",
   stm          char(3) default "",
   mov          char(3) default "",
   aut          char(3) default "",
   ral          char(3) default "",
   dum          char(3) default "",
   sra          char(3) default "",
   rmf          char(3) default "",
   act          char(3) default "",
   cns          char(3) default "",
   mnf          char(3) default "",
   ccu          char(3) default "",
   gre          char(3) default "",
   pro          char(3) default "",
   doc          char(3) default "",
   pla          char(3) default "",
   fin          char(3) default "",
   let          char(3) default "",
   tabla_cli    char(1) default "",
   tab_anual    char(3) default "",
   sch          char(3) default "",
   cnt          char(3) default "",
   ape          char(3) default "",
   dex          char(3) default "",
   condwhere    varchar(50) default "",
   orden_tabla  char(3) default "",
   primary key(base,etiqueta));

/* SISTEMAS( MAESTRO DE TABLAS DE SISTEMAS )*/                                                   
create table if not exists sistemas(       
   registro      char(4) not null,   
   base          char(8)  default "",
   nombre        varchar(50) default "",
   clave1        varchar(70) default "",
   clave2        varchar(45) default "",
   clave3        varchar(45) default "",
   clave4        varchar(45) default "",
   clave5        varchar(45) default "",
   clave6        varchar(45) default "",
   primary key(registro),
   constraint uq_sistemas_1 unique(base));
create index sistemas_1 on sistemas(registro);                                                 
create index sistemas_2 on sistemas(base);                                              

/* MSADP (TABLA DE MENU PRINCIPAL DEL SISTEMA SAD)*/
create table if not exists msadp(
   registro  char(2) not null, 
   sad       char(1) default '', 
   sad1      char(1) default '', 
   dsi       char(1) default '', 
   dma       char(1) default '', 
   rmf       char(1) default '', 
   dva       char(1) default '', 
   titulo    varchar(30) default '', 
   hotkey    varchar(10) default '',
   ejecuta   varchar(20) default '',
   tipo_ejec char(1) default "",    
   usuario_t char(1) default "",  
   usuario_l char(1) default "",
   usuario_u char(1) default "",
   usuario_s char(1) default "", 
  primary key(registro));

/* MSADS (TABLA DE SUB-MENU DEL SISTEMA SAD)*/
create table if not exists msads(
   registro   char(3) not null, 
   sad        char(3) default '', 
   sad1       char(3) default '', 
   dsi        char(3) default '', 
   dma        char(3) default '', 
   rmf        char(3) default '', 
   dva        char(3) default '', 
   titulo     varchar(70) default '', 
   hotkey     varchar(10) default '',
   ejecuta    varchar(90) default '',
   tipo_ejec  char(1) default "",    
   usuario_t  char(1) default "",  
   usuario_l  char(1) default "",
   usuario_u  char(1) default "",
   usuario_s  char(1) default "", 
   vcod_inter char(4) default "",
   inbuild    char(1) default "", 
  primary key(registro));

/* MSADR (TABLA DE  DETALLE DEL SUB-MENU DEL SISTEMA SAD)*/
create table if not exists msadr(
   registro   char(2) not null, 
   sad        char(5) not null, 
   sad1       char(5) not null, 
   dsi        char(5) not null, 
   dma        char(5) not null, 
   rmf        char(5) not null, 
   dva        char(5) not null, 
   titulo     varchar(60) default '', 
   hotkey     varchar(10) default '',
   ejecuta    varchar(100) default '',
   tipo_ejec  char(1) default "",    
   usuario_t  char(1) default "",  
   usuario_l  char(1) default "",
   usuario_u  char(1) default "",
   usuario_s  char(1) default "", 
  primary key(registro));

/*======================================================================*/
/*******    TABLAS DEL MENU DEL CONTROL DE CLIENTES CTE        **********/
/*=======================================================================*/

/* MCTEP (TABLA DE MENU PRINCIPAL DEL SISTEMA CTE)*/
create table if not exists mctep(
   registro  char(2) not null, 
   cte       char(1) default '', 
   vta       char(1) default '', 
   titulo    varchar(30) default '', 
   hotkey    varchar(10) default '',
   ejecuta   varchar(20) default '',
   tipo_ejec char(1) default "",    
   usuario_t char(1) default "",  
   usuario_f char(1) default "",
   usuario_u char(1) default "",
   usuario_s char(1) default "", 
  primary key(registro));

/* MCTES (TABLA DE SUBMENU PRINCIPAL DEL SISTEMA CTE)*/
create table if not exists mctes(
   registro   char(3) not null, 
   cte        char(3) default '', 
   vta        char(3) default '', 
   titulo     varchar(70) default '', 
   hotkey     varchar(10) default '',
   ejecuta    varchar(70) default '',
   tipo_ejec  char(1) default "",    
   usuario_t  char(1) default "",  
   usuario_f  char(1) default "",
   usuario_u  char(1) default "",
   usuario_s  char(1) default "", 
   vcod_inter char(4) default "",
   inbuild    char(1) default "", 
  primary key(registro));

/* MCTER (TABLA DE DETALLE DEL SUBMENU DEL SISTEMA CTE)*/
create table if not exists mcter(
   registro   char(2) not null, 
   cte        char(4) default '', 
   vta        char(4) default '', 
   titulo     varchar(40) default '', 
   hotkey     varchar(10) default '',
   ejecuta    varchar(40) default '',
   tipo_ejec  char(1) default "",    
   usuario_t  char(1) default "",  
   usuario_f  char(1) default "",
   usuario_u  char(1) default "",
   usuario_s  char(1) default "", 
   vcod_inter char(4) default "",
  primary key(registro));

/*===========================================================================*/
/*====================          TABLAS DE SISTEMA                  ==========*/
/*===========================================================================*/
/*TS0 (Tabla de Control  )*/
create table if not exists ts0(
   nombre      char(12) not null,                                               
   fecha       date,   	                                      
   primary key(nombre));                                                       

/*TS4 (Tabla de Afirmativo y Negativo  )*/
create table if not exists ts4(
   codigo      char(1) not null,                                               
   descripcio  varchar(15) default "",   	                                      
   primary key(codigo));                                                       
create index ts4_1 on ts4(codigo);                                         

/* TS35 (TABLA DE DERECHOS)*/
create table if not exists ts35(
   codigo      char(2) not null,
   derechos    varchar(20) default '',
   campo_dere  char(10) default '',
   cod_autoliq char(4) default '',
   reg_10      char(1) default "",
   reg_20      char(1) default "",
   reg_21      char(1) default "",
   reg_70      char(1) default "",
   proforma    varchar(15) default "",
   primary key(codigo),
   constraint uq_ts35 unique(derechos));
create index ts35 on ts35(codigo);
/*load data local infile "ta35.txt" into table ts35 lines terminated by "\r\n";*/

/* TS119( TABLAS DE ARCHIVOS A ENVIAR POR TELEDESPACHO )*/                      
create table if not exists ts119(                                               
   codigo      char(2) not null,                                                
   arch_adu    char(8) default "",                                              
   arch_sis    char(8) default "",                                              
   descripcio  varchar(40) default "",                                          
   tabla       char(3) default "",                                              
   reg_10      char(1) default "",                                              
   reg_20      char(1) default "",                                              
   reg_21      char(1) default "",                                              
   reg_30      char(1) default "",                                              
   reg_29      char(1) default "",                                              
   reg_31      char(1) default "",                                              
   reg_60      char(1) default "",                                              
   reg_65      char(1) default "",                                              
   reg_70      char(1) default "",                                              
   reg_80      char(1) default "",                                              
   reg_89      char(1) default "",                                              
   reg_40      char(1) default "",                                              
   reg_41      char(1) default "",                                              
   reg_50      char(1) default "",                                              
   reg_18      char(1) default "",                                              
   reg_48      char(1) default "",                                              
   reg_71      char(1) default "",                                              
   reg_00      char(1) default "",                                              
   reg_12      char(1) default "",                                              
   flag        char(1) default "",                                              
   reg_78      char(1) default "",                                              
   reg_25      char(1) default "",                                              
   reg_26      char(1) default "",                                              
   reg_01      char(1) default "",                                              
   reg_96      char(1) default "",                                              
   reg_85      char(1) default "",                                              
   reg_16      char(1) default "",                                              
   reg_17      char(1) default "",                                              
   reg_19      char(1) default "",                                              
   reg_61      char(1) default "",                                              
   reg_33      char(1) default "",                                              
   ope_0       char(1) default "",                                              
   ope_1       char(1) default "",                                              
   ope_7       char(1) default "",                                              
   ope_x       char(1) default "",                                              
   reg_79      char(1) default "",                                              
   reg_14      char(1) default "",                                              
   reg_15      char(1) default "",                                              
   reg_13      char(1) default "",                                              
   flaguso     char(1) default "",                                              
   reg_81      char(1) default "",                                              
   tabla1      char(3) default "",                                              
   reg_72      char(1) default "",                                              
   reg_43      char(1) default "",                                              
   reg_44      char(1) default "",                                              
   reg_45      char(1) default "",                                              
   reg_46      char(1) default "",                                              
   reg_04      char(1) default "",                                              
   reg_51      char(1) default "",                                              
   reg_52      char(1) default "",                                              
   reg_36      char(1) default "",                                              
   reg_77      char(1) default "",  
   reg_05      char(1) default "",  
   reg_76      char(1) default "",                                              
   reg_28      char(1) default "",                                              
   primary key(codigo));                                                        
create index ts119_1 on ts119(codigo);                                          
create index ts119_2 on ts119(arch_adu);                                        
create index ts119_3 on ts119(tabla);                                           
create index ts119_4 on ts119(tabla1);                                          

/* TS597( TIPO DE DOCUMENTOS DE LAS GUIAS DE ENVIO DE ENTREGA RAPIDA )*/            
create table if not exists ts597(                                               
   codigo      char(4) not null,                                                
   descripcio  char(35) not null,                                                
   primary key(codigo));                                               
create index ts597_1 on ts597(codigo);                                          
create index ts597_2 on ts597(descripcio);                                      
insert into ts597 values("guia","guia de transporte");
insert into ts597 values("ddjj","declaracion jurada");

/* TS70( PORCENTAJE DE IGV )*/            
create table if not exists ts70(                                               
   fech_porc   date not null,
   aduanas     numeric(7,0) default 0,
   sunat       decimal(7,2) default 0.00,
   sunat1      numeric(7,2) default 0.00,
   primary key(fech_porc));                                               
create index ts70 on ts70(fech_porc);                                          
insert into ts70 values("2003-07-31",16,0.18,1.18);
insert into ts70 values("2011-02-28",17,0.19,1.19);
insert into ts70 values("2999-12-31",16,0.18,1.18);

/*TS78 (TABLA DE TIPOS DE PROFORMA)*/
create table if not exists ts78(
   codigo      char(1) not null,
   descripcio  varchar(20) default '',
   primary key(codigo),
   constraint uq_ts78 unique(descripcio));
create index ts78 on ts78(codigo);
insert into ts78 values("o","por orden");
insert into ts78 values("r","por referencia");
insert into ts78 values("s","sin series (rapida)");

/* TS132( Campos a buscar en consultas Rapidas)*/            
create table if not exists ts132(                                               
   texto       char(20) not null,
   sistema     char(3) not null,
   campo       varchar(14) default "",
   nindice     numeric(2,0) default 0,
   ancho       numeric(3,0) default 0,
   tabla       varchar(10) default "",
   vcod_inter  char(4) default "",
   primary key(texto,sistema));                                               

/*TS371 (Tipo de Aduana para Calculo de Comisi�n)*/
create table if not exists ts371(
   codigo      char(1) not null,
   descripcio  varchar(15) default '',
   primary key(codigo),
   constraint uq_ts371 unique(descripcio));
create index ts371 on ts371(codigo);
insert into ts371 values("","");
insert into ts371 values("a","aerea    ");
insert into ts371 values("m","maritima ");
insert into ts371 values("r","terrestre");
insert into ts371 values("t","todas    ");
insert into ts371 values("p","postal   ");

/*TS372 (Tipo de Regimen para Calculo de Comisi�n)*/
create table if not exists ts372(
   codigo      char(3) not null,
   descripcio  varchar(15) default '',
   primary key(codigo),
   constraint uq_ts372 unique(descripcio));
create index ts372 on ts372(codigo);
insert into ts372 values("","");
insert into ts372 values("imp","importacion");
insert into ts372 values("exp","exportacion");
insert into ts372 values("dep","deposito");
insert into ts372 values("tmp","temporales");
insert into ts372 values("tod","todos");

/*TS505 (Tipo de Financiamiento para la Comision)*/
create table if not exists ts505(
   codigo      char(2) not null,
   descripcio  varchar(20) default '',
   primary key(codigo),
   constraint uq_ts505 unique(descripcio));
create index ts505 on ts505(codigo);
insert into ts505 values("","");
insert into ts505 values("01","financiado");
insert into ts505 values("02","contado");

/*TS6 (Tipo de comisiones )*/
create table if not exists ts6(
   cod         char(1) not null,
   descripcio  varchar(10) default '',
   primary key(cod),
   constraint uq_ts6 unique(descripcio));
create index ts6 on ts6(cod);
insert into ts6 values("","");
insert into ts6 values("1","fijo");
insert into ts6 values("2","intervalo");
insert into ts6 values("3","unica");

/*TS98 (Tipo de Base de Calculo para las comisiones )*/
create table if not exists ts98(
   cod        char(1) not null,
   descripcio varchar(15) default '',
   primary key(cod),
   constraint uq_ts98 unique(descripcio));
create index ts98 on ts98(cod);
insert into ts98 values("","");
insert into ts98 values("1","fob");
insert into ts98 values("2","cif");
insert into ts98 values("3","derechos");
insert into ts98 values("4","derech/gastos");

/* TS99 (Tipos de Generaci�n de Guias de Remision)*/
create table if not exists ts99 (
  codigo     char(1) not null,
  descripcio varchar(20) default '',
  primary key (codigo));
  create index ts99_1 on ts99(codigo);

/* TS419( TABLAS DE PROCEDIMIENTOS DE REGIMENES ADUANEROS )*/                   
create table if not exists ts419(                                               
   codigo      char(2) not null,                                                
   titulo      varchar(45) default "",                                          
   ruta_web    varchar(250) default "",                                         
   ejecuta     char(8) default "",                                              
   flag        char(1) default "",                                              
   primary key(codigo));                                                        
create index ts419_1 on ts419(codigo);                                          
create index ts419_2 on ts419(titulo);                                          

/* TS183( PAGINAS WEB DE INTERES DEL USUARIO)*/                   
create table if not exists ts183(                                               
   titulo      char(50) not null,                                                
   pagina      varchar(120) default "",                                          
   psistema    char(3) default "",                                         
   pagina_ant  char(120) default "",                                              
   primary key(titulo));                                                        
create index ts183_1 on ts183(titulo);                                          

/* TS428( Accesos directos a Aduanas x Orden                )*/                   
create table if not exists ts428(                                               
   titulo      char(50) not null,                                                
   pagina      varchar(240) default "",                                          
   pagina1     varchar(200) default "",                                          
   psistema    char(3) default "",                                         
   pagina_ant  char(240) default "",                                              
   primary key(titulo));                                                        
create index ts428_1 on ts428(titulo); 


/* TS24( Dias Feriados )*/                   
create table if not exists ts24(                                               
   feriado     date,                                   
   primary key(feriado));                                                        
create index ts24 on ts24(feriado); 

/*TS31 (Tipo de Documentos de la Cuenta Corriente )*/
create table if not exists ts31(
   cod        char(2) not null,
   documento  varchar(30) default "",
   f          char(1) default "",
   abrev      char(12) default "",
   sigla      char(3) default "",
   cod_conta  char(2) default "",
   primary key(cod),
   constraint uq_ts31 unique(documento));
create index ts31 on ts31(cod);
INSERT INTO TS31 VALUES("  ","                        "," ","            ","   ","  ");
INSERT INTO TS31 VALUES("00","PROFORMAS               ","1","PROFORMA    ","P/.","  ");
INSERT INTO TS31 VALUES("01","FACTURAS                ","0","FACTURA     ","F/.","01");
INSERT INTO TS31 VALUES("02","BOLETAS DE VENTA        ","0","BOLETA      ","B/.","03");
INSERT INTO TS31 VALUES("03","NOTAS DE DEBITO         ","1","N/DEBITO    ","N/D","08");
INSERT INTO TS31 VALUES("04","NOTAS DE CREDITO        ","1","N/CREDITO   ","N/C","07");
INSERT INTO TS31 VALUES("05","LETRAS X PAGAR          ","0","LETRAS      ","   ","  ");
INSERT INTO TS31 VALUES("06","VOUCHERS INGRESO/EGRESO ","0","VOUCHER     ","V/.","  ");
INSERT INTO TS31 VALUES("10","FACTURA DE TRANSPORTE   ","0","F/SERIE 2   ","FT/","01");
INSERT INTO TS31 VALUES("14","LIQUIDACION DE COBRANZA ","0","LIQ.COBRANZA","CC/","54");
INSERT INTO TS31 VALUES("18","NOTA CONTABLE DE CREDITO","2","N/CONT.CRE  ","NT/","32");
INSERT INTO TS31 VALUES("22","NOTA CONTABLE DEBITO    ","1","N/CONT.DEB  ","NC/","33");
INSERT INTO TS31 VALUES("99","VARIOS DOCUMENTOS       ","1","VAR/DOC     ","N/C","  ");

/* TS59( TIPO DE DOCUMENTOS DE LOS CLIENTES )*/            
create table if not exists ts59(     
   cod         char(1) not null primary key,                                    
   doc_clie    char(4) default "",
   documento   varchar(35) default "",
   dav         char(2) default "",
   concepto    varchar(35) default "",
   cod_regvta  char(1) default "");                                               
create index ts59_1 on ts59(cod);                                          
create index ts59_2 on ts59(doc_clie);                                      
INSERT INTO TS59 VALUES("1","LT.","LIBRETA TRIBUTARIA                 ","","","0");
INSERT INTO TS59 VALUES("2","LE.","LIBRETA ELECTORAL                  ","","","0");
INSERT INTO TS59 VALUES("4","RUC","REGISTRO UNICO DEL CONTRIBUYENTE   ","01","R.U.C.                             ","6");
INSERT INTO TS59 VALUES("5","C.I.","CARNET DE IDENTIDAD POLICIAL      ","02","DOCUMENTO NACIONAL DE IDENTIDAD   ","0");
INSERT INTO TS59 VALUES("6","PAS","PASAPORTE                          ","03","PASAPORTE                          ","7");
INSERT INTO TS59 VALUES("7","C.E.","CARNET DE EXTRANJERIA             ","05","CEDULA DE EXTRANJERIA              ","4");
INSERT INTO TS59 VALUES("8","O.I.","ORGANIZACIONES INTERNACIONALES    ","06","ORGANIZACIONES INTERNACIONALES     ","0");
INSERT INTO TS59 VALUES("9","S.C.","SALVOCONDUCTO                     ","","","0");
INSERT INTO TS59 VALUES("3","DNI","DOCUMENTO NACIONAL DE IDENTIDAD    ","02","DOCUMENTO NACIONAL DE IDENTIDAD   ","1");

/* TS314( INCIDENCIAS DE FACTURACION )*/            
create table if not exists ts314(     
   cod         char(2) not null primary key,                                    
   incidencia  varchar(55) default "",
   descripcio  varchar(11) default "",
   automatico  char(1) default "",
   ruta_txts   varchar(50) default "");
create index ts314_1 on ts314(cod);                                          
create index ts314_2 on ts314(incidencia);
INSERT INTO TS314 VALUES("01","FACTURA APERTURADA                                     ","APERTURADA ","X","");
INSERT INTO TS314 VALUES("02","PREPARANDO FACTURA                                     ","PREPARANDO ","X","");
INSERT INTO TS314 VALUES("03","FACTURA FINALIZADA                                     ","FINALIZADA ","X","");
INSERT INTO TS314 VALUES("04","FACTURA IMPRESA                                        ","IMPRESA    ","X","");
INSERT INTO TS314 VALUES("05","MODIFICADA                                             ","MODIFICADA ","X","");
INSERT INTO TS314 VALUES("06","ANULADA                                                ","ANULADA    ","X","");

/* TS217( TIPO DE DOCUMENTOS ADJUNTOS AL DESPACHO )*/            
create table if not exists ts217(     
   cod         char(2) not null primary key,                                    
   descripcio  varchar(40) default "",
   iniciales   char(1) default "",
constraint uq_ts217 unique(descripcio));
create index ts217_1 on ts217(cod);                                          
create index ts217_2 on ts217(descripcio);

/* TS218( INCIDENCIAS DE LA GUIA DE REMISION )*/            
create table if not exists ts218(     
   cod         char(2) not null primary key,                                    
   incidencia  varchar(40) default "",
   descripcio  varchar(11) default "");
create index ts218_1 on ts218(cod);                                          
create index ts218_2 on ts218(incidencia);
INSERT INTO TS218 VALUES("01","GUIA INGRESADA  ","APERTURADA ");
INSERT INTO TS218 VALUES("02","PREPARANDO GUIA ","PREPARANDO ");
INSERT INTO TS218 VALUES("03","GUIA IMPRESA    ","IMPRESA    ");
INSERT INTO TS218 VALUES("04","MODIFICADA      ","MODIFICADA ");
INSERT INTO TS218 VALUES("05","ANULADA         ","ANULADA    ");

/* TS5( DOCUMENTOS ADJUNTOS A LA FACTURA )*/            
create table if not exists ts5(     
   codigo      char(2) not null,                                    
   docum_adj   varchar(40) default "",
   numdoc_adj  varchar(25) default "",
   flag_adj    numeric(1,0) default 0,
   primary key(codigo),
   constraint uq_ts5 unique(docum_adj));
create index ts5_1 on ts5(codigo);                                          
create index ts5_2 on ts5(docum_adj);

/* TS9( CODIFICACION DE BANCOS PARA CTA.CTE Y CONTABILIDAD )*/            
create table if not exists ts9(     
   codigo      char(2) not null,        /* codigo del banco */                             
   banco       varchar(40) default "",  /* nombre del banco */
   iniciales   varchar(12) default "",  /* nombre corto del banco */
   primary key(codigo),
   constraint uq_ts9 unique(banco));
create index ts9_1 on ts9(codigo);                                          
create index ts9_2 on ts9(banco);

/* TS258( TABLA DE MONEDAS DE CTA.CTE Y CONTABILIDAD )*/            
create table if not exists ts258(     
   codigo      char(2) not null,        /* codigo de la monedao */                             
   descripcio  varchar(40) default "",  /* descripcion  */
   iniciales   varchar(3) default "",  /* nombre corto del banco */
   primary key(codigo),
   constraint uq_ts258 unique(descripcio));
create index ts258_1 on ts258(codigo);                                          
create index ts258_2 on ts258(descripcio);

/* TS638( TABLA DE MEDIOS DE PAGO DE CTA.CTE Y CONTABILIDAD )*/            
create table if not exists ts638(     
   cod_tpago   char(3) not null,        /* codigo de medio de pago */                             
   des_tpago   varchar(70) default "",  /* descripcion del medio de pago */
   primary key(cod_tpago),
   constraint uq_ts638 unique(des_tpago));
create index ts638_1 on ts638(cod_tpago);                                          
create index ts638_2 on ts638(des_tpago);
insert into `tS638` (`COD_TPAGO`,`DES_TPAGO`) values ('','Z');
insert into `tS638` (`COD_TPAGO`,`DES_TPAGO`) values ('001','DEPOSITO EN CUENTA');
insert into `tS638` (`COD_TPAGO`,`DES_TPAGO`) values ('005','TARJETA DE DEBITO');
insert into `tS638` (`COD_TPAGO`,`DES_TPAGO`) values ('006','TARJETA DE CREDITO');
insert into `tS638` (`COD_TPAGO`,`DES_TPAGO`) values ('009','EFECTIVO');
insert into `tS638` (`COD_TPAGO`,`DES_TPAGO`) values ('011','LETRAS DE CAMBIO');
insert into `tS638` (`COD_TPAGO`,`DES_TPAGO`) values ('101','TRANSFRENCIAS-COMERCIO EXTERIOR');
insert into `tS638` (`COD_TPAGO`,`DES_TPAGO`) values ('102','CHEQUES BANCARIOS-COMERCIO EXTERIOR');

/* TS29( TABLA DE DISTRITOS PARA LA FACTURACION )*/            
create table if not exists ts29(     
   codigo      char(6) not null, 
   distrito    varchar(30) default "",
   provincia   varchar(20) default "",
   dpto        char(15) default "",
   cregion     char(3) default "",
   csubregion  char(3) default "",
   fcambio     numeric(6,0) default 0,
   hcambio     char(8) default "",
   cusuario    varchar(7) default "",
   primary key(codigo));
create index ts29_1 on ts29(codigo);                                          
create index ts29_2 on ts29(distrito);

/* TS77( TIPO DE TASA PARA FINANCIAMIENTO )*/            
create table if not exists ts77(     
   codigo      char(6) not null, 
   descripcio  varchar(30) default "",
   primary key(codigo));
create index ts77_1 on ts77(codigo);                                          
create index ts77_2 on ts77(descripcio);
insert into `tS77` (`CODIGO`,`DESCRIPCIO`) values ('',' ');
insert into `tS77` (`CODIGO`,`DESCRIPCIO`) values ('11','NOMINAL/MENSUAL     ');
insert into `tS77` (`CODIGO`,`DESCRIPCIO`) values ('12','NOMINAL/ANUAL       ');
insert into `tS77` (`CODIGO`,`DESCRIPCIO`) values ('21','EFECTIVA/MENSUAL    ');
insert into `tS77` (`CODIGO`,`DESCRIPCIO`) values ('22','EFECTIVA/ANUAL      ');
insert into `tS77` (`CODIGO`,`DESCRIPCIO`) values ('31','ADELANTADA/MENSUAL  ');
insert into `tS77` (`CODIGO`,`DESCRIPCIO`) values ('32','ADELANTADA/ANUAL    ');

/* TS71( ESTADO DE LA LETRA )*/            
create table if not exists ts71(     
   codigo      char(6) not null, 
   descripcio  varchar(25) default "",
   primary key(codigo));
create index ts71_1 on ts71(codigo);                                          
create index ts71_2 on ts71(descripcio);
insert into `tS71` (`CODIGO`,`DESCRIPCIO`) values ('',' ');
insert into `tS71` (`CODIGO`,`DESCRIPCIO`) values ('01','EN CONSULTA              ');
insert into `tS71` (`CODIGO`,`DESCRIPCIO`) values ('02','POR COBRAR (DESCUENTO)   ');
insert into `tS71` (`CODIGO`,`DESCRIPCIO`) values ('03','RENOV.CONSULTA           ');
insert into `tS71` (`CODIGO`,`DESCRIPCIO`) values ('04','CANCELADA                ');
insert into `tS71` (`CODIGO`,`DESCRIPCIO`) values ('05','PROTESTADA               ');
insert into `tS71` (`CODIGO`,`DESCRIPCIO`) values ('06','RENOVADA                 ');
insert into `tS71` (`CODIGO`,`DESCRIPCIO`) values ('07','ANULADA                  ');
insert into `tS71` (`CODIGO`,`DESCRIPCIO`) values ('08','POR COBRAR (A CARTERA)   ');
insert into `tS71` (`CODIGO`,`DESCRIPCIO`) values ('09','POR COBRAR (FACTORING)   ');
insert into `tS71` (`CODIGO`,`DESCRIPCIO`) values ('10','POR COBRAR (ENDOSADA)    ');

/* TS24( TABLA DE FERIADOS )*/            
create table if not exists ts24(     
   feriado  date, 
   primary key(feriado));

/* TS106( Codigos de Formularios                          )*/            
create table if not exists ts106(     
   codigo     char(2) not null, 
   nombre     varchar(40) default "",
   prog       char(3) default "", 
   cod_agte   char(4) default "",
   cod_agte1  char(4) default "",
   dua        char(2) default "",
   emb        char(2) default "",
   dsi        char(2) default "",
   dma        char(2) default "",
   stm        char(2) default "",
   aut        char(2) default "",
   rmf        char(2) default "",
   due        char(2) default "",
   dva        char(2) default "",
   ree        char(2) default "",
   dtf        char(2) default "",
   rse        char(2) default "",
   dum        char(2) default "",
   stb        char(2) default "",
   djm        char(2) default "",
   rin        char(2) default "",
   flag_impre char(1) default "",
   primary key(codigo));
create index ts106_1 on ts106(codigo);                                          

/* TS117( Opciones de Formularios                           )*/            
create table if not exists ts117(     
   prog       char(3) not null, 
   opcion     varchar(35) default "",
   num        char(2) default "",
   subprog    char(3) default "",
   primary key(prog,num,subprog));
create index ts117_1 on ts117(prog);                                         

/* TS534(Tabla de Estructura del XML DUA)*/            
create table if not exists ts534(     
   cpadre     char(2) not null, 
   padre      varchar(60) default "", 
   chijo      char(2) not null, 
   hijo       varchar(80) default "", 
   cnieto     char(2) default "", 
   nieto      varchar(80) default "", 
   cbisnieto  char(2) default "", 
   bisnieto   varchar(50) default "", 
   ctataranie char(2) default "", 
   tataranie  varchar(50) default "", 
   ccuadrinie char(2) default "", 
   cuadrinie  varchar(50) default "", 
   cbicuadrin char(2) default "", 
   bicuadrin  varchar(50) default "",
   etiq_atrib char(15) default "",
   etiqatrib2 char(15) default "",
   camp_anual varchar(120) default "",
   atri_anual varchar(120) default "", 
   atrianual2 varchar(120) default "", 
   camp_sql   varchar(120) default "",
   atri_sql   varchar(120) default "",
   atri_sql2  varchar(140) default "",
   valid_dato varchar(60) default "",
   tipo_valor char(1) default "",
   reg_10     char(5) default "",
   reg_20     char(5) default "",
   reg_21     char(5) default "",
   reg_70     char(4) default "",
   atri_10    char(5) default "",
   atri_20    char(5) default "",
   atri_21    char(5) default "",
   atri_70    char(4) default "",
   descripcio varchar(120) default "",
   primary key(cpadre,chijo,cnieto,cbisnieto,ctataranie,ccuadrinie,cbicuadrin));
create index ts534 on ts534(cpadre,chijo);                                         

/* TS535(Tabla de Estructura del XML MANIFIESTOS)*/            
create table if not exists ts535(     
   cpadre     char(2) not null, 
   padre      varchar(60) default "", 
   chijo      char(2) not null, 
   hijo       varchar(80) default "", 
   cnieto     char(2) default "", 
   nieto      varchar(80) default "", 
   cbisnieto  char(2) default "", 
   bisnieto   varchar(50) default "", 
   ctataranie char(2) default "", 
   tataranie  varchar(50) default "", 
   ccuadrinie char(2) default "", 
   cuadrinie  varchar(50) default "", 
   cbicuadrin char(2) default "", 
   bicuadrin  varchar(50) default "", 
   camp_anual varchar(160) default "",
   camp_sql   varchar(160) default "",
   tipo_valor char(1) default "",
   tarja      char(4) default "",
   tarja_det  char(2) default "",
   ingreso    char(4) default "",
   bultos_sob char(4) default "",
   bultos_fal char(4) default "",
   acta       char(4) default "",   
   descripcio varchar(90) default "",
   primary key(cpadre,chijo,cnieto,cbisnieto,ctataranie,ccuadrinie,cbicuadrin));
create index ts535 on ts535(cpadre,chijo);                                         

/* TS558(Tabla de Estructura del XML OPERACIONES ASOCIADAS DEL MANIFIESTO)*/            
create table if not exists ts558(     
   cpadre     char(2) not null, 
   padre      varchar(60) default "", 
   chijo      char(2) not null, 
   hijo       varchar(80) default "", 
   cnieto     char(2) default "", 
   nieto      varchar(80) default "", 
   cbisnieto  char(2) default "", 
   bisnieto   varchar(80) default "", 
   ctataranie char(2) default "", 
   tataranie  varchar(50) default "", 
   ccuadrinie char(2) default "", 
   cuadrinie  varchar(50) default "", 
   cbicuadrin char(2) default "", 
   bicuadrin  varchar(50) default "", 
   campo_val  varchar(140) default "",
   tipo_valor char(1) default "",
   carga      char(6) default "",
   descripcio varchar(90) default "",
   objeto     varchar(90) default "",
   primary key(cpadre,chijo,cnieto,cbisnieto,ctataranie,ccuadrinie,cbicuadrin));
create index ts558 on ts558(cpadre,chijo);                                         

/* TS310( TABLA DE MONEDAS PARA LA AUTOLIQUIDACION )*/            
create table if not exists ts310(     
   codigo      numeric(1) not null,        /* codigo de la monedao */                             
   descripcio  varchar(25) default "",  /* descripcion de la moneda */
   primary key(codigo),
   constraint uq_ts310 unique(descripcio));
create index ts310_1 on ts310(codigo);                                          
create index ts310_2 on ts310(descripcio);

/* TS27(TIPOS DE DESPACHO)*/                                            
create table if not exists ts27(                                                
   codigo      char(3) not null,                                                
   descripcio  varchar(50) default "",
   tipo        char(1) default "",
   subcod      char(3) default "",
   form_pago   varchar(30) default "",                                          
   primary key(codigo,tipo));                                                        
create index ts27_1 on ts27(codigo);                                            
create index ts27_2 on ts27(descripcio);                                         

/* TS316(Tipo de Codigo Liberatorio                        )*/                
create table if not exists ts316(                                               
   cod         char(3) not null,                                                
   descripcio  varchar(40) default "",                                          
   tlib        char(1) default "",
   primary key(cod));                                                           
create index ts316_1 on ts316(cod);                                             
create index ts316_2 on ts316(descripcio);                                                                                                                         
                                                                               
/* TS317(Flag para Prorratear el Peso Bruto                )*/                
create table if not exists ts317(                                               
   cod         char(3) not null,                                                
   descripcio  varchar(80) default "",                                          
   primary key(cod));                                                           
create index ts317_1 on ts317(cod);                                             
create index ts317_2 on ts317(descripcio);                                                                                                                         

/* TS358(Flag para el Prorrateo del Pesos                  )*/                
create table if not exists ts358(                                               
   codigo      char(1) not null,                                                
   descripcio  varchar(60) default "",                                          
   primary key(codigo));                                                           
create index ts358_1 on ts358(codigo);                                             
create index ts358_2 on ts358(descripcio);                                                                                                                                                                                                       

/* TS304(Tabla tipo de transportiste para DHL               )*/                
create table if not exists ts304(                                               
   codigo      char(2) not null,                                                
   descripcio  varchar(20) default "",                                          
   primary key(codigo));                                                           
create index ts304_1 on ts304(codigo);                                             
create index ts304_2 on ts304(descripcio);                                                                                                                                                                                                       

/* TS305(Tabla de Zonas de Entrega para la Guia de Remision)*/                
create table if not exists ts305(                                               
   codigo      char(1) not null,                                                
   descripcio  varchar(84) default "",                                          
   primary key(codigo));                                                           
create index ts305_1 on ts305(codigo);                                             
create index ts305_2 on ts305(descripcio);                                                                                                                                                              
                                                                                
/* TS187( TABLAS DE TIPO DE USUARIOS )*/                                        
create table if not exists ts187(                                               
   codigo      char(1) not null,                                                
   descripcio  varchar(30) default "",                                          
   primary key(codigo));                                                        
create index ts187_1 on ts187(codigo);                                          
create index ts187_2 on ts187(descripcio);                                                                                                                                                                                                    
                                                                                
/* Ts273( TABLAS DE TIPO DE ENVIO DE LA ORDEN DE EMBARQUE )*/                   
create table if not exists ts273(                                               
   codigo      char(1) not null,                                                
   descripcio  varchar(30) default "",                                          
   primary key(codigo));                                                        
create index ts273_1 on ts273(codigo);                                          
create index ts273_2 on ts273(descripcio);                                      
                                                                                
/* TS274( TABLAS DE TIPO DE ENVIO DE EXPORTACION )*/                            
create table if not exists ts274(                                               
   codigo      char(1) not null,                                                
   descripcio  varchar(30) default "",                                          
   primary key(codigo));                                                        
create index ts274_1 on ts274(codigo);                                          
create index ts274_2 on ts274(descripcio);                                                                                                                                                                                                   
                                                                                
/* TS306( TABLAS DE CONTENEDORES )*/                                   
create table if not exists ts306(                                               
   codigo      char(2) not null,                                                
   descripcio  varchar(25) default "",                                          
   primary key(codigo));                                                        
create index ts306_1 on ts306(codigo);                                          
create index ts306_2 on ts306(descripcio);                                                                                                                     
                                                                                
/* TS313( TABLAS DE TIPO DE PRORRATEO (MULTIPLICACION ORD.) )*/                 
create table if not exists ts313(                                               
   codigo      char(1) not null,                                                
   descripcio  varchar(25) default "",                                          
   primary key(codigo));                                                        
create index ts313_1 on ts313(codigo);                                          
create index ts313_2 on ts313(descripcio);                                                                                                                                                                                                                                                                                                                                                                  

/* TS422( TABLAS DE REPORTEADOR - CAMPOS DE LOS FORMATOS )*/                    
create table if not exists ts422(                                               
   cod         char(6) not null,                                                
   tipo        char(1) default '',                                              
   activo      char(1) default '',
   campo_repo  varchar(10) default '',                                          
   tipo_repo   char(1) default '',    
   campo_type  char(1) default '',                                      
   campo_size  int(5),
   campo_len   int(3),
   descrip     varchar(30) default '',                                          
   campo_sql   varchar(20) default '',                                          
   llenado     varchar(254) default '',                                         
   grupoexcel  varchar(30) default '',                                          
   campo_grid  char(10) default '',
   tipo_grid   char(1) default '',                                             
   grupo       char(1) default '',                                             
   campo       varchar(20) default '',
   primary key(cod));                                                           
create index ts422_1 on ts422(cod);                               

/* TS427( TABLAS DE MAESTRO DE CLIENTES )*/                                     
create table if not exists ts427(                                               
   tipo_docum	char(1) not null,               /*c  1  0 tipo de documento del cliente*/
   documento 	char(11) not null,              /*c 11  0 ruc/documento del cliente*/
   nombre    	varchar(80) default '',	        /*c 80  0 nombre del cliente segun sunat*/
   direcc    	varchar(60) default '',	        /*c 60  0 direccion comercial del cliente*/
   distrito  	char(6) default '',             /*c  6  0 distrito*/
   nombres   	varchar(70) default '',	        /*c 70  0 nombre de la persona natural (couriers)*/
   apellidos 	varchar(70) default '',	        /*c 70  0 apellidos de la persona natural  (couriers)*/
   telef1    	char(10) default '',	        /*c 10  0 telefono*/
   fax       	char(10) default '',	        /*c 10  0 fax del cliente*/
   telef2    	char(10) default '',            /*c 10  0 telefono 2 del cliente*/
   ubigeo    	char(6) default '',	        /*c  6  0*/
   email_cli 	varchar(40) default '',	        /*c 30  0 correo electronico del cliente*/
   email_cli1	varchar(40) default '',	        /*c 30  0 otros correos electronicos del cliente*/
   email_cli2	varchar(40) default '',	        /*c 30  0 otros correos electronicos del cliente*/
   cod_entreg	char(4) default '',             /*c  4  0 codigo de lugar de entrega al cliente*/
   des_entreg	varchar(50) default '',	        /*c 50  0 descripcion del lugar de entrega al cliente*/
   direc_fact	varchar(100) default '',	/*c 60  0 direccion de facturacion*/
   pais_impor	char(2) default '',             /*c  2  0 nacionalidad del importador*/
   ccta_pael 	varchar(20) default '',	        /*c 20  0 cta. cte. del pago electronico*/
   cbco_pael 	char(3) default '',	        /*c  3  0 codigo de banco del pago electronico*/
   exclu_uif 	char(1) default '',	        /*c  1  0 flag que determina si el cliente va a ser excluido de la uif*/
   motexcluif	varchar(90) default '',	        /*c 90  0 motivo de exclusion de la uif*/
   pigv      	char(1) default '',             /*c  1  0 campo de percepcion de igv*/
   frecuente    char(1) default '',             /*c  1  0 flag que indica que el importador es frecuente  */
   primary key(tipo_docum,documento));                                          
create index ts427_1 on ts427(tipo_docum,documento);                            

/* TS442( TABLAS DE TABLA MAESTRA DE REPRESENTANTES )*/                         
create table if not exists ts442(                                               
   tipodoccli  char(1) not null,                                                
   documcli    varchar(11) not null,                                            
   codigo      char(2) not null,                                                
   nombre      varchar(50) default "",                                          
   td          char(1) default "",                                              
   documento   varchar(11) default "",                                          
   cargo       varchar(25) default "",                                          
   primary key(tipodoccli,documcli,codigo),
   constraint fk_ts442_ts427 foreign key(tipodoccli,documcli) references ts427(tipo_docum,documento));                                    
create index ts442_1 on ts442(tipodoccli,documcli,codigo);                      

/* TS443( TABLAS DE TABLA MAESTRA DE LUGARES DE ENTREGA )*/                     
create table if not exists ts443(                                               
   tipodoccli  char(1) not null,                                                
   documcli    varchar(11) not null,                                            
   codigo      char(4) default "",                                              
   lug_entreg  varchar(90) default "",                                          
   ll_viatipo  char(10) default "",                                             
   ll_vianomb  varchar(40) default "",                                          
   ll_numero   char(10) default "",                                             
   ll_inter    char(5) default "",                                              
   ll_zona     varchar(20) default "",                                          
   ll_dist     varchar(20) default "",                                          
   ll_prov     varchar(15) default "",                                          
   ll_dpto     varchar(15) default "",                                          
   referencia  varchar(35) default "",                                          
   primary key(tipodoccli,documcli,codigo),
   constraint fk_ts443_ts427 foreign key(tipodoccli,documcli) references ts427(tipo_docum,documento));                                    
create index ts443_1 on ts443(tipodoccli,documcli);                                                                                                                                                                                                                                                                                                                                                        

/* TS444( TABLAS DE CORREOS DEL CONSOLIDADO DE CLIENTES )*/                     
create table if not exists ts444(                                               
   tipodoccli   char(1) not null,                                                
   documcli     varchar(11) not null,    
   correl       char(2) not null,            
   correo_ele	varchar(90) default '',	     
   tip_correo	char(1) default '',	     
   primary key(tipodoccli,documcli,correl),
   constraint fk_ts444_ts427 foreign key(tipodoccli,documcli) references ts427(tipo_docum,documento));                                    
create index ts444_1 on ts444(tipodoccli,documcli);                                                                                                                                                                                                                                                                                                                                                        

/* TS260( TABLAS DE ZONAS DE TRANSPORTE PARA LA GUIA DE REMISION )*/                                   
create table if not exists ts260(                                               
   codigo      char(3) not null,                                                
   descripcio  varchar(20) default "",                                          
   primary key(codigo));                                                        
create index ts260_1 on ts260(codigo);                                          
create index ts260_2 on ts260(descripcio);                                                                                                                                                                                                    
                                                                
/* TS592( TABLAS DE HORARIO DE ALERTAS PARA VENCIMIENTOS DE TRANSBORDO )*/      
create table if not exists ts592(                                               
   horario     char(10) not null,                                               
   hora        char(5) not null,                                                
   segundos    numeric(8,0) default 0,                                          
   activar     numeric(1,0) default 0,                                          
   fecha_ale   date,                                                            
   correod     varchar(100) default '',
   correop     varchar(100) default '',
   correoc     varchar(100) default '',
   host        varchar(100) default '',
   tipo        char(1) default '',
   correo1     varchar(100) default '',
   correo2     varchar(100) default '',
   correo3     varchar(100) default '',
   correo4     varchar(100) default '',
   correo5     varchar(100) default '',
   correo6     varchar(100) default '',
   primary key(horario));                                                       
create index ts592_1 on ts592(horario);                                         
create index ts592_2 on ts592(segundos);                                        

/* TS375( TABLAS DE PROGRAMADORES QUE HACEN MANTENIMIENTO )*/                                   
create table if not exists ts375(                                               
   codigo      char(3) not null,                                                
   descripcio  varchar(30) default "",                                          
   tipo        char(1) default "",                                          
   primary key(codigo));                                                        
create index ts375_1 on ts375(codigo);                                          
create index ts375_2 on ts375(descripcio);                                                                                                                                                                                                    
                
/* TS387( Tipo de Contenedor para 43 y Control de Macromar   )*/                                   
create table if not exists ts387(                                               
   codigo      char(3) not null,                                                
   descripcio  varchar(25) default "",                                          
   primary key(codigo));                                                        
create index ts387_1 on ts387(codigo);                                          
create index ts387_2 on ts387(descripcio);                                                                                                                                                                                                    
                                                    
/*TS668 (Tabla de Estado Civil                              )*/
create table if not exists ts668(
   codigo      char(3) not null,                                               
   descripcio  varchar(20) default "",   	                                      
   primary key(codigo));                                                       
create index ts668_1 on ts668(codigo);                                         
                 
/*TS15 (Tabla de Tipos de Manifiestos         )*/
create table if not exists ts15(
   codigo      char(1) not null,                                               
   descripcio  varchar(20) default "",   	                                      
   primary key(codigo));                                                       
create index ts15_1 on ts15(codigo);

/*TS670 (Tabla de Incidencia de Discrepancia DHL           )*/
create table if not exists ts670(
   codigo      char(3) not null,                                               
   descripcio  varchar(40) default "",   	                                      
   primary key(codigo));                                                       
create index ts670_1 on ts670(codigo);                                         

/*TS671 (Petroperu - Solicitud de Aforo                    )*/
create table if not exists ts671(
   cod_petro      char(3) not null,                                               
   tipo_reple     char(1) default "",
   nro_repleg     char(11) default "", 
   des1           varchar(90) default "",   	                                      
   des2           varchar(90) default "",   	                                      
   primary key(cod_petro));                                                       
create index ts671_1 on ts671(cod_petro);                                         

/* TS8(Tabla de Estructura del XML PARA TRANSBORDO)*/            
create table if not exists ts8(     
   cpadre     char(2) not null, 
   padre      varchar(60) default "", 
   chijo      char(2) not null, 
   hijo       varchar(80) default "", 
   cnieto     char(2) default "", 
   nieto      varchar(80) default "", 
   cbisnieto  char(2) default "", 
   bisnieto   varchar(50) default "", 
   ctataranie char(2) default "", 
   tataranie  varchar(50) default "", 
   ccuadrinie char(2) default "", 
   cuadrinie  varchar(50) default "", 
   cbicuadrin char(2) default "", 
   bicuadrin  varchar(50) default "", 
   campo_val  varchar(120) default "",
   valid_dato varchar(60) default "",
   tipo_valor char(1) default "",
   reg_81     char(3) default "",
   descripcio varchar(120) default "",
   primary key(cpadre,chijo,cnieto,cbisnieto,ctataranie,ccuadrinie,cbicuadrin));
create index ts8 on ts8(cpadre,chijo);                                         

/*TS673 (Tipos de Documento de J&N Expediente-Notificacion )*/
create table if not exists ts673(
   codigo      char(1) not null,                                               
   descripcio  varchar(20) default "",
   primary key(codigo));                                                       
create index ts673_1 on ts673(codigo);                                         

/*TS674 (Tabla de Motivos de Expediente o Notificacion j&N    )*/
create table if not exists ts674(
   codigo      char(3) not null,                                               
   descripcio  varchar(80) default "",
   primary key(codigo));                                                       
create index ts674_1 on ts674(codigo);                                         

/*TS676 (Tabla de Estado de Expediente o notificacion  J&N  )*/
create table if not exists ts676(
   codigo      char(2) not null,                                               
   descripcio  varchar(20) default "",
   automatico  char(1) default "",
   primary key(codigo));                                                       
create index ts676_1 on ts676(codigo);                                         

/* TS10 (TABLA DE TIPO DE GASTO DE LA SOLICITUD DE CHEQUES)*/
create table if not exists ts10 (
  codigo     char(1) not null,
  descripcio varchar(20) default '',
  primary key (codigo));
  create index ts10_1 on ts10(codigo);

/*----------------------------------------------------------*/

/* TS11 (TABLA DE TIPO DE SOLICITUD DE CHEQUES)*/
create table if not exists ts11 (
  codigo     char(1) not null,
  descripcio varchar(20) default '',
  primary key (codigo));
  create index ts11_1 on ts11(codigo);

/* TS12 (TIPOS DE DIARIOS DE ASIENTOS DE VENTAS)*/
create table if not exists ts12 (
  codigo     char(1) not null,
  descripcio varchar(30) default '',
  primary key (codigo));
  create index ts12_1 on ts12(codigo);
INSERT INTO TS12 VALUES("1","DIARIO DE ASIENTO DE VENTAS");
INSERT INTO TS12 VALUES("2","DIARIO DE VENTAS DE C/C");
INSERT INTO TS12 VALUES("3","DIARIO DE ANTICIPOS");
INSERT INTO TS12 VALUES("4","DIARIO ABONO DE LETRAS");
INSERT INTO TS12 VALUES("5","DIARIO CANCELACION LETRAS");
INSERT INTO TS12 VALUES(" ","");

/* TS680 (Unidad de Negocio para EXPEDITORS                 )*/
create table if not exists ts680 (
  codigo     char(2) not null,
  descrip    varchar(40) default '',
  cod_clien  char(5) default '',
  primary key (codigo));
  create index ts680_1 on ts680(codigo);

/* TS681 (Lugares de Entrega de mercaderia para EXPEDITORS                 )*/
create table if not exists ts681 (
  codigo     char(2) not null,
  descripcio varchar(40) default '',
  tarifa     decimal(12,2) default 0.00,
  tarifa_s   decimal(12,2) default 0.00,
  primary key (codigo));
  create index ts681_1 on ts681(codigo);

/* TS678 (TIPOS DE TELEFONOS MOVILES)*/
create table if not exists ts678(
  codigo     char(1) not null,
  descripcio varchar(30) default '',
  primary key (codigo));
  create index ts678_1 on ts678(codigo);
INSERT INTO TS678 VALUES("M","MOVISTAR");
INSERT INTO TS678 VALUES("N","ENTEL");
INSERT INTO TS678 VALUES("C","CLARO");
INSERT INTO TS678 VALUES(" ","");

/* TS679(Tabla de Estructura del XML DUA Nueva que incluye la Aduana Maritima)*/            
create table if not exists ts679(     
   cpadre     char(2) not null, 
   padre      varchar(60) default "", 
   chijo      char(2) not null, 
   hijo       varchar(80) default "", 
   cnieto     char(2) default "", 
   nieto      varchar(80) default "", 
   cbisnieto  char(2) default "", 
   bisnieto   varchar(50) default "", 
   ctataranie char(2) default "", 
   tataranie  varchar(50) default "", 
   ccuadrinie char(2) default "", 
   cuadrinie  varchar(50) default "", 
   cbicuadrin char(2) default "", 
   bicuadrin  varchar(50) default "", 
   camp_anual varchar(140) default "",
   camp_sql   varchar(140) default "",
   valid_dato varchar(60) default "",
   tipo_valor char(1) default "",
   reg_10     char(5) default "",
   reg_20     char(5) default "",
   reg_21     char(5) default "",
   reg_70     char(4) default "",
   descripcio varchar(120) default "",
   primary key(cpadre,chijo,cnieto,cbisnieto,ctataranie,ccuadrinie,cbicuadrin));
create index ts679 on ts679(cpadre,chijo);                                         

/* TS430( Motivo de Anulacion - Lista Contenedores para Macr )*/                   
create table if not exists ts430(                                               
   cod         char(3) not null,                                                
   descripcio  varchar(90) default "",                                          
   primary key(cod));                                                        
create index ts430_1 on ts430(cod); 

/* TS639 (Tipos de Carriers para HP EXPEDITORS   )*/
create table if not exists ts639 (
  codigo     char(2) not null,
  descrip    varchar(30) default '',
  primary key (codigo));
  create index ts639_1 on ts639(codigo);

/* TS655 (Tabla Tipo de Servicios (solo para DHL).          )*/
create table if not exists ts655 (
  codigo     char(2) not null,
  descrip    varchar(40) default '',
  primary key (codigo));
  create index ts655_1 on ts655(codigo);

/* TS656 (Tabla de Owner (solo para DHL).                    )*/
create table if not exists ts656 (
  codigo     char(2) not null,
  descrip    varchar(20) default '',
  tipo_serv  char(2) not null,
  primary key (codigo,tipo_serv));
  create index ts656_1 on ts656(codigo);

/* TS657 (Tabla de Areas de HP (solo para DHL).              )*/
create table if not exists ts657 (
  codigo     char(2) not null,
  descrip    varchar(20) default '',
  tipo_serv  char(2)  not null,
  primary key (codigo,tipo_serv));
  create index ts657_1 on ts657(codigo);

/* TS537 (Tabla de Incoterrms para DHL                           )*/
create table if not exists ts537 (
  codigo     char(3) not null,
  descripcio varchar(39) default '',
  primary key (codigo));
  create index ts537_1 on ts537(codigo);

/* TS272 (Tabla de tipos de despacho de DHL                                 )*/
create table if not exists ts272 (
  codigo     char(3) not null,
  descripcio varchar(30) default '',
  primary key (codigo));
  create index ts272_1 on ts272(codigo);

/* TS640 (Tipos de correlativos para OCEAN PLUS )*/
create table if not exists ts640 (
  codigo     char(3) not null,
  descripcio varchar(30) default '',
  primary key (codigo));
  create index ts640_1 on ts640(codigo);

/* TS219( Tipos de Notas de Debito )*/            
create table if not exists ts219(     
   codigo      char(2) not null primary key,                                    
   descripcio  varchar(50) default "");
create index ts219_1 on ts219(codigo);                                          
create index ts219_2 on ts219(descripcio);
INSERT INTO TS219 VALUES("01","INTERES POR MORA");
INSERT INTO TS219 VALUES("02","AUMENTO DE VALOR");
INSERT INTO TS219 VALUES("03","PENALIDADES / OTROS CONCEPTOS");

/* TS220( Tipos de Notas de Credito )*/            
create table if not exists ts220(     
   codigo      char(2) not null primary key,                                    
   descripcio  varchar(50) default "");
create index ts220_1 on ts220(codigo);                                          
create index ts220_2 on ts220(descripcio);
INSERT INTO TS220 VALUES("01"," Anulaci�n de la operaci�n ");
INSERT INTO TS220 VALUES("02"," Anulaci�n por error en el RUC"); 
INSERT INTO TS220 VALUES("03"," Correcci�n por error en la descripci�n ");
INSERT INTO TS220 VALUES("04"," Descuento global ");
INSERT INTO TS220 VALUES("05"," Descuento por �tem ");
INSERT INTO TS220 VALUES("06"," Devoluci�n total ");
INSERT INTO TS220 VALUES("07"," Devoluci�n por �tem ");
INSERT INTO TS220 VALUES("08"," Bonificaci�n ");
INSERT INTO TS220 VALUES("09"," Disminuci�n en el valor ");
INSERT INTO TS220 VALUES("10"," Otros Conceptos   ");


/* TS261( Tipos de Correos de los Clientes )*/            
create table if not exists ts261(     
   codigo      char(1) not null primary key,                                    
   descripcio  varchar(40) default "");
create index ts261_1 on ts261(codigo);                                          
create index ts261_2 on ts261(descripcio);
INSERT INTO TS261 VALUES("F","FACTURACION ELECTRONICA");
INSERT INTO TS261 VALUES("C","PARA ENVIO DEL FORMATO C");
INSERT INTO TS261 VALUES("O","OTROS");

/* TS445( Chequeos de Tasas variables para Expeditor )*/            
create table if not exists ts445(     
   codigo      char(3) not null primary key,                                    
   descripcio  varchar(40) default "",
   automatico  char(1) default "");
create index ts445_1 on ts445(codigo);                                          
create index ts445_2 on ts445(descripcio);
INSERT INTO ts445 VALUES("ISC","IMPUESTO SELECTIVO AL CONSUMO","X");
INSERT INTO ts445 VALUES("IGV","IMPUESTO GENERAL A LAS VENTAS E IPM","X");
INSERT INTO ts445 VALUES("AUT","AUTORIZACIONES","X");
INSERT INTO ts445 VALUES("ANT","ANTIDUMPING","X");
INSERT INTO ts445 VALUES("CNV","CONVENIOS INTERNACIONALES","X");

/* TS446( Tipos de Mercaderia para J.K.M. )*/            
create table if not exists ts446(     
   codigo      char(3) not null primary key,                                    
   descripcio  varchar(40) default "");
create index ts446_1 on ts446(codigo);                                          
create index ts446_2 on ts446(descripcio);
INSERT INTO ts446 VALUES("DGR","PARA AEREO");
INSERT INTO ts446 VALUES("IMO","PARA MARITIMO");

/* TS559(Tabla de Estructura del XML OPERACIONES ASOCIADAS DEL MANIFIESTO (NUEVO))*/            
create table if not exists ts559(     
   cpadre     char(2) not null, 
   padre      varchar(60) default "", 
   chijo      char(2) not null, 
   hijo       varchar(80) default "", 
   cnieto     char(2) default "", 
   nieto      varchar(80) default "", 
   cbisnieto  char(2) default "", 
   bisnieto   varchar(80) default "", 
   ctataranie char(2) default "", 
   tataranie  varchar(50) default "", 
   ccuadrinie char(2) default "", 
   cuadrinie  varchar(50) default "", 
   cbicuadrin char(2) default "", 
   bicuadrin  varchar(50) default "", 
   cticuadrin char(2) default "", 
   ticuadrin  varchar(50) default "", 
   campo_val  varchar(140) default "",
   tipo_valor char(1) default "",
   num_0201   char(1) default "",
   mod_0202   char(1) default "",
   inc_0203   char(1) default "",
   anu_0204   char(1) default "",
   num_0431   char(1) default "",
   mod_0432   char(1) default "",
   inc_0433   char(1) default "",
   anu_0434   char(1) default "",
   ifc_0435   char(1) default "", 
   descripcio varchar(90) default "",
   objeto     varchar(90) default "",
   primary key(cpadre,chijo,cnieto,cbisnieto,ctataranie,ccuadrinie,cbicuadrin,cticuadrin));
create index ts559 on ts559(cpadre,chijo);                                         

/* TS560(Tabla de Estructura del XML ICA (NUEVO))*/            
create table if not exists ts560(     
   cpadre     char(2) not null, 
   padre      varchar(60) default "", 
   chijo      char(2) not null, 
   hijo       varchar(80) default "", 
   cnieto     char(2) default "", 
   nieto      varchar(80) default "", 
   cbisnieto  char(2) default "", 
   bisnieto   varchar(80) default "", 
   ctataranie char(2) default "", 
   tataranie  varchar(50) default "", 
   ccuadrinie char(2) default "", 
   cuadrinie  varchar(50) default "", 
   cbicuadrin char(2) default "", 
   bicuadrin  varchar(50) default "", 
   cticuadrin char(2) default "", 
   ticuadrin  varchar(50) default "", 
   campo_val  varchar(140) default "",
   tipo_valor char(1) default "",
   num_0121   char(1) default "",
   num_0421   char(1) default "",
   num_0321   char(1) default "",
   num_0821   char(1) default "",
   rct_0122   char(1) default "",
   rct_0422   char(1) default "",
   rct_0322   char(1) default "",
   rct_0822   char(1) default "",
   descripcio varchar(90) default "",
   objeto     varchar(90) default "",
   primary key(correl));
create index ts560 on ts560(correl);                                         

/* TS275( Tipos de Actualizacion del Sistema )*/            
create table if not exists ts275(     
   codigo      char(1) not null primary key,                                    
   descripcio  varchar(30) default "");
create index ts275_1 on ts275(codigo);                                          
create index ts275_2 on ts275(descripcio);
INSERT INTO ts275 VALUES("1","CORRECION SOLO DE EJECUTABLE");
INSERT INTO ts275 VALUES("2","TAMEX DIARIO");
INSERT INTO ts275 VALUES("3","FACTOR DE CONVERSION");
INSERT INTO ts275 VALUES("4","DERECHO ESPECIFICO");
INSERT INTO ts275 VALUES("5","ACTUALIZACION DE ADUANAS");
INSERT INTO ts275 VALUES("6","ACTUALIZACION DEL SISTEMA");

