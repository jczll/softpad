/* TA4( TABLAS DE TIPOS DE LETRAS )*/                                           
CREATE TABLE IF NOT EXISTS TA4(                                                 
   CODIGO      CHAR(1) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(40) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA4_1 ON TA4(CODIGO);                                              
CREATE INDEX TA4_2 ON TA4(DESCRIPCIO);                                          
                                                                                
/* TA5( TABLAS DE DOCUMENTOS ADJUNTOS A LA FACTURA )*/                          
CREATE TABLE IF NOT EXISTS TA5(                                                 
   CODIGO      CHAR(2) NOT NULL,                                                
   DOCUM_ADJ   VARCHAR(40) DEFAULT "",                                          
   NUMDOC_ADJ  VARCHAR(25) DEFAULT "",                                          
   FLAG_ADJ    NUMERIC(1,0) DEFAULT 0,                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA5_1 ON TA5(CODIGO);                                              
CREATE INDEX TA5_2 ON TA5(DOCUM_ADJ);                                           
                                                                                
/* TA6( TABLAS DE TIPOS DE COMISI�N )*/                                         
CREATE TABLE IF NOT EXISTS TA6(                                                 
   COD         CHAR(1) NOT NULL,                                                
   DESCRIPCIO  CHAR(10) DEFAULT "",                                             
   PRIMARY KEY(COD));                                                           
CREATE INDEX TA6_1 ON TA6(COD);                                                 
CREATE INDEX TA6_2 ON TA6(DESCRIPCIO);                                          
                                                                                
/* TA9( TABLAS DE BANCOS PARA CTA.CTE. )*/                                      
CREATE TABLE IF NOT EXISTS TA9(                                                 
   CODIGO      CHAR(2) NOT NULL,                                                
   BANCO       VARCHAR(40) DEFAULT "",                                          
   INICIALES   VARCHAR(12) DEFAULT "",                                          
   SECTORISTA  VARCHAR(30) DEFAULT "",                                          
   CTACTEME    VARCHAR(20) DEFAULT "",                                          
   CTACTEMN    VARCHAR(20) DEFAULT "",                                          
   CTA_DES_S   CHAR(8) DEFAULT "",                                              
   CTA_DES_D   CHAR(8) DEFAULT "",                                              
   CTA_COB_S   CHAR(8) DEFAULT "",                                              
   CTA_COB_D   CHAR(8) DEFAULT "",                                              
   CARTERA     VARCHAR(12) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA9_1 ON TA9(CODIGO);                                              
CREATE INDEX TA9_2 ON TA9(BANCO);                                               
                                                                                
/* TA13( TABLAS DE TIPO DE VOUCHER DE CTA.CTE. )*/                              
CREATE TABLE IF NOT EXISTS TA13(                                                
   COD         CHAR(2) NOT NULL,                                                
   DOCUMENTO   VARCHAR(25) DEFAULT "",                                          
   F           CHAR(1) DEFAULT "",                                              
   ABREV       CHAR(10) DEFAULT "",                                             
   PRIMARY KEY(COD));                                                           
CREATE INDEX TA13_1 ON TA13(COD);                                               
CREATE INDEX TA13_2 ON TA13(DOCUMENTO);                                         
                                                                                
/* TA24( TABLAS DE DIAS FERIADOS )*/                                            
CREATE TABLE IF NOT EXISTS TA24(                                                
   FERIADO     DATE NOT NULL,                                                   
   PRIMARY KEY(FERIADO));                                                       
CREATE INDEX TA24_1 ON TA24(FERIADO);                                           
                                                                                
/* TA27( TABLAS DE TIPOS DE DESPACHO )*/                                        
CREATE TABLE IF NOT EXISTS TA27(                                                
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(50) DEFAULT "",                                          
   TIPO        CHAR(1) DEFAULT "",                                              
   SUBCOD      CHAR(3) DEFAULT "",                                              
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA27_1 ON TA27(CODIGO);                                            
CREATE INDEX TA27_2 ON TA27(DESCRIPCIO);                                        
                                                                                
/* TA29( TABLAS DE C�DIGO DE DISTRITOS )*/                                      
CREATE TABLE IF NOT EXISTS TA29(                                                
   CODIGO      CHAR(6) NOT NULL,                                                
   DISTRITO    VARCHAR(30) DEFAULT "",                                          
   PROVINCIA   VARCHAR(20) DEFAULT "",                                          
   DPTO        VARCHAR(15) DEFAULT "",                                          
   CREGION     CHAR(3) DEFAULT "",                                              
   CSUBREGION  CHAR(3) DEFAULT "",                                              
   FCAMBIO     NUMERIC(6,0) DEFAULT 0,                                          
   HCAMBIO     CHAR(8) DEFAULT "",                                              
   CUSUARIO    CHAR(7) DEFAULT "",                                              
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA29_1 ON TA29(CODIGO);                                            
CREATE INDEX TA29_2 ON TA29(DISTRITO);                                          
                                                                                
/* TA31( TABLAS DE DOCUMENTOS DE CUENTA CORRIENTE )*/                           
CREATE TABLE IF NOT EXISTS TA31(                                                
   COD         CHAR(2) NOT NULL,                                                
   DOCUMENTO   VARCHAR(25) DEFAULT "",                                          
   F           CHAR(1) DEFAULT "",                                              
   ABREV       VARCHAR(12) DEFAULT "",                                          
   SIGLA       CHAR(3) DEFAULT "",                                              
   TDOC        CHAR(1) DEFAULT "",                                              
   TITULO      VARCHAR(30) DEFAULT "",                                          
   COD_CONTA   CHAR(2) DEFAULT "",                                              
   PRIMARY KEY(COD));                                                           
CREATE INDEX TA31_1 ON TA31(COD);                                               
CREATE INDEX TA31_2 ON TA31(DOCUMENTO);                                         
                                                                                
/* TA35( TABLAS DE DERECHOS ADUANEROS DESPACHO/PROFORMA )*/                     
CREATE TABLE IF NOT EXISTS TA35(                                                
   CODIGO      CHAR(2) NOT NULL,                                                
   DERECHOS    VARCHAR(20) DEFAULT "",                                          
   CAMPO_DERE  CHAR(10) DEFAULT "",                                             
   PROFORMA    VARCHAR(15) DEFAULT "",                                          
   CONCEP_PRO  VARCHAR(20) DEFAULT "",                                          
   COD_AUTOLI  CHAR(4) DEFAULT "",                                              
   CAMPO_SIS   CHAR(10) DEFAULT "",                                             
   REG_10      CHAR(1) DEFAULT "",                                              
   REG_20      CHAR(1) DEFAULT "",                                              
   REG_21      CHAR(1) DEFAULT "",                                              
   REG_70      CHAR(1) DEFAULT "",                                              
   CAMPO_DERS  CHAR(10) DEFAULT "",                                             
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA35_1 ON TA35(CODIGO);                                            
CREATE INDEX TA35_2 ON TA35(DERECHOS);                                          
                                                                                
/* TA37( TABLAS DE TIPO PAGO CTA.CTE. )*/                                       
CREATE TABLE IF NOT EXISTS TA37(                                                
   TIPO        CHAR(1) NOT NULL,                                                
   DESCRIPCIO  CHAR(10) DEFAULT "",                                             
   PRIMARY KEY(TIPO));                                                          
CREATE INDEX TA37_1 ON TA37(TIPO);                                              
CREATE INDEX TA37_2 ON TA37(DESCRIPCIO);                                        
                                                                                
/* TA59( TABLAS DE TIPO DE DOC. (CLIENTE) )*/                                   
CREATE TABLE IF NOT EXISTS TA59(                                                
   COD         CHAR(1) NOT NULL,                                                
   DOC_CLIE    CHAR(4) DEFAULT "",                                              
   DOCUMENTO   VARCHAR(35) DEFAULT "",                                          
   DAV         CHAR(2) DEFAULT "",                                              
   CONCEPTO    VARCHAR(35) DEFAULT "",                                          
   COD_REGVTA  CHAR(1) DEFAULT "",                                              
   PRIMARY KEY(COD));                                                           
CREATE INDEX TA59_1 ON TA59(COD);                                               
CREATE INDEX TA59_2 ON TA59(DOC_CLIE);                                          
                                                                                
/* TA70( TABLAS DE PORCENTAJES DE IGV )*/                                       
CREATE TABLE IF NOT EXISTS TA70(                                                
   FECH_PORC   DATE NOT NULL,                                                   
   ADUANAS     NUMERIC(7,0) DEFAULT 0,                                          
   SUNAT       DECIMAL(7,2) DEFAULT 0.00,                                       
   SUNAT1      DECIMAL(7,2) DEFAULT 0.00,                                       
   PRIMARY KEY(FECH_PORC));                                                     
CREATE INDEX TA70_1 ON TA70(FECH_PORC);                                         
                                                                                
/* TA71( TABLAS DE ESTADO DE LA LETRA PARA CTA.CTE. )*/                         
CREATE TABLE IF NOT EXISTS TA71(                                                
   CODIGO      CHAR(2) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(25) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA71_1 ON TA71(CODIGO);                                            
CREATE INDEX TA71_2 ON TA71(DESCRIPCIO);                                        
                                                                                
/* TA76( TABLAS DE DOCUMENTOS QUE SE PUEDEN FINACIAR )*/                        
CREATE TABLE IF NOT EXISTS TA76(                                                
   CODIGO      CHAR(1) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(20) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA76_1 ON TA76(CODIGO);                                            
CREATE INDEX TA76_2 ON TA76(DESCRIPCIO);                                        
                                                                                
/* TA77( TABLAS DE TIPOS DE TASA PARA FINANCIAMIENTO )*/                        
CREATE TABLE IF NOT EXISTS TA77(                                                
   CODIGO      CHAR(2) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(20) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA77_1 ON TA77(CODIGO);                                            
CREATE INDEX TA77_2 ON TA77(DESCRIPCIO);                                        
                                                                                
/* TA78( TABLAS DE TIPOS DE PROFORMA )*/                                        
CREATE TABLE IF NOT EXISTS TA78(                                                
   CODIGO      CHAR(1) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(20) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA78_1 ON TA78(CODIGO);                                            
CREATE INDEX TA78_2 ON TA78(DESCRIPCIO);                                        
                                                                                
/* TA98( TABLAS DE TIPO DE BASE IMPONIBLE PARA COMISIONES )*/                   
CREATE TABLE IF NOT EXISTS TA98(                                                
   COD         CHAR(1) NOT NULL,                                                
   DESCRIP     VARCHAR(15) DEFAULT "",                                          
   PRIMARY KEY(COD));                                                           
CREATE INDEX TA98_1 ON TA98(COD);                                               
                                                                                
/* TA106( TABLAS DE CODIGOS DE FORMULARIOS )*/                                  
CREATE TABLE IF NOT EXISTS TA106(                                               
   CODIGO      CHAR(2) NOT NULL,                                                
   NOMBRE      VARCHAR(40) DEFAULT "",                                          
   PROG        CHAR(3) DEFAULT "",                                              
   COD_AGTE    CHAR(4) DEFAULT "",                                              
   COD_AGTE1   CHAR(4) DEFAULT "",                                              
   DUA         CHAR(2) DEFAULT "",                                              
   EMB         CHAR(2) DEFAULT "",                                              
   DSI         CHAR(2) DEFAULT "",                                              
   DMA         CHAR(2) DEFAULT "",                                              
   STM         CHAR(2) DEFAULT "",                                              
   AUT         CHAR(2) DEFAULT "",                                              
   RMF         CHAR(2) DEFAULT "",                                              
   DUE         CHAR(2) DEFAULT "",                                              
   DVA         CHAR(2) DEFAULT "",                                              
   REE         CHAR(2) DEFAULT "",                                              
   DTF         CHAR(2) DEFAULT "",                                              
   RSE         CHAR(2) DEFAULT "",                                              
   DUM         CHAR(2) DEFAULT "",                                              
   STB         CHAR(2) DEFAULT "",                                              
   DJM         CHAR(2) DEFAULT "",                                              
   RIN         CHAR(2) DEFAULT "",                                              
   FLAG_IMPRE  CHAR(1) DEFAULT "",                                              
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA106_1 ON TA106(CODIGO);                                          
                                                                                
/* TA117( TABLAS DE OPCIONES DE FORMULARIOS )*/                                 
CREATE TABLE IF NOT EXISTS TA117(                                               
   PROG        CHAR(3) NOT NULL,                                                
   OPCION      VARCHAR(35) DEFAULT "",                                          
   NUM         CHAR(1) DEFAULT "",                                              
   SUBPROG     CHAR(3) DEFAULT "",                                              
   PRIMARY KEY(PROG));                                                          
CREATE INDEX TA117_1 ON TA117(PROG);                                            
CREATE INDEX TA117_2 ON TA117(OPCION);                                          
                                                                                
/* TA124( TABLAS DE REGIMENES QUE ENVIA TELEDESPACHO )*/                        
CREATE TABLE IF NOT EXISTS TA124(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(40) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA124_1 ON TA124(CODIGO);                                          
CREATE INDEX TA124_2 ON TA124(DESCRIPCIO);                                      
                                                                                
/* TA132( TABLAS DE CAMPOS A BUSCAR EN CONSULTAS RAPIDAS )*/                    
CREATE TABLE IF NOT EXISTS TA132(                                               
   TEXTO       VARCHAR(20) NOT NULL,                                            
   CAMPO       VARCHAR(14) DEFAULT "",                                          
   NINDICE     NUMERIC(2,0) DEFAULT 0,                                          
   ANCHO       NUMERIC(3,0) DEFAULT 0,                                          
   TABLA       CHAR(10) DEFAULT "",                                             
   SISTEMA     CHAR(3) DEFAULT "",                                              
   VCOD_INTER  CHAR(4) DEFAULT "",                                              
   PRIMARY KEY(TEXTO));                                                         
CREATE INDEX TA132_1 ON TA132(TEXTO);                                           
                                                                                
/* TA183( TABLAS DE PAGINAS WEB DEL USUARIO )*/                                 
CREATE TABLE IF NOT EXISTS TA183(                                               
   TITULO      VARCHAR(50) NOT NULL,                                            
   PAGINA      VARCHAR(120) DEFAULT "",                                         
   PSISTEMA    CHAR(3) DEFAULT "",                                              
   PAGINA_ANT  VARCHAR(120) DEFAULT "",                                         
   PRIMARY KEY(TITULO));                                                        
CREATE INDEX TA183_1 ON TA183(TITULO);                                          
CREATE INDEX TA183_2 ON TA183(PAGINA);                                          
                                                                                
/* TA187( TABLAS DE TIPO DE USUARIOS )*/                                        
CREATE TABLE IF NOT EXISTS TA187(                                               
   CODIGO      CHAR(1) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(30) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA187_1 ON TA187(CODIGO);                                          
CREATE INDEX TA187_2 ON TA187(DESCRIPCIO);                                      
                                                                                
/* TA217( TABLAS DE DOCUMENTOS ADJUNTOS A LA POLIZA )*/                         
CREATE TABLE IF NOT EXISTS TA217(                                               
   COD         CHAR(2) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(40) DEFAULT "",                                          
   INICIALES   CHAR(1) DEFAULT "",                                              
   PRIMARY KEY(COD));                                                           
CREATE INDEX TA217_1 ON TA217(COD);                                             
CREATE INDEX TA217_2 ON TA217(DESCRIPCIO);                                      
                                                                                
/* TA252( TABLAS DE SOLICITUD DE CHEQUES (DANZAS)ENTREGADO )*/                  
CREATE TABLE IF NOT EXISTS TA252(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(52) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA252_1 ON TA252(CODIGO);                                          
CREATE INDEX TA252_2 ON TA252(DESCRIPCIO);                                      
                                                                                
/* TA253( TABLAS DE SOLICITUD DE CHEQUES (DANZAS)GASTOS )*/                     
CREATE TABLE IF NOT EXISTS TA253(                                               
   CODIGO      CHAR(2) NOT NULL,                                                
   GASTOS      VARCHAR(40) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA253_1 ON TA253(CODIGO);                                          
CREATE INDEX TA253_2 ON TA253(GASTOS);                                          
                                                                                
/* TA254( TABLAS DE SOLICITUD DE CHEQUES(DANZAS)BENEFICIARIO )*/                
CREATE TABLE IF NOT EXISTS TA254(                                               
   CODIGO      VARCHAR(11) NOT NULL,                                            
   DESCRIPCIO  VARCHAR(40) DEFAULT "",                                          
   CORTO       VARCHAR(15) DEFAULT "",                                          
   CODIGO1     CHAR(2) DEFAULT "",                                              
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA254_1 ON TA254(CODIGO);                                          
CREATE INDEX TA254_2 ON TA254(DESCRIPCIO);                                      
                                                                                
/* TA258( TABLAS DE TIPO DE MONEDA )*/                                          
CREATE TABLE IF NOT EXISTS TA258(                                               
   CODIGO      CHAR(1) NOT NULL,                                                
   DESCRIPCIO  CHAR(10) DEFAULT "",                                             
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA258_1 ON TA258(CODIGO);                                          
CREATE INDEX TA258_2 ON TA258(DESCRIPCIO);                                      
                                                                                
/* TA273( TABLAS DE TIPO DE ENVIO DE LA ORDEN DE EMBARQUE )*/                   
CREATE TABLE IF NOT EXISTS TA273(                                               
   CODIGO      CHAR(1) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(30) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA273_1 ON TA273(CODIGO);                                          
CREATE INDEX TA273_2 ON TA273(DESCRIPCIO);                                      
                                                                                
/* TA274( TABLAS DE TIPO DE ENVIO DE EXPORTACION )*/                            
CREATE TABLE IF NOT EXISTS TA274(                                               
   CODIGO      CHAR(1) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(30) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA274_1 ON TA274(CODIGO);                                          
CREATE INDEX TA274_2 ON TA274(DESCRIPCIO);                                      
                                                                                
/* TA294( TABLAS DE SOLICITUD EN CHEQUE  (RESTITUCION 13) )*/                   
CREATE TABLE IF NOT EXISTS TA294(                                               
   CODIGO      CHAR(1) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(40) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA294_1 ON TA294(CODIGO);                                          
CREATE INDEX TA294_2 ON TA294(DESCRIPCIO);                                      
                                                                                
/* TA302( TABLAS DE TABLA DE DOCUMENTOS DE LA CARTA CARGO )*/                   
CREATE TABLE IF NOT EXISTS TA302(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(45) DEFAULT "",                                          
   REG_10      CHAR(1) DEFAULT "",                                              
   REG_20      CHAR(1) DEFAULT "",                                              
   REG_21      CHAR(1) DEFAULT "",                                              
   REG_70      CHAR(1) DEFAULT "",                                              
   REG_80      CHAR(1) DEFAULT "",                                              
   REG_89      CHAR(1) DEFAULT "",                                              
   REG_18      CHAR(1) DEFAULT "",                                              
   REG_48      CHAR(1) DEFAULT "",                                              
   REG_40      CHAR(1) DEFAULT "",                                              
   REG_41      CHAR(1) DEFAULT "",                                              
   REG_50      CHAR(1) DEFAULT "",                                              
   REG_30      CHAR(1) DEFAULT "",                                              
   REG_60      CHAR(1) DEFAULT "",                                              
   REG_71      CHAR(1) DEFAULT "",                                              
   REG_72      CHAR(1) DEFAULT "",                                              
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA302_1 ON TA302(CODIGO);                                          
CREATE INDEX TA302_2 ON TA302(DESCRIPCIO);                                      
                                                                                
/* TA304( TABLAS DE TABLA TIPO DE TRANSPORTISTE PARA DHL )*/                    
CREATE TABLE IF NOT EXISTS TA304(                                               
   CODIGO      CHAR(2) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(20) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA304_1 ON TA304(CODIGO);                                          
CREATE INDEX TA304_2 ON TA304(DESCRIPCIO);                                      
                                                                                
/* TA305( TABLAS DE TABLA DE ZONAS DE ENTREGA PARA LA GUIA DE REMISION )*/      
CREATE TABLE IF NOT EXISTS TA305(                                               
   CODIGO      CHAR(1) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(84) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA305_1 ON TA305(CODIGO);                                          
CREATE INDEX TA305_2 ON TA305(DESCRIPCIO);                                      
                                                                                
/* TA306( TABLAS DE TABLA DE CONTENEDORES )*/                                   
CREATE TABLE IF NOT EXISTS TA306(                                               
   CODIGO      CHAR(2) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(25) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA306_1 ON TA306(CODIGO);                                          
CREATE INDEX TA306_2 ON TA306(DESCRIPCIO);                                      
                                                                                
/* TA310( TABLAS DE TABLA DE MONEDAS PARA LA AUTOLIQUIDACION )*/                
CREATE TABLE IF NOT EXISTS TA310(                                               
   CODIGO      NUMERIC(1,0) NOT NULL,                                           
   DESCRIPCIO  VARCHAR(25) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA310_1 ON TA310(CODIGO);                                          
CREATE INDEX TA310_2 ON TA310(DESCRIPCIO);                                      
                                                                                
/* TA313( TABLAS DE TIPO DE PRORRATEO (MULTIPLICACION ORD.) )*/                 
CREATE TABLE IF NOT EXISTS TA313(                                               
   CODIGO      CHAR(1) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(25) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA313_1 ON TA313(CODIGO);                                          
CREATE INDEX TA313_2 ON TA313(DESCRIPCIO);                                      
                                                                                
/* TA314( TABLAS DE INCIDENCIAS DE FACTURACION )*/                              
CREATE TABLE IF NOT EXISTS TA314(                                               
   COD         CHAR(2) NOT NULL,                                                
   INCIDENCIA  VARCHAR(55) DEFAULT "",                                          
   DESCRIPCIO  VARCHAR(11) DEFAULT "",                                          
   AUTOMATICO  CHAR(1) DEFAULT "",                                              
   RUTA_TXTS   VARCHAR(50) DEFAULT "",                                          
   PRIMARY KEY(COD));                                                           
CREATE INDEX TA314_1 ON TA314(COD);                                             
CREATE INDEX TA314_2 ON TA314(INCIDENCIA);                                      
                                                                                
/* TA316( TABLAS DE TIPO DE CODIGO LIBERATORIO )*/                              
CREATE TABLE IF NOT EXISTS TA316(                                               
   COD         CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(40) DEFAULT "",                                          
   TLIB        CHAR(1) DEFAULT "",                                              
   PRIMARY KEY(COD));                                                           
CREATE INDEX TA316_1 ON TA316(COD);                                             
CREATE INDEX TA316_2 ON TA316(DESCRIPCIO);                                      
                                                                                
/* TA317( TABLAS DE FLAG PARA PRORRATEAR EL PESO BRUTO )*/                      
CREATE TABLE IF NOT EXISTS TA317(                                               
   COD         CHAR(1) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(80) DEFAULT "",                                          
   PRIMARY KEY(COD));                                                           
CREATE INDEX TA317_1 ON TA317(COD);                                             
CREATE INDEX TA317_2 ON TA317(DESCRIPCIO);                                      
                                                                                
/* TA358( TABLAS DE FLAG PARA EL PRORRATEO DEL PESOS )*/                        
CREATE TABLE IF NOT EXISTS TA358(                                               
   CODIGO      CHAR(1) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(60) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA358_1 ON TA358(CODIGO);                                          
CREATE INDEX TA358_2 ON TA358(DESCRIPCIO);                                      
                                                                                
/* TA371( TABLAS DE TIPO DE ADUANA PARA CALCULO DE COMISI�N )*/                 
CREATE TABLE IF NOT EXISTS TA371(                                               
   CODIGO      CHAR(1) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(15) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA371_1 ON TA371(CODIGO);                                          
CREATE INDEX TA371_2 ON TA371(DESCRIPCIO);                                      
                                                                                
/* TA372( TABLAS DE TIPO DE REGIMEN PARA CALCULO DE COMISI�N )*/                
CREATE TABLE IF NOT EXISTS TA372(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(15) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA372_1 ON TA372(CODIGO);                                          
CREATE INDEX TA372_2 ON TA372(DESCRIPCIO);                                      
                                                                                
/* TA376( TABLAS DE ORDEN EN QUE  ABONARAN LOS DOC X LETRAS )*/                 
CREATE TABLE IF NOT EXISTS TA376(                                               
   ORDEN       CHAR(1) DEFAULT "",                                              
   CODIGO      CHAR(2) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(30) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA376_1 ON TA376(CODIGO);                                          
CREATE INDEX TA376_2 ON TA376(ORDEN);                                           
                                                                                
/* TA387( TABLAS DE TIPO DE CONTENEDOR PARA CONTROL DE MACROMAR )*/             
CREATE TABLE IF NOT EXISTS TA387(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(25) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA387_1 ON TA387(CODIGO);                                          
                                                                                
/* TA404( TABLAS DE TECNICOS ADUANERO (UPS) )*/                                 
CREATE TABLE IF NOT EXISTS TA404(                                               
   CODIGO      CHAR(2) NOT NULL,                                                
   NOMBRE      VARCHAR(30) DEFAULT "",                                          
   INICIALES   CHAR(3) DEFAULT "",                                              
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA404_1 ON TA404(CODIGO);                                          
CREATE INDEX TA404_2 ON TA404(NOMBRE);                                          
                                                                                
/* TA419( TABLAS DE PROCEDIMIENTOS DE REGIMENES ADUANEROS )*/                   
CREATE TABLE IF NOT EXISTS TA419(                                               
   CODIGO      CHAR(2) NOT NULL,                                                
   TITULO      VARCHAR(45) DEFAULT "",                                          
   RUTA_WEB    VARCHAR(150) DEFAULT "",                                         
   EJECUTA     CHAR(8) DEFAULT "",                                              
   FLAG        CHAR(1) DEFAULT "",                                              
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA419_1 ON TA419(CODIGO);                                          
CREATE INDEX TA419_2 ON TA419(TITULO);                                          
                                                                                
/* TA421( TABLAS DE REPORTEADOR - CAMPOS DE CADA REPORTE )*/                    
CREATE TABLE IF NOT EXISTS TA421(                                               
   NOMBRE_REP  VARCHAR(15) NOT NULL,                                            
   CAMPO       CHAR(6) NOT NULL,                                                
   ORDEN       NUMERIC(3,0) DEFAULT 0,                                          
   PRIMARY KEY(NOMBRE_REP,CAMPO));                                              
CREATE INDEX TA421_1 ON TA421(NOMBRE_REP,CAMPO);                                
CREATE INDEX TA421_2 ON TA421(NOMBRE_REP,ORDEN,3);                              
                                                                                
/* TA422( TABLAS DE REPORTEADOR - CAMPOS DE LOS FORMATOS )*/                    
CREATE TABLE IF NOT EXISTS TA422(                                               
   COD         CHAR(6) NOT NULL,                                                
   TIPO        CHAR(1) DEFAULT "",                                              
   CAMPO       VARCHAR(20) DEFAULT "",                                          
   CAMPO1      VARCHAR(20) DEFAULT "",                                          
   LLENADO     VARCHAR(180) DEFAULT "",                                         
   DESCRIP     VARCHAR(30) DEFAULT "",                                          
   GRUPOEXCEL  VARCHAR(30) DEFAULT "",                                          
   CAMPO2      CHAR(10) DEFAULT "",                                             
   PRIMARY KEY(COD));                                                           
CREATE INDEX TA422_1 ON TA422(COD);                                             
                                                                                
/* TA424( TABLAS DE REPORTEADOR - GRUPOS DE CADA REPORTE )*/                    
CREATE TABLE IF NOT EXISTS TA424(                                               
   NOMBRE_REP  VARCHAR(15) NOT NULL,                                            
   CAMPO       VARCHAR(20) DEFAULT "",                                          
   DESCRIP     VARCHAR(30) DEFAULT "",                                          
   GRUPOEXCEL  VARCHAR(30) DEFAULT "",                                          
   PRIMARY KEY(NOMBRE_REP));                                                    
CREATE INDEX TA424_1 ON TA424(NOMBRE_REP);                                      
CREATE INDEX TA424_2 ON TA424(NOMBRE_REP,CAMPO);                                
                                                                                
/* TA428( TABLAS DE ACCESOS DIRECTOS A ADUANAS X ORDEN )*/                      
CREATE TABLE IF NOT EXISTS TA428(                                               
   TITULO      VARCHAR(50) NOT NULL,                                            
   PAGINA      VARCHAR(240) DEFAULT "",                                         
   PAGINA1     VARCHAR(200) DEFAULT "",                                         
   PSISTEMA    CHAR(3) DEFAULT "",                                              
   PAGINA_ANT  VARCHAR(240) DEFAULT "",                                         
   PRIMARY KEY(TITULO));                                                        
CREATE INDEX TA428_1 ON TA428(TITULO);                                          
CREATE INDEX TA428_2 ON TA428(PAGINA);                                          
                                                                                
/* TA429( TABLAS DE REPORTEADOR -RELACI�N DE REPORTES )*/                       
CREATE TABLE IF NOT EXISTS TA429(                                               
   NOMBRE_REP  VARCHAR(15) NOT NULL,                                            
   DER_SERIES  NUMERIC(1,0) DEFAULT 0,                                          
   PRIMARY KEY(NOMBRE_REP));                                                    
CREATE INDEX TA429_1 ON TA429(NOMBRE_REP);                                      
                                                                                
/* TA430( TABLAS DE MOTIVO DE ANULACION - LISTA CONTENEDORES PARA MACR )*/      
CREATE TABLE IF NOT EXISTS TA430(                                               
   COD         CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(90) DEFAULT "",                                          
   PRIMARY KEY(COD));                                                           
CREATE INDEX TA430_1 ON TA430(COD);                                             
CREATE INDEX TA430_2 ON TA430(DESCRIPCIO);                                      
                                                                                
/* TA442( TABLAS DE TABLA MAESTRA DE REPRESENTANTES )*/                         
CREATE TABLE IF NOT EXISTS TA442(                                               
   CODIGO      CHAR(2) NOT NULL,                                                
   NOMBRE      VARCHAR(50) DEFAULT "",                                          
   TD          CHAR(1) DEFAULT "",                                              
   DOCUMENTO   VARCHAR(11) DEFAULT "",                                          
   TD1         CHAR(1) DEFAULT "",                                              
   DOCUMENTO1  VARCHAR(11) DEFAULT "",                                          
   FECH_NAC    DATE,                                                            
   CARGO       VARCHAR(25) DEFAULT "",                                          
   COD_CLIEN   CHAR(5) DEFAULT "",                                              
   TIPODOCCLI  CHAR(1) NOT NULL,                                                
   DOCUMCLI    VARCHAR(11) NOT NULL,                                            
   PRIMARY KEY(TIPODOCCLI,DOCUMCLI,CODIGO));                                    
CREATE INDEX TA442_1 ON TA442(TIPODOCCLI,DOCUMCLI,CODIGO);                      
                                                                                
/* TA443( TABLAS DE TABLA MAESTRA DE LUGARES DE ENTREGA )*/                     
CREATE TABLE IF NOT EXISTS TA443(                                               
   CODIGO      CHAR(4) DEFAULT "",                                              
   LUG_ENTREG  VARCHAR(90) DEFAULT "",                                          
   LL_VIATIPO  CHAR(10) DEFAULT "",                                             
   LL_VIANOMB  VARCHAR(40) DEFAULT "",                                          
   LL_NUMERO   CHAR(10) DEFAULT "",                                             
   LL_INTER    CHAR(5) DEFAULT "",                                              
   LL_ZONA     VARCHAR(20) DEFAULT "",                                          
   LL_DIST     VARCHAR(20) DEFAULT "",                                          
   LL_PROV     VARCHAR(15) DEFAULT "",                                          
   LL_DPTO     VARCHAR(15) DEFAULT "",                                          
   COD_CLIEN   CHAR(5) DEFAULT "",                                              
   REFERENCIA  VARCHAR(35) DEFAULT "",                                          
   TIPODOCCLI  CHAR(1) NOT NULL,                                                
   DOCUMCLI    VARCHAR(11) NOT NULL,                                            
   PRIMARY KEY(TIPODOCCLI,DOCUMCLI));                                           
CREATE INDEX TA443_1 ON TA443(TIPODOCCLI,DOCUMCLI);                             
                                                                                
/* TA447( TABLAS DE TABLA DE GASTOS (DHL) )*/                                   
CREATE TABLE IF NOT EXISTS TA447(                                               
   CODIGO      CHAR(6) NOT NULL,                                                
   CONCEPTO    VARCHAR(45) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA447_1 ON TA447(CODIGO);                                          
CREATE INDEX TA447_2 ON TA447(CONCEPTO);                                        
                                                                                
/* TA456( TABLAS DE INCIDENCIAS DE LA SOLIC.DE CHEQUE (DHL) )*/                 
CREATE TABLE IF NOT EXISTS TA456(                                               
   COD         CHAR(2) NOT NULL,                                                
   INCIDENCIA  VARCHAR(50) DEFAULT "",                                          
   DESCRIPCIO  VARCHAR(13) DEFAULT "",                                          
   AUTOMATICO  CHAR(1) DEFAULT "",                                              
   PRIMARY KEY(COD));                                                           
CREATE INDEX TA456_1 ON TA456(COD);                                             
                                                                                
/* TA460( TABLAS DE COMPA�IA MARITIMA PARA MACROMAR )*/                         
CREATE TABLE IF NOT EXISTS TA460(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(80) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA460_1 ON TA460(CODIGO);                                          
CREATE INDEX TA460_2 ON TA460(DESCRIPCIO);                                      
                                                                                
/* TA470( TABLAS DE TIPO DE CARGA PARA JN )*/                                   
CREATE TABLE IF NOT EXISTS TA470(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  CHAR(10) DEFAULT "",                                             
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA470_1 ON TA470(CODIGO);                                          
CREATE INDEX TA470_2 ON TA470(DESCRIPCIO);                                      
                                                                                
/* TA471( TABLAS DE TABLA DE CODIGOS DE APROB. COBRANZA DHL )*/                 
CREATE TABLE IF NOT EXISTS TA471(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(30) DEFAULT "",                                          
   TIPO        CHAR(2) DEFAULT "",                                              
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA471_1 ON TA471(CODIGO);                                          
CREATE INDEX TA471_2 ON TA471(DESCRIPCIO);                                      
                                                                                
/* TA472( TABLAS DE TABLA DE CODIGOS DE APROB. CONTROLING DHL )*/               
CREATE TABLE IF NOT EXISTS TA472(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(50) DEFAULT "",                                          
   TIPO        CHAR(2) DEFAULT "",                                              
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA472_1 ON TA472(CODIGO);                                          
CREATE INDEX TA472_2 ON TA472(DESCRIPCIO);                                      
                                                                                
/* TA498( TABLAS DE DESTINATARIOS PARA DHL (GUIA DE REMISION) )*/               
CREATE TABLE IF NOT EXISTS TA498(                                               
   CODIGO      CHAR(4) NOT NULL,                                                
   NOMB_DESTI  VARCHAR(90) DEFAULT "",                                          
   DIR_DESTI   VARCHAR(80) DEFAULT "",                                          
   TDOC_DESTI  CHAR(1) DEFAULT "",                                              
   DOCU_DESTI  VARCHAR(11) DEFAULT "",                                          
   COD_CLIEN   CHAR(5) NOT NULL,                                                
   PRIMARY KEY(COD_CLIEN,CODIGO));                                              
CREATE INDEX TA498_1 ON TA498(COD_CLIEN,CODIGO);                                
CREATE INDEX TA498_2 ON TA498(NOMB_DESTI);                                      
CREATE INDEX TA498_3 ON TA498(COD_CLIEN,NOMB_DESTI);                            
                                                                                
/* TA505( TABLAS DE TIPO DE FINANCIAMIENTO - CLIENTES )*/                       
CREATE TABLE IF NOT EXISTS TA505(                                               
   CODIGO      CHAR(2) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(20) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA505_1 ON TA505(CODIGO);                                          
CREATE INDEX TA505_2 ON TA505(DESCRIPCIO);                                      
                                                                                
/* TA534( TABLAS DE TABLA DE ESTRUCTURA DEL XML DUA )*/                         
CREATE TABLE IF NOT EXISTS TA534(                                               
   CPADRE      CHAR(2) NOT NULL,                                                
   PADRE       VARCHAR(60) NOT NULL,                                            
   CHIJO       CHAR(2) NOT NULL,                                                
   HIJO        VARCHAR(80) NOT NULL,                                            
   CNIETO      CHAR(2) NOT NULL,                                                
   NIETO       VARCHAR(80) NOT NULL,                                            
   CBISNIETO   CHAR(2) NOT NULL,                                                
   BISNIETO    VARCHAR(50) NOT NULL,                                            
   CTATARANIE  CHAR(2) NOT NULL,                                                
   TATARANIE   VARCHAR(50) NOT NULL,                                            
   CCUADRINIE  CHAR(2) NOT NULL,                                                
   CUADRINIE   VARCHAR(50) NOT NULL,                                            
   CBICUADRIN  CHAR(2) NOT NULL,                                                
   BICUADRIN   VARCHAR(50) NOT NULL,                                            
   CAMPO_VAL   VARCHAR(120) DEFAULT "",                                         
   TIPO_VALOR  CHAR(1) DEFAULT "",                                              
   REG_10      CHAR(4) DEFAULT "",                                              
   REG_20      CHAR(4) DEFAULT "",                                              
   REG_21      CHAR(4) DEFAULT "",                                              
   REG_70      CHAR(3) DEFAULT "",                                              
   DESCRIPCIO  VARCHAR(120) DEFAULT "",                                         
   PRIMARY KEY(CPADRE,CHIJO,CNIETO,CBISNIETO,CTATARANIE,CCUADRINIE,CBICUADRIN));
CREATE INDEX TA534_1 ON TA534(CPADRE,CHIJO,CNIETO,CBISNIETO,CTATARANIE,CCUADRINI
                                                                                
/* TA535( TABLAS DE TABLA DE ESTRUCTURA DEL XML DUIM )*/                        
CREATE TABLE IF NOT EXISTS TA535(                                               
   CPADRE      CHAR(2) NOT NULL,                                                
   PADRE       VARCHAR(60) NOT NULL,                                            
   CHIJO       CHAR(2) NOT NULL,                                                
   HIJO        VARCHAR(80) NOT NULL,                                            
   CNIETO      CHAR(2) NOT NULL,                                                
   NIETO       VARCHAR(80) NOT NULL,                                            
   CBISNIETO   CHAR(2) NOT NULL,                                                
   BISNIETO    VARCHAR(50) NOT NULL,                                            
   CTATARANIE  CHAR(2) NOT NULL,                                                
   TATARANIE   VARCHAR(50) NOT NULL,                                            
   CCUADRINIE  CHAR(2) NOT NULL,                                                
   CUADRINIE   VARCHAR(50) NOT NULL,                                            
   CBICUADRIN  CHAR(2) NOT NULL,                                                
   BICUADRIN   VARCHAR(50) NOT NULL,                                            
   CAMPO_VAL   VARCHAR(120) DEFAULT "",                                         
   TIPO_VALOR  CHAR(1) DEFAULT "",                                              
   TARJA       CHAR(4) DEFAULT "",                                              
   TARJA_DET   CHAR(2) DEFAULT "",                                              
   INGRESO     CHAR(4) DEFAULT "",                                              
   BULTOS_SOB  CHAR(4) DEFAULT "",                                              
   BULTOS_FAL  CHAR(4) DEFAULT "",                                              
   ACTA        CHAR(4) DEFAULT "",                                              
   DESCRIPCIO  VARCHAR(90) DEFAULT "",                                          
   PRIMARY KEY(CPADRE,CHIJO,CNIETO,CBISNIETO,CTATARANIE,CCUADRINIE,CBICUADRIN));
CREATE INDEX TA535_1 ON TA535(CPADRE,CHIJO,CNIETO,CBISNIETO,CTATARANIE,CCUADRINI
                                                                                
/* TA537( TABLAS DE TABLA DE INCOTERRMS PARA DHL )*/                            
CREATE TABLE IF NOT EXISTS TA537(                                               
   CODIGO      CHAR(3) NOT NULL,                                                
   DESCRIPCIO  VARCHAR(39) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA537_1 ON TA537(CODIGO);                                          
CREATE INDEX TA537_2 ON TA537(DESCRIPCIO);                                      
                                                                                
/* TA546( TABLAS DE PARTIDAS PARA EL BCR )*/                                    
CREATE TABLE IF NOT EXISTS TA546(                                               
   PARTIDA     CHAR(10) NOT NULL,                                               
   PRIMARY KEY(PARTIDA));                                                       
CREATE INDEX TA546_1 ON TA546(PARTIDA);                                         
                                                                                
/* TA558( TABLAS DE TABLA DE ESTRUCTURA DEL XML-MANIF )*/                       
CREATE TABLE IF NOT EXISTS TA558(                                               
   CPADRE      CHAR(2) NOT NULL,                                                
   PADRE       VARCHAR(60) NOT NULL,                                            
   CHIJO       CHAR(2) NOT NULL,                                                
   HIJO        VARCHAR(80) NOT NULL,                                            
   CNIETO      CHAR(2) NOT NULL,                                                
   NIETO       VARCHAR(80) NOT NULL,                                            
   CBISNIETO   CHAR(2) NOT NULL,                                                
   BISNIETO    VARCHAR(50) NOT NULL,                                            
   CTATARANIE  CHAR(2) NOT NULL,                                                
   TATARANIE   VARCHAR(50) NOT NULL,                                            
   CCUADRINIE  CHAR(2) NOT NULL,                                                
   CUADRINIE   VARCHAR(50) NOT NULL,                                            
   CBICUADRIN  CHAR(2) NOT NULL,                                                
   BICUADRIN   VARCHAR(50) NOT NULL,                                            
   CAMPO_VAL   VARCHAR(120) DEFAULT "",                                         
   TIPO_VALOR  CHAR(1) DEFAULT "",                                              
   CARGA       CHAR(5) DEFAULT "",                                              
   DESCRIPCIO  VARCHAR(90) DEFAULT "",                                          
   PRIMARY KEY(CPADRE,CHIJO,CNIETO,CBISNIETO,CTATARANIE,CCUADRINIE,CBICUADRIN));
CREATE INDEX TA558_1 ON TA558(CPADRE,CHIJO,CNIETO,CBISNIETO,CTATARANIE,CCUADRINI
                                                                                
/* TA592( TABLAS DE HORARIO DE ALERTAS PARA VENCIMIENTOS DE TRANSBORDO )*/      
CREATE TABLE IF NOT EXISTS TA592(                                               
   HORARIO     CHAR(10) NOT NULL,                                               
   HORA        CHAR(5) NOT NULL,                                                
   SEGUNDOS    NUMERIC(8,0) DEFAULT 0,                                          
   ACTIVAR     NUMERIC(1,0) DEFAULT 0,                                          
   FECHA_ALE   DATE,                                                            
   PRIMARY KEY(HORARIO));                                                       
CREATE INDEX TA592_1 ON TA592(HORARIO);                                         
CREATE INDEX TA592_2 ON TA592(SEGUNDOS);                                        
                                                                                
/* TA592C( TABLAS DE CONTROL DE ALERTAS PARA VENCIMIENTO DE TRANSBORDO )*/      
CREATE TABLE IF NOT EXISTS TA592C(                                              
   NOMBREPC    VARCHAR(30) NOT NULL,                                            
   FECHA_PROC  CHAR(8) NOT NULL,                                                
   TIPO_HORA   CHAR(10) NOT NULL,                                               
   CODIGO_AGT  CHAR(4) NOT NULL,                                                
   HORA_REGI   CHAR(8) DEFAULT "",                                              
   HORA        CHAR(5) NOT NULL,                                                
   PRIMARY KEY(NOMBREPC,FECHA_PROC,TIPO_HORA,CODIGO_AGT));                      
CREATE INDEX TA592C_1 ON TA592C(NOMBREPC,FECHA_PROC,TIPO_HORA,CODIGO_AGT);      
                                                                                
