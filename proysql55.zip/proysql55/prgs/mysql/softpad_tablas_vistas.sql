/**********************************************************************************/
/*  CREACION DE VISTAS PARA EL SOFTPAD_TABLAS 
/**********************************************************************************/

create view softpad_tablas.TA191 as 
select marca as codigo,ta734.descripcio,categoria,ta734.fechaini,ta734.fechafin 
from softpad_tablas.ta259 
left join softpad_tablas.ta734 on softpad_tablas.ta734.codigo=softpad_tablas.ta259.marca;

create view softpad_tablas.TA192 as 
select carroc as codigo,ta735.descripcio,modelo,marca,categoria,ta735.descrip1,ta735.fechaini,ta735.fechafin 
from softpad_tablas.ta259 
left join softpad_tablas.ta735 on softpad_tablas.ta735.codigo=softpad_tablas.ta259.carroc;

