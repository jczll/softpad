﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using System.Net;
using System.IO;
using System.Configuration;
using System.Threading;
using System.Data;
using System.Collections;

namespace SeidaParametros
{
    

    public class WebService
    {
        #region Privates Variables
        public DataTable m_dtEnvios = null; ///< Objeto DataTable para manipular los registros a enviar
        private DataTable m_dtConsultas = null;  ///< Objeto DataTable para manipular los registros a recibir
        private string m_url= "https://e-seida.sunat.gob.pe/ol-ad-itseida-ws/ReceptorService.htm?wsdl"; ///< Direccion URL del servicio Web
        private string m_pathApp= "C:\\ESTSQL\\ADUANAS\\"; ///< Ruta de ejecucion de la aplicacion
        private TextWriterTraceListener m_listenerLog; ///< Bitacora de eventos del sistema
        private System.IO.FileStream m_traceLog; ///< Archivo enlazado con la bitacora de eventos del sistema        
        #endregion

        string rucagencia;
        string usuariosol;
        string clavesol;
        string codigoenvio;
        string ip_pc;
        string mac_pc;
        string url_seida;

        public void SenFilesWebService(string xrucagencia, string xusuariosol, string xclavesol, string xcodigoenvio,string xrutazip,string xtransaccion)
        {
            m_dtEnvios = Logic.Core.CreateModelSend();
            m_dtConsultas = Logic.Core.CreateModelQuery();            
            Logic.Core.VerifieDirectories(m_pathApp);
            CreateListener();            
            Logic.Core.TraceLogApp("++++++++++++++++++++BITACORA DE ENVIO++++++++++++++++++++++++++++");
            Logic.Core.TraceLogApp("Ruta de Ejecucion: " + m_pathApp);            
            CreateListener();
            SendFiles(xrucagencia,xusuariosol,xclavesol,xcodigoenvio,xrutazip,xtransaccion);
            CloseListener();


        }
        public void SendQueryWebService(string xrucagencia, string xusuariosol, string xclavesol, string xaño, string xticket)
        {
            m_dtEnvios = Logic.Core.CreateModelSend();
            m_dtConsultas = Logic.Core.CreateModelQuery();            
            Logic.Core.VerifieDirectories(m_pathApp);
            CreateListener();            
            Logic.Core.TraceLogApp("++++++++++++++++++++BITACORA DE ENVIO++++++++++++++++++++++++++++");
            Logic.Core.TraceLogApp("Ruta de Ejecucion: " + m_pathApp);            
            CreateListener();
            SendQuerys(xrucagencia, xusuariosol, xclavesol, xaño, xticket);
            CloseListener();
        }
        private void CreateListener()
        {
            if (File.Exists(m_pathApp + "\\" + Logic.Core.DIRECTORIO_LOGGER + "\\" + Logic.Core.TRACE_LOG_FILENAME))
                m_traceLog = new System.IO.FileStream(m_pathApp + "\\" + Logic.Core.DIRECTORIO_LOGGER + "\\" + Logic.Core.TRACE_LOG_FILENAME, System.IO.FileMode.Open, FileAccess.ReadWrite, FileShare.ReadWrite);
            else
                m_traceLog = new System.IO.FileStream(m_pathApp + "\\" + Logic.Core.DIRECTORIO_LOGGER + "\\" + Logic.Core.TRACE_LOG_FILENAME, System.IO.FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.ReadWrite);

            m_traceLog.Seek(0, SeekOrigin.End);
            m_listenerLog = new TextWriterTraceListener(m_traceLog);
            Trace.Listeners.Add(m_listenerLog);
        }
        
        private void EvtClick1(object sender, EventArgs e)
        {
            CloseListener();
            Application.Exit();
        }
        private void CloseListener()
        {
            m_traceLog.Seek(0, SeekOrigin.End);
            m_listenerLog.Flush();
            m_traceLog.Flush();
            m_listenerLog.Close();
            m_listenerLog.Dispose();
            m_traceLog.Close();
            m_traceLog.Dispose();
            m_traceLog = null;
            m_listenerLog = null;
        }
        private void SendFiles(string xrucagencia,string xusuariosol,string xclavesol,string xcodigoenvio,string xrutazip,string xtransaccion)
        {            
            bool change = false;
            Configuration config = ConfigurationManager.OpenExeConfiguration(Application.ExecutablePath);
            rucagencia = xrucagencia;
            usuariosol = xusuariosol;
            clavesol = xclavesol;
            codigoenvio = xclavesol;            
            url_seida = m_url;
            ip_pc = Logic.Core.GetIP();
            mac_pc = Logic.Core.GetMACAddress();
            Logic.Core.TraceLogApp("NombrePC: " + Dns.GetHostName());
            Logic.Core.TraceLogApp("IP      : " + ip_pc);
            Logic.Core.TraceLogApp("MAC     : " + mac_pc);

            string dir = "" + config.AppSettings.Settings["DirectorioDocumento"].Value;
            if (dir.Length == 0)
            {
                dir = m_pathApp + "\\" + Logic.Core.DIRECTORIO_DOCUMENTO;
                config.AppSettings.Settings.Remove("DirectorioDocumento");
                config.AppSettings.Settings.Add("DirectorioDocumento", dir);
                change = true;
            }
            dir = "" + config.AppSettings.Settings["DirectorioAcuse"].Value;
            if (dir.Length == 0)
            {
                dir = m_pathApp + "\\" + Logic.Core.DIRECTORIO_ACUSE;
                config.AppSettings.Settings.Remove("DirectorioAcuse");
                config.AppSettings.Settings.Add("DirectorioAcuse", dir);
                change = true;
            }
            dir = "" + config.AppSettings.Settings["DirectorioRespuesta"].Value;
            if (dir.Length == 0)
            {
                dir = m_pathApp + "\\" + Logic.Core.DIRECTORIO_RESPUESTA;
                config.AppSettings.Settings.Remove("DirectorioRespuesta");
                config.AppSettings.Settings.Add("DirectorioRespuesta", dir);
                change = true;
            }
            if (true == change)
            {
                config.Save(ConfigurationSaveMode.Modified);
            }
            /////////////////////
            if (ValidatePreEnvio(1))
            {                
                Application.DoEvents();

                #region Ejecucion de hilos de envio               
                ArrayList objectsThread = new ArrayList();
                
                Application.DoEvents();
                int i = 0;                
                try
                {                    
                    Application.DoEvents();
                    Thread.Sleep(500);

                    Logic.ThreadProxy otp = new Logic.ThreadProxy("Task-" + i.ToString(), 1);
                    otp.Correlativo = (i + 1);
                    otp.Url = m_url;
                    otp.Usuario = Logic.Core.CombineUserData(rucagencia, usuariosol);
                    otp.Clave = clavesol;                    
                    otp.IdProceso = Logic.Core.NameUnique();                    
                    otp.NumeroTransaccion = xtransaccion;                    
                    otp.NombreArchivo = xrutazip;
                    otp.DirectorioSave = m_pathApp + "\\" + Logic.Core.DIRECTORIO_ACUSE;                    
                    Logic.Core.TraceLogApp("Enviando Hilo(" + otp.Correlativo.ToString() + ") | Nro.Transaccion:" + otp.NumeroTransaccion + " | Archivo: " + otp.NombreArchivo);
                    objectsThread.Add(otp);
                    Application.DoEvents();
                    otp.Run();
                }
                catch (Exception ex)
                {                    
                    MessageBox.Show(ex.Message+"<--+-->"+ex.Source);
                    Logic.Core.TraceLogApp("Error: " + ex.Message.ToString());
                }               

                for (int j = 0; j < objectsThread.Count; j++)
                {
                    Logic.ThreadProxy otp = (Logic.ThreadProxy)objectsThread[j];
                    ///<Trace.WriteLine("Thread Nombre: " + otp.Namethread);
                    //progressBar1.PerformStep();
                    Application.DoEvents();
                    otp.Join();
                }
                objectsThread.Clear();
                objectsThread = null;
                #endregion

                Thread.Sleep(500);              
                m_traceLog.Seek(0, SeekOrigin.End);
                m_listenerLog.Flush(); 
                m_traceLog.Flush();
                
            }
        }
        private Boolean ValidatePreEnvio(int typeValidate)
        {
            if (rucagencia.Length== 0)
            {
                MessageBox.Show("Número de RUC invalido!", "Error de Validación");
                return false;
            }
            if (usuariosol.Length == 0)
            {
                MessageBox.Show("Usuario es invalido!", "Error de Validación");
                return false;
            }
            if (codigoenvio.Length == 0)
            {
                MessageBox.Show("Codigo de Envio es invalido!", "Error de Validación");
                return false;
            }
            if (clavesol.Length == 0)
            {
                MessageBox.Show("Clave SOL es invalido!", "Error de Validación");
                return false;
            }
            if (ip_pc.Length == 0)
            {
                MessageBox.Show("Error al obtener la direccion IP, no se podrá enviar y/o consultar.", "Error de Validación");
                return false;
            }
            if (mac_pc.Length == 0)
            {
                MessageBox.Show("Error al obtener la direccion MAC, no se podrá enviar y/o consultar.", "Error de Validación");
                return false;
            }           
            return true;
        }
        private void SendQuerys(string xrucagencia, string xusuariosol, string xclavesol, string xaño, string xticket)
        {            
            bool change = false;
            Configuration config = ConfigurationManager.OpenExeConfiguration(Application.ExecutablePath);
            rucagencia = xrucagencia;
            usuariosol = xusuariosol;
            clavesol = xclavesol;
            codigoenvio = xclavesol;            
            url_seida = m_url;
            ip_pc = Logic.Core.GetIP();
            mac_pc = Logic.Core.GetMACAddress();
            Logic.Core.TraceLogApp("NombrePC: " + Dns.GetHostName());
            Logic.Core.TraceLogApp("IP      : " + ip_pc);
            Logic.Core.TraceLogApp("MAC     : " + mac_pc);

            string dir = "" + config.AppSettings.Settings["DirectorioDocumento"].Value;
            if (dir.Length == 0)
            {
                dir = m_pathApp + "\\" + Logic.Core.DIRECTORIO_DOCUMENTO;
                config.AppSettings.Settings.Remove("DirectorioDocumento");
                config.AppSettings.Settings.Add("DirectorioDocumento", dir);
                change = true;
            }
            dir = "" + config.AppSettings.Settings["DirectorioAcuse"].Value;
            if (dir.Length == 0)
            {
                dir = m_pathApp + "\\" + Logic.Core.DIRECTORIO_ACUSE;
                config.AppSettings.Settings.Remove("DirectorioAcuse");
                config.AppSettings.Settings.Add("DirectorioAcuse", dir);
                change = true;
            }
            dir = "" + config.AppSettings.Settings["DirectorioRespuesta"].Value;
            if (dir.Length == 0)
            {
                dir = m_pathApp + "\\" + Logic.Core.DIRECTORIO_RESPUESTA;
                config.AppSettings.Settings.Remove("DirectorioRespuesta");
                config.AppSettings.Settings.Add("DirectorioRespuesta", dir);
                change = true;
            }
            if (true == change)
            {
                config.Save(ConfigurationSaveMode.Modified);
            }
            /////////////////////
            if (ValidatePreEnvio(2))
            {                
                Application.DoEvents();               

                #region Ejecucion de hilos de consulta
                ArrayList objectsThread = new ArrayList();
                
                int i = 0;                
                try
                {                    
                    Application.DoEvents();
                    Thread.Sleep(150);
                    Logic.ThreadProxy otp = new Logic.ThreadProxy("Task-" + i.ToString(), 2);
                    otp.Correlativo = (i + 1);
                    otp.Url = m_url;
                    otp.Usuario = Logic.Core.CombineUserData(rucagencia, usuariosol);
                    otp.Clave = clavesol;
                    otp.IdProceso = Logic.Core.NameUnique();
                    otp.AnnoConsulta = xaño;
                    otp.TicketConsulta = xticket;
                    otp.DirectorioSave = m_pathApp + "\\" + Logic.Core.DIRECTORIO_RESPUESTA;                    
                    Logic.Core.TraceLogApp("Consulta Hilo(" + otp.Correlativo.ToString() + ") | Año:" + otp.AnnoConsulta + " | Ticket: " + otp.TicketConsulta);
                    Application.DoEvents();
                    objectsThread.Add(otp);
                    otp.Run();
                    Application.DoEvents();
                }
                catch (Exception ex)
                {                    
                    Logic.Core.TraceLogApp("Error: " + ex.Message.ToString());
                }                

                for (int j = 0; j < objectsThread.Count; j++)
                {
                    Logic.ThreadProxy otp = (Logic.ThreadProxy)objectsThread[j];
                    ///<Trace.WriteLine("Thread Nombre: " + otp.Namethread);
                    otp.Join();                    
                    Application.DoEvents();
                }

                for (int j = 0; j < objectsThread.Count; j++)
                {
                    Logic.ThreadProxy otp = (Logic.ThreadProxy)objectsThread[j];
                    ///<Trace.WriteLine("Thread NombreRespuesta: " + otp.NombreRespuesta);
                    for (int k = 0; k < m_dtConsultas.Rows.Count; k++)
                    {
                        if (m_dtConsultas.Rows[k][0].ToString() == otp.IdProceso)
                        {
                            m_dtConsultas.Rows[k]["ArchivoRecibido"] = otp.NombreRespuesta;
                            break;
                        }
                    }
                }
                objectsThread.Clear();
                objectsThread = null;
                #endregion                
                Thread.Sleep(500);               
                m_traceLog.Seek(0, SeekOrigin.End);
                m_listenerLog.Flush(); ///< Actualizando la bitacora de eventos
                m_traceLog.Flush();
                
            }
        }
    }
}
