﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;
using System.Diagnostics;
using System.Web.Services;
using System.Web.Services.Protocols;
using System.Xml.Serialization;
using Microsoft.Web.Services3;

namespace SeidaParametros.Logic
{
    class ProxyClient
    {

    }
    
    [System.CodeDom.Compiler.GeneratedCodeAttribute("wsdl", "4.0.30319.17929")]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Web.Services.WebServiceBindingAttribute(Name = "ReceptorWebServiceServiceImplPortBinding", Namespace = "http://service.receptor.tecnologia.sunat.gob.pe/")]
    public partial class ReceptorServicehtm : Microsoft.Web.Services3.WebServicesClientProtocol
    {

        private System.Threading.SendOrPostCallback recibirArchivoOperationCompleted;
        private System.Threading.SendOrPostCallback realizarConsultaOperationCompleted;
        
        public ReceptorServicehtm(string url)
        {
            this.Url = url; 
        }
        
        public event recibirArchivoCompletedEventHandler recibirArchivoCompleted;
        
        public event realizarConsultaCompletedEventHandler realizarConsultaCompleted;
        
        [System.Web.Services.Protocols.SoapDocumentMethodAttribute("urn:recibirArchivo", RequestNamespace = "http://services.sigad.sunat.gob.pe", ResponseNamespace = "http://services.sigad.sunat.gob.pe", Use = System.Web.Services.Description.SoapBindingUse.Literal, ParameterStyle = System.Web.Services.Protocols.SoapParameterStyle.Wrapped)]
        [return: System.Xml.Serialization.XmlElementAttribute("recibirArchivoResultado", Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public acuseRecibo recibirArchivo([System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified)] string numeroTransaccion, [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, DataType = "base64Binary")] byte[] informacionArchivo)
        {
            object[] results = this.Invoke("recibirArchivo", new object[] {
                    numeroTransaccion,
                    informacionArchivo});
            return ((acuseRecibo)(results[0]));
        }
        
        public System.IAsyncResult BeginrecibirArchivo(string numeroTransaccion, byte[] informacionArchivo, System.AsyncCallback callback, object asyncState)
        {
            return this.BeginInvoke("recibirArchivo", new object[] {
                    numeroTransaccion,
                    informacionArchivo}, callback, asyncState);
        }
        
        public acuseRecibo EndrecibirArchivo(System.IAsyncResult asyncResult)
        {
            object[] results = this.EndInvoke(asyncResult);
            return ((acuseRecibo)(results[0]));
        }
       
        public void recibirArchivoAsync(string numeroTransaccion, byte[] informacionArchivo)
        {
            this.recibirArchivoAsync(numeroTransaccion, informacionArchivo, null);
        }
        
        public void recibirArchivoAsync(string numeroTransaccion, byte[] informacionArchivo, object userState)
        {
            if ((this.recibirArchivoOperationCompleted == null))
            {
                this.recibirArchivoOperationCompleted = new System.Threading.SendOrPostCallback(this.OnrecibirArchivoOperationCompleted);
            }
            this.InvokeAsync("recibirArchivo", new object[] {
                    numeroTransaccion,
                    informacionArchivo}, this.recibirArchivoOperationCompleted, userState);
        }

        private void OnrecibirArchivoOperationCompleted(object arg)
        {
            if ((this.recibirArchivoCompleted != null))
            {
                System.Web.Services.Protocols.InvokeCompletedEventArgs invokeArgs = ((System.Web.Services.Protocols.InvokeCompletedEventArgs)(arg));
                this.recibirArchivoCompleted(this, new recibirArchivoCompletedEventArgs(invokeArgs.Results, invokeArgs.Error, invokeArgs.Cancelled, invokeArgs.UserState));
            }
        }
        
        [System.Web.Services.Protocols.SoapDocumentMethodAttribute("urn:realizarConsulta", RequestNamespace = "http://services.sigad.sunat.gob.pe", ResponseNamespace = "http://services.sigad.sunat.gob.pe", Use = System.Web.Services.Description.SoapBindingUse.Literal, ParameterStyle = System.Web.Services.Protocols.SoapParameterStyle.Wrapped)]
        [return: System.Xml.Serialization.XmlElementAttribute("respuesta", Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public respuestaConsultaBean realizarConsulta([System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified)] string parametrosConsulta, [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, DataType = "base64Binary")] out byte[] realizarConsultaResultado)
        {
            object[] results = this.Invoke("realizarConsulta", new object[] {
                    parametrosConsulta});
            realizarConsultaResultado = ((byte[])(results[1]));
            return ((respuestaConsultaBean)(results[0]));
        }
        
        public System.IAsyncResult BeginrealizarConsulta(string parametrosConsulta, System.AsyncCallback callback, object asyncState)
        {
            return this.BeginInvoke("realizarConsulta", new object[] {
                    parametrosConsulta}, callback, asyncState);
        }
        
        public respuestaConsultaBean EndrealizarConsulta(System.IAsyncResult asyncResult, out byte[] realizarConsultaResultado)
        {
            object[] results = this.EndInvoke(asyncResult);
            realizarConsultaResultado = ((byte[])(results[1]));
            return ((respuestaConsultaBean)(results[0]));
        }
        
        public void realizarConsultaAsync(string parametrosConsulta)
        {
            this.realizarConsultaAsync(parametrosConsulta, null);
        }
        
        public void realizarConsultaAsync(string parametrosConsulta, object userState)
        {
            if ((this.realizarConsultaOperationCompleted == null))
            {
                this.realizarConsultaOperationCompleted = new System.Threading.SendOrPostCallback(this.OnrealizarConsultaOperationCompleted);
            }
            this.InvokeAsync("realizarConsulta", new object[] {
                    parametrosConsulta}, this.realizarConsultaOperationCompleted, userState);
        }

        private void OnrealizarConsultaOperationCompleted(object arg)
        {
            if ((this.realizarConsultaCompleted != null))
            {
                System.Web.Services.Protocols.InvokeCompletedEventArgs invokeArgs = ((System.Web.Services.Protocols.InvokeCompletedEventArgs)(arg));
                this.realizarConsultaCompleted(this, new realizarConsultaCompletedEventArgs(invokeArgs.Results, invokeArgs.Error, invokeArgs.Cancelled, invokeArgs.UserState));
            }
        }
        
        public new void CancelAsync(object userState)
        {
            base.CancelAsync(userState);
        }
    }
    
    [System.CodeDom.Compiler.GeneratedCodeAttribute("wsdl", "4.0.30319.17929")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://services.sigad.sunat.gob.pe")]
    public partial class acuseRecibo
    {

        private string anhoEnvioField;
        private string documentoEmisorField;
        private string fechaRecepcionField;
        private string hashDocumentoField;
        private errorAcuse[] listaErroresField;
        private errorAcuse[] listaWarningField;
        private string numeroOrdenField;
        private string ticketEnvioField;
        
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public string anhoEnvio
        {
            get
            {
                return this.anhoEnvioField;
            }
            set
            {
                this.anhoEnvioField = value;
            }
        }
        
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public string documentoEmisor
        {
            get
            {
                return this.documentoEmisorField;
            }
            set
            {
                this.documentoEmisorField = value;
            }
        }
        
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public string fechaRecepcion
        {
            get
            {
                return this.fechaRecepcionField;
            }
            set
            {
                this.fechaRecepcionField = value;
            }
        }
        
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public string hashDocumento
        {
            get
            {
                return this.hashDocumentoField;
            }
            set
            {
                this.hashDocumentoField = value;
            }
        }
        
        [System.Xml.Serialization.XmlElementAttribute("listaErrores", Form = System.Xml.Schema.XmlSchemaForm.Unqualified, IsNullable = true)]
        public errorAcuse[] listaErrores
        {
            get
            {
                return this.listaErroresField;
            }
            set
            {
                this.listaErroresField = value;
            }
        }
        
        [System.Xml.Serialization.XmlElementAttribute("listaWarning", Form = System.Xml.Schema.XmlSchemaForm.Unqualified, IsNullable = true)]
        public errorAcuse[] listaWarning
        {
            get
            {
                return this.listaWarningField;
            }
            set
            {
                this.listaWarningField = value;
            }
        }
        
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public string numeroOrden
        {
            get
            {
                return this.numeroOrdenField;
            }
            set
            {
                this.numeroOrdenField = value;
            }
        }
        
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public string ticketEnvio
        {
            get
            {
                return this.ticketEnvioField;
            }
            set
            {
                this.ticketEnvioField = value;
            }
        }
    }
    
    [System.CodeDom.Compiler.GeneratedCodeAttribute("wsdl", "4.0.30319.17929")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://services.sigad.sunat.gob.pe")]
    public partial class errorAcuse
    {

        private string codigoField;
        private string descripcionField;
        private string tipoField;
        
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public string codigo
        {
            get
            {
                return this.codigoField;
            }
            set
            {
                this.codigoField = value;
            }
        }
        
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public string descripcion
        {
            get
            {
                return this.descripcionField;
            }
            set
            {
                this.descripcionField = value;
            }
        }
        
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public string tipo
        {
            get
            {
                return this.tipoField;
            }
            set
            {
                this.tipoField = value;
            }
        }
    }
    
    [System.CodeDom.Compiler.GeneratedCodeAttribute("wsdl", "4.0.30319.17929")]
    [System.SerializableAttribute()]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(Namespace = "http://services.sigad.sunat.gob.pe")]
    public partial class respuestaConsultaBean
    {

        private string descripcionField;
        private string tipoField;
        
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public string descripcion
        {
            get
            {
                return this.descripcionField;
            }
            set
            {
                this.descripcionField = value;
            }
        }
        
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
        public string tipo
        {
            get
            {
                return this.tipoField;
            }
            set
            {
                this.tipoField = value;
            }
        }
    }
    
    [System.CodeDom.Compiler.GeneratedCodeAttribute("wsdl", "4.0.30319.17929")]
    public delegate void recibirArchivoCompletedEventHandler(object sender, recibirArchivoCompletedEventArgs e);
    
    [System.CodeDom.Compiler.GeneratedCodeAttribute("wsdl", "4.0.30319.17929")]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    public partial class recibirArchivoCompletedEventArgs : System.ComponentModel.AsyncCompletedEventArgs
    {

        private object[] results;

        internal recibirArchivoCompletedEventArgs(object[] results, System.Exception exception, bool cancelled, object userState) :
            base(exception, cancelled, userState)
        {
            this.results = results;
        }
        
        public acuseRecibo Result
        {
            get
            {
                this.RaiseExceptionIfNecessary();
                return ((acuseRecibo)(this.results[0]));
            }
        }
    }
    
    [System.CodeDom.Compiler.GeneratedCodeAttribute("wsdl", "4.0.30319.17929")]
    public delegate void realizarConsultaCompletedEventHandler(object sender, realizarConsultaCompletedEventArgs e);
    
    [System.CodeDom.Compiler.GeneratedCodeAttribute("wsdl", "4.0.30319.17929")]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    public partial class realizarConsultaCompletedEventArgs : System.ComponentModel.AsyncCompletedEventArgs
    {

        private object[] results;

        internal realizarConsultaCompletedEventArgs(object[] results, System.Exception exception, bool cancelled, object userState) :
            base(exception, cancelled, userState)
        {
            this.results = results;
        }
        
        public respuestaConsultaBean Result
        {
            get
            {
                this.RaiseExceptionIfNecessary();
                return ((respuestaConsultaBean)(this.results[0]));
            }
        }
        
        public byte[] realizarConsultaResultado
        {
            get
            {
                this.RaiseExceptionIfNecessary();
                return ((byte[])(this.results[1]));
            }
        }
    }

}
