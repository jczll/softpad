﻿#region using directives
using System;
using System.Xml.Serialization;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Web.Services3;
using Microsoft.Web.Services3.Security;
using Microsoft.Web.Services3.Security.Tokens;
using Microsoft.Web.Services3.Design;
using System.Web.Services;
using System.Windows.Forms;
using System.Configuration;
#endregion

namespace SeidaParametros.Logic
{
    class ThreadProxy
    {
        #region declare variables
        private int correlativo;
        private string url;
        private string idProceso;
        private string numeroTransaccion;
        private string nombreArchivo;
        private string annoConsulta;
        private string ticketConsulta;
        private string directorioSave;
        private string usuario;
        private string clave;
        private TextBox txtMessage;
        private Thread Thrd;
        private string nombreRespuesta;
        private string proxyActivo;
        private string proxyDireccionIP;
        private string proxyPuerto;
        private string proxyNombreDominio;
        private string proxyUsuario;
        private string proxyClave;
        #endregion

        #region Constructors
        public ThreadProxy()
        {
        }

        public ThreadProxy(string nameTask, int typeStart)
        {
            Configuration config = ConfigurationManager.OpenExeConfiguration(Application.ExecutablePath);
            this.proxyActivo = config.AppSettings.Settings["ProxyActivo"].Value;
            this.proxyDireccionIP = config.AppSettings.Settings["ProxyDireccionIP"].Value;
            this.proxyPuerto = config.AppSettings.Settings["ProxyPuerto"].Value;
            this.proxyNombreDominio = config.AppSettings.Settings["ProxyNombreDominio"].Value;
            this.proxyUsuario = config.AppSettings.Settings["ProxyUsuario"].Value;
            this.proxyClave = config.AppSettings.Settings["ProxyClave"].Value;

            this.nombreRespuesta = "";
            if (1 == typeStart)
            {
                Thrd = new Thread(this.OnStartSend);
            }
            else
            {
                Thrd = new Thread(this.OnStartQuery);
            }
            Thrd.Name = nameTask;
        }
        #endregion

        public void Run()
        {
            Thrd.Start();
        }

        public void Join()
        {
            Thrd.Join();
        }

        #region OnStartQuery        
        private void OnStartQuery()
        {
            try
            {
                byte[] fileBytes;
                NetworkCredential cr = null;
                WebProxy pr = null;
                
                Logic.ReceptorServicehtm oProxy = new Logic.ReceptorServicehtm(this.url);
                
                if (Logic.Core.CONSTANTS_TRUE == this.proxyActivo.ToLower())
                {
                    cr = new NetworkCredential(this.proxyUsuario, this.proxyClave, this.proxyNombreDominio);
                    pr = new WebProxy(this.proxyDireccionIP, int.Parse(this.proxyPuerto));
                    pr.Credentials = cr;
                    oProxy.Proxy = pr;
                    Logic.Core.TraceLogApp("Activando credenciales de proxy!");
                }

                Logic.Extensions.CustomHeadersAssertion assert = new Logic.Extensions.CustomHeadersAssertion(this.usuario, this.clave);
                Policy policy = new Policy();
                policy.Assertions.Add(assert);
                oProxy.SetPolicy(policy);

                String query = "<consulta><tipo>1</tipo><parametros><numeroTicket>" + this.ticketConsulta.Trim() + "</numeroTicket><annoTicket>" + this.annoConsulta + "</annoTicket></parametros></consulta>";
                IAsyncResult result = oProxy.BeginrealizarConsulta(query, null, null);
                result.AsyncWaitHandle.WaitOne();
                Logic.respuestaConsultaBean valueResult = oProxy.EndrealizarConsulta(result, out fileBytes);
                if (valueResult != null)
                {                    
                    if (fileBytes != null)
                    {
                        string fileName = this.directorioSave + "\\" + Logic.Core.GenerateNameResponse(this.annoConsulta, this.ticketConsulta);
                        this.nombreRespuesta = fileName;
                        File.WriteAllBytes(@fileName, fileBytes);                        
                        Logic.Core.TraceLogApp("Respuesta Hilo(" + this.correlativo.ToString() + ") | Ticket:" + this.ticketConsulta + " | Archivo: " + fileName);
                    }
                }
                policy = null;
                oProxy = null;
            }
            catch (Exception ex)
            {
                string messageEval = Logic.Core.EvaluateMessageError(ex.Message.ToString());                
                Logic.Core.TraceLogApp("Error OnStartQuery : " + messageEval);
            }
        }
        #endregion

        #region OnStartSend        
        private void OnStartSend()
        {
            if (File.Exists(this.nombreArchivo))
            {
                try
                {
                    NetworkCredential cr = null;
                    WebProxy pr = null;

                    byte[] fileArray = File.ReadAllBytes(this.nombreArchivo);
                    Logic.ReceptorServicehtm oProxy = new Logic.ReceptorServicehtm(this.url);
                    
                    if (Logic.Core.CONSTANTS_TRUE == this.proxyActivo.ToLower())
                    {
                        cr = new NetworkCredential(this.proxyUsuario, this.proxyClave, this.proxyNombreDominio);
                        pr = new WebProxy(this.proxyDireccionIP, int.Parse(this.proxyPuerto));
                        pr.Credentials = cr;
                        oProxy.Proxy = pr;
                        Logic.Core.TraceLogApp("Activando credenciales de proxy!");
                    }

                    Logic.Extensions.CustomHeadersAssertion assert = new Logic.Extensions.CustomHeadersAssertion(this.usuario, this.clave);
                    Policy policy = new Policy();
                    policy.Assertions.Add(assert);
                    oProxy.SetPolicy(policy);
                    
                    IAsyncResult result = oProxy.BeginrecibirArchivo(this.numeroTransaccion, fileArray, null, null);
                    result.AsyncWaitHandle.WaitOne();
                    var valueResult = oProxy.EndrecibirArchivo(result);         
                                      
                    Logic.acuseRecibo oTicket = (Logic.acuseRecibo)valueResult;
                    string fileName = this.directorioSave + "\\" + Logic.Core.GenerateNameAcuse(oTicket.anhoEnvio, oTicket.ticketEnvio);
                    XmlSerializer x = new XmlSerializer(typeof(Logic.acuseRecibo));
                    TextWriter writer = new StreamWriter(fileName);
                    x.Serialize(writer, valueResult);
                    writer.Close();
                    writer = null;
                    
                    Logic.Core.TraceLogApp("Respuesta Hilo(" + this.correlativo.ToString() + ") | Ticket: " + oTicket.ticketEnvio + " | acuse:" + fileName);
                }
                catch (Exception ex)
                {
                    string messageEval = Logic.Core.EvaluateMessageError(ex.Message.ToString() + "<--+-->"+ ex.Source+"<--+-->"+ex.TargetSite);                    
                    Logic.Core.TraceLogApp("Error OnStartSend : " + messageEval);
                }
            }
            else
            {                
                Logic.Core.TraceLogApp("Archivo a enviar NO EXISTE:" + this.nombreArchivo);
            }
        }
        #endregion

        #region Attributes
        public string Namethread
        {
            get { return Thrd.Name; }
        }
        public string Url
        {
            get { return url; }
            set { url = value; }
        }
        public string IdProceso
        {
            get { return idProceso; }
            set { idProceso = value; }
        }
        public string NumeroTransaccion
        {
            get { return numeroTransaccion; }
            set { numeroTransaccion = value; }
        }
        public string NombreArchivo
        {
            get { return nombreArchivo; }
            set { nombreArchivo = value; }
        }
        public string DirectorioSave
        {
            get { return directorioSave; }
            set { directorioSave = value; }
        }
        public string Usuario
        {
            get { return usuario; }
            set { usuario = value; }
        }
        public string Clave
        {
            get { return clave; }
            set { clave = value; }
        }
        public TextBox TxtMessage
        {
            get { return txtMessage; }
            set { txtMessage = value; }
        }
        public string AnnoConsulta
        {
            get { return annoConsulta; }
            set { annoConsulta = value; }
        }
        public string TicketConsulta
        {
            get { return ticketConsulta; }
            set { ticketConsulta = value; }
        }
        public string NombreRespuesta
        {
            get { return nombreRespuesta; }
            set { nombreRespuesta = value; }
        }
        public int Correlativo
        {
            get { return correlativo; }
            set { correlativo = value; }
        }
        #endregion
    }
}
