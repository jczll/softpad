﻿#region using directivas
using System;
using System.IO;
using System.Data;
using System.Net;
using System.Net.NetworkInformation;
using System.Diagnostics;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Security.Cryptography;
#endregion

namespace SeidaParametros.Logic
{
    class Core
    {
        public static string URL_PRODUCCION = "https://www.sunat.gob.pe/ol-ad-itseida-ws/ReceptorService.htm?wsdl";
        public static string URL_PRUEBAS = "http://pruebaaduana.sunat.gob.pe/ol-ad-itseida-ws/ReceptorService.htm?wsdl";
        public static string DIRECTORIO_DOCUMENTO = "origen_documento";
        public static string DIRECTORIO_ACUSE = "destino_acuse";
        public static string DIRECTORIO_RESPUESTA = "destino_respuesta";
        public static string DIRECTORIO_LOGGER = "log";
        public static string TRACE_LOG_FILENAME = "BitacoraEventos.txt";
        public static string EXTENSION_ZIP = "zip";
        public static string EXTENSION_TXT = ".txt";
        private static string KEY_AES = "3F34F69EB6EA530";
        public static string CONSTANTS_TRUE = "true";
        public static string CONSTANTS_FALSE = "false";
        public static string TAG_XML_1 = "<faultcode>";
        public static string TAG_XML_2 = "</faultstring>";

        public static string EvaluateMessageError(string message)
        {            
            if (message.IndexOf(TAG_XML_1) > 0)
            {
                int length = message.IndexOf(TAG_XML_2) - message.IndexOf(TAG_XML_1) + 14;
                message = message.Substring(message.IndexOf(TAG_XML_1), length);
            }
            return message;
        }
        
        public static int AddSendFromFile(string type, ref DataTable dt, string fileName,string response)
        {
            string line = "";
            string parameter1 = "";
            string parameter2 = "";
            int index = 0;
            int error = 0;
            StreamReader swSource = new StreamReader(fileName);
            try
            {
                while (true)
                {
                    line = swSource.ReadLine();
                    if (line == null)
                    {
                        break;
                    }
                    else if (0 == line.Length)
                    {
                        break;
                    }
                    
                    if (line.IndexOf(",") > 0)
                    {
                        parameter1 = line.Substring(0, line.IndexOf(","));
                        parameter2 = line.Substring(line.IndexOf(",") + 1);
                        if ("ENVIO" == type)
                        {
                            if (File.Exists(parameter2))
                            {
                                index++;
                                dt.Rows.Add(Logic.Core.NameUnique() + "_" + index.ToString(), parameter1, parameter2, response);
                            }
                            else
                            {
                                TraceLogApp("Error en formato, el segundo parametro debe ser un archivo que exista:" + line);
                                error++;
                            }
                        }
                        else if ("CONSULTA" == type)
                        {
                            long intParsed;
                            if (long.TryParse(parameter1, out intParsed))
                            {
                                if (long.TryParse(parameter2, out intParsed))
                                {
                                    index++;
                                    dt.Rows.Add(Logic.Core.NameUnique() + "_" + index.ToString(), parameter1, parameter2, response);
                                }
                                else
                                {
                                    TraceLogApp("Error en formato, el segundo parametro debe ser un valor numerico:" + line);
                                    error++;
                                }
                            }
                            else
                            {
                                TraceLogApp("Error en formato, el primer parametro debe ser un año correcto:" + line);
                                error++;
                            }
                        }
                    }
                    else
                    {
                        TraceLogApp("Error en formato, se esperaba de linea el separador coma: " + line);
                        error++;
                    }
                }
            }
            catch { }
            swSource.Close();
            swSource = null;
            return error;
        }
        
        public static void TraceLogApp(string message)
        {
            Trace.WriteLine(DateTime.Now.ToLongTimeString() + " " + message);
        }
        
        public static string CombineUserData(string ruc, string user)
        {
            return ruc + user + "|" + GetMACAddress() + "|" + GetIP() + "|2";
        }
                
        public static void VerifieDirectories(string path)
        {
            Directory.CreateDirectory(path + "\\" + DIRECTORIO_DOCUMENTO);
            Directory.CreateDirectory(path + "\\" + DIRECTORIO_ACUSE);
            Directory.CreateDirectory(path + "\\" + DIRECTORIO_RESPUESTA);
            Directory.CreateDirectory(path + "\\" + DIRECTORIO_LOGGER);
        }
        
        public static int GetIndexRowFromDataTable(DataTable findTable, string valueFind)
        {
            int index = -1;
            for (int i = 0; i < findTable.Rows.Count; i++)
            {
                if (valueFind.Equals(findTable.Rows[i][0].ToString()))
                {
                    index = i;
                    break;
                }
            }
            return index;
        }

        public static string GenerateNameAcuse(string anno, string ticket)
        {
            return "seida_acuse_" + anno + "_" + ticket.Trim() + ".xml";
        }

        public static string GenerateNameResponse(string anno, string ticket)
        {
            return "seida_respuesta_" + anno + "_" + NameUnique() + "_" + ticket.Trim() + ".xml";
        }
        
        public static string GenerateUniqueName(string extension)
        {
            return NameUnique() + "__" + Guid.NewGuid().ToString("N") + "." + extension;
        }

        public static string NameUnique()
        {
            return DateTime.Now.Year.ToString() + DateTime.Now.Month.ToString().PadLeft(2, '0') + DateTime.Now.Day.ToString().PadLeft(2, '0') + DateTime.Now.Hour.ToString().PadLeft(2, '0') + DateTime.Now.Minute.ToString().PadLeft(2, '0') + DateTime.Now.Second.ToString().PadLeft(2, '0');
            //return "1";
        }
        
        public static string GetIP()
        {
            string ip = "";
            IPAddress[] localIPs = Dns.GetHostAddresses(Dns.GetHostName());
            foreach (IPAddress addr in localIPs)
            {
                if (addr.AddressFamily.ToString() == "InterNetwork")
                {
                    ip = addr.ToString();
                    break;
                }
            }
            return ip;
        }
        
        public static string GetMACAddress()
        {
            string mac = "00:00:00:00:00:00";
            string ip1 = GetIP();
            NetworkInterface[] nics = NetworkInterface.GetAllNetworkInterfaces();
            foreach (NetworkInterface adapter in nics)
            {
                IPInterfaceProperties properties = adapter.GetIPProperties();
                if (adapter.NetworkInterfaceType == NetworkInterfaceType.Ethernet)
                {
                    mac = string.Join(":", (from z in adapter.GetPhysicalAddress().GetAddressBytes() select z.ToString("X2")).ToArray());
                    string ipMatch = "";
                    foreach (IPAddressInformation unicast in properties.UnicastAddresses)
                    {
                        ipMatch = unicast.Address.ToString();
                        if (ip1 == ipMatch)
                        {
                            TraceLogApp("adapter:" + adapter.Name + " - mac:" + adapter.GetPhysicalAddress().ToString() + " IP & MAC MATCHING! : " + ipMatch);
                            return mac;
                        }
                    }
                }
            }
            return mac;
        }
        
        public static DataTable CreateModelSend()
        {
            DataTable table = new DataTable();
            table.Columns.Add("EnvioId", typeof(string));
            table.Columns.Add("NumeroTransaccion", typeof(string));
            table.Columns.Add("NombreArchivo", typeof(string));
            table.Columns.Add("Estado", typeof(string));
            return table;
        }
        
        public static DataTable CreateModelQuery()
        {
            DataTable table = new DataTable();
            table.Columns.Add("ConsultaId", typeof(string));
            table.Columns.Add("Anno", typeof(string));
            table.Columns.Add("NumeroTicket", typeof(string));
            table.Columns.Add("ArchivoRecibido", typeof(string));
            return table;
        }
        
        private string Encrypt(string clearText)
        {
            byte[] clearBytes = Encoding.Unicode.GetBytes(clearText);
            using (Aes encryptor = Aes.Create())
            {
                Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(KEY_AES, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
                encryptor.Key = pdb.GetBytes(32);
                encryptor.IV = pdb.GetBytes(16);
                using (MemoryStream ms = new MemoryStream())
                {
                    using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateEncryptor(), CryptoStreamMode.Write))
                    {
                        cs.Write(clearBytes, 0, clearBytes.Length);
                        cs.Close();
                    }
                    clearText = Convert.ToBase64String(ms.ToArray());
                }
            }
            return clearText;
        }
        
        private string Decrypt(string cipherText)
        {
            byte[] cipherBytes = Convert.FromBase64String(cipherText);
            using (Aes encryptor = Aes.Create())
            {
                Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(KEY_AES, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
                encryptor.Key = pdb.GetBytes(32);
                encryptor.IV = pdb.GetBytes(16);
                using (MemoryStream ms = new MemoryStream())
                {
                    using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateDecryptor(), CryptoStreamMode.Write))
                    {
                        cs.Write(cipherBytes, 0, cipherBytes.Length);
                        cs.Close();
                    }
                    cipherText = Encoding.Unicode.GetString(ms.ToArray());
                }
            }
            return cipherText;
        }

    }
}

