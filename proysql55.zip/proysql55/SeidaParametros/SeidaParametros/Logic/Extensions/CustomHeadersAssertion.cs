﻿#region using directives
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using Microsoft.Web.Services3;
using Microsoft.Web.Services3.Design;
using Microsoft.Web.Services3.Security;
using Microsoft.Web.Services3.Security.Tokens;
#endregion

namespace SeidaParametros.Logic.Extensions
{
    public class CustomHeadersAssertion : PolicyAssertion
    {
        private string username;
        private string password;

        public CustomHeadersAssertion(string username, string password)
        {
            this.username = username;
            this.password = password;
        }

        public override SoapFilter CreateClientInputFilter(FilterCreationContext context)
        {
            return new ClientInputFilter();
        }

        public override SoapFilter CreateClientOutputFilter(FilterCreationContext context)
        {
            return new ClientOutputFilter(this.username, this.password);
        }

        public override SoapFilter CreateServiceInputFilter(FilterCreationContext context)
        {
            return new ServiceInputFilter();
        }

        public override SoapFilter CreateServiceOutputFilter(FilterCreationContext context)
        {
            return new ServiceOutputFilter();
        }

        public override System.Collections.Generic.IEnumerable<System.Collections.Generic.KeyValuePair<string, Type>> GetExtensions()
        {
            return new KeyValuePair<string, Type>[] { new KeyValuePair<string, Type>("RemoveAddressingHeadersAssertion", this.GetType()) };
        }

        public override void ReadXml(XmlReader reader, IDictionary<string, Type> extensions)
        {
            reader.ReadStartElement("RemoveAddressingHeadersAssertion");
        }
    }

    public class ClientInputFilter : SoapFilter
    {
        public override SoapFilterResult ProcessMessage(SoapEnvelope envelope)
        {
            return SoapFilterResult.Continue;
        }
    }

    public class ClientOutputFilter : SoapFilter
    {
        private string username;
        private string password;
        public ClientOutputFilter(string usr, string pwd) : base()
        {
            this.username = usr;
            this.password = pwd;
        }

        public override SoapFilterResult ProcessMessage(SoapEnvelope envelope)
        {
            XmlNode securityNode = envelope.CreateNode(XmlNodeType.Element, "wsse:Security", "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd");
            XmlAttribute securityAttr = envelope.CreateAttribute("soap:mustUnderstand");
            securityAttr.Value = "1";

            XmlNode usernameTokenNode = envelope.CreateNode(XmlNodeType.Element, "wsse:UsernameToken", "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd");
            XmlElement userElement = usernameTokenNode as XmlElement;
            userElement.SetAttribute("xmlns:wsu", "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd");

            XmlNode userNameNode = envelope.CreateNode(XmlNodeType.Element, "wsse:Username", "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd");
            userNameNode.InnerXml = this.username;

            XmlNode pwdNode = envelope.CreateNode(XmlNodeType.Element, "wsse:Password", "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd");
            XmlElement pwdElement = pwdNode as XmlElement;
            pwdElement.SetAttribute("Type", "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#PasswordText");
            pwdNode.InnerXml = this.password;

            usernameTokenNode.AppendChild(userNameNode);
            usernameTokenNode.AppendChild(pwdNode);
            securityNode.AppendChild(usernameTokenNode);
            envelope.ImportNode(securityNode, true);                

            XmlNode node = envelope.Header;
            node.AppendChild(securityNode);

            return SoapFilterResult.Continue;
        }
    }

    public class ServiceInputFilter : SoapFilter
    {
        public override SoapFilterResult ProcessMessage(SoapEnvelope envelope)
        {            
            return SoapFilterResult.Continue;
        }
    }

    public class ServiceOutputFilter : SoapFilter
    {
        public override SoapFilterResult ProcessMessage(SoapEnvelope envelope)
        {
            return SoapFilterResult.Continue;
        }
    }
}
