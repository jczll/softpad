﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SeidaParametros
{
    public class Program
    {
        public static void Main(string[] args)
        {
            WebService objservice = new WebService();
            String[] parametros = Environment.GetCommandLineArgs();
            if (parametros[1]=="1")
            {
                //String[] parametros = Environment.GetCommandLineArgs();                
                objservice.SenFilesWebService(parametros[2], parametros[3], parametros[4], parametros[5],parametros[6],parametros[7]);
            }
            else if(parametros[1] == "2")
            {
                objservice.SendQueryWebService(parametros[2], parametros[3], parametros[4], parametros[5], parametros[6]);
            }
            else
            {
                MessageBox.Show("No se han pasado parámetros, sólo el de defecto: " + Environment.NewLine + Environment.NewLine + Environment.GetCommandLineArgs()[0], "ERROR SOFTPAD", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
    }
}
