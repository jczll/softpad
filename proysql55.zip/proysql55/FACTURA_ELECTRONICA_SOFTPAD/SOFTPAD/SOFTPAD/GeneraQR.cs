﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Windows.Forms;
using System.Drawing;
using System.Drawing.Imaging;
using Gma.QrCodeNet.Encoding;
using Gma.QrCodeNet.Encoding.Windows.Render;

namespace SOFTPAD
{
    public class GeneraQR
    {
        public void GeneracodigoQR(string xruta,string xarchivo, string xruc, string xtipodoc, string xserie, string xnumero, string xigv, string xtotal, string xfecha, string xtipodoccliente, string xruccliente)
        {            
            try
            {
                var qrEncoder = new QrEncoder(ErrorCorrectionLevel.Q);
                var qrCode = qrEncoder.Encode(xruc + "|" + xtipodoc + "|" + xserie + "|" + xnumero + "|" + xigv + "|" + xtotal + "|" + xfecha + "|" + xtipodoccliente + "|" + xruccliente);
                var renderer = new GraphicsRenderer(new FixedModuleSize(5, QuietZoneModules.Two), Brushes.Black, Brushes.White);
                using (var stream = new FileStream(xruta+xarchivo+".jpg", FileMode.Create))
                    renderer.WriteToStream(qrCode.Matrix, ImageFormat.Png, stream);                
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message, "Error Al generar QR", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
            }           
        }
    }
}
