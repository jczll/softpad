﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Security.Cryptography.Xml;
using System.Security.Cryptography.X509Certificates;
using System.Xml;
using Microsoft.VisualBasic.CompilerServices;
using System.Diagnostics;
using System.IO;
using System.Collections;
using System.Runtime.InteropServices;


namespace SOFTPAD
{
    public class Genera_firmaXML
    {
        IEnumerator enumerator;

        //variables privadas
        private string _CertificateFile;
        private string _CertificatePwd;
        private string _XMLFile;
        private string _NameSpaceDocument;
        private string _xpathFirm;
        private string _SignatureId;
        //variables publicas
        public string CertificateFile
        {
            get
            {
                return this._CertificateFile;
            }
            set
            {
                this._CertificateFile = value;
            }
        }
        public string CertificatePwd
        {
            get
            {
                return this._CertificatePwd;
            }
            set
            {
                this._CertificatePwd = value;
            }
        }
        public string XMLFile
        {
            get
            {
                return this._XMLFile;
            }
            set
            {
                this._XMLFile = value;
            }
        }
        public string NameSpaceDocument
        {
            get
            {
                return this._NameSpaceDocument;
            }
            set
            {
                this._NameSpaceDocument = value;
            }
        }
        public string xpathFirm
        {
            get
            {
                return this._xpathFirm;
            }
            set
            {
                this._xpathFirm = value;
            }
        }
        public string SignatureId
        {
            get
            {
                return this._SignatureId;
            }
            set
            {
                this._SignatureId = value;
            }
        }
        
        [DebuggerNonUserCode]
        public Genera_firmaXML()
        {
        }
        public string ComputeSignature()
        {

            string result;
            try
            {
                bool flag = Operators.CompareString(this._XMLFile, "", false) == 0;
                if (flag)
                {
                    throw new Exception("The XML file is requiered");
                }
                //flag = !MyProject.Computer.FileSystem.FileExists(this._XMLFile);
                //if (flag)
                //{
                //	throw new Exception("The XML file " + this._XMLFile + "was not found");
                //}
                flag = (Operators.CompareString(this.CertificateFile, "", false) == 0);
                if (flag)
                {
                    throw new Exception("The certificate file is requiered");
                }
                flag = (Operators.CompareString(this._CertificatePwd, "", false) == 0);
                if (flag)
                {
                    throw new Exception("The certificate password is requiered");
                }
                flag = (Operators.CompareString(this._NameSpaceDocument, "", false) == 0);
                if (flag)
                {
                    throw new Exception("The namespace value of the document is requiered");
                }
                flag = (Operators.CompareString(this._xpathFirm, "", false) == 0);
                if (flag)
                {
                    throw new Exception("The xpath value to firm your xml file is requiered");
                }
                flag = (Operators.CompareString(this._SignatureId, "", false) == 0);
                if (flag)
                {
                    throw new Exception("The SignatureId value is missing");
                }
                string fileName = Path.GetFileName(this._XMLFile);
                string text = fileName.Split(new char[]
                {
                    '-'
                })[1];
                X509Certificate2 x509Certificate = new X509Certificate2(this.CertificateFile, this._CertificatePwd);
                XmlDocument xmlDocument = new XmlDocument();
                xmlDocument.PreserveWhitespace = true;
                xmlDocument.Load(this._XMLFile);
                SignedXml signedXml = new SignedXml(xmlDocument);
                signedXml.SigningKey = x509Certificate.PrivateKey;
                KeyInfo keyInfo = new KeyInfo();
                Reference reference = new Reference();
                reference.Uri = "";
                reference.AddTransform(new XmlDsigEnvelopedSignatureTransform());
                signedXml.AddReference(reference);
                X509Chain x509Chain = new X509Chain();
                x509Chain.Build(x509Certificate);
                X509ChainElement x509ChainElement = x509Chain.ChainElements[0];
                KeyInfoX509Data keyInfoX509Data = new KeyInfoX509Data(x509ChainElement.Certificate);
                string subject = x509ChainElement.Certificate.Subject;
                keyInfoX509Data.AddSubjectName(subject);
                keyInfo.AddClause(keyInfoX509Data);
                signedXml.KeyInfo = keyInfo;
                signedXml.ComputeSignature();
                XmlElement xml = signedXml.GetXml();
                xml.Prefix = "ds";
                signedXml.ComputeSignature();
                try
                {
                    IEnumerator enumerator = xml.SelectNodes("descendant-or-self::*[namespace-uri()='http://www.w3.org/2000/09/xmldsig#']").GetEnumerator();
                    while (enumerator.MoveNext())
                    {
                        XmlNode xmlNode = (XmlNode)enumerator.Current;
                        flag = (Operators.CompareString(xmlNode.LocalName, "Signature", false) == 0);
                        if (flag)
                        {
                            XmlAttribute xmlAttribute = xmlDocument.CreateAttribute("Id");
                            xmlAttribute.Value = this._SignatureId;
                            xmlNode.Attributes.Append(xmlAttribute);
                            break;
                        }
                    }
                }
                finally
                {
                    //IEnumerator enumerator;
                    //flag = (enumerator is IDisposable);
                    if (enumerator is IDisposable)
                    {
                        (enumerator as IDisposable).Dispose();
                    }
                }
                XmlNamespaceManager xmlNamespaceManager = new XmlNamespaceManager(xmlDocument.NameTable);
                xmlNamespaceManager.AddNamespace("sac", "urn:sunat:names:specification:ubl:peru:schema:xsd:SunatAggregateComponents-1");
                xmlNamespaceManager.AddNamespace("ccts", "urn:un:unece:uncefact:documentation:2");
                xmlNamespaceManager.AddNamespace("xsi", "http://www.w3.org/2001/XMLSchema-instance");
                xmlNamespaceManager.AddNamespace("tns", this._NameSpaceDocument);
                xmlNamespaceManager.AddNamespace("cac", "urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2");
                xmlNamespaceManager.AddNamespace("udt", "urn:un:unece:uncefact:data:specification:UnqualifiedDataTypesSchemaModule:2");
                xmlNamespaceManager.AddNamespace("ext", "urn:oasis:names:specification:ubl:schema:xsd:CommonExtensionComponents-2");
                xmlNamespaceManager.AddNamespace("qdt", "urn:oasis:names:specification:ubl:schema:xsd:QualifiedDatatypes-2");
                xmlNamespaceManager.AddNamespace("cbc", "urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2");
                xmlNamespaceManager.AddNamespace("ds", "http://www.w3.org/2000/09/xmldsig#");
                xmlDocument.SelectSingleNode("/tns:" + this._xpathFirm, xmlNamespaceManager).AppendChild(xmlDocument.ImportNode(xml, true));
                xmlDocument.Save(this._XMLFile);
                XmlNodeList elementsByTagName = xmlDocument.GetElementsByTagName("ds:Signature");
                flag = (elementsByTagName.Count != 1);
                if (flag)
                {
                    throw new Exception("Se produjo un error en la firma del documento");
                }
                signedXml.LoadXml((XmlElement)elementsByTagName[0]);
                flag = !signedXml.CheckSignature();
                if (flag)
                {
                    throw new Exception("Se produjo un error en la firma del documento");
                }
                result = "";
            }
            catch (Exception expr_470)
            {
                ProjectData.SetProjectError(expr_470);
                Exception ex = expr_470;
                result = ex.Message + ex.Message;
                ProjectData.ClearProjectError();
            }
            return result;
        }
    }
}
