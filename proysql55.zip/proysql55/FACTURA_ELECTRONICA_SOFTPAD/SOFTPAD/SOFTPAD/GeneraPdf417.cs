﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using iTextSharp.text.pdf;
using System.Drawing;
using System.Windows.Forms;

namespace SOFTPAD
{
    public class GeneraPdf417
    {
        public void GeneraImagen(string xruc,string xtipodoc,string xserie,string xnumero,string xigv,string xtotal,string xfecha,string xtipodoccliente,string xruccliente,string xresumen,string xfirma)
        {
            try
            {
                string contenido;
                BarcodePDF417 objpdf = new BarcodePDF417();
                objpdf.Options = BarcodePDF417.PDF417_USE_ASPECT_RATIO;
                objpdf.ErrorLevel = 5;
                contenido = xruc + "|" + xtipodoc + "|" + xserie + "|" + xnumero + "|" + xigv + "|" + xtotal + "|" + xfecha + "|" + xtipodoccliente + "|" + xruccliente + "|" + xresumen + "|" + xfirma;
                objpdf.SetText(contenido);
                Bitmap imagen = new Bitmap(objpdf.CreateDrawingImage(Color.Black, Color.White));

                imagen.Save("C:\\ESTSQL\\PDFS\\pdf417.bmp");
                MessageBox.Show("Imagen Generada con Exito", "Mensaje", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error al Generar PDF417", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
            }
        }
    }
}
