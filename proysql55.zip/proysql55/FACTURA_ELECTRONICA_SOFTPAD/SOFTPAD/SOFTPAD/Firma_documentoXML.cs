﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace SOFTPAD
{
    
    public class Firma_documentoXML
    {
        Genera_firmaXML xmlsignature = new Genera_firmaXML();
        public void Inserta_firmaXML(string xcertificado, string xpassword, string xrutaxml)
        {
            xmlsignature.CertificateFile = xcertificado;
            xmlsignature.CertificatePwd = xpassword;
            xmlsignature.XMLFile = xrutaxml;
            xmlsignature.xpathFirm = "Invoice/ext:UBLExtensions/ext:UBLExtension[2]/ext:ExtensionContent";
            xmlsignature.NameSpaceDocument = "urn:oasis:names:specification:ubl:schema:xsd:Invoice-2";
            xmlsignature.SignatureId = "SignatureId";
            string errormessage = xmlsignature.ComputeSignature();
            if (errormessage == "")
            {
                //MessageBox.Show("OK... Firmado Correctamente...", "MENSAJE", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1);
            }
            else
            {
                MessageBox.Show(errormessage, "Error...!!!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
        public void Firma_notadecredito(string xcertificado, string xpassword, string xrutaxml)
        {
            xmlsignature.CertificateFile = xcertificado;
            xmlsignature.CertificatePwd = xpassword;
            xmlsignature.XMLFile = xrutaxml;
            xmlsignature.xpathFirm = "CreditNote/ext:UBLExtensions/ext:UBLExtension[2]/ext:ExtensionContent";
            xmlsignature.NameSpaceDocument = "urn:oasis:names:specification:ubl:schema:xsd:CreditNote-2";
            xmlsignature.SignatureId = "SignatureId";
            string errormessage = xmlsignature.ComputeSignature();
            if (errormessage == "")
            {
                //MessageBox.Show("OK... Firmado Correctamente...", "MENSAJE", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1);
            }
            else
            {
                MessageBox.Show(errormessage, "Error...!!!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
        public void Firma_comunicadodebaja(string xcertificado, string xpassword, string xrutaxml)
        {
            xmlsignature.CertificateFile = xcertificado;
            xmlsignature.CertificatePwd = xpassword;
            xmlsignature.XMLFile = xrutaxml;
            xmlsignature.xpathFirm = "VoidedDocuments/ext:UBLExtensions/ext:UBLExtension/ext:ExtensionContent";
            xmlsignature.NameSpaceDocument = "urn:sunat:names:specification:ubl:peru:schema:xsd:VoidedDocuments-1";
            xmlsignature.SignatureId = "SignatureId";
            string errormessage = xmlsignature.ComputeSignature();
            if (errormessage == "")
            {
                //MessageBox.Show("OK... Firmado Correctamente...", "MENSAJE", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1);
            }
            else
            {
                MessageBox.Show(errormessage, "Error...!!!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
        public void Firma_notadedebito(string xcertificado, string xpassword, string xrutaxml)
        {
            xmlsignature.CertificateFile = xcertificado;
            xmlsignature.CertificatePwd = xpassword;
            xmlsignature.XMLFile = xrutaxml;
            xmlsignature.xpathFirm = "DebitNote/ext:UBLExtensions/ext:UBLExtension[2]/ext:ExtensionContent";
            xmlsignature.NameSpaceDocument = "urn:oasis:names:specification:ubl:schema:xsd:CreditNote-2";
            xmlsignature.SignatureId = "SignatureId";
            string errormessage = xmlsignature.ComputeSignature();
            if (errormessage == "")
            {
                //MessageBox.Show("OK... Firmado Correctamente...", "MENSAJE", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1);
            }
            else
            {
                MessageBox.Show(errormessage, "Error...!!!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
    }
}
