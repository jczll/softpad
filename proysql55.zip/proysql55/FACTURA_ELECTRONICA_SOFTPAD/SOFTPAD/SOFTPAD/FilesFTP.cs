﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Net;

namespace SOFTPAD
{
    public class FilesFTP
    {
        public void LoadFilesFTP(string fileftp,string pathftp)
        {
            try
            {
                FtpWebRequest request = (FtpWebRequest)FtpWebRequest.Create("ftp://softpad.pe/facturas/"+fileftp);
                request.Method = WebRequestMethods.Ftp.UploadFile;
                request.Credentials = new NetworkCredential("aduanas@softpad.pe", "707293");
                request.UsePassive = true;
                request.UseBinary = true;
                request.KeepAlive = true;
                FileStream stream = File.OpenRead(pathftp);
                byte[] buffer = new byte[stream.Length];
                stream.Read(buffer, 0, buffer.Length);
                stream.Close();
                Stream reqStream = request.GetRequestStream();
                reqStream.Write(buffer, 0, buffer.Length);
                reqStream.Flush();
                reqStream.Close();
                MessageBox.Show("Archivo Subido al Servidor...!!!");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        public void DeleteFilesFTP(string fileftp)
        {
            try
            {
                FtpWebRequest request = (FtpWebRequest)FtpWebRequest.Create("ftp://softpad.pe/facturas/"+fileftp);
                //request.Method = WebRequestMethods.Ftp.UploadFile;
                request.Credentials = new NetworkCredential("aduanas@softpad.pe", "707293");
                request.UsePassive = true;
                request.UseBinary = true;
                request.KeepAlive = true;
                request.Method = WebRequestMethods.Ftp.DeleteFile;
                FtpWebResponse response = (FtpWebResponse)request.GetResponse();
                response.Close();
                MessageBox.Show("Archivo Eliminado del Servidor...!!!");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
