﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace Factura_WS
{
    public class Genera_EnvioWS
    {
        
        Conecta_WS WSconecta = new Conecta_WS();
        public void envia_documentoWS(string xrutacarpeta,string xrutazip)
        {            
                try
                {
                    string archivozip = xrutazip;
                    string carpetazip = xrutacarpeta;
                    string mensajeWS = WSconecta.Envia_DocumentoWS(carpetazip,archivozip);
                    //WSconecta.Envia_DocumentoWS(carpetazip,archivozip);
                    MessageBox.Show(mensajeWS, "MENSAJE", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);
                }            
        }
        public void documentobaja_ws(string xrutacarpeta,string xrutazip)
        {
            try
            {
                string archivozip = xrutazip;
                string carpetazip = xrutacarpeta;
                string mensajeticket = WSconecta.EnviarResumenBaja(carpetazip,archivozip);
                MessageBox.Show("SE GENERO EL TICKET N° " + mensajeticket + " SE PROCEDERA A CONSULTARLO....!!!", "Mensaje", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1);
                string ticket = mensajeticket;
                string resultado = WSconecta.ObtenerEstado(ticket);
                MessageBox.Show(resultado, "Mensaje", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error al enviar Documento de Baja", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
            }
        }
    }
}
