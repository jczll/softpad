﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.ServiceModel;
using System.IO;
using Microsoft.VisualBasic.CompilerServices;
using System.Runtime.InteropServices;
using System.Net;


namespace Factura_WS
{
    [ClassInterface(ClassInterfaceType.None)]
    //[ClassInterface(ClassInterfaceType.AutoDual)]
    [ProgId("Conecta_WS")]
    
    public class Conecta_WS
    {
        public WsSunat.billServiceClient servicemodel;
        public Conecta_WS()
        {
            servicemodel = new WsSunat.billServiceClient();
            ServicePointManager.UseNagleAlgorithm = true;
            ServicePointManager.Expect100Continue = false;
            ServicePointManager.CheckCertificateRevocationList = true;
        }
        
        public string Envia_DocumentoWS(string xruta,string pArchivo)
        {            
            string currentDirectory = xruta;
            string result = "";
            string path = currentDirectory + pArchivo;
            byte[] contentFile = File.ReadAllBytes(path);
            try
            {
                servicemodel.Open();
                byte[] array = this.servicemodel.sendBill(pArchivo, contentFile, result);
                servicemodel.Close();
                FileStream fileStream = new FileStream(currentDirectory+"RPTAS\\" + pArchivo + ".zip", FileMode.Create);
                fileStream.Write(array, 0, array.Length);
                fileStream.Close();
                result = "Archivo Enviado y Recepcionado con Exito...!!!";
            }
            catch (FaultException expr_87)
            {
                ProjectData.SetProjectError(expr_87);
                FaultException ex = expr_87;
                result = ex.Code.Name + "<=+=>" + ex.Message;
                ProjectData.ClearProjectError();
            }
            return result;
        }
        
        public string EnviarResumenBaja(string xruta,string pArchivo)
        {
            string ruta = xruta;
            string strRetorno = "";
            string Filezip = pArchivo;
            string FilePath = xruta + Filezip;
            byte[] bytearray = File.ReadAllBytes(FilePath);
            try
            {
                servicemodel.Open();
                string ticket = servicemodel.sendSummary(Filezip, bytearray, strRetorno);
                servicemodel.Close();
                strRetorno = ticket;
            }
            catch (FaultException ex)
            {
                strRetorno = ex.Code.Name + "<<--+-->> " + ex.Message;
            }
            return strRetorno;
        }
        public string ObtenerEstado(string pticket)
        {            
            string ruta = Directory.GetCurrentDirectory();
            string strRetorno = "";
            try
            {
                servicemodel.Open();
                WsSunat.statusResponse returnstring = servicemodel.getStatus(pticket);
                string retorno = returnstring.statusCode;
                servicemodel.Close();
            }
            catch (FaultException ex)
            {
                strRetorno = ex.Code.Name + " <<-+->> " + ex.Message;
            }
            return strRetorno;
        }
    }
}
