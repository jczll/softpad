﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Factura_WS
{
    public class Program
    {
        public static void Main(string[] args)
        {            
            Genera_EnvioWS objenvio = new Genera_EnvioWS();
            String[] parametros = Environment.GetCommandLineArgs();
            if (parametros[1] =="1")
            {                
                objenvio.envia_documentoWS(parametros[2],parametros[3]);
            }
            //else if(Environment.GetCommandLineArgs().Length == 1)
            else if (parametros[1]=="2")
            {
                objenvio.documentobaja_ws(parametros[2], parametros[3]);
            }
            else
            {
                MessageBox.Show("No se han pasado parámetros, sólo el de defecto: " + Environment.NewLine + Environment.NewLine + Environment.GetCommandLineArgs()[0], "ERROR SOFTPAD", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
    }
}
