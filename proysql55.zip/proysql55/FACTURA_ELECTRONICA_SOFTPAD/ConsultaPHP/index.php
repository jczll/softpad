<style type="text/css">
<!--
.Estilo4 {color: #F0F0F0}
.Estilo5 {
	color: #CCCC00;
	font-style: italic;
	font-weight: bold;
}
.Estilo6 {color: #FFCC33}
.Estilo7 {
	font-size: 16px;
	font-weight: bold;
	color: #AA0000;
}
-->
</style>
<script>
function rellenar(quien,que){
cadcero='';
for(i=0;i<(8-que.length);i++){
cadcero+='0';
}
quien.value=cadcero+que;
}
</script>
<form name="form1" action="consulta.php" method="post">
  <table width="100%" border="0">
    <tr>
      <th class="Estilo4" scope="row">&nbsp;</th>
    </tr>
    <tr bgcolor="#003300">
      <th height="78" class="Estilo4" scope="row"><div align="left">
        <h1 class="Estilo5 Estilo6">SOFTWARE PARA ADUANAS S.A.C.</h1>
        </div>
      <p>&nbsp;</p></th>
    </tr>
  </table>
  <table width="402" border="0" align="center">
    <tr>
      <td width="359"><div align="center">
        <h3><strong>SOFTPAD PONE A SU DISPOSICION EL APLICATIVO PARA LA CONSULTA Y DESCARGA DE DOCUMENTOS ELECTRONICOS </strong></h3>
      </div></td>
    </tr>
  </table>
  <br>
  <center>
  <fieldset style="width:400" align="left">
  <legend><strong>Seleccione el tipo de Documento :</strong> </legend>
  <table width="426" border="0" align="center">
    
    <tr>
      <td width="241"><label>
        <input name="tipodoc" type="radio" value="01" checked="checked">
        FACTURA        
        </label></td>
      <td width="194"><label>
        <input name="tipodoc" type="radio" value="07">
        NOTA DE CREDITO        
        </label></td>
    </tr>
    <tr>
      <td height="26"><label>
        <input name="tipodoc" type="radio" value="03">
        BOLETA        
        </label></td>
      <td><label>
        <input name="tipodoc" type="radio" value="08">
        NOTA DE DEBITO        
        </label></td>
    </tr>
  </table>
  </fieldset>
  </center>
  <br>
  <center>
  <fieldset style="width:600" align="left">
  <legend><strong>Ingrese los Datos del Documento:</strong> </legend>
  <table width="561" border="0" align="center">
    
    <tr>
      <td width="164">Numero de R.U.C: </td>
      <td width="381"><label>
        <input type="text" name="txtagencia" placeholder="Ej: 20500826526" required="required" maxlength="11">
      </label></td>
    </tr>
    <tr>
      <td height="23">Numero del Documento: </td>
      <td><label>
        <input type="text" name="txtserie" placeholder="Ej: FXXX" required="required" width="50" maxlength="4" onKeyUp="this.value=this.value.toUpperCase();">
      -
      <input type="text" name="txtnumero" placeholder="Ej: 12345678" required="required" maxlength="8" onblur="rellenar(this,this.value)" />
      </label></td>
    </tr>
    <tr>
      <td>Importe : </td>
      <td><label>
        <input type="number" name="txtimporte" step="any" required="required"/>
      </label></td>
    </tr>
    <tr>
      <td>Fecha del Documento: </td>
      <td><label>
        <input type="date" name="txtfecha" min="2018-01-01" max="2100-12-31" step="0" required="required">
      </label></td>
    </tr>
    <tr>
      <td colspan="2"><label>
        <div align="center">
          <input type="submit" name="Submit" value="Consultar Documento" />          
          </label>
        </div></td>
    </tr>
    <tr>
      <td colspan="2"><label></label></td>
    </tr>
  </table>
  </fieldset>
  </center>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p align="center" class="Estilo7">Recuerda:&nbsp;La vigencia de los documentos a consultar ser&aacute; como m&aacute;ximo de un a&ntilde;o, tomando como referencia base la fecha de emisi&oacute;n del comprobante. (Documentos con fecha de emisi&oacute;n mayor a un a&ntilde;o de antig&uuml;edad ya no se podr&aacute;n consultar bajo esta aplicaci&oacute;n.)</p>
</form>

