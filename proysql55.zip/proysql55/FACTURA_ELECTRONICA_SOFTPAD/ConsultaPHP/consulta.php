<style type="text/css">
<!--
.Estilo4 {color: #F0F0F0}
.Estilo5 {
	color: #CCCC00;
	font-style: italic;
	font-weight: bold;
}
.Estilo6 {color: #FFCC33}
.Estilo10 {
	color: #FF0000;
	font-weight: bold;
	font-size: 18px;
}
.Estilo12 {color: #000000}
-->
</style>
<?php
	$num_ruc=$_POST['txtagencia'];
	$tipo_doc=$_POST['tipodoc'];
	$num_serie=$_POST['txtserie'];
	$num_documento=$_POST['txtnumero'];
	$extension='.pdf';
	$extxml='.xml';
	$guion='-';
	$fecha=$_POST['txtfecha'];
	$importe=$_POST['txtimporte'];
?>
<form action="" method="post">
  <table width="100%" border="0">
    <tr>
      <th class="Estilo4" scope="row">&nbsp;</th>
    </tr>
    <tr bgcolor="#003300">
      <th height="78" class="Estilo4" scope="row"><div align="left">
        <h1 class="Estilo5 Estilo6">SOFTWARE PARA ADUANAS S.A.C.</h1>
        </div>
      <p>&nbsp;</p></th>
    </tr>
  </table>
  <br>
  <br>
  <center>
  <fieldset style="width:800" align="left">
  <legend><strong>
  <?php if($_POST['tipodoc']=="01")
		  		{echo "Factura Nro. ";}
				if($_POST['tipodoc']=="03")
		  		{echo "Boleta Nro. ";}
				if($_POST['tipodoc']=="07")
		  		{echo "Nota de Credito Nro. ";}
				if($_POST['tipodoc']=="08")
		  		{echo "Nota de Debito Nro. ";}
		   ?>
	<?php 
	$guion='-';
	$documento=$_POST['txtserie'].$guion.$_POST['txtnumero']; 
	echo $documento;
	 ?>	   
  </strong> </legend>
  <table width="747" border="0" align="center">
    <tr>
      <td height="412" colspan="2"><?php echo "<iframe src='http://www.softpad.pe/aduanas/facturas/".$num_ruc.$guion.$tipo_doc.$guion.$num_serie.$guion.$num_documento.$guion.$fecha.$guion.$importe.$extension."' width='100%' height='100%' style='background: #808080;'></iframe>"; ?></td>
    </tr>
    <tr>
      <td width="364"><div align="center"><strong><?php echo "<a href='http://www.softpad.pe/aduanas/facturas/".$num_ruc.$guion.$tipo_doc.$guion.$num_serie.$guion.$num_documento.$guion.$fecha.$guion.$importe.$extension."' download='Documento.pdf'>Descarga PDF</a>"; ?></strong></div></td>
      <td width="367"><div align="center"><strong><?php echo "<a href='http://www.softpad.pe/aduanas/facturas/".$num_ruc.$guion.$tipo_doc.$guion.$num_serie.$guion.$num_documento.$guion.$fecha.$guion.$importe.$extxml."' download='ArchivoXML.pdf'>Descarga XML</a>"; ?></strong></div></td>
    </tr>
  </table>
  </fieldset>
  </center>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
</form>

