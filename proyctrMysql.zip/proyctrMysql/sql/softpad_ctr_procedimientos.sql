--PROCEDIMIENTOS DEL SOFTPAD_CTR 

--Procedimiento para Borrar todlas las Tablas
create Procedure USPBorra_tablas
AS
Begin
	drop table cliente_correo
    drop table cliente_telefono	 
    drop table contrato
    drop table producto	 
    drop table sistema
	drop table cliente 
	drop table empleado_correo
    drop table empleado_telefono	 
    drop table empleado_sueldo	 
	drop table empleado 
	drop table empresa
End
go
 
 execute USPBorra_tablas

 Insert TBAmigo 
Select * from TBAmigo
go

--Procedimiento para Agregar Clientes
Create Procedure uspCrea_Cliente
@p_COD_CLI char(3)
as
begin
   if EXISTs(Select * from cliente where cod_cli = @p_cod_cli)
      begin
	     print 'ERROR : Codigo duplicado'
		 return 
	  end
   else
      insert into cliente(cod_cli) VALUES(@p_cod_cli)
end
go

BEGIN TRY
    EXECUTE uspCrea_Cliente 'C01'
END TRY
BEGIN CATCH
       PRINT @@ERROR
       PRINT ERROR_MESSAGE()
END CATCH


BEGIN TRY
    EXECUTE uspCrea_Cliente 'C01'
END TRY
BEGIN CATCH
    IF @@ERROR=8114
       PRINT 'ERROR AL CONVERTIR DATO TIPO VARCHAR A DATE '
       PRINT ERROR_MESSAGE()
END CATCH

SELECT * FROM tablas

/*****************************/

CREATE FUNCTION [dbo].[nuevo_codigo2]
(
� � -- Add the parameters for the function here
� � @valor int
)
RETURNS varchar(2)
AS
BEGIN
� � -- Declare the return variable here
� � DECLARE @codigo varchar(2)
� � -- Add the T-SQL statements to compute the return value here
� � select @codigo = replicate('0',(2-len((cast(@valor as 
varchar(10))))))+cast(@valor as varchar(2))
� � --
� � -- Return the result of the function
� � RETURN @codigo
END

