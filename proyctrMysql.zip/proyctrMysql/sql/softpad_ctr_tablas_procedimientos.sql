--Trigger para Borrar los distritos
use bdSoftpad_ctr_tablas
go
create trigger TxtBorraTa1
on ta1 for delete
as 
begin transaction
      if exists(Select cod_distrito from bdsoftpad_ctr.dbo.CLIENTE where cod_distrito=(Select cod_distrito from deleted))
	     begin
		    print ' Codigo de Distrio esta Siendo Usado en la Tabla de clientes ' 
		    rollback transaction
		 end
      else
	     commit transaction
      if exists(Select cod_distrito from bdsoftpad_ctr.dbo.empleado where cod_distrito=(Select cod_distrito from deleted))
	     begin
		    print ' Codigo de Distrio esta Siendo Usado en la Tabla de Empleado ' 
		    rollback transaction
		 end
      else
	     commit transaction

	
--Trigger para Borrar los Codigos de Ruta
create trigger TxtBorraTa2
on ta2 for delete
as 
begin transaction
      if exists(Select cod_ruta from bdsoftpad_ctr.dbo.CLIENTE where cod_ruta=(Select cod_ruta from deleted))
	     begin
		    print ' Codigo de Ruta esta Siendo Usado en la Tabla de clientes ' 
		    rollback transaction
		 end
      else
	     commit transaction
	
--Trigger para Borrar los Tipos de Operadores de comercio exterior
create trigger TxtBorraTa3
on ta3 for delete
as 
begin transaction
      if exists(Select cod_tip_opera from bdsoftpad_ctr.dbo.CLIENTE where cod_tip_opera=(Select cod_tip_opera from deleted))
	     begin
		    print ' Codigo de Ruta esta Siendo Usado en la Tabla de clientes ' 
		    rollback transaction
		 end
      else
	     commit transaction

--Trigger para Borrar los Codigos de Zona
create trigger TxtBorraTa4
on ta4 for delete
as 
begin transaction
      if exists(Select cod_zona from bdsoftpad_ctr.dbo.CLIENTE where cod_zona=(Select cod_zona from deleted))
	     begin
		    print ' Codigo de Zona esta Siendo Usado en la Tabla de clientes ' 
		    rollback transaction
		 end
      else
	     commit transaction

--Trigger para Borrar los Codigos de Estado Civil
create trigger TxtBorraTa5
on ta5 for delete
as 
begin transaction
      if exists(Select ecivil_emp from bdsoftpad_ctr.dbo.empleado where ecivil_emp=(Select ecivil_emp from deleted))
	     begin
		    print ' Codigo de Estado Civil esta Siendo Usado en la Tabla de Empleados ' 
		    rollback transaction
		 end
      else
	     commit transaction

--Trigger para Borrar los Codigos de Tipos de Empleado
Create trigger TxtBorraTa6
on ta6 for delete
as 
begin transaction
      if exists(Select cod_tip_emp from bdsoftpad_ctr.dbo.empleado where cod_tip_emp=(Select cod_tip_emp from deleted))
	     begin
		    print ' Codigo de Tipo de Empleado esta Siendo Usado en la Tabla de Empleados ' 
		    rollback transaction
		 end
      else
	     commit transaction

--Trigger para Borrar los Codigos de Tipos de Contrato
Create trigger TxtBorraTa10
on ta10 for delete
as 
begin transaction
      if exists(Select tipo_contrato from bdsoftpad_ctr.dbo.cliente_contrato where tipo_contrato=(Select codigo from deleted))
	     begin
		    print ' Codigo de Tipo de Contrato esta Siendo Usado en la Tabla de Cliente_Contrato ' 
		    rollback transaction
		 end
      else
	     commit transaction
