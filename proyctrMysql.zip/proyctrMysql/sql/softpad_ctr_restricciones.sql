--RESTRICCIONES PARA LA TABLA DE CLIENTES 
Alter table CLIENTE 
add constraint CHK_CLIENTE_COD_CLI CHECK (COD_CLI LIKE '[0-9][0-9][0-9]'),
    constraint UQQ_CLIENTE_RAZ_SOC_CLI UNIQUE (raz_soc_cli),
	constraint DFF_CLIENTE_RAZ_SOC_CLI DEFAULT '' FOR raz_soc_cli,
    constraint CHK_CLIENTE_RUC CHECK (ruc LIKE '[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]'),
	constraint DFF_CLIENTE_RUC DEFAULT '00000000000' FOR ruc,
	constraint DFF_CLIENTE_DIR_CLI DEFAULT '' FOR dir_cli,
    constraint DFF_CLIENTE_FECH_CREA DEFAULT SYSDATETIME() FOR fech_crea,
	constraint DFF_CLIENTE_NOMBRE_CH DEFAULT '' FOR nombre_ch,
    constraint DFF_CLIENTE_VIGENTE DEFAULT 'S' FOR vigente,
    constraint DFF_CLIENTE_DISTRITO DEFAULT '' FOR cod_distrito,
    constraint DFF_CLIENTE_COD_RUTA DEFAULT '' FOR cod_ruta,
    constraint DFF_CLIENTE_COD_TIP_OPERA DEFAULT '' FOR cod_tip_opera,
    constraint DFF_CLIENTE_COD_ZONA DEFAULT '' FOR cod_zona,
    constraint DFF_CLIENTE_DIR_CLI_ALTER DEFAULT '' FOR dir_cli_alter,
    constraint DFF_CLIENTE_VERSION_SYS DEFAULT 'MYSQL' FOR version_sys
go

Alter table CLIENTE_CORREO 
add constraint DFF_CLIENTE_CORREO DEFAULT '' FOR dir_correo,
    constraint UQQ_CLIENTE_CORREO UNIQUE (cod_cli,dir_correo),
    constraint DFF_CLIENTE_CORREO_USU_CORREO DEFAULT '' FOR usu_correo,
    constraint DFF_CLIENTE_CORREO_CARGO_USU  DEFAULT '' FOR cargo_usu,
    constraint DFF_CLIENTE_CORREO_TELEFONO_USU DEFAULT '' FOR telefono_usu,
    constraint DFF_CLIENTE_CORREO_TIPO_TELF_MOVIL DEFAULT '' FOR tipo_telf_movil,
    constraint DFF_CLIENTE_CORREO_ETIQUETA DEFAULT '' FOR etiqueta
GO

Alter table CLIENTE_USUARIO 
add constraint DFF_CLIENTE_USUARIO_NOMB_USUARIO DEFAULT '' FOR nomb_usuario,
    constraint UQQ_CLIENTE_USUARIO_COD_CLI_NOMB_USUARIO UNIQUE (cod_cli,nomb_usuario)
GO

Alter table CLIENTE_TELEFONO 
add constraint DFF_CLIENTE_telefono DEFAULT '' FOR telefono,
    constraint DFF_CLIENTE_observacio DEFAULT '' FOR observacio,
    constraint UQQ_CLIENTE_cod_cli_telefono UNIQUE (cod_cli,telefono)
GO
-- RESTRICCIONES PARA LAS TABLAS DE CLIENTE_CONTRATO
Alter table CLIENTE_CONTRATO
add constraint CHK_CLIENTE_CONTRATO_CONTRATO_CORREL CHECK (CONTRATO_CORREL LIKE '[0-9,F][0-9][0-9]'),
    constraint DFF_CLIENTE_CONTRATO_FECH_CREA DEFAULT SYSDATETIME() FOR fech_crea,
    constraint CHK_CLIENTE_CONTRATO_fech_ini CHECK (fech_ini<=fech_venc),
    constraint CHK_CLIENTE_CONTRATO_fech_venc CHECK (fech_venc>=fech_ini),
    constraint DFF_CLIENTE_CONTRATO_fech_ini DEFAULT GETDATE() FOR fech_ini,
    constraint DFF_CLIENTE_CONTRATO_fech_venc DEFAULT GETDATE()+364 FOR fech_venc,
	constraint DFF_CLIENTE_CONTRATO_NOMB_REPRES DEFAULT '' FOR nomb_repres,
    constraint DFF_CLIENTE_CONTRATO_DNI_REPRES DEFAULT '00000000'  FOR dni_repres,
    constraint DFF_CLIENTE_CONTRATO_CARGO_REPRES DEFAULT '' FOR cargo_repres,
    constraint DFF_CLIENTE_CONTRATO_COD_SISTEMA DEFAULT '' FOR cod_sistema,
    constraint DFF_CLIENTE_CONTRATO_MONEDA DEFAULT 'S' FOR moneda,
	constraint DFF_CLIENTE_CONTRATO_MENSUALIDAD DEFAULT 0.00 FOR mensualidad,
	constraint DFF_CLIENTE_CONTRATO_INSTALACION DEFAULT 0.00 FOR instalacion,
	constraint DFF_CLIENTE_CONTRATO_CANT_EST DEFAULT 0 FOR cant_est,
    constraint DFF_CLIENTE_CONTRATO_period_contrato DEFAULT '' FOR period_contrato,
    constraint DFF_CLIENTE_CONTRATO_correo_contrato DEFAULT '' FOR correo_contrato,
    constraint DFF_CLIENTE_CONTRATO_TIPO_SERVICIO DEFAULT 'N' FOR tipo_servicio,
	constraint DFF_CLIENTE_CONTRATO_CONTRATO_ASOC DEFAULT '' FOR CONTRATO_ASOC
go

Alter table CLIENTE_CONTRATO_INCIDENCIA
add constraint CHK_CLIENTE_CONTRATO_INCIDENCIA_CONTRATO_CORREL CHECK (CONTRATO_CORREL LIKE '[0-9,F][0-9][0-9]'),
    constraint DFF_CLIENTE_CONTRATO_INCIDENCIA_FECH_INCIDENCIA DEFAULT SYSDATETIME() FOR fech_incidencia,
    constraint CHK_CLIENTE_CONTRATO_INCIDENCIA_ESTADO CHECK (estado LIKE '[0-9][0-9]'),
    constraint DFF_CLIENTE_CONTRATO_INCIDENCIA_OBSERVAC DEFAULT '' FOR observac
go

Alter table CLIENTE_CONTRATO_OPERADOR
add constraint CHK_CLIENTE_CONTRATO_OPERADOR_CONTRATO_CORREL CHECK (CONTRATO_CORREL LIKE '[0-9,F][0-9][0-9]'),
	constraint DFF_CLIENTE_CONTRATO_OPERADOR_COD_OPERADOR DEFAULT '7072' FOR cod_operador,
    constraint DFF_CLIENTE_CONTRATO_OPERADOR_DES_OPERADOR DEFAULT '' FOR des_operador
go  

Alter table CLIENTE_CONTRATO_SERVIDOR
add constraint CHK_CLIENTE_CONTRATO_SERVIDOR_CONTRATO_CORREL CHECK (CONTRATO_CORREL LIKE '[0-9,F][0-9][0-9]'),
	constraint DFF_CLIENTE_CONTRATO_SERVIDOR_FECH_ACTIVA DEFAULT GETDATE() FOR fech_activa
go  

Alter table CLIENTE_CONTRATO_ESTACION
add constraint CHK_CLIENTE_CONTRATO_ESTACION_CONTRATO_CORREL CHECK (CONTRATO_CORREL LIKE '[0-9,F][0-9][0-9]'),
	constraint DFF_CLIENTE_CONTRATO_ESTACION_FECH_ACTIVA DEFAULT GETDATE() FOR fech_activa
go  

--Trigger para Insertar Datos en la Tabla de Clientes
Create trigger TxtUpdateCliente
on Cliente for update 
as 
begin transaction
      if update(cod_distrito)
		 if not exists(Select cod_distrito from bdsoftpad_ctr_tablas.dbo.ta1 where cod_distrito=(Select cod_distrito from inserted))
		    begin
				print ' Codigo de Distrio no Valido' 
				rollback transaction
			end
		 else
		    commit transaction
      if update(cod_ruta)
		 if not exists(Select cod_ruta from bdsoftpad_ctr_tablas.dbo.ta2 where cod_ruta=(Select cod_ruta from inserted))
		    begin
				print ' Codigo de Ruta no Valido' 
				rollback transaction
			end
		 else
		    commit transaction
      if update(cod_tip_opera)
		 if not exists(Select cod_tip_opera from bdsoftpad_ctr_tablas.dbo.ta3 where cod_tip_opera=(Select cod_tip_opera from inserted))
		    begin
				print ' Codigo de Tipo de Operador no Valido' 
				rollback transaction
			end
		 else
		    commit transaction
      if update(cod_zona)
		 if not exists(Select cod_zona from bdsoftpad_ctr_tablas.dbo.ta4 where cod_zona=(Select cod_zona from inserted))
		    begin
				print ' Codigo de Zona no valido' 
				rollback transaction
			end
		 else
		    commit transaction
go


-- RESTRICCIONES PARA LA TABLA DE EMPLEADOS 
Alter table EMPLEADO 
add constraint CHK_empleado_cod_emp CHECK (cod_emp LIKE '[A-Z][A-Z][A-Z]'),
	constraint DFF_EMPLEADO_nomb_emp DEFAULT '' FOR nomb_emp,
    constraint DFF_EMPLEADO_ape_emp DEFAULT ''  FOR ape_emp,
    constraint UQQ_empleado_nomb_emp_ape_emp UNIQUE (nomb_emp,ape_emp),
    constraint DFF_EMPLEADO_dire_emp DEFAULT ''  FOR dire_emp,
    constraint DFF_EMPLEADO_fch_ingre_emp DEFAULT SYSDATETIME() FOR fch_ingre_emp,
    constraint CHK_empleado_dni CHECK (dni_emp LIKE '[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]'),
    constraint UQQ_empleado_dni UNIQUE (dni_emp),
    constraint DFF_EMPLEADO_dni DEFAULT '00000000'  FOR dni_emp,
    constraint DFF_EMPLEADO_distrito DEFAULT ''  FOR cod_distrito,
    constraint DFF_EMPLEADO_ecivil DEFAULT ''  FOR ecivil_emp,
    constraint DFF_EMPLEADO_tip_emp DEFAULT ''  FOR cod_tip_emp,
    constraint DFF_EMPLEADO_cod_afp DEFAULT ''  FOR cod_afp,
    constraint CHK_empleado_contratado CHECK (contratado in('S','N')),
    constraint DFF_empleado_contratado DEFAULT 'N' FOR contratado,
    constraint CHK_empleado_vigente CHECK (vigente in('S','N')),
    constraint DFF_empleado_vigente DEFAULT 'S' FOR vigente,
	constraint DFF_EMPLEADO_afp_cups DEFAULT ''  FOR afp_cups,
	constraint DFF_EMPLEADO_nro_segsocial DEFAULT '' FOR nro_segsocial
GO

insert into empleado(cod_emp,
                     nomb_emp,
					 ape_emp,
					 dni_emp,
					 cod_tip_emp,
					 fch_nac_emp)
        	values('JCZ',
			       'JUAN CARLOS ',
				   'ZORRILLA LLERENA',
				   '09506613',
				   'S',
				   '1970-02-24')
go

Alter table EMPLEADO_CORREO 
add constraint DFF_EMPLEADO_CORREO DEFAULT '' FOR correo,
    constraint UQQ_empleado_correo UNIQUE (correo)
GO

Alter table EMPLEADO_telefono 
add constraint DFF_EMPLEADO_telefono DEFAULT '' FOR telefono,
    constraint DFF_EMPLEADO_observacio DEFAULT '' FOR observacio,
    constraint UQQ_empleado_telefono UNIQUE (telefono)
GO

Alter table EMPLEADO_CONTRATO 
add constraint CHK_EMPLEADO_CONTRATO_CONTRATO_CORREL CHECK (CONTRATO_CORREL LIKE '[0-9][0-9]'),
    constraint DFF_EMPLEADO_CONTRATO_FECH_CREA DEFAULT SYSDATETIME() FOR fech_crea,
    constraint DFF_EMPLEADO_CONTRATO_tipo_contrato DEFAULT ''  FOR tipo_contrato,
    constraint DFF_EMPLEADO_CONTRATO_cod_tip_emp DEFAULT ''  FOR cod_tip_emp,
    constraint CHK_empleado_CONTRATO_fech_inic CHECK (fech_inic<=fech_fin),
    constraint CHK_empleado_CONTRATO_fech_fin CHECK (fech_fin>=fech_inic),
    constraint DFF_EMPLEADO_CONTRATO_fech_inic DEFAULT GETDATE() FOR fech_inic,
    constraint DFF_EMPLEADO_CONTRATO_fech_fin DEFAULT GETDATE()+360 FOR fech_fin,
	constraint DFF_EMPLEADO_CONTRATO_sueldo_base DEFAULT 0.00 FOR sueldo_base,
    constraint DFF_EMPLEADO_CONTRATO_asig_familiar DEFAULT 0.00 FOR asig_familiar,
    constraint DFF_EMPLEADO_CONTRATO_correo_contrato DEFAULT '' FOR correo_contrato,
	constraint DFF_EMPLEADO_CONTRATO_sueldo_final DEFAULT 0.00 FOR sueldo_final,
    constraint DFF_EMPLEADO_CONTRATO_fasig_familiar DEFAULT 'N' FOR fasig_familiar
GO

Alter table EMPLEADO_CONTRATO_INCIDENCIA
add constraint CHK_EMPLEADO_CONTRATO_INCIDENCIA_CONTRATO_CORREL CHECK (CONTRATO_CORREL LIKE '[0-9][0-9]'),
    constraint DFF_EMPLEADO_CONTRATO_INCIDENCIA_FECH_INCIDENCIA DEFAULT SYSDATETIME() FOR fech_incidencia,
    constraint CHK_EMPLEADO_CONTRATO_INCIDENCIA_ESTADO CHECK (estado LIKE '[0-9]'),
    constraint DFF_EMPLEADO_CONTRATO_INCIDENCIA_OBSERVAC DEFAULT '' FOR observac
go

Alter table EMPLEADO_Sueldo 
add constraint CHK_empleado_sueldo_fech_inic CHECK (fech_inic<=fech_fin),
    constraint CHK_empleado_sueldo_fech_fin CHECK (fech_fin>=fech_inic),
    constraint DFF_EMPLEADO_sueldo_fech_inic DEFAULT GETDATE() FOR fech_inic,
    constraint DFF_EMPLEADO_sueldo_fech_fin DEFAULT GETDATE()+360 FOR fech_fin,
	constraint DFF_EMPLEADO_sueldo_sueldo_base DEFAULT 0.00 FOR sueldo_base,
    constraint DFF_EMPLEADO_sueldo_asig_familiar DEFAULT 0.00 FOR asig_familiar,
	constraint DFF_EMPLEADO_sueldo_sueldo_final DEFAULT 0.00 FOR sueldo_final
GO

--Trigger para Insertar Datos en la Tabla de Clientes
Create trigger TxtUpdateEmpleado
on Empleado for update 
as 
begin transaction
      if update(cod_distrito)
		 if not exists(Select cod_distrito from bdsoftpad_ctr_tablas.dbo.ta1 where cod_distrito=(Select cod_distrito from inserted))
		    begin
				print ' Codigo de Distrio no Valido' 
				rollback transaction
			end
		 else
		    commit transaction
      if update(ecivil_emp)
		 if not exists(Select ecivil_emp from bdsoftpad_ctr_tablas.dbo.ta5 where ecivil_emp=(Select ecivil_emp from inserted))
		    begin
				print ' Codigo de estado civil no Valido' 
				rollback transaction
			end
		 else
		    commit transaction
      if update(cod_tip_emp)
		 if not exists(Select cod_tip_emp from bdsoftpad_ctr_tablas.dbo.ta6 where cod_tip_emp=(Select cod_tip_emp from inserted))
		    begin
				print ' Codigo de Tipo de Empleado no Valido' 
				rollback transaction
			end
		 else
		    commit transaction
go

-- RESTRICCIONES PARA LAS TABLA DE COTIZACIONES 

Alter table COTIZACION
add constraint CHK_COTIZACION_NRO_COTIZACION CHECK (NRO_COTIZACION LIKE '[1-3][0-9][0-9][0-9][0-9][0-9]'),
    constraint DFF_COTIZACION_FECH_CREA DEFAULT SYSDATETIME() FOR fech_crea,
    constraint CHK_COTIZACION_FECH_CREA_NRO_COTIZACION CHECK (LEFT(NRO_COTIZACION,2)=right(YEAR(FECH_CREA),2)),
    constraint DFF_COTIZACION_FECH_VENC DEFAULT GETDATE()+15 FOR fech_venc,
    constraint DFF_COTIZACION_TIPO_COTIZ DEFAULT 'R' FOR tipo_cotiz,
    constraint DFF_COTIZACION_CANTIDAD DEFAULT 0 FOR cantidad,
    constraint DFF_COTIZACION_IMPOR_COTIZ DEFAULT 0.00 FOR impor_cotiz,
    constraint DFF_COTIZACION_MONEDA DEFAULT 'S' FOR moneda,
    constraint CHK_COTIZACION_MONEDA CHECK (moneda in('S','D')),
    constraint DFF_COTIZACION_ATENCION DEFAULT '' FOR atencion,
    constraint DFF_COTIZACION_CORREO_COTIZ DEFAULT '' FOR correo_cotiz
go

Alter table COTIZACION_SISTEMA
add constraint CHK_COTIZACION_SISTEMA_NRO_COTIZACION CHECK (NRO_COTIZACION LIKE '[1-3][0-9][0-9][0-9][0-9][0-9]'),
    constraint DFF_COTIZACION_SISTEMA_COD_SISTEMA DEFAULT '' FOR cod_sistema,
    constraint DFF_COTIZACION_SISTEMA_TIPO_CONTRATO DEFAULT 'M' FOR tipo_contrato,
    constraint DFF_COTIZACION_MENSUALIDAD DEFAULT 0.00 FOR mensualidad,
    constraint DFF_COTIZACION_INSTALACION DEFAULT 0.00 FOR instalacion,
    constraint DFF_COTIZACION_TIPO_DESTINO DEFAULT 'C' FOR tipo_destino,
    constraint DFF_COTIZACION_TIPO_SERVICIO DEFAULT 'N' FOR tipo_servicio
go
    
Alter table COTIZACION_REQUERIMIENTO
      add constraint CHK_COTIZACION_REQUERIMIENTO_NRO_COTIZACION CHECK (NRO_COTIZACION LIKE '[1-3][0-9][0-9][0-9][0-9][0-9]')
go

Alter table COTIZACION_OTROS
      add constraint CHK_COTIZACION_OTROS_NRO_COTIZACION CHECK (NRO_COTIZACION LIKE '[1-3][0-9][0-9][0-9][0-9][0-9]')
go

Alter table COTIZACION_INCIDENCIA
add constraint CHK_COTIZACION_INCIDENCIA_NRO_COTIZACION CHECK (NRO_COTIZACION LIKE '[1-3][0-9][0-9][0-9][0-9][0-9]'),
    constraint DFF_COTIZACION_INCIDENCIA_FECH_INCIDENCIA DEFAULT SYSDATETIME() FOR fech_incidencia,
    constraint CHK_COTIZACION_INCIDENCIA_ESTADO CHECK (estado LIKE '[0-9][0-9]'),
    constraint DFF_COTIZACION_INCIDENCIA_OBSERVAC DEFAULT '' FOR observac
go

-- RESTRICCIONES PARA LAS TABLAS DE REQUERIMIENTOS
Alter table REQUERIMIENTO
add constraint CHK_REQUERIMIENTO_NRO_REQUERIMIENTO CHECK (NRO_REQUERIMIENTO LIKE '[0-9][0-9][0-9][1-3][0-9][0-9][0-9][0-9][0-9]'),
    constraint CHK_REQUERIMIENTO_FECH_CREA_NRO_REQUERIMIENTO CHECK (SUBSTRING(NRO_REQUERIMIENTO,4,2)=right(YEAR(FECH_CREA),2)),
    constraint DFF_REQUERIMIENTO_FECH_CREA DEFAULT SYSDATETIME() FOR fech_crea,
    constraint DFF_REQUERIMIENTO_TITULO_REQ DEFAULT '' FOR titulo_req,
    constraint DFF_REQUERIMIENTO_CANT_DIAS DEFAULT 0 FOR cant_dias,
    constraint DFF_REQUERIMIENTO_USUARIO_SIS DEFAULT '' FOR usuario_sis,
    constraint DFF_REQUERIMIENTO_FECH_VENC DEFAULT GETDATE()+15 FOR fech_venc,
    constraint DFF_REQUERIMIENTO_CORREO_ORIGEN DEFAULT '' FOR correo_origen
go

Alter table REQUERIMIENTO_INCIDENCIA
add constraint CHK_REQUERIMIENTO_INCIDENCIA_NRO_REQUERIMIENTO CHECK (NRO_REQUERIMIENTO LIKE '[0-9][0-9][0-9][1-3][0-9][0-9][0-9][0-9][0-9]'),
    constraint DFF_REQUERIMIENTO_INCIDENCIA_FECH_INCIDENCIA DEFAULT SYSDATETIME() FOR fech_incidencia,
    constraint CHK_REQUERIMIENTO_INCIDENCIA_ESTADO CHECK (estado LIKE '[0-9][0-9]'),
    constraint DFF_REQUERIMIENTO_INCIDENCIA_OBSERVAC DEFAULT '' FOR observac
go


-- RESTRICCIONES PARA LA TABLA DE SISTEMA 
Alter table SISTEMA
      add constraint DFF_SISTEMA_INSTALACION DEFAULT 0.00 FOR instalacion
go

-- RESTRICCIONES PARA LAS TABLA DE VISITAS 
Alter table VISITA
add constraint CHK_VISITA_NRO_VISITA CHECK (NRO_VISITA LIKE '[0-9][0-9][0-9][0-9][0-9][0-9][0-9]'),
    constraint DFF_VISITA_FECH_CREA DEFAULT SYSDATETIME() FOR fech_crea,
    constraint DFF_VISITA_DETALLE_TIPO_VISITA DEFAULT '' FOR tipo_visita,
    constraint DFF_VISITA_DETALLE_TIPO_DESTINO DEFAULT '' FOR tipo_destino,
    constraint DFF_VISITA_DETALLE_SERV_MENSUAL DEFAULT '' FOR serv_mensual
go


Alter table VISITA_INCIDENCIA
add constraint CHK_VISITA_INCIDENCIA_NRO_VISITA CHECK (NRO_VISITA LIKE '[0-9][0-9][0-9][0-9][0-9][0-9][0-9]'),
    constraint DFF_VISITA_INCIDENCIA_FECH_INCIDENCIA DEFAULT SYSDATETIME() FOR fech_incidencia,
    constraint CHK_VISITA_INCIDENCIA_ESTADO CHECK (estado LIKE '[0-9][0-9]'),
    constraint DFF_VISITA_INCIDENCIA_OBSERVAC DEFAULT '' FOR observac
go

-- RESTRICCIONES PARA LAS TABLA DE LLAMADAS 
Alter table LLAMADA
add constraint CHK_LLAMADA_NRO_TICKET CHECK (NRO_TICKET LIKE '[0-9][0-9][0-9][0-9][0-9][0-9][0-9]'),
    constraint CHK_LLAMADA_FECH_CREA_NRO_TICKET CHECK (SUBSTRING(NRO_TICKET,1,2)=right(YEAR(FECH_CREA),2)),
    constraint DFF_LLAMADA_FECH_CREA DEFAULT SYSDATETIME() FOR fech_crea,
    constraint DFF_LLAMADA_USUARIO_SIS DEFAULT '' FOR usuario_sis,
    constraint DFF_LLAMADA_MOTIVO_LLAMADA DEFAULT '' FOR motivo_llamada,
    constraint DFF_LLAMADA_TELEFONO_REF DEFAULT '' FOR telefono_ref,
    constraint DFF_LLAMADA_TIPO_ATENT DEFAULT '' FOR tipo_atent
go

Alter table LLAMADA_INCIDENCIA
add constraint CHK_LLAMADA_INCIDENCIA_NRO_TICKET CHECK (NRO_TICKET LIKE '[0-9][0-9][0-9][0-9][0-9][0-9][0-9]'),
    constraint DFF_LLAMADA_INCIDENCIA_FECH_INCIDENCIA DEFAULT SYSDATETIME() FOR fech_incidencia,
    constraint CHK_LLAMADA_INCIDENCIA_ESTADO CHECK (estado LIKE '[0-9][0-9]'),
    constraint DFF_LLAMADA_INCIDENCIA_OBSERVAC DEFAULT '' FOR observac
go

-- RESTRICCIONES PARA LAS TABLA DE DOCUMENTOS 
Alter table DOCUMENTO
add constraint CHK_DOCUMENTO_TIPO_DOC CHECK (TIPO_DOC LIKE '[0-9][1-9]'),
    constraint CHK_DOCUMENTO_NRO_DOCUMENTO CHECK (NRO_DOCUMENTO LIKE '[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]'),
    constraint DFF_DOCUMENTO_FECH_CREA DEFAULT SYSDATETIME() FOR fech_crea,
    constraint CHK_DOCUMENTO_FECH_CREA CHECK (fech_crea<=fech_venc),
    constraint CHK_DOCUMENTO_FECH_VENC CHECK (fech_venc>=fech_crea),
    constraint DFF_DOCUMENTO_FECH_VENC DEFAULT GETDATE()+15 FOR fech_venc,
    constraint DFF_DOCUMENTO_MONEDA DEFAULT 'S' FOR moneda,
    constraint DFF_DOCUMENTO_T_CAMBIO DEFAULT 0.00 FOR t_cambio,
    constraint DFF_DOCUMENTO_DIMPORTE DEFAULT 0.00 FOR dimporte,
    constraint DFF_DOCUMENTO_SIMPORTE DEFAULT 0.00 FOR simporte,
    constraint DFF_DOCUMENTO_DIGV DEFAULT 0.00 FOR digv,
    constraint DFF_DOCUMENTO_SIGV DEFAULT 0.00 FOR sigv,
    constraint DFF_DOCUMENTO_DTOT_DOCUM DEFAULT 0.00 FOR dtot_docum,
    constraint DFF_DOCUMENTO_STOT_DOCUM DEFAULT 0.00 FOR stot_docum,
    constraint DFF_DOCUMENTO_IMPORTE_LETRA DEFAULT '' FOR importe_letra,
    constraint DFF_DOCUMENTO_NRO_DOC_ASOC DEFAULT '' FOR nro_doc_asoc
go

Alter table DOCUMENTO_DETALLE
add constraint CHK_DOCUMENTO_DETALLE_TIPO_DOC CHECK (TIPO_DOC LIKE '[0-9][1-9]'),
    constraint CHK_DOCUMENTO_DETALLE_NRO_DOCUMENTO CHECK (NRO_DOCUMENTO LIKE '[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]'),
    constraint DFF_DOCUMENTO_DETALLE_TIPO_CONCEPTO DEFAULT '' FOR tipo_concepto,
    constraint DFF_DOCUMENTO_DETALLE_TIT_CONCEPTO DEFAULT '' FOR tit_concepto,
    constraint DFF_DOCUMENTO_DETALLE_MES_SERV DEFAULT '' FOR mes_serv,
    constraint DFF_DOCUMENTO_DETALLE_A�O_SERV DEFAULT '' FOR a�o_serv,
    constraint DFF_DOCUMENTO_DETALLE_DIMPORTE DEFAULT 0.00 FOR dimporte,
    constraint DFF_DOCUMENTO_DETALLE_SIMPORTE DEFAULT 0.00 FOR simporte,
go

Alter table DOCUMENTO_INCIDENCIA
add constraint CHK_DOCUMENTO_INCIDENCIA_TIPO_DOC CHECK (TIPO_DOC LIKE '[0-9][1-9]'),
    constraint CHK_DOCUMENTO_INCIDENCIA_NRO_DOCUMENTO CHECK (NRO_DOCUMENTO LIKE '[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]'),
    constraint DFF_DOCUMENTO_INCIDENCIA_FECH_INCIDENCIA DEFAULT SYSDATETIME() FOR fech_incidencia,
    constraint CHK_DOCUMENTO_INCIDENCIA_ESTADO CHECK (estado LIKE '[0-9][0-9]'),
    constraint DFF_DOCUMENTO_INCIDENCIA_OBSERVAC DEFAULT '' FOR observac
go

-- RESTRICCIONES PARA LAS TABLA DE VOUCHERS 
Alter table VOUCHER
add constraint CHK_VOUCHER_TIPO_VOUCHER CHECK (TIPO_VOUCHER LIKE '[0-9][1-9]'),
    constraint CHK_VOUCHER_NRO_VOUCHER CHECK (NRO_VOUCHER LIKE '[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]'),
    constraint DFF_VOUCHER_FECH_CREA DEFAULT SYSDATETIME() FOR fech_crea,
    constraint DFF_VOUCHER_MONEDA DEFAULT 'S' FOR moneda,
    constraint DFF_VOUCHER_T_CAMBIO DEFAULT 0.00 FOR t_cambio,
    constraint DFF_VOUCHER_COD_CUENTA DEFAULT '1' FOR cod_cuenta,
    constraint DFF_VOUCHER_TIPO_PAGO DEFAULT ' ' FOR tipo_pago,
    constraint DFF_VOUCHER_NRO_CHEQUE DEFAULT ' ' FOR nro_cheque,
    constraint DFF_VOUCHER_DIMPORTE DEFAULT 0.00 FOR dimporte,
    constraint DFF_VOUCHER_SIMPORTE DEFAULT 0.00 FOR simporte,
    constraint DFF_VOUCHER_BANCO_CHEQUE DEFAULT ' ' FOR banco_cheque,
    constraint DFF_VOUCHER_REFER_BANCO DEFAULT ' ' FOR refer_banco,
    constraint DFF_VOUCHER_DTOT_APLICADOS DEFAULT 0.00 FOR dtot_aplicados,
    constraint DFF_VOUCHER_STOT_APLICADOS DEFAULT 0.00 FOR stot_aplicados
go

Alter table VOUCHER_DETALLE
add constraint CHK_VOUCHER_DETALLE_TIPO_VOUCHER CHECK (TIPO_VOUCHER LIKE '[0-9][1-9]'),
    constraint CHK_VOUCHER_DETALLE_NRO_VOUCHER CHECK (NRO_VOUCHER LIKE '[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]'),
    constraint DFF_VOUCHER_DETALLE_DIMPORTE DEFAULT 0.00 FOR dimporte,
    constraint DFF_VOUCHER_DETALLE_SIMPORTE DEFAULT 0.00 FOR simporte,
    constraint DFF_VOUCHER_DETALLE_OBSERVAC DEFAULT '' FOR observac,
    constraint DFF_VOUCHER_DETALLE_NRO_CHEQUE DEFAULT ' ' FOR nro_cheque,
    constraint DFF_VOUCHER_DETALLE_BANCO_CHEQUE DEFAULT ' ' FOR banco_cheque,
    constraint DFF_VOUCHER_DETALLE_FLAG_APLIC DEFAULT ' ' FOR flag_aplic
go

Alter table VOUCHER_INCIDENCIA
add constraint CHK_VOUCHER_INCIDENCIA_TIPO_VOUCHER CHECK (TIPO_VOUCHER LIKE '[0-9][1-9]'),
    constraint CHK_VOUCHER_INCIDENCIA_NRO_VOUCHER CHECK (NRO_VOUCHER LIKE '[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]'),
    constraint DFF_VOUCHER_INCIDENCIA_FECH_INCIDENCIA DEFAULT SYSDATETIME() FOR fech_incidencia,
    constraint CHK_VOUCHER_INCIDENCIA_ESTADO CHECK (estado LIKE '[0-9][0-9]'),
    constraint DFF_VOUCHER_INCIDENCIA_OBSERVAC DEFAULT '' FOR observac
go

Alter table AUSENCIA
add constraint CHK_AUSENCIA_NRO_AUSENCIA CHECK (NRO_AUSENCIA LIKE '[0-9][0-9][0-9][0-9][0-9][0-9]'),
    constraint DFF_AUSENCIA_fech_crea DEFAULT GETDATE() FOR fech_crea,
    constraint DFF_AUSENCIA_COD_AUSENCIA DEFAULT '' FOR cod_ausencia,
    constraint CHK_AUSENCIA_fech_crea CHECK (fech_crea<=fech_inicio),
	constraint CHK_AUSENCIA_fech_crea1 CHECK (fech_inicio<fech_termino),
    constraint CHK_AUSENCIA_fech_inicio CHECK (fech_inicio<=fech_termino),
    constraint CHK_AUSENCIA_fech_termino CHECK (fech_termino>=fech_inicio),
    constraint DFF_AUSENCIA_CORREO_DESTINO DEFAULT '' FOR correo_destino,
    constraint DFF_AUSENCIA_SUBCODIGO DEFAULT '' FOR subcodigo
go
    
Alter table AUSENCIA_INCIDENCIA
add constraint CHK_AUSENCIA_INCIDENCIA_NRO_AUSENCIA CHECK (NRO_AUSENCIA LIKE '[0-9][0-9][0-9][0-9][0-9][0-9]'),
    constraint DFF_AUSENCIA_INCIDENCIA_FECH_INCIDENCIA DEFAULT SYSDATETIME() FOR fech_incidencia,
    constraint CHK_AUSENCIA_INCIDENCIA_COD_ESTADO CHECK (cod_estado LIKE '[0-9]'),
    constraint DFF_AUSENCIA_INCIDENCIA_OBSERVAC DEFAULT '' FOR observac
go

Alter table ADELANTO 
add constraint CHK_ADELANTO_NRO_ADELANTO CHECK (NRO_ADELANTO LIKE '[0-9][0-9][0-9][0-9][0-9][0-9]'),
    constraint DFF_ADELANTO_FECH_CREA DEFAULT GETDATE() FOR fech_crea,
    constraint DFF_ADELANTO_FECH_ADELANTO DEFAULT GETDATE() FOR fech_adelanto,
    constraint CHK_ADELANTO_FECH_ADELANTO CHECK (fech_crea<=fech_adelanto),
    constraint DFF_ADELANTO_IMPORTE DEFAULT 0.00 FOR importe,
    constraint DFF_ADELANTO_CORREO_DESTINO DEFAULT '' FOR correo_destino
go

Alter table ADELANTO_INCIDENCIA
add constraint CHK_ADELANTO_INCIDENCIA_NRO_AUSENCIA CHECK (NRO_ADELANTO LIKE '[0-9][0-9][0-9][0-9][0-9][0-9]'),
    constraint DFF_ADELANTO_INCIDENCIA_FECH_INCIDENCIA DEFAULT SYSDATETIME() FOR fech_incidencia,
    constraint CHK_ADELANTO_INCIDENCIA_COD_ESTADO CHECK (cod_estado LIKE '[0-9]'),
    constraint DFF_ADELANTO_INCIDENCIA_OBSERVAC DEFAULT '' FOR observac
go

Alter table HORARIO
add constraint CHK_HORARIO_COD_HORARIO CHECK (COD_HORARIO LIKE '[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]'),
    constraint DFF_HORARIO_fech_crea DEFAULT GETDATE() FOR fech_crea,
    constraint CHK_HORARIO_entrada CHECK (entrada>='0700'),
    constraint CHK_HORARIO_salida CHECK (entrada<=salida),
	constraint CHK_HORARIO_entrada1 CHECK (salida<entrada1),
	constraint CHK_HORARIO_salida1 CHECK (entrada1<salida1),
    constraint DFF_HORARIO_OBSERVAC DEFAULT '' FOR observac
go    

Alter table HORARIO_INCIDENCIA
add constraint CHK_HORARIO_INCIDENCIA_COD_HORARIO CHECK (COD_HORARIO LIKE '[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]'),
    constraint DFF_HORARIO_INCIDENCIA_FECH_INCIDENCIA DEFAULT SYSDATETIME() FOR fech_incidencia,
    constraint CHK_HORARIO_INCIDENCIA_COD_ESTADO CHECK (cod_estado LIKE '[0-9]'),
    constraint DFF_HORARIO_INCIDENCIA_OBSERVAC DEFAULT '' FOR observac
go


CREATE TABLE [CLIENTE_CORREO_FACT]
( 
	[COD_CLI]            char(3)  NOT NULL ,
	[correl]             char(1)  NOT NULL ,
	[dir_correo]         varchar(60)  NULL ,
	[observac]           varchar(50)  NULL ,
)
go
ALTER TABLE [CLIENTE_CORREO_FACT]
	ADD CONSTRAINT [XPKCLIENTE_CORREO_FACT] PRIMARY KEY  CLUSTERED ([COD_CLI] ASC,[correl] ASC)
go

ALTER TABLE [CLIENTE_CORREO_FACT]
	ADD CONSTRAINT [R_222888] FOREIGN KEY ([cod_cli]) REFERENCES [CLIENTE]([cod_cli])
		ON DELETE NO ACTION
		ON UPDATE NO ACTION
go
Alter table CLIENTE_CORREO_FACT 
add constraint DFF_CLIENTE_CORREO_FACT DEFAULT '' FOR dir_correo,
    constraint UQQ_CLIENTE_CORREO_FACT UNIQUE (cod_cli,dir_correo),
    constraint DFF_CLIENTE_CORREO_FACT_OBSERVAC DEFAULT '' FOR OBSERVAC
GO
