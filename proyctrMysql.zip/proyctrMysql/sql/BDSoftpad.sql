--Creando Base de Datos SOFTPAD

create database bdSoftpad_ctr
on
(
name=softpad_data,
filename='c:\ctrsql\data\softpad_ctr_data.mdf',
size=5MB,
maxsize=10MB,
filegrowth=10%
)
log on
(
name=softpad_log,
filename='c:\ctrsql\registro\softpad_ctr_log.ldf',
size=5MB,
MAXSIZE=100MB,
filegrowth=10%
)
go

create database bdSoftpad_ctr_tablas
on
(
name=softpad_data,
filename='c:\ctrsql\data\softpad_ctr_tablas_data.mdf',
size=5MB,
maxsize=10MB,
filegrowth=10%
)
log on
(
name=softpad_log,
filename='c:\ctrsql\registro\softpad_ctr_tablas_log.ldf',
size=5MB,
MAXSIZE=100MB,
filegrowth=10%
)
go

-- Ver estructura 
Sp_helpdb BDSOFTPAD
go

ALTER DATABASE BDSOFTPAD
ADD FILE 
(
name=backus_dataS1,
filename='C:\Backus\data\backus_data.ndf',
size=5MB,
maxsize=10MB,
filegrowth=10%
)
go

--ALTERAR LA BASE DE DATOS PARA GREGAR UN LOGFILE
ALTER DATABASE bdsoftpad_ctr
ADD LOG FILE
(
Name=Backus_Log2,
FileName='C:\Program Files\Microsoft SQL Server\MSSQL13.MSSQLSERVER\MSSQL\DATA\softpad_ctr_log.ldf',
Size=20MB,
MaxSize=1024MB,
FileGrowth=10%
)
GO

SP_HelpDB BDBACKUS
GO