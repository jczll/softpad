-- CREACION DE TABLA MAESTRAS DEL CONTROL 

--Tabla de Distritos  
CREATE TABLE TA1( 
	cod_distrito       char(6)  NOT NULL PRIMARY KEY,
	des_distrito       varchar(30)  NULL ,
	provincia          varchar(20)  NULL ,
	dpto               varchar(15)  NULL)
go

INSERT INTO TA1 SELECT CODIGO,DISTRITO,PROVINCIA,DPTO FROM master.dbo.TA29

--Tabla de Rutas del Cliente 
CREATE TABLE TA2( 
	cod_ruta      char(1)  NOT NULL PRIMARY KEY,
	des_ruta      varchar(20)  NULL)
go

INSERT INTO TA1 SELECT COD_ruta,des_ruta FROM master.dbo.TA29

-- Tabla de Tipos de Operador 
CREATE TABLE TA3( 
	cod_tip_opera   char(1)  NOT NULL PRIMARY KEY,
	des_tip_opera   varchar(50)  NULL)
go

INSERT INTO TA3 SELECT CODIGO,DESCRIPCIO FROM master.dbo.TA164


-- Tabla de Zona de Cliente 
CREATE TABLE TA4( 
	cod_zona     char(1)  NOT NULL PRIMARY KEY,
	des_zona     varchar(20)  NULL)
go

INSERT INTO TA4 SELECT CODIGO,DESCRIPCIO FROM master.dbo.TA26

-- Tabla de Estado Civil de los Empleados 
CREATE TABLE TA5( 
	ecivil_emp   char(1)  NOT NULL PRIMARY KEY,
	des_ecivil   varchar(20)  NULL)
go

-- Tabla de Tipo de Empleados 
CREATE TABLE TA6( 
	cod_tip_emp   char(1)  NOT NULL PRIMARY KEY,
	des_tip_emp  varchar(20)  NULL)
go


CREATE TABLE TA7
 (
   fchtcambio 	DATE NOT NULL DEFAULT GETDATE(),
   DOLAR_BANC	DECIMAL(12,10) DEFAULT 0.0000000000,
 PRIMARY KEY (fchtcambio)
 )

CREATE TABLE TA8
 (
   programa  char(10) NOT NULL,
   descripcio varchar(30),
   usuario_a    char(1),
   usuario_c    char(1),
   usuario_d    char(1),
   usuario_s    char(1),
 PRIMARY KEY (programa)
 )
 
 CREATE TABLE TA9
 (
   codigo     char(3) NOT NULL,
   descripcio varchar(30) default '',
   aporte     decimal(8,2) default 0.00,
   prima      decimal(8,2) default 0.00,
   comision1  decimal(8,2) default 0.00,
   comision2  decimal(8,2) default 0.00,
 PRIMARY KEY (codigo)
 )

 CREATE TABLE TA10
 (
   codigo  char(1) NOT NULL,
   descripcio varchar(25),
 PRIMARY KEY (codigo)
 )
 
  CREATE TABLE TA11
 (
   codigo  char(1) NOT NULL,
   descripcio varchar(25),
   simbolo varchar(5),
 PRIMARY KEY (codigo)
 )

 CREATE TABLE TA12
 (
   codigo  char(1) NOT NULL,
   descripcio varchar(50),
   tarifa decimal(8,2),
 PRIMARY KEY (codigo)
 )
 
 CREATE TABLE TA13
 (
   codigo  char(2) NOT NULL,
   descripcio varchar(50),
 PRIMARY KEY (codigo)
 )

  CREATE TABLE TA14
 (
   codigo  char(2) NOT NULL,
   descripcio varchar(50),
 PRIMARY KEY (codigo)
 )

  CREATE TABLE TA15
 (
   codigo  char(1) NOT NULL,
   descripcio varchar(10),
 PRIMARY KEY (codigo)
 )
  CREATE TABLE TA16
 (
   codigo  char(2) NOT NULL,
   descripcio varchar(50),
 PRIMARY KEY (codigo)
 )

  CREATE TABLE TA17
 (
   codigo  char(2) NOT NULL,
   descripcio varchar(15),
 PRIMARY KEY (codigo)
 )

  CREATE TABLE TA18
 (
   codigo  char(1) NOT NULL,
   descripcio varchar(15),
 PRIMARY KEY (codigo)
 )

   CREATE TABLE TA19
 (
   codigo  char(1) NOT NULL,
   descripcio varchar(10),
 PRIMARY KEY (codigo)
 )

 CREATE TABLE TA20
  (
   codigo  char(3) NOT NULL,
   descripcio varchar(30),
 PRIMARY KEY (codigo)
 )

 CREATE TABLE TA21
 (
   codigo  char(2) NOT NULL,
   descripcio varchar(50),
 PRIMARY KEY (codigo)
 )
 
 CREATE TABLE TA22
 (
   codigo  char(2) NOT NULL,
   descripcio varchar(15),
 PRIMARY KEY (codigo)
 )

 CREATE TABLE TA23
 (
   codigo  char(2) NOT NULL,
   descripcio varchar(50),
 PRIMARY KEY (codigo)
 )

  CREATE TABLE TA24
 (
   codigo  char(1) NOT NULL,
   descripcio varchar(20),
 PRIMARY KEY (codigo)
 )

  CREATE TABLE TA25
 (
   codigo  char(1) NOT NULL,
   descripcio varchar(20),
 PRIMARY KEY (codigo)
 )
   CREATE TABLE TA26
 (
   codigo  char(2) NOT NULL,
   descripcio varchar(20),
 PRIMARY KEY (codigo)
 )
 
  CREATE TABLE TA27
 (
   codigo  char(3) NOT NULL,
   descripcio varchar(20),
 PRIMARY KEY (codigo)
 )
  CREATE TABLE TA28
 (
   codigo  char(2) NOT NULL,
   descripcio varchar(20),
 PRIMARY KEY (codigo)
 )
 
 CREATE TABLE TA29
 (
   codigo  char(1) NOT NULL,
   descripcio varchar(40),
   nro_cuenta varchar(18),
 PRIMARY KEY (codigo)
 )

 CREATE TABLE TA30
 (
   codigo  char(2) NOT NULL,
   descripcio varchar(40),
   iniciales varchar(12),
 PRIMARY KEY (codigo)  
 )
 
 CREATE TABLE TA31
 (
   codigo  char(1) NOT NULL,
   descripcio varchar(30),   
 PRIMARY KEY (codigo)  
 )

 CREATE TABLE TA32
 (
   codigo  char(2) NOT NULL,
   descripcio varchar(20),
 PRIMARY KEY (codigo)
 )
 
 CREATE TABLE TA33
 (
   codigo  char(1) NOT NULL,
   descripcio varchar(40),
 PRIMARY KEY (codigo)
 )

 CREATE TABLE TA34
 (
   codigo  char(1) NOT NULL,
   descripcio varchar(20),
 PRIMARY KEY (codigo)
 )

 CREATE TABLE TA35
 (
   codigo  char(2) NOT NULL,
   descripcio varchar(30),
 PRIMARY KEY (codigo)
 )
 
  CREATE TABLE TA36
 (
   codigo  char(1) NOT NULL,
   descripcio varchar(30),
 PRIMARY KEY (codigo)
 )

   CREATE TABLE TA37
 (
   codigo  char(1) NOT NULL,
   descripcio varchar(20),
 PRIMARY KEY (codigo)
 )

 CREATE TABLE TA38
 (
   codigo  char(1) NOT NULL,
   descripcio varchar(30),
 PRIMARY KEY (codigo)
 )
 
 CREATE TABLE TA39
 (
   fecha_inic  date,
   impor_asignac numeric(8,2),
 PRIMARY KEY (fecha_inic)
 )

  CREATE TABLE TA40
 (
   fecha_feriado  date, 
 PRIMARY KEY (fecha_feriado)
 )

 CREATE TABLE TA41
 (
   codigo  char(2) NOT NULL,
   descripcio varchar(30),
 PRIMARY KEY (codigo)
 )

 CREATE TABLE TA42
 (
   codigo  char(1) NOT NULL,
   descripcio varchar(30),
 PRIMARY KEY (codigo)
 )

 CREATE TABLE TA43
 (
   codigo  char(1) NOT NULL,
   descripcio varchar(30),
 PRIMARY KEY (codigo)
 )

 CREATE TABLE TA44
 (
   codigo  char(1) NOT NULL,
   descripcio varchar(30),
 PRIMARY KEY (codigo)
 )

 CREATE TABLE TA45
 (
   codigo  char(1) NOT NULL,
   descripcio varchar(30),
 PRIMARY KEY (codigo)
 )

CREATE TABLE Indices
 (
   alias  char(10) NOT NULL,
   nom_tabla varchar(30) NOT NULL,
   tab_madre varchar(30) NOT NULL,
   clave1    varchar(50) default '',
   clave2    varchar(50) default '',
   tipo_clave char(1) default 'A', 
   editable   char(1) default 'S',
 PRIMARY KEY (alias,nom_tabla)
 )
 go 

 
 CREATE TABLE TABLAS
 (
   correl       int  NOT NULL  IDENTITY ( 1,1 ),
   tabla        char(10) NOT NULL,
   tabla_nombre varchar(50),
   clave1       varchar(50) default '',
   clave2       varchar(50) default '',
   tipo_clave   char(1) default 'A', 
 PRIMARY KEY (correl,tabla),
 constraint UQQ_TABLA_TABLA UNIQUE (tabla)
 );
 
INSERT INTO TABLAS(tabla,tabla_nombre,clave1,clave2,tipo_clave) VALUES('TA1','TABLA DE DISTRITOS','COD_DISTRITO','DES_DISTRITO','A');
INSERT INTO TABLAS(tabla,tabla_nombre,clave1,clave2,tipo_clave) VALUES('TA2','TABLA DE RUTAS DE TRABAJO','COD_RUTA','DES_RUTA','A');
INSERT INTO TABLAS(tabla,tabla_nombre,clave1,clave2,tipo_clave) VALUES('TA3','TIPO DE OPERADOR','COD_TIP_OPERA','DES_TIP_OPERA','A');  
INSERT INTO TABLAS(tabla,tabla_nombre,clave1,clave2,tipo_clave) VALUES('TA4','TABLA DE ZONAS DE TRABAJO','COD_ZONA','DES_ZONA','A');  
INSERT INTO TABLAS(tabla,tabla_nombre,clave1,clave2,tipo_clave) VALUES('TA5','ESTADO CIVIL DEL EMPLEADO','ECIVIL_EMP','DES_ECIVIL','A');  
INSERT INTO TABLAS(tabla,tabla_nombre,clave1,clave2,tipo_clave) VALUES('TA6','TABLA DE TIPOS DE EMPLEADO','COD_TIP_EMP','DES_TIP_EMP','A');  
INSERT INTO TABLAS(tabla,tabla_nombre,clave1,clave2,tipo_clave) VALUES('TA7','TABLA DE TIPOS DE CAMBIO','FCHTCAMBIO','','A');  
INSERT INTO TABLAS(tabla,tabla_nombre,clave1,clave2,tipo_clave) VALUES('TA8','ACCESOS X TIPO DE USUARIOS AL SISTEMA','PROGRAMA ','DESCRIPCIO','A');  
INSERT INTO TABLAS(tabla,tabla_nombre,clave1,clave2,tipo_clave) VALUES('TA9','TIPO DE AFPS','CODIGO','DESCRIPCIO','A');  
INSERT INTO TABLAS(tabla,tabla_nombre,clave1,clave2,tipo_clave) VALUES('TA10','TIPO DE PERIODO DE CONTRATO DEL CLIENTE','CODIGO','DESCRIPCIO','A');  
INSERT INTO TABLAS(tabla,tabla_nombre,clave1,clave2,tipo_clave) VALUES('TA11','TIPO DE MONEDA','CODIGO','DESCRIPCIO','A');  
INSERT INTO TABLAS(tabla,tabla_nombre,clave1,clave2,tipo_clave) VALUES('TA12','TIPO DE COTIZACION Y TARIFA','CODIGO','DESCRIPCIO','A');  
INSERT INTO TABLAS(tabla,tabla_nombre,clave1,clave2,tipo_clave) VALUES('TA13','INCIDENCIA DE COTIZACION','CODIGO','DESCRIPCIO','A');  
INSERT INTO TABLAS(tabla,tabla_nombre,clave1,clave2,tipo_clave) VALUES('TA14','INCIDENCIA DE REQUERIMIENTO','CODIGO','DESCRIPCIO','A');  
INSERT INTO TABLAS(tabla,tabla_nombre,clave1,clave2,tipo_clave) VALUES('TA15','TIPOS DE CONTRATO DEL CLIENTE','CODIGO','DESCRIPCIO','A');  
INSERT INTO TABLAS(tabla,tabla_nombre,clave1,clave2,tipo_clave) VALUES('TA16','INCIDENCIA DE CONTRATO DEL CLIENTE','CODIGO','DESCRIPCIO','A');  
INSERT INTO TABLAS(tabla,tabla_nombre,clave1,clave2,tipo_clave) VALUES('TA17','VERSIONES DEL SISTEMA','CODIGO','DESCRIPCIO','A');  
INSERT INTO TABLAS(tabla,tabla_nombre,clave1,clave2,tipo_clave) VALUES('TA18','TIPOS DE TELEFONOS MOVILES DEL CLIENTE','CODIGO','DESCRIPCIO','A');  
INSERT INTO TABLAS(tabla,tabla_nombre,clave1,clave2,tipo_clave) VALUES('TA19','TIPOS DE DESTINATARIO DE LA COTIZACION','CODIGO','DESCRIPCIO','A');  
INSERT INTO TABLAS(tabla,tabla_nombre,clave1,clave2,tipo_clave) VALUES('TA20','TIPOS DE VISITA','CODIGO','DESCRIPCIO','A');  
INSERT INTO TABLAS(tabla,tabla_nombre,clave1,clave2,tipo_clave) VALUES('TA21','INCIDENCIAS DE VISITAS','CODIGO','DESCRIPCIO','A');  
INSERT INTO TABLAS(tabla,tabla_nombre,clave1,clave2,tipo_clave) VALUES('TA22','MESES DEL A�O','CODIGO','DESCRIPCIO','A');  
INSERT INTO TABLAS(tabla,tabla_nombre,clave1,clave2,tipo_clave) VALUES('TA23','INCIDENCIAS DE LLAMADAS','CODIGO','DESCRIPCIO','A');  
INSERT INTO TABLAS(tabla,tabla_nombre,clave1,clave2,tipo_clave) VALUES('TA24','TIPO DE ATENCION DE LLAMADAS','CODIGO','DESCRIPCIO','A');  
INSERT INTO TABLAS(tabla,tabla_nombre,clave1,clave2,tipo_clave) VALUES('TA25','TIPO DE SERVICIO PARA COTIZACION Y CONTRATOS','CODIGO','DESCRIPCIO','A');  
INSERT INTO TABLAS(tabla,tabla_nombre,clave1,clave2,tipo_clave) VALUES('TA26','TIPO DE DOCUMENTOS A FACTURAR','CODIGO','DESCRIPCIO','A');  
INSERT INTO TABLAS(tabla,tabla_nombre,clave1,clave2,tipo_clave) VALUES('TA27','TIPO DE CONCEPTO PARA FACTURACION','CODIGO','DESCRIPCIO','A');  
INSERT INTO TABLAS(tabla,tabla_nombre,clave1,clave2,tipo_clave) VALUES('TA28','INCIDENCIAS PARA FACTURACION','CODIGO','DESCRIPCIO','A');  
INSERT INTO TABLAS(tabla,tabla_nombre,clave1,clave2,tipo_clave) VALUES('TA29','CUENTAS DE SOFTPAD','CODIGO','DESCRIPCIO','A');  
INSERT INTO TABLAS(tabla,tabla_nombre,clave1,clave2,tipo_clave) VALUES('TA30','CODIGO DE BANCOS','CODIGO','DESCRIPCIO','A');  
INSERT INTO TABLAS(tabla,tabla_nombre,clave1,clave2,tipo_clave) VALUES('TA31','TIPOS DE PAGO','CODIGO','DESCRIPCIO','A');  
INSERT INTO TABLAS(tabla,tabla_nombre,clave1,clave2,tipo_clave) VALUES('TA32','INCIDENCIAS PARA VOUCHER','CODIGO','DESCRIPCIO','A');  
INSERT INTO TABLAS(tabla,tabla_nombre,clave1,clave2,tipo_clave) VALUES('TA33','TIPOS DE CONTRATO DEL EMPLEADO','CODIGO','DESCRIPCIO','A');  
INSERT INTO TABLAS(tabla,tabla_nombre,clave1,clave2,tipo_clave) VALUES('TA34','INCIDENCIA DEL CONTRATO DEL EMPLEADO','CODIGO','DESCRIPCIO','A');  
INSERT INTO TABLAS(tabla,tabla_nombre,clave1,clave2,tipo_clave) VALUES('TA35','TIPOS AUSENCIAS DEL EMPLEADO','CODIGO','DESCRIPCIO','A');  
INSERT INTO TABLAS(tabla,tabla_nombre,clave1,clave2,tipo_clave) VALUES('TA36','INCIDENCIAS DE TIPOS AUSENCIAS','CODIGO','DESCRIPCIO','A');  
INSERT INTO TABLAS(tabla,tabla_nombre,clave1,clave2,tipo_clave) VALUES('TA37','TIPOS DE MEMORANDUM','CODIGO','DESCRIPCIO','A');  
INSERT INTO TABLAS(tabla,tabla_nombre,clave1,clave2,tipo_clave) VALUES('TA38','ASIGNACION FAMILIAR','CODIGO','DESCRIPCIO','A');  
INSERT INTO TABLAS(tabla,tabla_nombre,clave1,clave2,tipo_clave) VALUES('TA39','TABLA DE ASIGNACION FAMILIAR','FECHA_INIC','','A');  
INSERT INTO TABLAS(tabla,tabla_nombre,clave1,clave2,tipo_clave) VALUES('TA40','TABLA DE FERIADOS','FECHA_FERIADO','','A');  
INSERT INTO TABLAS(tabla,tabla_nombre,clave1,clave2,tipo_clave) VALUES('TA41','TIPOS DE NOTA DE CREDITO ELECTRONICA','CODIGO','DESCRIPCIO','A');  
INSERT INTO TABLAS(tabla,tabla_nombre,clave1,clave2,tipo_clave) VALUES('TA42','INCIDENCIAS DE LA BOLETA DE PAGO','CODIGO','DESCRIPCIO','A');  
INSERT INTO TABLAS(tabla,tabla_nombre,clave1,clave2,tipo_clave) VALUES('TA43','TIPO DE ACTUALIZACION','CODIGO','DESCRIPCIO','A');  
INSERT INTO TABLAS(tabla,tabla_nombre,clave1,clave2,tipo_clave) VALUES('TA44','NOMBRE DE LOS MESES DEL A�O','CODIGO','DESCRIPCIO','A');  
INSERT INTO TABLAS(tabla,tabla_nombre,clave1,clave2,tipo_clave) VALUES('TA45','VERSION DE ACTUALIZACION','CODIGO','DESCRIPCIO','A');  

