CREATE TABLE BOLETA
( nro_boleta      char(6) NOT NULL,
  cod_emp         char(3) NOT NULL ,
  contrato_correl char(2) NOT NULL ,
  fech_crea       date default SYSDATETIME(),
  asig_familiar   decimal(8,2) default 0.00,
  hora_ext25      decimal(8,2) default 0.00,
  hora_ext35      decimal(8,2) default 0.00,
  tardanzas       decimal(8,2) default 0.00, 
  faltas          decimal(8,2) default 0.00, 
  otros_ingre     decimal(8,2) default 0.00, 
  sueldo_final    decimal(8,2) default 0.00, 
  gratificacion   decimal(8,2) default 0.00,
  essaludbonif    decimal(8,2) default 0.00,
  snp_afp         decimal(8,2) default 0.00,
  essaludv        decimal(8,2) default 0.00,
  quinta_cat      decimal(8,2) default 0.00,
  prestamo        decimal(8,2) default 0.00,
  tot_boleta      decimal(8,2) default 0.00,
  essalud         decimal(8,2) default 0.00,
  PRIMARY KEY(NRO_BOLETA,COD_EMP),
  CONSTRAINT FK_BOLETA_EMP FOREIGN KEY(COD_EMP,contrato_correl) REFERENCES EMPLEADO_CONTRATO(cod_emp,contrato_correl))
go

CREATE TABLE BOLETA_INCIDENCIA
(nro_boleta      char(6) NOT NULL,
 cod_emp         char(3) NOT NULL ,
 correl          integer  NOT NULL  IDENTITY ( 1,1 ) ,
 fech_incidencia datetime default SYSDATETIME(),
 cod_estado      char(1)  NULL ,
 observac        varchar(50)  NULL,
 PRIMARY KEY(NRO_BOLETA,COD_EMP,CORREL),
 CONSTRAINT FK_BOLETA_INCIDENCIA_BOLETA FOREIGN KEY(NRO_BOLETA,COD_EMP) REFERENCES BOLETA(nro_boleta,cod_emp),
 CONSTRAINT FK_BOLETA_INCIDENCIA_EMP FOREIGN KEY(COD_EMP) REFERENCES EMPLEADO(cod_emp)
 )
go


CREATE TABLE PROVEEDOR
( ruc           char(11) NOT NULL,
  nom_proveedor varchar(60) default '',
  encargado   	char(40) default '',
  telefono1 	char(7) default '',
  telefono2 	char(7) default '',
  anexo 	    char(4) default '',
  telef_movil1 	char(9) default '',
  telef_movil2 	char(9) default '',
  correo        varchar(60) default '',
  rubro         char(2) default '',
  fech_crea     datetime default SYSDATETIME(),
  primary key(ruc),	
  CONSTRAINT FK_PROVEEDOR_RUBRO FOREIGN KEY(RUBRO) REFERENCES PROVEEDOR_RUBRO(rubro),
  CONSTRAINT UQ_PROVEEDOR UNIQUE(NOM_PROVEEDOR)
 ) 
go

CREATE TABLE PROVEEDOR_RUBRO
 (
   rubro  char(2) NOT NULL,
   descripcio varchar(30),
 PRIMARY KEY (rubro)
 )

CREATE TABLE ACTUALIZACION
( Id              int  NOT NULL  IDENTITY ( 1,1 ) ,
  fech_crea       datetime default SYSDATETIME(),
  cod_emp         char(3) NOT NULL,
  tipo_act        char(1) default '',
  titulo          varchar(60) default '',
  detalle         varchar(500),
  enviado1        bit,     
  vers_act        char(1) default '1'  
  PRIMARY KEY(id),
  CONSTRAINT FK_ACTUALIZACION_EMP FOREIGN KEY(COD_EMP) REFERENCES EMPLEADO(cod_emp))
go

CREATE TABLE ACTUALIZACION_ZIP
( Id              int NOT NULL IDENTITY ( 1,1 ) ,
  ActId           int NOT NULL,
  arch_zip        char(15) default '',
  PRIMARY KEY(Id,ActId),
  CONSTRAINT FK_ACTUALIZACION_ZIP FOREIGN KEY(ActId) REFERENCES ACTUALIZACION(Id))
go

