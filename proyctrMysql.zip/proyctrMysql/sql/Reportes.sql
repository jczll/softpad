/*Agencias vigentes para Almanaques de Meche */
select cli.cod_cli,clin.contrato_correl,raz_soc_cli,cod_zona,cod_sistema,cant_est,mensualidad,fech_ini,fech_venc,
(select top 1 cod_operador from cliente_contrato_operador Clin_operador where clin_operador.cod_cli=clin.cod_cli and clin_operador.contrato_correl=clin.contrato_correl) as cod_operador 
from cliente_contrato CliN 
left join cliente Cli on cli.cod_cli=cliN.cod_cli 
where left(CliN.contrato_correl,1)<>'F' and (CONVERT (date, CliN.fech_venc))>=(CONVERT (date, GETDATE())) 
      and (CONVERT (date, CliN.fech_ini,112))<=(CONVERT (date, GETDATE())) 
	  and (Select top 1 estado from cliente_contrato_incidencia where cod_cli=CliN.cod_cli and contrato_correl=CliN.contrato_correl order by fech_incidencia desc) not in('07') 
order by cod_cli 

/* Todos los clientes con sistema SAD en Lima y Callao */
select cli.cod_cli,clin.contrato_correl,raz_soc_cli,cod_zona,cod_sistema,fech_ini,fech_venc,
(select top 1 cod_operador from cliente_contrato_operador Clin_operador where clin_operador.cod_cli=clin.cod_cli and clin_operador.contrato_correl=clin.contrato_correl) as cod_operador 
from cliente_contrato CliN 
left join cliente Cli on cli.cod_cli=cliN.cod_cli 
where (CONVERT (date, CliN.fech_venc))>=(CONVERT (date, GETDATE())) 
      and (CONVERT (date, CliN.fech_ini,112))<=(CONVERT (date, GETDATE())) 
	  and (Select top 1 estado from cliente_contrato_incidencia where cod_cli=CliN.cod_cli and contrato_correl=CliN.contrato_correl order by fech_incidencia desc) not in('07') 
      and cod_sistema in('SAD','SD1','SD2','SD3','SD4') AND cod_zona='L'
order by raz_soc_cli 

/* Claves del control por a�o */
select Emp.cod_emp,Emp.nomb_emp,Emp.ape_emp,EmpN.cod_tip_emp,right(CAST(emp.dni_emp AS numeric(18,0))*cast((2020/0.153) as int),8) as clave   
 from empleado_contrato EmpN left join empleado Emp on emp.cod_emp=empN.cod_emp 
 where empN.fech_inic<=getdate() and empN.fech_fin>=getdate() 
 order by EmpN.fech_fin desc 

 /* Clientes Vigentes a la fecha x version */
select cli.cod_cli,clin.contrato_correl,raz_soc_cli,cod_zona,cod_sistema,fech_ini,fech_venc,
(select top 1 cod_operador from cliente_contrato_operador Clin_operador where clin_operador.cod_cli=clin.cod_cli and clin_operador.contrato_correl=clin.contrato_correl) as cod_operador 
from cliente_contrato CliN 
left join cliente Cli on cli.cod_cli=cliN.cod_cli 
where (CONVERT (date, CliN.fech_venc))>=(CONVERT (date, GETDATE())) 
      and (CONVERT (date, CliN.fech_ini,112))<=(CONVERT (date, GETDATE())) 
	  and (Select top 1 estado from cliente_contrato_incidencia where cod_cli=CliN.cod_cli and contrato_correl=CliN.contrato_correl order by fech_incidencia desc) not in('07') 
	  and version_sys='03' 
order by raz_soc_cli

 /* Para cambiar de jefatura de Atencion al Cliente */
UPDATE empleado_contrato set cod_tip_emp='C' where cod_emp='JPV' and contrato_correl='21'

/* Para cREAR VACACIONES ADELANTADAS */
 SELECT * FROM AUSENCIA WHERE nro_ausencia='190111'
  update AUSENCIA set cod_emp='LMC',CONTRATO_CORREL='02' WHERE NRO_AUSENCIA='190112'


SELECT * FROM EMPLEADO_contrato where cod_emp
update empleado set fech_cese='NULL' where cod_emp='MVG'
select * from visita_incidencia where nro_visita='1801107'
insert into visita_incidencia(nro_visita,estado,cod_emp,observac) values('1801636','01','VMG','PROGRAMADA')
update visita_incidencia set observac='PROGRAMADA' where nro_visita='1801107'

select * from ausencia where nro_ausencia='180933'
update ausencia set fech_inicio='2018-07-25 09:00:00.000',fech_Termino='2018-07-25 18:00:00.000' where nro_ausencia='180933'

/* PARA BORRAR INCIDENCIA DE IMPRESION EN LA BOLETA */

select * from boleta where nro_boleta='201910'
select * from BOLETA_INCIDENCIA where nro_boleta='201910' and cod_emp='VMG'
delete from BOLETA_INCIDENCIA where nro_boleta='201910' and cod_emp='VMG'and correl=39914

select * from ausencia where nro_ausencia='190945'
update ausencia set fech_inicio='2019-10-15 09:00:00.000',fech_termino='2019-10-15 18:00:00.000' where nro_ausencia='190945'