USE bdSoftpad_ctrSELECT GETDATE() fn_GetDate, SYSDATETIME() fn_SysDateTime
SELECT * FROM syslanguages
SET LANGUAGE 'Espa�ol'
sp_configure 'default language'
SP_CONFIGURE 'default language', 5 RECONFIGURE;
select * from empleado
insert into empleado_telefono values('998376851','JCZ','TELEFONO CELULAR')
SELECT * FROM TA2

SELECT * FROM TA711 WHERE FCHTCAMBIO=GETDATE()
INSERT INTO TABLAS(tabla,tabla_nombre) VALUES('TA1','TABLA DE DISTRITOS')  
INSERT INTO TABLAS(tabla,tabla_nombre) VALUES('TA2','TABLA DE RUTAS DE TRABAJO')  
INSERT INTO TABLAS(tabla,tabla_nombre) VALUES('TA3','TABLA DE RUTAS DE TRABAJO')  

UPDATE TABLAS SET TABLA='TA8',TABLA_NOMBRE='CLAVES X OPCION DEL SISTEMA'  WHERE CORREL=9
 alter table ta8 add constraint UQQ_TA8_DESCRIPCIO UNIQUE (DESCRIPCIO)
 alter table ta8 add constraint UQQ_TA8_CLAVE UNIQUE (CLAVE)
INSERT INTO TA8 VALUES('CTRTEMP','TABLA DE EMPLEADOS','JPV')
INSERT INTO CLIENTE(COD_CLI,RAZ_SOC_CLI,cod_distrito)  VALUES('003','JUAN CARLOS CASTRO ',)
update cliente set cod_tip_opera='1' where cod_cli='003' 
delete from bdSoftpad_ctr_tablas.dbo.TA2
insert into bdSoftpad_ctr_tablas.dbo.TA2 values('L','LIMA')
insert into bdSoftpad_ctr_tablas.dbo.TA2 values('C','CALLAO')
insert into bdSoftpad_ctr_tablas.dbo.TA2 values('M','LA MARINA')

USE BDSOFTPAD_CTR

SELECT right(YEAR(FCH_INGRE_EMP),2) FROM EMPLEADO

select left(fech_crea,12) from cotizacion where (fech_crea>='2014-09-24' and fech_crea<='2014-09-24')
Select * from cotizacion_sistema
insert into requerimiento values('140001',SYSDATETIME(),'001','REPORTE DE CUENTA CORRIETE POR CLIENTE ',4)
insert into cotizacion_requerimiento values('140002','140001')
INSERT INTO COTIZACION(nro_cotizacion,tipo_cotiz,cod_emp) values('140001','R','JCZ')
SELECT * FROM COTIZACION_REQUERIMIENTO
insert into ta7 values('2014-10-10',2.65)
Select fchtcambio,getdate(),SYSDATETIME() from bdSoftpad_ctr_tablas.dbo.ta7 where fchtcambio=getdate()
SET DATEFORMAT DMY
select * from tablas where dolar_banc=0
Select * from sistema where ctzo='X'
select dolar_banc from ta7 where fchtcambio=getdate()
SELECT * FROM cotizacion_incidencia
insert into cliente_contrato(cod_cli,nro_contrato) values('003','001')
insert into requerimiento(nro_requerimiento) values('180140003')
select * from tablas
select * from contrato
insert into contrato(nro_contrato,tipo_contrato) values('14002','C')
Select top 1 * from contrato where cod_cli='001' and tipo_contrato='C' order by fech_venc desc
USE BDSOFTPAD_CTR_tablas
alter table empresa alter column vnro_visita char(7) 

SELECT top 1 cod_cli,contrato_correl,fech_venc 
FROM cliente_contrato 
where cod_cli='004' and fech_venc>=SYSDATETIME() 
order by fech_Venc desc
select * from LLAMADA_INCIDENCIA
delete from llamada_incidencia where observac=''

select cli.cod_cli,version_sys,raz_soc_cli
from cliente cli 
left join cliente_contrato clic on clic.cod_cli=cli.cod_cli 
where left(cod_sistema,1)='S' and version_sys='02'
group by cli.cod_cli,version_sys,raz_soc_cli

Select * from visita where cod_cli='585' and contrato_correl='100' and tipo_visita='CAP' and cod_sistema='SAD' 

Select count(tipo_visita) as cant_visita from visita where cod_cli='585' and contrato_correl='100' and tipo_visita='CAP' and cod_sistema='SAD' 
group by tipo_visita
select * from visita where tipo_visita='CAP' AND cod_clie
select * from requerimiento where nro_requerimiento='123150008'
update requerimiento set titulo_req='MODIFICACIONES DEL ANEXO 2'  where nro_requerimiento='123150008'

update cliente_contrato set tipo_servicio='N'
alter table cliente_contrato add constraint DFF_CLIENTE_CONTRATO_TIPO_SERVICIO DEFAULT 'N' FOR tipo_servicio
select * from cliente_usuario where cod_cli='009' nomb_usuario='MOISES CASTAGNETTO GUTIERREZ'

(select top 1 concat(cod_sistema,cod_operador,fech_venc) from cliente_contrato CliN 

select a.cod_cli,raz_soc_cli,ruc,vigente,
(select top 1 concat(clin.contrato_correl,cod_sistema,cod_operador) from cliente_contrato CliN left join cliente_contrato_operador CliN_ope on CliN_ope.cod_cli=CliN.cod_cli and CliN_ope.contrato_correl=CliN.contrato_correl where CliN.cod_cli=a.cod_cli order by fech_venc desc) as 'sistema_operador',
(Select top 1 dir_correo from cliente_correo b where b.cod_cli=a.cod_cli) as 'cliente_correo',
(Select top 1 telefono from cliente_telefono c where c.cod_cli=a.cod_cli) as 'cliente_telefono' 
from cliente a 

select top 1 Clin.cod_cli,clin.contrato_correl,cod_sistema,cod_operador,fech_venc,estado,fech_incidencia 
from cliente_contrato CliN 
left join cliente_contrato_operador CliN_ope on CliN_ope.cod_cli=CliN.cod_cli and CliN_ope.contrato_correl=CliN.contrato_correl 
left join cliente_contrato_incidencia CliN_inc on CliN_inc.cod_cli=CliN.cod_cli and CliN_inc.contrato_correl=CliN.contrato_correl 
where CliN.cod_cli='004' order by fech_venc,fech_incidencia desc 
select * from ta28

select fech_venc,estado 
from cliente_contrato CliN 
left join cliente_contrato_incidencia CliN_inc on CliN_inc.cod_cli=CliN.cod_cli and CliN_inc.contrato_correl=CliN.contrato_correl 
where CliN.cod_cli='004' and CliN.contrato_correl='110' order by fech_venc desc 
select * from cliente_contrato_incidencia


select * from visita where cod_cli='307' and contrato_correl='104'
update visita set cod_cli='316',contrato_correl='202' from visita where nro_visita='0005701'
select * from visita where cod_cli=null and contrato_correl=null
select * from ta28
select * from visita where cod_cli='313' and contrato_correl='104'
select * from documento
select * from tablas

update visita set contrato_correl='204' where cod_cli='375' and contrato_correl='106'
delete from cliente_contrato where cod_cli='182' and contrato_correl='110'
SELECT * FROM LLAMADA where cod_usuario is not null
DELETE FROM CLIENTE_USUARIO
update llamada set cod_usuario=null where  cod_cli='143'

select * from llamada_incidencia where nro_ticket='1501997'
delete from llamada_incidencia where nro_ticket='1501997' and correl=8590
delete from cliente_contrato where cod_cli='464' and contrato_correl='103'
select * from visita where cod_cli='464' and contrato_correl='102'
update visita set contrato_correl='102' where cod_cli='464' and contrato_correl='103' 
select * from documento_detalle where cod_cli='180'
select * from ta14
select nro_voucher,fech_crea from voucher where year(fech_crea)='2015' and month(fech_crea)='09' and day(fech_crea)='09'

update cliente set cod_cli='445' where c_cli='602'
update cliente_telefono set cod_cli='445' where cod_cli='601' and correl=11082
select * from cliente_telefono where cod_cli='601'


Select nro_documento,tipo_doc,sum(saldo) as saldo 
from (
select nro_documento,tipo_doc,stot_docum as saldo 
from documento doc 
where tipo_doc='01' and nro_documento='0010000517'
and (Select top 1 estado from documento_incidencia where tipo_doc=doc.tipo_doc and nro_documento=doc.nro_documento order by fech_incidencia desc) in('04','05','06','08') 
union all 
select docd.nro_factura as nro_documento,'01' as tipo_doc,(stot_docum*-1) as saldo 
from documento doc 
left join documento_detalle docd on docd.tipo_doc=doc.tipo_doc and docd.nro_documento=doc.nro_documento 
where doc.tipo_doc='07' and docd.nro_factura='0010000517' 
and (Select top 1 estado from documento_incidencia where tipo_doc=doc.tipo_doc and nro_documento=doc.nro_documento order by fech_incidencia desc) in('04','05','06','08') 
union all 
Select voud.nro_documento,voud.tipo_doc,(voud.simporte*-1) as saldo 
from voucher_detalle voud 
left join voucher vou on vou.tipo_voucher=voud.tipo_voucher and vou.nro_voucher=voud.nro_voucher 
where voud.tipo_doc='01' and voud.nro_documento='0010000517'
and (Select top 1 estado from documento_incidencia where tipo_doc=voud.tipo_doc and nro_documento=voud.nro_documento order by fech_incidencia desc) in('04','05','06','08') 
     )  as A group by nro_documento,tipo_doc


Select distinct doc.tipo_doc,doc.nro_documento,doc.moneda,doc.dtot_docum,doc.stot_docum,docd.tipo_concepto,Clin.cod_sistema,docd.nro_factura,
(Select descripcio from bdsoftpad_ctr_tablas.dbo.ta26 where codigo=doc.tipo_doc) as des_doc,
(Select nombre_ch from cliente where cod_cli=doc.cod_cli) as nombre_ch,
(Select sum(simporte) from voucher_detalle where tipo_doc=doc.tipo_doc and nro_documento=doc.nro_documento group by tipo_doc,nro_documento) tot_voucher, 
(Select sum(simporte) from documento_detalle where tipo_doc='07' and nro_factura=doc.nro_documento group by tipo_doc,nro_factura) tot_credito, 
(Select top 1 concat(estado,observac) from documento_incidencia where tipo_doc=doc.tipo_doc and nro_documento=doc.nro_documento order by fech_incidencia desc) as datos_incidencia 
from documento doc 
left join documento_detalle docd on docd.tipo_doc=doc.tipo_doc and docd.nro_documento=doc.nro_documento 
left join cliente_contrato cliN on CliN.cod_cli=docd.cod_cli and cliN.contrato_correl=docd.contrato_correl 

select vis.nro_visita,vis.fech_crea,vis.cod_sistema,cli.nombre_ch,cli.cod_ruta,  
(Select top 1 fech_visita from visita_incidencia where nro_visita=vis.nro_visita order by fech_incidencia desc) as fech_visita, 
(Select top 1 concat(estado,cod_emp,observac) from visita_incidencia where nro_visita=vis.nro_visita order by fech_incidencia desc) as datos_incidencia,
(Select des_ruta from bdsoftpad_ctr_tablas.dbo.ta2 where cod_ruta=cli.cod_ruta) as des_ruta  
from visita vis 
left join cliente cli on cli.cod_cli=vis.cod_cli 
where vis.tipo_visita='MNT' and left(vis.nro_visita,4)='1510'

Select distinct cli.cod_cli,cli.raz_soc_cli,cli.ruc,clin.fech_ini,clin.fech_venc 
from cliente cli 
left join cliente_contrato CliN on CliN.cod_cli=Cli.cod_cli 
where CliN.fech_ini<=SYSDATETIME() and CliN.fech_venc>=SYSDATETIME() 
and (Select top 1 estado from cliente_contrato_incidencia where cod_cli=CliN.cod_cli and contrato_correl=CliN.contrato_correl order by fech_incidencia desc) not in('07')

select * from empleado where right(CAST(dni_emp AS numeric(18,0))*cast((2015/0.153) as int),8)='92586597'
select cod_emp,cod_tip_emp,right(CAST(dni_emp AS numeric(18,0))*cast((2015/0.153) as int),8) from empleado  where cod_emp='JCZ'

select distinct cli.cod_cli,raz_soc_cli,cod_sistema,fech_venc,cod_zona 
from cliente  cli 
left join cliente_contrato clin on clin.cod_cli=cli.cod_cli 
where version_sys='01' and cod_sistema='SAD' and cod_zona='L' and clin.fech_venc>getdate() 

select * from CLIENTE_CONTRATO_SERVIDOR where cod_cli='605' order by fech_activa
select * from ta11
update CLIENTE_CONTRATO_SERVIDOR set servidor='1688552944                    ' where cod_cli='605'

select *,
(Select top 1 cod_emp from visita_incidencia where nro_visita=vis.nro_visita order by fech_incidencia desc) as programado,
(Select top 1 fech_visita from visita_incidencia where nro_visita=vis.nro_visita order by fech_incidencia desc) as fech_visita 
from visita vis where month(fech_visita)='12' and year(fech_visita)='2015'
select * from ta20


Select cod_emp,contrato_correl,fech_crea,tipo_contrato,cod_tip_emp,fech_inic,fech_fin,sueldo_final,
(Select top 1 estado from empleado_contrato_incidencia where cod_emp=EmpN.cod_emp and contrato_correl=EmpN.contrato_correl order by fech_incidencia desc) as estado,
(Select concat(rtrim(nomb_emp),' ',rtrim(ape_emp)) from empleado where cod_emp=EmpN.cod_emp) as nombre_empleado 
from empleado_contrato EmpN 

Select nro_ausencia,fech_crea,fech_inicio,fech_termino,observac,
(Select descripcio from bdsoftpad_ctr_tablas.dbo.ta35 where codigo=aus.cod_ausencia) as des_ausencia,
(Select concat(nomb_emp,' ',ape_emp) from empleado where cod_emp=aus.cod_emp) as des_empleado,
(Select top 1 concat(cod_estado,observac) from ausencia_incidencia where nro_ausencia=aus.nro_ausencia order by fech_incidencia desc) as datos_incidencia 
from ausencia aus 
SELECT * FROM TA36
insert into empleado_contrato(cod_emp,contrato_correl) values('MCS','01')
Select * from empleado_contrato
insert into empleado_contrato_incidencia(cod_emp,contrato_correl,estado) values('MCS','01','1')

 select top 1 nomb_emp,ape_emp,empN.cod_tip_emp from empleado_contrato EmpN 
 left join empleado Emp on emp.cod_emp=empN.cod_emp 
 where empn.cod_emp='OMG' order by fech_fin desc 
 select * from empleado_contrato where cod_emp='IAA'
 update empleado_contrato set tipo_contrato='P' where cod_emp='IAA'
 SELECT * FROM ausencia_incidencia WHERE COD_EMP='CIV'
 Select top 1 contrato_correl from empleado_contrato where cod_emp='MRD' order by fech_FIN desc
 
 select * from visita_incidencia where nro_visita='1601575'
 update visita_incidencia set estado='04' where nro_visita='1601575' and correl=20242
 select * from ausencia
 SELECT * FROM CLIENTE_CONTRATO WHERE COD_EMP='OMG'
 Select * from empleado_contrato where cod_emp='OMG'
 update empleado_contrato set FECH_inicio=fech_crea 
 select nro_ausencia,cod_emp from ausencia_incidencia where cod_emp='CPS' and year(fech_incidencia)='2016' group by nro_ausencia,cod_emp
 select * from ta35
 alter table ausencia add constraint DFF_AUSENCIA_SUBCODIGO DEFAULT '' FOR subcodigo;

 Select top 1 tipo_contrato from empleado_contrato where cod_emp='MRD' order by fech_inic desc
 update empleado_contrato set cod_tip_emp='C' where cod_emp='MTM' and contrato_correl='10'
 select * from empleado_contrato where cod_emp='MTM'
 update ausencia set cod_emp='JCZ' where nro_ausencia='160915'
 select * from ausencia where 
 Select top 1 contrato_correl from empleado_contrato where cod_emp='GMC' order by fech_fin desc
 update ausencia set cod_emp=(select top 1 cod_emp from ausencia_incidencia where nro_ausencia=ausencia.nro_ausencia order by fech_incidencia desc) where COD_EMP='JCZ'
 update ausencia set contrato_correl=(select top 1 contrato_correl from empleado_contrato where cod_emp=ausencia.cod_emp order by contrato_correl desc) where nro_ausencia='160018'
 
select distinct cod_operador,cli.cod_cli,raz_soc_cli,cod_sistema,fech_venc,cod_zona 
from cliente  cli 
left join cliente_contrato clin on clin.cod_cli=cli.cod_cli 
left join cliente_contrato_operador clin_operador on clin_operador.cod_cli=cli.cod_cli 
where clin.cod_sistema in('SAD','SD1','SD2','SD3','SD4') and clin.fech_venc>getdate() order by 1

Select top 1 cod_emp,contrato_correl,fech_fin,datediff(month,fech_inic,fech_fin) as 'Diferencia' 
from empleado_contrato 
where cod_emp='CIV' and fech_fin<getdate() and datediff(month,fech_inic,fech_fin)>=12 and tipo_contrato in('P','R') 
order by fech_fin desc 

select * from empleado_contrato EmpN
where EmpN.fech_inic<getdate() and EmpN.fech_fin>=getdate() and 
(Select top 1 estado from empleado_contrato_incidencia where cod_emp=empN.cod_emp and contrato_correl=empN.contrato_correl order by fech_incidencia desc) not in('7') 


select * from empleado_contrato

select cod_cli,raz_soc_cli from cliente 
where 
not exists (select * from cliente_telefono where cod_cli=cliente.cod_cli) and 
exists (select * from cliente_contrato where cod_cli=cliente.cod_cli and fech_venc>getdate())

Alter table EMPLEADO_CONTRATO 
add constraint DFF_EMPLEADO_CONTRATO_fasig_familiar DEFAULT 'N' FOR fasig_familiar
Select * from bdsoftpad_ctr_tablas.dbo.ta39 where CONVERT (char(10), fecha_inic, 112)>='20160101' and CONVERT (char(10), fecha_inic, 112)<='20161231'
update empleado_contrato set asig_familiar=0.00 where cod_emp='CIV' and contrato_correl='18'
select * from ta8
SELECT * FROM AUSENCIA WHERE COD_AUSENCIA='05'
UPDATE Adelanto SET CONTRATO_CORREL='14' WHERE NRO_adelanto='160001'
select * from adelanto

select top 1 fech_adelanto from adelanto where cod_emp='CIV' and datediff(day,fech_adelanto,getdate())<40 order by


select * from ta17
select * from voucher where nro_voucher='1622090125'
select * from voucher where nro_voucher='1622010099'
insert into voucher_incidencia(tipo_voucher,nro_voucher,fech_incidencia,estado,observac,cod_emp) 
     values('01','1622010099','2016-01-15 10:41:10.977','01','PENDIENTE','MCS')
update voucher set fech_crea='2016-09-19 00:00:00.000' where nro_voucher='1622090125'

select * from visita where cod_cli='029' and contrato_correl='204'
update visita set contrato_correl='203' where cod_cli='029' and contrato_correl='204'
select cod_cli,contrato_correl,period_contrato,datediff(day,fech_ini,fech_venc) as dias,fech_ini,fech_venc from cliente_contrato where period_contrato in('S','A') order by 3,4

select * from cliente_CONTRATO_servidor
delete from cliente_CONTRATO_servidor where cod_cli='643'



CREATE TABLE [HORARIO_INCIDENCIA]
( 
	[COD_HORARIO]        char(8)  NOT NULL ,
	[cod_emp]            char(3)  NOT NULL ,
	[correl]             integer  NOT NULL  IDENTITY ( 1,1 ) ,
	[fech_incidencia]    datetime  NULL ,
	[cod_estado]         char(1)  NULL ,
	[observac]           varchar(50)  NULL 
)
go

ALTER TABLE [HORARIO_INCIDENCIA]
	ADD CONSTRAINT [XPKHORARIO_INCIDENCIA] PRIMARY KEY  CLUSTERED ([COD_HORARIO] ASC,[cod_emp] ASC,[correl] ASC)
go


ALTER TABLE [HORARIO]
	ADD CONSTRAINT [R_111888] FOREIGN KEY ([cod_emp],[contrato_correl]) REFERENCES [EMPLEADO_CONTRATO]([cod_emp],[contrato_correl])
		ON DELETE NO ACTION
		ON UPDATE NO ACTION
go

ALTER TABLE [HORARIO_INCIDENCIA]
	ADD CONSTRAINT [R_112888] FOREIGN KEY ([COD_HORARIO],[cod_emp]) REFERENCES [HORARIO]([COD_HORARIO],[cod_emp])
		ON DELETE NO ACTION
		ON UPDATE NO ACTION
go

select * from horario
update horario set fech_salida='2016-11-03 18:00:27.470'
select * from ta8

Select Emp.cod_emp,Emp.nomb_emp,Emp.ape_emp,EmpN.cod_tip_emp,right(CAST(emp.dni_emp AS numeric(18,0))*cast((2017/0.153) as int),8)  
 from empleado_contrato EmpN left join empleado Emp on emp.cod_emp=empN.cod_emp 
 where empN.fech_inic<=getdate() and empN.fech_fin>=getdate() 
 order by EmpN.fech_fin desc 

 delete from horario where cod_emp='JCZ'
 select hour(getdate())
 select concat(datepart(hh,getdate()),':',datepart(n,getdate()),':',datepart(ss,getdate())) as 'Horaxxxx '
insert into horario(cod_horario,cod_emp,contrato_correl,fech_crea,entrada) values('20161110','JCZ','03',getdate(),'09:26')

concat(datepart(hh,getdate()),':',datepart(n,getdate()))),
select cod_ausencia from ausencia where cod_emp='JBA' and fech_inicio<getdate() and fech_termino>getdate()

select * from TA20
insert into horario(cod_horario,cod_emp,contrato_correl) values('20161121','JBA','20')
select * from empleado_contrato where cod_emp='JBA'

select * from horario where cod_emp='JBA'
select * from ausencia where cod_emp='JBA' ORDER BY FECH_INICIO
SELECT fech_crea,getdate() FROM ausencia 
Select * from documento where tipo_doc='01' and nro_documento='0010038082'
update documento set fech_crea='2016-12-01 12:49:17.923' where tipo_doc='01' and nro_documento='0010038083'
select * from documento_detalle
select * from ta35
select * from ausencia where cod_emp='JBA' AND COD_AUSENCIA='03'
update ausencia set cod_ausencia='06' where cod_emp='JBA' AND COD_AUSENCIA='03' and nro_ausencia='160070'
select * from horario where cod_emp='JCZ' and left(cod_horario,6)='201612'
update horario set entrada='0845' where cod_horario='20161220'
select cod_emp,contrato_correl,sueldo_base from empleado_contrato
where CONVERT (char(10), EmpN.fech_inic, 112)<='"+dtos(date())+"' and CONVERT (char(10), EmpN.fech_fin, 112)>='"+dtos(date())+"' 


select Emp.cod_emp,Emp.nomb_emp,Emp.ape_emp,EmpN.cod_tip_emp,right(CAST(emp.dni_emp AS numeric(18,0))*cast((2017/0.153) as int),8) as clave   
 from empleado_contrato EmpN left join empleado Emp on emp.cod_emp=empN.cod_emp 
 where empN.fech_inic<=getdate() and empN.fech_fin>=getdate() 
 order by EmpN.fech_fin desc 

 select * from empleado_contrato 
 select * from ta7
 delete from ta7 where year(fchtcambio)='2017'
 select tipo_doc,nro_documento,concepto_ele from documento_detalle where concepto_ele<>'' order by 3
 update documento_detalle set concepto_ele='MANT. DEL MES DE ENERO 2017 SAD CTE  Y BCO                                                                                                           ' 
 where concepto_ele='MANT. DEL MES DE ENERO 2017 SAD, CTE  Y BCO    '
 select nro_documento,concepto_ele from documento_detalle where nro_documento='0010038300' order by nro_documento
 select * from ta8
 update ta8 set usuario_l=usuario_m
 alter table documento add constraint DFF_DOCUMENTO_NRO_DOC_ASOC DEFAULT '' FOR nro_doc_asoc
 select * from documento_detalle 
 select * from horario where LEFT(cod_horario,6)='201703' and cod_emp='JPV'

select cli.cod_cli,clin.contrato_correl,raz_soc_cli,cod_zona,cod_sistema,fech_ini,fech_venc,
(select top 1 cod_operador from cliente_contrato_operador Clin_operador where clin_operador.cod_cli=clin.cod_cli and clin_operador.contrato_correl=clin.contrato_correl) as cod_operador 
from cliente_contrato CliN 
left join cliente Cli on cli.cod_cli=cliN.cod_cli 
where (CONVERT (date, CliN.fech_venc))>=(CONVERT (date, GETDATE())) 
      and (CONVERT (date, CliN.fech_ini,112))<=(CONVERT (date, GETDATE())) 
	  and (Select top 1 estado from cliente_contrato_incidencia where cod_cli=CliN.cod_cli and contrato_correl=CliN.contrato_correl order by fech_incidencia desc) not in('07') 
order by raz_soc_cli

Select bol.nro_boleta,bol.cod_emp,bol.hora_ext25,bol.hora_ext35,bol.tardanzas,bol.faltas,bol.snp,bol.essaludv,bol.quinta_cat,bol.tot_boleta,
(Select concat(rtrim(ape_emp),',',nomb_emp) from empleado where cod_emp=bol.cod_emp) as desc_empleado,
(Select top 1 cod_estado from boleta_incidencia where nro_boleta=bol.nro_boleta order by fech_incidencia desc) as cod_estado,
EmpN.sueldo_base,empN.fech_fin,empN.sueldo_final 
from boleta bol 
left join empleado_contrato EmpN on empn.cod_emp=bol.cod_emp and EmpN.contrato_correl=Bol.contrato_correl 


select * from requerimiento where nro_requerimiento='599170013'
update requerimiento set titulo_req='CONTROL DE ORDENES' where nro_requerimiento='599170013'
select * from boleta
update boleta set sueldo_final=1615+asig_familiar+hora_ext25+hora_ext35-(tardanzas+faltas)

select * from bdSoftpad_ctr_tablas.dbo.ta9
select * from boleta
update empleado set essaludv='N'
select year(fech_crea),month(fech_crea) from boleta 
select * from boleta where nro_boleta='201704' order by cod_emp

SELECT CONCEPTO_ELE FROM DOCUMENTO_DETALLE WHERE TIPO_DOC='01' AND NRO_DOCUMENTO='0010001115'
UPDATE DOCUMENTO_DETALLE SET CONCEPTO_ELE='POR LA INSTALACION DEL SISTEMA PARA AGENCIAS DE ADUANA (SAD) PARA 7 PUNTOS (418 LICENCIAS)' 
WHERE TIPO_DOC='01' AND NRO_DOCUMENTO='0010001115'

select cod_emp,contrato_correl 
from empleado_contrato 
where cod_emp='JCL'and concat(year(fech_inic),dbo.nuevo_codigo2(month(fech_inic)))<='201707' and concat(year(fech_fin),dbo.nuevo_codigo2(month(fech_fin)))>='201707' 

select cod_emp,sueldo_base,asig_familiar,fech_inic,fech_fin 
from empleado_contrato 
where cod_emp='MRD' 
and CONVERT (char(10), fech_inic, 112)<='20170601' and CONVERT (char(10), fech_fin, 112)>='20170601'
select count(*) as cant_visitas from visita_incidencia where cod_emp='VMG' and CONVERT (char(10), fech_visita, 112)='20170717'

select nro_visita,fech_visita
from visita_incidencia 
where cod_emp='VMG' and CONVERT (char(10), fech_visita, 112)='20170718'
group by nro_visita,CONVERT (char(10), fech_visita, 112)

select * from documento_detalle where tipo_doc='01' and nro_documento='0010001339'
update documento_detalle set contrato_correl='105',
tit_concepto='MANTENIMIENTO DEL MES DE JULIO DEL A�O 2017                       ',
mes_serv='07',
concepto_ele='MANT. DEL MES DE JULIO 2017 SISTEMA PARA AGENCIAS DE ADUANA (SAD)                                                                                 '  
where tipo_doc='01' and nro_documento='0010001339'
select * from empleado_contrato where cod_emp='OMG'
update empleado_contrato set fech_fin='2017-09-30 06:00:00.000' where cod_emp='OMG' and contrato_correl='17'
select * from adelanto where nro_adelanto='170009'
update adelanto set fech_crea='2017-07-16 17:11:53.227',fech_adelanto='2017-07-16 17:11:53.227' where nro_adelanto='170009'
select * from empleado_contrato where cod_emp='OMG'
update empleado_contrato set fech_fin='2017-07-31 18:00:00.000' where cod_emp='OMG' and contrato_correl='17'
select * from boleta where nro_boleta='201708'
delete from boletA where nro_boleta='201708' and cod_emp='OMG'
select * from ausencia where nro_ausencia='170927'
update ausencia set fech_inicio='2017-09-22 09:00:00.000', fech_termino='2017-09-22 18:00:00.000' where nro_ausencia='170927'
select * from voucher_detalle where nro_voucher='1722030197'
select * from empleado_contrato where cod_emp='JCZ' and fech_inic<='2017-12-31 09:00:00' and fech_fin>='2017-12-31 18:00:00'
select * from boleta where nro_boleta='201709' and cod_emp='MDD'
select * from documento where tipo_doc='07' and nro_documento='0010000014'
select * from documento_detalle where tipo_doc='07'
select * from ta9
select * from empleado where cod_emp=
update empleado set fech_cese=NULL where cod_emp in('MVG','MDD','JCL')
select * from documento_detalle where tipo_doc='01' and nro_documento='0010002043'
update documento_detalle set cod_cli='702' where tipo_doc='01' and nro_documento='0010002043'
select * from llamada_incidencia where nro_ticket='1709908'
delete from llamada_incidencia where nro_ticket='1709908' and estado='08'
select * from documento_detalle where tipo_doc='01' and nro_documento='0010002274'
update documento_detalle set concepto_ele='MANT.POR TRES A�OS DEL SISTEMA PARA LINEAS AEREAS (DMA)                                                                                                           ' 
where tipo_doc='01' and nro_documento='0010002274'
select * from documento
UPDATE empleado_contrato set cod_tip_emp='C' where cod_emp='JPV' and contrato_correl='19'
select * from cliente_contrato where cod_cli='644' and contrato_correl='200'
update cliente_contrato set fech_venc='2020-10-11 00:00:00.000' where cod_cli='644' and contrato_correl='200'
up sistema_tarifa set tarifa_2018=tarifa_2017
select * from sistema_tarifa
select * from cliente_contrato where cod_cli='705' and contrato_correl='100'
update cliente_contrato set fech_venc='2018-04-09 00:00:00.000' where cod_cli='705' and contrato_correl='100'
select * from documento_detalle where nro_documento='0010002375'
update documento_detalle set tit_concepto='MANTENIMIENTO TRIMESTRAL' WHERE nro_documento='0010002375'
select * from voucher_detalle
alter table documento alter column nro_documento char(12) null
insert into documento(tipo_doc,nro_documento,fech_crea,fech_venc,cod_cli,moneda) 
            select tipo_doc,nro_documento,fech_crea,fech_venc,cod_cli,moneda from bdbackup_ctr_nro_documento.dbo.documento

select * from documento_detalle
delete from documento
insert into documento(tipo_doc,nro_documento) values('01','FAC100000001')
SELECT * FROM DOCUMENTO

select * from empresa
update empresa set vnumfact='F00100002504',vnumabono='FNC100001265'

select * from voucher_detalle where nro_documento='000100038438'

select * from documento where tipo_doc='01' order by nro_documento desc 

update bdbackup_ctr_nro_documento.dbo.documento set nro_documento=concat('F',substring(nro_documento,2,3),substring(nro_documento,5,8)) where tipo_doc='01' and nro_documento<'00010002600'
update bdbackup_ctr_nro_documento.dbo.documento set nro_documento=concat('FNC1',substring(nro_documento,5,8)) where tipo_doc='07' and substring(nro_documento,5,8)<'00000030'

select * from documento where tipo_doc='07' and substring(nro_documento,5,8)<'00000030'

delete from boleta_incidencia where nro_boleta='201801' and cod_emp='IAA' and correl='16175'

select * from horario where cod_emp='LQC' AND COD_HORARIO='201801'
DELETE FROM BOLETA WHERE cod_emp='LQC' AND NRO_BOLETA='201801'
select * from documento
alter table documento alter column nro_doc_asoc char(12) null
select concat('F',substring(nro_doc_asoc,1,3),'0',substring(nro_doc_asoc,4,8)),nro_doc_asoc from documento where nro_doc_asoc<>'' and nro_doc_asoc is not null 
update documento set nro_doc_asoc=concat('F',substring(nro_doc_asoc,1,3),'0',substring(nro_doc_asoc,4,8)) where nro_doc_asoc<>'' and nro_doc_asoc is not null 

select * from documento_incidencia where nro_documento='F00100002720' and rtrim(observac) in('A CUENTA CON N/C','CANCELADO CON N/C')
update documento set nro_doc_asoc='F00100002720' where tipo_doc='07' and nro_documento='FNC100000030'
select * from boleta where cod_emp='MDD' and nro_boleta='201809'
select * from boleta_incidencia where cod_emp='MAV' and nro_boleta='201803'
delete from boleta_incidencia where cod_emp='MAV' and nro_boleta='201803' and correl='26448'

update boleta set afp_aporte=0.00, afp_comision=0.00,afp_prima=0.00 where afp_aporte is null  
select * from boleta 
select * from requerimiento where nro_requerimiento='052181009'
update requerimiento set titulo_req='CONSISTENCIA DE VALORES X CLIENTE Y FECHA ' where nro_requerimiento='052181009'

select * from cliente 
select * from cotizacion where nro_cotizacion='180157'
update cotizacion set tipo_cotiz='F' where nro_cotizacion='180157'
select * from ausencia where nro_ausencia='180935'
update ausencia set fech_inicio='2018-08-17 09:00:00.000' where nro_ausencia='180935'
update ausencia set fech_termino='2018-08-17 18:00:00.000' where nro_ausencia='180935'
select * from empleado_contrato where cod_emp='MAV' and contrato_correl='18'
update empleado_contrato set cod_tip_emp='D' where cod_emp='MAV' and contrato_correl='18'

select * from empleado_contrato where cod_emp='VMG' and contrato_correl='08'
update empleado_contrato set fech_inic='2017-09-01 09:00:00.000', fech_fin='2018-08-31 18:00:00.000' where cod_emp='VMG' and contrato_correl='08'
select * from ta27
insert into ta27 VALUES('CNF','FACT.ELEC')
select * from cliente_contrato where cod_cli='180' and contrato_correl='100'
update cliente_contrato set fech_venc='2025-08-30 18:00:00.000' where cod_cli='180' and contrato_correl='100'

delete from boleta_incidencia where cod_emp='MDD' and nro_boleta='201809' and correl='26448'
delete from boleta where cod_emp='MDD' and nro_boleta='201809' and correl='26448'
select * from ta8
insert into ta8 values('CTRTPRV','TABLA DE PROVEEDORES','S','N','N','S','N','S','S','N','N','N')

select ruc,nom_proveedor,encargado,telefono1,telefono2,telef_movil1,correo,rubro,fech_crea 
        from proveedor 

Select doc.tipo_doc,doc.nro_documento,doc.fech_crea,mes_serv,a�o_serv 
       from documento_detalle docd 
            left join documento doc on doc.tipo_doc=docd.tipo_doc and doc.nro_documento=docd.nro_documento 
       where docd.cod_cli='054' and docd.contrato_correl='300'
             and 
			 (Select top 1 estado from documento_incidencia where tipo_doc=docd.tipo_doc and nro_documento=docd.nro_documento order by fech_incidencia desc) not in('07','00')
             and not exists
			 (select nro_doc_asoc from documento docN left join documento_detalle docND on docN.tipo_doc=docNd.tipo_doc and docN.nro_documento=docNd.nro_documento 
               where docN.tipo_doc='07' and docN.nro_doc_asoc=docd.nro_documento and docNd.mes_serv='01')

select * from voucher where nro_voucher='1822100150'
update voucher set fech_crea='2018-12-12 00:00:00.000' where nro_voucher='1822120076'

select * from ausencia where nro_ausencia='190904'
update ausencia set fech_termino='2019-02-06 18:00:00.000' where nro_ausencia='190904'

select * from tablas
select * from ta9
update ta9 set comision2=0.67 where codigo='PRO'

select * from indices
insert into indices values('ACT_ZIP','ACTUALIZACION','ACTUALIZACION_ZIP','NRO_ACT+STR(CORREL,4)','','A','S')

select * from ta8
insert into ta8 values('CTRACT','REGISTRO DE ACTUALIZACIONES','N','N','N','S','N','N','S','N','N','N')


Select distinct Emp.cod_emp,Emp.nomb_emp,Emp.ape_emp,EmpN.cod_tip_emp,EmpN.fech_inic,EmpN.fech_fin,CONVERT (char(6), EmpN.fech_inic, 112)
from empleado emp 
left join empleado_contrato EmpN on EmpN.cod_emp=Emp.cod_emp 
where CONVERT (char(6), EmpN.fech_inic, 112)<='201903' and CONVERT (char(6), EmpN.fech_fin, 112)>='201903' 
order by 2
select * from boleta where cod_emp='TPA'
select * from ta43
insert into ta43 VALUES('6','ACTUALIZACION DEL SISTEMA')
 
UPDATE TA43 SET DESCRIPCIO='DERECHO ESPECIFICO' WHERE CODIGO='4'
