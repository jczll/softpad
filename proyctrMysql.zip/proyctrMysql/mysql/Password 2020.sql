select Emp.cod_emp,Emp.nomb_emp,Emp.ape_emp,EmpN.cod_tip_emp,EmpN.contrato_correl,right(cast(emp.dni_emp AS signed)*cast((2020/0.153) as signed),8) 
    from empleado_contrato EmpN left join empleado Emp on emp.cod_emp=empN.cod_emp 
    where (empN.fech_inic<=curdate() and empN.fech_fin>=curdate()) 
    order by EmpN.fech_fin desc 
