/*  TABLAS PARA EL CONTROL WEB */                 
/* TA43(TIPO DE ACTUALIZACION)*/                 
CREATE TABLE IF NOT EXISTS TA43(                                               
   CODIGO      CHAR(1) NOT NULL,                                               
   DESCRIPCIO  VARCHAR(30) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA43_1 ON TA43(CODIGO);                                          
CREATE INDEX TA43_2 ON TA43(DESCRIPCIO);                                            


/* TA44( NOMBRE DE LOS MESES DEL A�O )*/                 
CREATE TABLE IF NOT EXISTS TA44(                                               
   ID   INT NOT NULL,                                               
   MES  VARCHAR(30) DEFAULT "",                                          
   PRIMARY KEY(ID));                                                        
CREATE INDEX TA44_1 ON TA44(ID);                                          
CREATE INDEX TA44_2 ON TA44(MES);                                            

/* TA45(VERSION DE ACTUALIZACION)*/                 
CREATE TABLE IF NOT EXISTS TA45(                                               
   CODIGO      CHAR(1) NOT NULL,                                               
   DESCRIPCIO  VARCHAR(30) DEFAULT "",                                          
   PRIMARY KEY(CODIGO));                                                        
CREATE INDEX TA45_1 ON TA45(CODIGO);                                          
CREATE INDEX TA45_2 ON TA45(DESCRIPCIO);                                            


