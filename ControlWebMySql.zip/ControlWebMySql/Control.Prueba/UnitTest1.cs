﻿using System;
using System.Configuration;
using System.Linq;
using Control.AccesoDatos;
using Control.Entidades;
using Control.Interfaz;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Control.Prueba
{
    [TestClass]
    public class UnitTest1
    {
        private readonly IUnidadDeTrabajo unidadDeTrabajo;

        public UnitTest1()
        {
            unidadDeTrabajo = new UnidadDeTrabajo(ConfigurationManager.ConnectionStrings["ControlConexion"].ConnectionString);
        }

        [TestMethod]
        public void ObtenerTodoTest()
        {
            //Preparacion y Configuracion
            //var data = unidadDeTrabajo.actualizacion.GetList();
            var data = unidadDeTrabajo.actualizacion.GetList();
            //Ejecucion : Obtener Data
            //Comprobacion
            Assert.AreEqual(true, data.Count > 0);
        }
        [TestMethod]
        public void InsertarTest()
        {
            var actualizacion = new Actualizacion()
            {
                fech_crea = DateTime.Now,
                cod_usuario = "MTM",
                tipo_act = "2",
                titulo = "ACTUALIZACION DE FACTOR DE CONVERSION"
            };
            var NuevoId = unidadDeTrabajo.actualizacion.Insert(actualizacion);
            //Obtener el objeto insertado para hacer la comprabacion
            var objetoBD = unidadDeTrabajo.actualizacion.Get((int)NuevoId);

            Assert.AreEqual(actualizacion.cod_usuario, objetoBD.cod_usuario);
        }
        [TestMethod]
        public void EliminarTest()
        {
            //Obtenemos la lista de Customer
            var actualizacion = unidadDeTrabajo.actualizacion_zip.Get(3);
            //Borramos el Registro
            var resultadoEliminar = unidadDeTrabajo.actualizacion_zip.Delete(actualizacion);
            //si ya se elimino, esto deberia ser null
            var objetoArtudoBD = unidadDeTrabajo.actualizacion.Get(actualizacion.Id);
            Assert.AreEqual(null, objetoArtudoBD);
        }
        [TestMethod]
        public void ReporteObtenerActualizacionXTipo()
        {
            var reporte = unidadDeTrabajo.RepositorioActualizacion.ConsultaActualizacionXTipo_Act("1");
            Assert.AreEqual(true, reporte.Count > 0);
        }
        [TestMethod]
        public void BucarUltimaActualizacionXTipo()
        {
            var resultado = unidadDeTrabajo.RepositorioActualizacion.BuscaUltimaActualizacionXTipo("5",3);
            Assert.AreEqual(true, resultado.Count>0);
        }
        [TestMethod]
        //T
        public void TObtenerUsuarioPorLogin()
        {
            var resultado = unidadDeTrabajo.RepositorioUsuarios.ObtenerUsuarioPorLogin("jczll@softpad.pe","70729");
            Assert.AreEqual(true, resultado.Count > 0);
        }
        [TestMethod]
        public void InsertarTestCargo()
        {
            var cargo = new Cargo()
            {
                tipo_id = "MOD",
                anio = "20",
                mes = "04",
                descripcio = "ACTUALIZACION DE FACTOR DE CONVERSION"
            };
            var NuevoId = unidadDeTrabajo.cargo.Insert(cargo);
            //Obtener el objeto insertado para hacer la comprabacion
            var objetoBD = unidadDeTrabajo.cargo.Get((int)NuevoId);

            Assert.AreEqual(cargo.tipo_id, objetoBD.tipo_id);
        }

    }
}
