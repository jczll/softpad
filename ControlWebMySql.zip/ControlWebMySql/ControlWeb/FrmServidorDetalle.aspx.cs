﻿using Control.Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ControlWeb
{
    public partial class FrmServidorDetalle : PaginaBase
    {
        public FrmServidorDetalle()
        {
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            base.IsAutenticate();
            if (!Page.IsPostBack)
            {
                ConsultaServidoresActivos("");
            }
        }
        private void ConsultaServidoresActivos(string sDes_cliente)
        {
            List<Servidores_detalle> data;
            data = unidadDeTrabajo.RepositorioCliente_activacion.ConsultaServidoresDetalle(sDes_cliente);
            GrdServidores.DataSource = data;
            GrdServidores.DataBind();
        }
        protected void GrdServidores_SelectedIndexChanging(object sender, GridViewSelectEventArgs e)
        {
            GridViewRow gr = GrdServidores.SelectedRow;
            var iId = gr.Cells[1].Text;
        }

        protected void GrdServidores_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            GrdServidores.PageIndex = e.NewPageIndex;
            ConsultaServidoresActivos(TxtBuscar.Text);
        }

        protected void BtnConsultar_Click(object sender, EventArgs e)
        {
            ConsultaServidoresActivos(TxtBuscar.Text);
        }

        protected void BtnRetornar_Click(object sender, EventArgs e)
        {
            Response.Redirect("default.aspx");
        }
    }
}