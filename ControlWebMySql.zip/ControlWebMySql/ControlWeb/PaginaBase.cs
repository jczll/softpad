﻿using Control.AccesoDatos;
using Control.Interfaz;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;

namespace ControlWeb
{
    public class PaginaBase : System.Web.UI.Page
    {
        protected readonly IUnidadDeTrabajo unidadDeTrabajo;
        public PaginaBase()
        {
            unidadDeTrabajo = new UnidadDeTrabajo(ConfigurationManager.ConnectionStrings["ControlConexion"].ConnectionString);
        }
        protected void IsAutenticate()
        {
            //Verificando si el usuario esta autenticado a la aplicacion
            if (!HttpContext.Current.User.Identity.IsAuthenticated)
            {
                RedirectToLogin();
            }
        }
        private void RedirectToLogin()
        {
            Response.Redirect("~/FrmIngresoUsuario.aspx");
        }
        protected void IsSupervisor()
        {
           if(Application["Usuario_cod"].ToString()!="JCZ")
           {
               Response.Redirect("~/default.aspx");
           }
        }
    }
}