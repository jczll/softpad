﻿using Control.Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ControlWeb
{
    public partial class FrmActivacion : PaginaBase
    {
        public FrmActivacion()
        {
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            base.IsAutenticate();
            base.IsSupervisor();
            if (!Page.IsPostBack)
            {
                ConsultaAcitvacionPendiente();
            }
        }
        private void ConsultaAcitvacionPendiente()
        {
            List<Cliente_activacion> data;
            data = unidadDeTrabajo.RepositorioCliente_activacion.ConsultaAcitvacionPendiente();
            GrdActivacion.DataSource = data;
            GrdActivacion.DataBind();
        }
        protected void BtnSalir_Click(object sender, EventArgs e)
        {
            Response.Redirect("default");
        }

        protected void GrdActivacion_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            var sCod_cli = GrdActivacion.DataKeys[e.RowIndex].Value.ToString();
            unidadDeTrabajo.RepositorioCliente_activacion.ActualizaEstadoActivacionCliente(sCod_cli, "", "R");
            ConsultaAcitvacionPendiente();
        }
    }
}