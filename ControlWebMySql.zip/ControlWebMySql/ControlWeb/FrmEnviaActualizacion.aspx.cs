﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;

namespace ControlWeb
{
    public partial class FrmEnviaActualizacion : PaginaBase
    {
        public FrmEnviaActualizacion()
        {
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            base.IsAutenticate();
            ValidaEditaActualizacion();
            if (!Page.IsPostBack)
            {
                ObtenerActualizacion();                
            }
        }
        private void ObtenerActualizacion()
        {
            var id = Convert.ToInt32(Request.QueryString["id"]);
            var actualizacion = unidadDeTrabajo.actualizacion.Get(id);
            LblId.Text = actualizacion.Id.ToString();
            LblFech_crea.Text = actualizacion.fech_crea.ToString();
            LblNomb_emp.Text = unidadDeTrabajo.RepositorioActualizacion.BuscaNombreEmpleado(actualizacion.cod_usuario);
            LblDesc_act.Text = unidadDeTrabajo.RepositorioActualizacion.BuscaDescripcioTipoActualizacion(actualizacion.tipo_act);
            LblDesc_ver.Text = unidadDeTrabajo.RepositorioActualizacion.BuscaDescripcioVersionoActualizacion(actualizacion.vers_act);
            LblTitulo.Text = actualizacion.titulo;
            LblDetalle1.Text = actualizacion.detalle;
            HFId.Value = actualizacion.Id.ToString();
            var lista = unidadDeTrabajo.RepositorioActualizacion_zip.ConsultaActualizacion_zipXActId(id);
            foreach (var item in lista)
            {
                LstArchivos.Items.Add(item.arch_zip);
            }
            CreaArchivoXML(actualizacion.tipo_act, actualizacion.cod_usuario, actualizacion.vers_act);
        }

        private void CreaArchivoXML(string sTipo_act, string sCod_Usuario, string sVers_act)
        {
            var nContador_arch = 0;
            //Creamos el objeto Xml
            XmlDocument XmlDoc = new XmlDocument();
            //Creamos la Etiqueta Raiz
            XmlElement raiz = XmlDoc.CreateElement("Actualizacion");
            XmlDoc.AppendChild(raiz);
            //Creamos la Primera Familia
            XmlElement eCabecera = XmlDoc.CreateElement("Cabecera");
            raiz.AppendChild(eCabecera);
            //Creamos la Primera Etiqueta Hija
            XmlElement eId = XmlDoc.CreateElement("ID");
            eId.AppendChild(XmlDoc.CreateTextNode(LblId.Text));
            eCabecera.AppendChild(eId);
            //Creamos la Segunda Etiqueta Hija
            XmlElement eFech_Crea = XmlDoc.CreateElement("FechaCreacion");
            eFech_Crea.AppendChild(XmlDoc.CreateTextNode(LblFech_crea.Text));
            eCabecera.AppendChild(eFech_Crea);
            //Creamos la Tercera Etiqueta Hija
            XmlElement eEmpleado = XmlDoc.CreateElement("CreadoPor");
            eEmpleado.AppendChild(XmlDoc.CreateTextNode(sCod_Usuario));
            eCabecera.AppendChild(eEmpleado);
            //Creamos la Cuarta Etiqueta Hija
            XmlElement eTipo_act = XmlDoc.CreateElement("TipoActualizacion");
            eTipo_act.AppendChild(XmlDoc.CreateTextNode(sTipo_act));
            eCabecera.AppendChild(eTipo_act);
            //Creamos la Quinta Etiqueta Hija
            XmlElement eVers_act = XmlDoc.CreateElement("VersionActualizacion");
            eVers_act.AppendChild(XmlDoc.CreateTextNode(sVers_act));
            eCabecera.AppendChild(eVers_act);
            //Creamos la Sexta Etiqueta Hija
            XmlElement eTitulo = XmlDoc.CreateElement("Titulo");
            eTitulo.AppendChild(XmlDoc.CreateTextNode(LblTitulo.Text));
            eCabecera.AppendChild(eTitulo);
            //Creamos la Octava Etiqueta Hija
            XmlElement eDetalle = XmlDoc.CreateElement("Detalle");
            eDetalle.AppendChild(XmlDoc.CreateTextNode(LblDetalle1.Text));
            eCabecera.AppendChild(eDetalle);

            //Creamos la Segunda Familiar
            nContador_arch = 0;
            XmlElement eAdjuntos = XmlDoc.CreateElement("ArchivosAdjuntos");
            raiz.AppendChild(eAdjuntos);
            //Creamos la Primera Etiqueta Hija
            foreach (var item in LstArchivos.Items)
            {
                var Archivo_zip = Path.GetFileName(LstArchivos.Items[nContador_arch].Value);
                XmlElement eArch_Zip = XmlDoc.CreateElement("Archivo_Zip");
                eArch_Zip.AppendChild(XmlDoc.CreateTextNode(Archivo_zip));
                eAdjuntos.AppendChild(eArch_Zip);
                nContador_arch++;
            }
            var sNomArchXml = Convert.ToDateTime(LblFech_crea.Text);
            string sNomArchXml1 = sNomArchXml.Year.ToString()+ sNomArchXml.Month.ToString().PadLeft(2,'0') + sNomArchXml.Day.ToString().PadLeft(2, '0') + Request.QueryString["id"].Trim();
            //XmlDoc.Save($"C:/estctr/{sNomArchXml1}.xml");            
            if (LblDesc_act.Text.Contains("TAMEX") || LblDesc_act.Text.Contains("FACTOR") || LblDesc_act.Text.Contains("ESPECIF"))
                XmlDoc.Save(Server.MapPath("~/Subidos/util_sql/" + sNomArchXml1 + ".XML"));
            else
               if (LblDesc_ver.Text.Contains("ACTUAL"))
                  XmlDoc.Save(Server.MapPath("~/Subidos/0SQLMAY200703/" + sNomArchXml1 + ".XML"));
                  //File.Copy(Archivo_zip, Server.MapPath("~/Subidos/0SQLAGO191003/" + Archivo_zipDestino));
               else
                  XmlDoc.Save(Server.MapPath("~/Subidos/0SQLABR200603/" + sNomArchXml1 + ".XML"));
            LstArchivos.Items.Add(sNomArchXml1 + ".xml");
            //LstArchivos.Items.Add("C:\\" + "estctr\\" + sNomArchXml1 + ".xml");
        }

        protected void BtnEnviar_Click(object sender, EventArgs e)
        {
            BtnEnviar.Enabled = false;
            BtnContinuar.Enabled = false;
            //Marcando como enviado 
            //System.Threading.Thread.Sleep(5000);
            long nRegistro = Convert.ToInt32(HFId.Value);
            var actualizacion = unidadDeTrabajo.actualizacion.Get(nRegistro);
            //Hacemos los cambios en los campos que queremos 
            actualizacion.enviado1 = true;
            //Obtener el objeto de BD nuevamente 
            var resultado = unidadDeTrabajo.actualizacion.Update(actualizacion);
            //En caso que se actualizacion Atomatica tipo Tamex,Factor o Especif borramos la anterior porque ya no es valida 
            if (LblDesc_act.Text.Contains("TAMEX") || LblDesc_act.Text.Contains("FACTOR") || LblDesc_act.Text.Contains("ESPECIF"))
            {
                var lista = unidadDeTrabajo.RepositorioActualizacion.BuscaUltimaActualizacionXTipo(actualizacion.tipo_act, actualizacion.Id);
                if (lista.Count > 0)
                {
                    foreach (var item in lista)
                    {
                        var dFechaCrea = Convert.ToDateTime(item.fech_crea);
                        string sNomArchXml1 = dFechaCrea.Year.ToString() + dFechaCrea.Month.ToString().PadLeft(2, '0') + dFechaCrea.Day.ToString().PadLeft(2, '0') + item.Id;
                        var sNomArchXml = sNomArchXml1 + ".xml";
                        File.Delete(Server.MapPath("~/Subidos/util_sql/" + sNomArchXml));
                    }
                }
            }
            BtnContinuar.Enabled = true;
        }

        protected void BtnContinuar_Click(object sender, EventArgs e)
        {
            Response.Redirect("FrmActualizacion");
        }
        private void ValidaEditaActualizacion()
        {
            var id = Convert.ToInt32(Request.QueryString["id"]);
            if (unidadDeTrabajo.RepositorioActualizacion.EvaluaActualizacionEnviada(id))
            {
                BtnEnviar.Visible = false;
                BtnContinuar.Visible = false;
            }
        }
    }
}