﻿using Control.Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ControlWeb
{
    public partial class FrmVisitas : PaginaBase
    {
        public FrmVisitas()
        {
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            base.IsAutenticate();
            if (!Page.IsPostBack)
            {
                if (Session["Usuario_cod"].ToString() != "JCZ")
                    BtnGenerar.Visible = false;
                LlenaDropDownList("CLIENTE");
                ConsultarVisitasPendientes(TxtNro_visita.Text, DrpCliente.Text, IptFech_visitas.Value);
            }
        }
        private void ConsultarVisitasPendientes(string sNro_visita, string sCod_cli, string sFech_visita)
        {
            List<Consulta_Visitas> data;
            if (!ChkNro_visita.Checked)
                sNro_visita = "";
            if (!ChkCliente.Checked)
                sCod_cli = "";
            if (!ChkFech_visita.Checked)
                sFech_visita = "";

            data = unidadDeTrabajo.RepositorioVisitas.ConsultaVisitasPendientes(sNro_visita,sCod_cli,sFech_visita);
            GrdVisitas.DataSource = data;
            GrdVisitas.DataBind();

        }
        private void LlenaDropDownList(string sTabla)
        {
            if (sTabla.ToUpper() == "CLIENTE")
            {
                DrpCliente.DataSource = unidadDeTrabajo.visitas.ConsultaDatos(Application["SqlCliente"].ToString());
                DrpCliente.DataTextField = "raz_soc_cli";
                DrpCliente.DataValueField = "cod_cli";
                DrpCliente.DataBind();
            }
        }
        protected void GrdVisitas_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            GrdVisitas.PageIndex = e.NewPageIndex;
            ConsultarVisitasPendientes(TxtNro_visita.Text, DrpCliente.Text, IptFech_visitas.Value);
        }
        protected void GrdVisitas_SelectedIndexChanging(object sender, GridViewSelectEventArgs e)
        {
            GridViewRow gr = GrdVisitas.SelectedRow;
            var iId = gr.Cells[1].Text;
        }
        protected void GrdVisitas_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            var iId = Convert.ToInt32(GrdVisitas.DataKeys[e.RowIndex].Value.ToString());
            //Verificamos si se puede Borrar esta Visita 
            var sEstado = unidadDeTrabajo.RepositorioVisitas.DatoIncidenciaVisita(iId, "Estado");
            if(sEstado!="05" && sEstado != "04")
            {
                var sCod_emp = unidadDeTrabajo.RepositorioVisitas.DatoIncidenciaVisita(iId, "cod_emp");
                var sFech_visita = unidadDeTrabajo.RepositorioVisitas.DatoIncidenciaVisita(iId, "Fech_visita");
                var bAgrego = unidadDeTrabajo.RepositorioVisitas.AgregaIncidencia_Visita(iId, "05", sCod_emp, sFech_visita);
                if (bAgrego)
                    ConsultarVisitasPendientes(TxtNro_visita.Text, DrpCliente.Text, IptFech_visitas.Value);
                else
                    Response.Write("<script>alert('No se pudo Concluir esta Vista ')</script>");
                ////Primero Borramos sus Incidencias
                //var resultadoEliminarIncidencias = unidadDeTrabajo.RepositorioVisitas.EliminaIncidencia_Visitas(iId);
                //if (resultadoEliminarIncidencias)
                //{
                //    var visitas = unidadDeTrabajo.visitas.Get(iId);
                //    //Borramos el Registro
                //    var resultadoEliminar = unidadDeTrabajo.visitas.Delete(visitas);
                //    GrdVisitas.EditIndex = -1;
                //    //si ya se elimino, esto deberia ser null
                //    if (resultadoEliminar)
                //    {
                //        //LblSuccessMessage.Text = "Registro Borrado en Forma Satisfactoria";
                //        ConsultarVisitasPendientes(TxtNro_visita.Text, DrpCliente.Text, IptFech_visitas.Value);
                //    }
                //}
                //else
                //{
                //    Response.Write("<script>alert('No se pudo Eliminar las Incidencias de esta Visita')</script>");
                //}
            }
            else
                Response.Write("<script>alert('No se puede Anular esta visita porque ya esta concluido ')</script>");
        }

        protected void BtnConsultar_Click(object sender, EventArgs e)
        {
            ConsultarVisitasPendientes(TxtNro_visita.Text, DrpCliente.Text, IptFech_visitas.Value);
        }

        protected void ChkNro_visita_CheckedChanged(object sender, EventArgs e)
        {
            if (ChkNro_visita.Checked)
               TxtNro_visita.Enabled = true;
            else
               TxtNro_visita.Enabled = false;
        }

        protected void ChkCliente_CheckedChanged(object sender, EventArgs e)
        {
            if (ChkCliente.Checked)
               DrpCliente.Enabled = true;
            else
               DrpCliente.Enabled = false;
        }

        protected void ChkFech_visita_CheckedChanged(object sender, EventArgs e)
        {
            if (ChkFech_visita.Checked)
               IptFech_visitas.Disabled = false;
            else
               IptFech_visitas.Disabled = true;
        }

        protected void BtnNuevo_Click(object sender, EventArgs e)
        {
            Response.Redirect("FrmEditaVisita.aspx");
        }

        protected void GrdVisitas_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            var iId = Convert.ToInt32(GrdVisitas.DataKeys[e.RowIndex].Value.ToString());
            var sCod_emp = unidadDeTrabajo.RepositorioVisitas.DatoIncidenciaVisita(iId, "cod_emp");
            var sFech_visita = unidadDeTrabajo.RepositorioVisitas.DatoIncidenciaVisita(iId, "Fech_visita");
            var bAgrego =unidadDeTrabajo.RepositorioVisitas.AgregaIncidencia_Visita(iId, "04", sCod_emp, sFech_visita);
            if (bAgrego)
               ConsultarVisitasPendientes(TxtNro_visita.Text, DrpCliente.Text, IptFech_visitas.Value);
            else
                Response.Write("<script>alert('No se pudo Concluir esta Vista ')</script>");
        }
        private void GeneraMantenMensual(string sMes, string sAño)
        {
            List<Cliente_contrato> dContratosVigentes = unidadDeTrabajo.RepositorioCliente.ConsultaContratosVigentes();
            foreach (var item in dContratosVigentes)
            {
                var sNro_visita = sAño.Substring(2, 2) + sMes + item.cod_cli;
                List<Consulta_Visitas> dVisitas = unidadDeTrabajo.RepositorioVisitas.ConsultaVisitasPendientes(sNro_visita, "","");
                if (dVisitas.Count==0)
                {
                    if (ValidaGeneraMantenMensual(item.cod_cli, item.period_contrato, item.contrato_correl, item.moneda, sMes, sAño))
                    {
                        var visitas = new Visitas()
                        {
                            nro_visita = sNro_visita,
                            tipo_destino = "C",
                            cod_emp = Session["Usuario_cod"].ToString(),
                            cod_cli = item.cod_cli,
                            contrato_correl = item.contrato_correl,
                            cod_sistema = item.cod_sistema,
                            tipo_visita = "MNT",
                            serv_mensual = sMes,
                        };
                        var NuevoId = unidadDeTrabajo.visitas.Insert(visitas);
                        if (NuevoId > 0)
                        {
                            unidadDeTrabajo.RepositorioVisitas.AgregaIncidencia_Visita(NuevoId, "01", Session["Usuario_cod"].ToString(), DateTime.Now.ToString());
                        }
                    }
                }
            }
        }
        private bool ValidaGeneraMantenMensual(string sCod_cli, string sPeriod_Contrato, string sContrato_correl, string sMoneda, string sMes, string sAño)
        {
            var sSalida = false;
            var rDocumento = unidadDeTrabajo.RepositorioDocumento.ValidaGeneraMantenMensual(sCod_cli, sPeriod_Contrato, sContrato_correl, sMes, sAño);
            if (!string.IsNullOrEmpty(rDocumento.nro_documento))
            {
                var rSaldoDocumento = unidadDeTrabajo.RepositorioDocumento.GeneraConsultaSaldo(sCod_cli, sMoneda, rDocumento.tipo_doc, rDocumento.nro_documento);
                if (rSaldoDocumento.saldo <= 0)
                {
                    sSalida = true;
                }
            }
            return sSalida;
        }

        protected void BtnGenerar_Click(object sender, EventArgs e)
        {
            GeneraMantenMensual("06", "2020");
        }
    }
}