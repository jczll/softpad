﻿using Control.Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ControlWeb
{
    public partial class FrmVisitas : PaginaBase
    {
        public FrmVisitas()
        {
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            base.IsAutenticate();
            if (!Page.IsPostBack)
            {
                LlenaDropDownList("CLIENTE");
                ConsultarVisitasPendientes(TxtNro_visita.Text, DrpCliente.Text, IptFech_visitas.Value);
            }
        }
        private void ConsultarVisitasPendientes(string sNro_visita, string sCod_cli, string sFech_visita)
        {
            List<Consulta_Visitas> data;
            if (!ChkNro_visita.Checked)
                sNro_visita = "";
            if (!ChkCliente.Checked)
                sCod_cli = "";
            if (!ChkFech_visita.Checked)
                sFech_visita = "";

            data = unidadDeTrabajo.RepositorioVisitas.ConsultaVisitasPendientes(sNro_visita,sCod_cli,sFech_visita);
            GrdVisitas.DataSource = data;
            GrdVisitas.DataBind();

        }
        private void LlenaDropDownList(string sTabla)
        {
            if (sTabla.ToUpper() == "CLIENTE")
            {
                var sComandoSql = @"
                Select distinct cli.cod_cli,cli.raz_soc_cli,cli.ruc,clin.fech_ini,clin.fech_venc
                  from cliente cli
                       left join cliente_contrato CliN on CliN.cod_cli = Cli.cod_cli
                  where
                      ((curdate() <= adddate(cli.fech_crea, interval 30 day)) or
                      (left(CliN.contrato_correl, 1) not in ('F', 'T') and CliN.fech_ini <= adddate(curdate(), interval 15 day) and CliN.fech_venc >= curdate()) and
                      (Select estado from cliente_contrato_incidencia where cod_cli = CliN.cod_cli and contrato_correl = CliN.contrato_correl order by fech_incidencia desc limit 1) not in ('07'))
                      order by raz_soc_cli";

                DrpCliente.DataSource = unidadDeTrabajo.RepositorioVisitas.ConsultaDatos(sComandoSql);
                DrpCliente.DataTextField = "raz_soc_cli";
                DrpCliente.DataValueField = "cod_cli";
                DrpCliente.DataBind();
            }
            else
            {
                //DrpTipoDocumento.DataSource = ConsultaDatos("SELECT descripcio, codigo FROM bdsoftpad_ctr_tablas.ta26");
                //DrpTipoDocumento.DataTextField = "Descripcio";
                //DrpTipoDocumento.DataValueField = "codigo";
                //DrpTipoDocumento.DataBind();
            }
       }

        protected void DrpCliente_SelectedIndexChanged(object sender, EventArgs e)
        {
            //Application["Tipodocum"] = DrpCliente.SelectedValue;
        }

        protected void GrdVisitas_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void GrdVisitas_SelectedIndexChanging(object sender, GridViewSelectEventArgs e)
        {
            GridViewRow gr = GrdVisitas.SelectedRow;
            var iId = gr.Cells[1].Text;
        }

        protected void GrdVisitas_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            GrdVisitas.PageIndex = e.NewPageIndex;
            ConsultarVisitasPendientes(TxtNro_visita.Text, DrpCliente.Text, IptFech_visitas.Value);
        }

        protected void GrdVisitas_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            var iId = Convert.ToInt32(GrdVisitas.DataKeys[e.RowIndex].Value.ToString());
            //Obtenemos la lista de Customer
            var cargo = unidadDeTrabajo.cargo.Get(iId);
            //Borramos el Registro
            var resultadoEliminar = unidadDeTrabajo.cargo.Delete(cargo);
            GrdVisitas.EditIndex = -1;
            //si ya se elimino, esto deberia ser null
            if (resultadoEliminar)
            {
                //LblSuccessMessage.Text = "Registro Borrado en Forma Satisfactoria";
                ConsultarVisitasPendientes(TxtNro_visita.Text, DrpCliente.Text, IptFech_visitas.Value);
            }

        }

        protected void BtnConsultar_Click(object sender, EventArgs e)
        {
            ConsultarVisitasPendientes(TxtNro_visita.Text, DrpCliente.Text, IptFech_visitas.Value);
        }

        protected void ChkNro_visita_CheckedChanged(object sender, EventArgs e)
        {
            if (ChkNro_visita.Checked)
               TxtNro_visita.Enabled = true;
            else
               TxtNro_visita.Enabled = false;
        }

        protected void ChkCliente_CheckedChanged(object sender, EventArgs e)
        {
            if (ChkCliente.Checked)
               DrpCliente.Enabled = true;
            else
               DrpCliente.Enabled = false;
        }

        protected void ChkFech_visita_CheckedChanged(object sender, EventArgs e)
        {
            if (ChkFech_visita.Checked)
               IptFech_visitas.Disabled = false;
            else
               IptFech_visitas.Disabled = true;
        }
    }
}