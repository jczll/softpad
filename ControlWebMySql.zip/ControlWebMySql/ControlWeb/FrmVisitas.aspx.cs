﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ControlWeb
{
    public partial class FrmVisitas : PaginaBase
    {
        public FrmVisitas()
        {
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            base.IsAutenticate();
            if (!Page.IsPostBack)
            {
                LlenaDropDownList("CLIENTE");
            }
        }
        private void LlenaDropDownList(string sTabla)
        {
            if (sTabla.ToUpper() == "CLIENTE")
            {
                var sComandoSql = @"
                Select distinct cli.cod_cli,cli.raz_soc_cli,cli.ruc,clin.fech_ini,clin.fech_venc
                  from cliente cli
                       left join cliente_contrato CliN on CliN.cod_cli = Cli.cod_cli
                  where
                      ((curdate() <= adddate(cli.fech_crea, interval 30 day)) or
                      (left(CliN.contrato_correl, 1) not in ('F', 'T') and CliN.fech_ini <= adddate(curdate(), interval 15 day) and CliN.fech_venc >= curdate()) and
                      (Select estado from cliente_contrato_incidencia where cod_cli = CliN.cod_cli and contrato_correl = CliN.contrato_correl order by fech_incidencia desc limit 1) not in ('07'))";

                DrpCliente.DataSource = unidadDeTrabajo.RepositorioVisitas.ConsultaDatos(sComandoSql);
                DrpCliente.DataTextField = "cod_cli";
                DrpCliente.DataValueField = "cod_cli";
                DrpCliente.DataBind();
            }
            else
            {
                //DrpTipoDocumento.DataSource = ConsultaDatos("SELECT descripcio, codigo FROM bdsoftpad_ctr_tablas.ta26");
                //DrpTipoDocumento.DataTextField = "Descripcio";
                //DrpTipoDocumento.DataValueField = "codigo";
                //DrpTipoDocumento.DataBind();
            }
       }

        protected void DrpCliente_SelectedIndexChanged(object sender, EventArgs e)
        {
            Application["Tipodocum"] = DrpCliente.SelectedValue;
            LlenaDropDownList("CLIENTE");
        }
    }
}