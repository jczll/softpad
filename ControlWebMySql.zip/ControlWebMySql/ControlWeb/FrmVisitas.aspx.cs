﻿using Control.Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ControlWeb
{
    public partial class FrmVisitas : PaginaBase
    {
        public FrmVisitas()
        {
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            base.IsAutenticate();
            if (!Page.IsPostBack)
            {
                LlenaDropDownList("CLIENTE");
                ConsultarVisitasPendientes(TxtNro_visita.Text, DrpCliente.Text, IptFech_visitas.Value);
            }
        }
        private void ConsultarVisitasPendientes(string sNro_visita, string sCod_cli, string sFech_visita)
        {
            List<Consulta_Visitas> data;
            if (!ChkNro_visita.Checked)
                sNro_visita = "";
            if (!ChkCliente.Checked)
                sCod_cli = "";
            if (!ChkFech_visita.Checked)
                sFech_visita = "";

            data = unidadDeTrabajo.RepositorioVisitas.ConsultaVisitasPendientes(sNro_visita,sCod_cli,sFech_visita);
            GrdVisitas.DataSource = data;
            GrdVisitas.DataBind();

        }
        private void LlenaDropDownList(string sTabla)
        {
            if (sTabla.ToUpper() == "CLIENTE")
            {
                DrpCliente.DataSource = unidadDeTrabajo.visitas.ConsultaDatos(Application["SqlCliente"].ToString());
                DrpCliente.DataTextField = "raz_soc_cli";
                DrpCliente.DataValueField = "cod_cli";
                DrpCliente.DataBind();
            }
       }

        protected void DrpCliente_SelectedIndexChanged(object sender, EventArgs e)
        {
            //Application["Tipodocum"] = DrpCliente.SelectedValue;
        }

        protected void GrdVisitas_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void GrdVisitas_SelectedIndexChanging(object sender, GridViewSelectEventArgs e)
        {
            GridViewRow gr = GrdVisitas.SelectedRow;
            var iId = gr.Cells[1].Text;
        }

        protected void GrdVisitas_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            GrdVisitas.PageIndex = e.NewPageIndex;
            ConsultarVisitasPendientes(TxtNro_visita.Text, DrpCliente.Text, IptFech_visitas.Value);
        }

        protected void GrdVisitas_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            var iId = Convert.ToInt32(GrdVisitas.DataKeys[e.RowIndex].Value.ToString());
            //Verificamos si se puede Borrar esta Visita 
            var sEstado = unidadDeTrabajo.RepositorioVisitas.DatoIncidenciaVisita(iId, "Estado");
            if(sEstado!="05" && sEstado != "04")
            {
                //Primero Borramos sus Incidencias
                var resultadoEliminarIncidencias = unidadDeTrabajo.RepositorioVisitas.EliminaIncidencia_Visitas(iId);
                if (resultadoEliminarIncidencias)
                {
                    var visitas = unidadDeTrabajo.visitas.Get(iId);
                    //Borramos el Registro
                    var resultadoEliminar = unidadDeTrabajo.visitas.Delete(visitas);
                    GrdVisitas.EditIndex = -1;
                    //si ya se elimino, esto deberia ser null
                    if (resultadoEliminar)
                    {
                        //LblSuccessMessage.Text = "Registro Borrado en Forma Satisfactoria";
                        ConsultarVisitasPendientes(TxtNro_visita.Text, DrpCliente.Text, IptFech_visitas.Value);
                    }
                }
                else
                {
                    Response.Write("<script>alert('No se pudo Eliminar las Incidencias de esta Visita')</script>");
                }
            }
            else
                Response.Write("<script>alert('No se puede Eliminar esta visita porque ya esta concluido o anulado')</script>");
        }

        protected void BtnConsultar_Click(object sender, EventArgs e)
        {
            ConsultarVisitasPendientes(TxtNro_visita.Text, DrpCliente.Text, IptFech_visitas.Value);
        }

        protected void ChkNro_visita_CheckedChanged(object sender, EventArgs e)
        {
            if (ChkNro_visita.Checked)
               TxtNro_visita.Enabled = true;
            else
               TxtNro_visita.Enabled = false;
        }

        protected void ChkCliente_CheckedChanged(object sender, EventArgs e)
        {
            if (ChkCliente.Checked)
               DrpCliente.Enabled = true;
            else
               DrpCliente.Enabled = false;
        }

        protected void ChkFech_visita_CheckedChanged(object sender, EventArgs e)
        {
            if (ChkFech_visita.Checked)
               IptFech_visitas.Disabled = false;
            else
               IptFech_visitas.Disabled = true;
        }

        protected void BtnNuevo_Click(object sender, EventArgs e)
        {
            Response.Redirect("FrmEditaVisita.aspx");
        }

        protected void GrdVisitas_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            var iId = Convert.ToInt32(GrdVisitas.DataKeys[e.RowIndex].Value.ToString());
            var sCod_emp = unidadDeTrabajo.RepositorioVisitas.DatoIncidenciaVisita(iId, "cod_emp");
            var sFech_visita = unidadDeTrabajo.RepositorioVisitas.DatoIncidenciaVisita(iId, "Fech_visita");
            var bAgrego =unidadDeTrabajo.RepositorioVisitas.AgregaIncidencia_Visita(iId, "04", sCod_emp, sFech_visita);
            if (bAgrego)
               ConsultarVisitasPendientes(TxtNro_visita.Text, DrpCliente.Text, IptFech_visitas.Value);
            else
                Response.Write("<script>alert('No se pudo Concluir esta Vista ')</script>");
        }
    }
}