﻿using Control.Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ControlWeb
{
    public partial class FrmCargos : PaginaBase
    {
        public FrmCargos()
        {
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            base.IsAutenticate();
            if (!Page.IsPostBack)
            {
                LlenaDropDownList();
                DrpSistema.Text = Session["Sistema"].ToString();
                DrpAño.Text = Session["Año"].ToString();
                DrpMes.Text = Session["Mes"].ToString();
                ConsultarMantenimiento(Session["Año"].ToString(), Session["Mes"].ToString(), Session["Sistema"].ToString());
            }
        }
        private void LlenaDropDownList()
        {
            //Sistema:
            DrpSistema.DataSource = unidadDeTrabajo.cargo.ConsultaDatos("Select des_sistema,cod_sistema from sistema where cod_sistema in('SAD','DSI','DMA','RMF') ");
            DrpSistema.DataTextField = "des_sistema";
            DrpSistema.DataValueField = "cod_sistema";
            DrpSistema.DataBind();
            //Año de Cargo
            DrpAño.DataSource = unidadDeTrabajo.cargo.ConsultaDatos("select distinct anio AS Expr1 FROM cargo order by 1 desc");
            DrpAño.DataTextField = "Expr1";
            DrpAño.DataValueField = "Expr1";
            DrpAño.DataBind();
            //Mes del Cargo
            DrpMes.DataSource = unidadDeTrabajo.cargo.ConsultaDatos("Select descripcio, codigo FROM bdsoftpad_ctr_tablas.ta22 order by codigo");
            DrpMes.DataTextField = "descripcio";
            DrpMes.DataValueField = "codigo";
            //DrpMes.SelectedValue = DateTime.Now.Month.ToString();
            DrpMes.DataBind();
        }
        private void ConsultarMantenimiento(string sAño, string sMes, string sSistema)
        {
            List<Cargo> data;
            data = unidadDeTrabajo.RepositorioCargo.ConsultaCargoXMesAño(sAño, sMes, sSistema);
            if (data.Count == 0)
            {
                GeneraPuntosCargoAutomaticos(sAño, sMes);
                data = unidadDeTrabajo.RepositorioCargo.ConsultaCargoXMesAño(sAño, sMes, sSistema);
            }
            Habilita_DesabilitaControles(sAño, sMes);
            GrdTablas.DataSource = data;
            GrdTablas.DataBind();
        }

        protected void BtnNuevo_Click(object sender, EventArgs e)
        {
            Response.Redirect("FrmEditaCargo.aspx?id="+""+"&sAño=" + DrpAño.Text + "&sMes=" + DrpMes.Text);
        }

        protected void BtnConsultar_Click(object sender, EventArgs e)
        {
            ConsultarMantenimiento(DrpAño.Text, DrpMes.Text, DrpSistema.Text); 
        }

        protected void GrdTablas_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        protected void GrdTablas_SelectedIndexChanging(object sender, GridViewSelectEventArgs e)
        {
            GridViewRow gr = GrdTablas.SelectedRow;
            var iId = gr.Cells[1].Text;
        }
        protected void GrdTablas_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            GrdTablas.PageIndex = e.NewPageIndex;
            ConsultarMantenimiento(DrpAño.Text, DrpMes.Text, DrpSistema.Text);
        }
        protected void GrdTablas_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            var iId = Convert.ToInt32(GrdTablas.DataKeys[e.RowIndex].Value.ToString());
            //Obtenemos la lista de Customer
            var cargo = unidadDeTrabajo.cargo.Get(iId);
            //Borramos el Registro
            var resultadoEliminar = unidadDeTrabajo.cargo.Delete(cargo);
            GrdTablas.EditIndex = -1;
            //si ya se elimino, esto deberia ser null
            if (resultadoEliminar)
            {
                LblSuccessMessage.Text = "Registro Borrado en Forma Satisfactoria";
                ConsultarMantenimiento(DrpAño.Text, DrpMes.Text, DrpSistema.Text);
            }
        }
        private void GeneraPuntosCargoAutomaticos(string sAño, string sMes)
        {
            String[] aCargosAutomiticos = new String[6];
            aCargosAutomiticos[0] = "SERVICIO DE ACTUALIZACION DE TAMEX DIARIO A LA FECHA.";
            aCargosAutomiticos[1] = "FACTORES DE CONVERSIÓN - MES AÑO SEGUN PORTAL DE ADUANAS (PÚB 99.99.9999).";
            aCargosAutomiticos[2] = "PRECIOS DE REFERENCIA Y DERECHOS VARIABLES ADICIONALES APLICABLES A  IMPORTACIONES DE MAIZ, AZUCAR, ARROZ Y LECHE ENTERA EN POLVO. RVM.Nº 000-9999-EF/99.99 del 99/99/9999.";
            aCargosAutomiticos[3] = "ACTUALIZACIÓN DE DATOS DE PROVEEDORES EXTRANJEROS (DIRECCION, TELEFONO, CIUDAD, ETC)  CON LA TABLA MAESTRA DE CONSOLIDADO DE PROVEEDORES.";
            aCargosAutomiticos[4] = "SE ACTUALIZO LA TABLA MAESTRA DE CONSOLIDADO DE  CLIENTES DEL SISTEMA.";
            aCargosAutomiticos[5] = "ACTUALIZACION DEL INDICE DE NORMAS LEGALES DESDE EL 99.99.9999  HASTA EL 99.99.9999.";
            int i;
            for (i = 0; i < aCargosAutomiticos.Length; i++)
            {
                var cargo = new Cargo()
                {
                    anio = sAño,
                    mes = sMes,
                    tipo_id = "ADU",
                    descripcio = aCargosAutomiticos[i],
                    sad = Convert.ToString(i).PadLeft(2, '0'),
                    dsi = Convert.ToString(i).PadLeft(2, '0'),
                    dma = Convert.ToString(i).PadLeft(2, '0'),
                    rmf = Convert.ToString(i).PadLeft(2, '0'),
                };
                var NuevoId = unidadDeTrabajo.cargo.Insert(cargo);
            }
        }
        protected void BtnCerrar_Click(object sender, EventArgs e)
        {
            var iResultado=unidadDeTrabajo.RepositorioCargo.CerrarCargoMantenimiento(DrpAño.Text, DrpMes.Text);
            if (iResultado>0)
            {
                Habilita_DesabilitaControles(DrpAño.Text, DrpMes.Text);
                LblSuccessMessage.Text = "Cargo de Mantenimiento Cerrado Correctamente";
            }
        }
        private void Habilita_DesabilitaControles(string sAño, string sMes)
        {
            var iCerrado = unidadDeTrabajo.RepositorioCargo.ValidaCerroCargoMantenimiento(sAño, sMes);
            if (iCerrado)
            {
                GrdTablas.Columns[6].Visible = false;
                GrdTablas.Columns[7].Visible = false;
                BtnNuevo.Visible = false;
                BtnCerrar.Visible = false;
                LblSuccessMessage.Text = "";
            }
            else
            {
                GrdTablas.Columns[6].Visible = true;
                GrdTablas.Columns[7].Visible = true;
                BtnNuevo.Visible = true;
                BtnCerrar.Visible = true;
                LblSuccessMessage.Text = "";
            }
        }
    }
}