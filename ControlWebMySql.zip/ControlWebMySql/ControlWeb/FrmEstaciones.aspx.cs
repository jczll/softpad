﻿using Control.Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ControlWeb
{
    public partial class FrmEstaciones : PaginaBase
    {
        public FrmEstaciones()
        {
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            base.IsAutenticate();
            if (!Page.IsPostBack)
            {
                if (!String.IsNullOrWhiteSpace(Request.QueryString["cod_cli"]))
                {
                    var sCod_cli = Request.QueryString["cod_cli"].ToString();
                    LblTitulo.Text = "ESTACIONES DEL CLIENTE : " + unidadDeTrabajo.RepositorioCliente_activacion.BuscaNombreCliente(sCod_cli);
                    ConsultaEstacionesxCliente(Request.QueryString["cod_cli"].ToString());
                }
            }
        }
        private void ConsultaEstacionesxCliente(string sCod_cli)
        {
            List<Cliente_contrato_estacion> data;
            data = unidadDeTrabajo.RepositorioCliente_activacion.ConsultaEstacionesxCliente(sCod_cli);
            GrdEstaciones.DataSource = data;
            GrdEstaciones.DataBind();
        }
        protected void GrdEstaciones_SelectedIndexChanged(object sender, EventArgs e)
        {
            GridViewRow gr = GrdEstaciones.SelectedRow;
            var iId = gr.Cells[1].Text;
        }

        protected void GrdEstaciones_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            GrdEstaciones.PageIndex = e.NewPageIndex;
            ConsultaEstacionesxCliente(Request.QueryString["cod_cli"].ToString());
        }

        protected void BtnRetornar_Click(object sender, EventArgs e)
        {
            Response.Redirect("FrmServidorDetalle.aspx");
        }
    }
}