﻿using Control.AccesoDatos;
using Control.Interfaz;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ControlWeb
{
    public partial class FrmIngresoUsuario : System.Web.UI.Page
    {
        IUnidadDeTrabajo unidadDeTrabajo = new UnidadDeTrabajo(ConfigurationManager.ConnectionStrings["ControlConexion"].ConnectionString);
        public FrmIngresoUsuario()
        {
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            LlenaDropDownList();
        }
        private void LlenaDropDownList()
        {
            DrpLogin.DataSource = unidadDeTrabajo.usuarios.ConsultaDatos("SELECT cod_usuario, concat(rtrim(nombres),' ',rtrim(apellidos)) as nombres FROM usuarios where cod_usuario in('MTM','OMG','JCZ','IMC') ORDER BY nombres");
            DrpLogin.DataTextField = "nombres";
            DrpLogin.DataValueField = "cod_usuario";
            DrpLogin.DataBind();
        }
        protected void BtnLogin_Click(object sender, EventArgs e)
        {
            Ingresar();
        }
        private void Ingresar()
        {
            if (ValidaUsuario())
            {
                FormsAuthenticationTicket tkt;
                string cookieStr;
                HttpCookie httpCookie;
                tkt = new FormsAuthenticationTicket(
                          1,
                          DrpLogin.Text.Trim(),
                          DateTime.Now,
                          DateTime.Now.AddMinutes(220),
                          false,
                          ""
                          );
                cookieStr = FormsAuthentication.Encrypt(tkt);
                httpCookie = new HttpCookie(FormsAuthentication.FormsCookieName, cookieStr);

                Response.Cookies.Add(httpCookie);
                Response.Redirect("~/default.aspx", true);
            }
        }
        private bool ValidaUsuario()
        {
            var usuario = unidadDeTrabajo.RepositorioUsuarios.ObtenerUsuarioPorLogin(DrpLogin.Text.Trim(), TxtPassword.Text.Trim());
            if (usuario.Count > 0)
            {        
                foreach (var item in usuario)
                {
                    Session["Usuario_cod"] = item.cod_usuario;
                    Session["Usuario_Nombre"] = item.nombres.Trim()+" "+item.apellidos.Trim();
                    //StreamWriter DatosUsuario = File.CreateText(Server.MapPath("~/Subidos/usertxt" + item.cod_usuario + ".txt"));
                    //DatosUsuario.WriteLine(item.cod_usuario);
                    //DatosUsuario.WriteLine(item.nombres.Trim() + " " + item.apellidos.Trim());
                    //DatosUsuario.Close();
                }
                return true;
            }
            else
                Response.Write("<script>alert('No se ha podido Autenticar el ingreso de dicho Usuario ')</script>");
                //MessageBox.Show("No se ha podido Autenticar el ingreso de dicho Usuario", "SOFTPAD", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
        }
    }
}