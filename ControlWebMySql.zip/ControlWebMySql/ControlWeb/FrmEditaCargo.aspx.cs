﻿using Control.Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ControlWeb
{
    public partial class FrmEditaCargo : PaginaBase
    {
        public FrmEditaCargo()
        {
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                base.IsAutenticate();
                ObtenerPuntoCargo();
            }
        }
        protected void BtnGuardar_Click(object sender, EventArgs e)
        {
            if (Guardar() > 0)
            {
                ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('Registro Guardado en Forma Satisfactoria');", true);
                Response.Redirect("FrmCargos.aspx");
            }
            else
                Response.Write("<script>alert('No se pudo guardar el Registro')</script>");
        }
        private void ObtenerPuntoCargo()
        {
            if (String.IsNullOrWhiteSpace(Request.QueryString["id"]))
            {
                CmbTipo_id.Text = "ADU";
                var sCorrel = unidadDeTrabajo.RepositorioCargo.BuscaCorrelativo(Request.QueryString["sAño"].ToString(), Request.QueryString["sMes"].ToString());
                sCorrel = Convert.ToString(Convert.ToInt32(sCorrel)+1).PadLeft(2,'0'); 
                TxtSad.Text = sCorrel;
                TxtDsi.Text = "00";
                TxtDma.Text = "00";
                TxtRmf.Text = "00";
                Session["Año"] = Request.QueryString["sAño"].ToString();
                Session["Mes"] = Request.QueryString["sMes"].ToString();
                return;
            }
            else
            {
                var id = Convert.ToInt32(Request.QueryString["id"]);
                //Obteniendo la informacion Completa del Alumno
                var cargo = unidadDeTrabajo.cargo.Get(id);
                CmbTipo_id.Text = cargo.tipo_id.ToString();
                TxtDetalle.Text = cargo.descripcio;
                TxtSad.Text = cargo.sad;
                TxtDsi.Text = cargo.dsi;
                TxtDma.Text = cargo.dma;
                TxtRmf.Text = cargo.rmf;
                HFId.Value = cargo.Id.ToString();
                Session["Año"] = cargo.anio;
                Session["Mes"] = cargo.mes;
            }
        }
        private long Guardar()
        {
            if (ValidaGrabarCargo())
            {
                if (string.IsNullOrWhiteSpace(HFId.Value))  //Nuevo
                {
                    var cargo = new Cargo()
                    {
                        anio = Request.QueryString["sAño"].ToString(),
                        mes = Request.QueryString["sMes"].ToString(),
                        tipo_id = CmbTipo_id.Text,
                        descripcio = TxtDetalle.Text,
                        sad = TxtSad.Text,
                        dsi = TxtDsi.Text,
                        dma = TxtDma.Text,
                        rmf = TxtRmf.Text
                    };
                    var NuevoId = unidadDeTrabajo.cargo.Insert(cargo);
                    return NuevoId;
                }
                else //Edicion
                {
                    //Obtener el Objeto de base de datos a Actualizar
                    long nRegistro = Convert.ToInt32(HFId.Value);
                    var cargo = unidadDeTrabajo.cargo.Get(nRegistro);
                    //Hacemos los cambios en los campos que queremos 
                    cargo.tipo_id = CmbTipo_id.Text;
                    cargo.descripcio = TxtDetalle.Text;
                    cargo.sad = TxtSad.Text;
                    cargo.dsi = TxtDsi.Text;
                    cargo.dma = TxtDma.Text;
                    cargo.rmf = TxtRmf.Text;

                    //Obtener el objeto de BD nuevamente 
                    var resultado = unidadDeTrabajo.cargo.Update(cargo);
                    if (!resultado)
                        nRegistro = 0;
                    return nRegistro;
                }
            }
            else
            {
                return 0;
            }
        }
        private bool ValidaGrabarCargo()
        {
            var bSalida = true;
            if (string.IsNullOrWhiteSpace(TxtDetalle.Text) || string.IsNullOrWhiteSpace(TxtSad.Text) || string.IsNullOrWhiteSpace(TxtDsi.Text) || string.IsNullOrWhiteSpace(TxtDma.Text) || string.IsNullOrWhiteSpace(TxtRmf.Text))
            {
                bSalida = false;
                Response.Write("<script>alert('No puede dejar ningun dato en blanco')</script>");
            }
            return bSalida;
        }

        protected void BtnCancelar_Click(object sender, EventArgs e)
        {
            Response.Redirect("FrmCargos.aspx");
        }
    }
}