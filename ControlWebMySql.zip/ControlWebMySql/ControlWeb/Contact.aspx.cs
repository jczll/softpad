﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;

namespace ControlWeb
{
    public partial class Contact : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            //Creamos el objeto Xml
            XmlDocument XmlDoc = new XmlDocument();
            //Creamos la Etiqueta Raiz
            XmlElement raiz = XmlDoc.CreateElement("Actualizacion");
            XmlDoc.AppendChild(raiz);
            //Creamos la Primera Familia
            XmlElement eCabecera = XmlDoc.CreateElement("Cabecera");
            raiz.AppendChild(eCabecera);
              //Creamos la Primera Etiqueta Hija
              XmlElement eId = XmlDoc.CreateElement("ID");
                         eId.AppendChild(XmlDoc.CreateTextNode("El Hobbit"));
                         eCabecera.AppendChild(eId);
              //Creamos la Segunda Etiqueta Hija
              XmlElement eFech_Crea = XmlDoc.CreateElement("FechaCreacion");
                         eFech_Crea.AppendChild(XmlDoc.CreateTextNode("15/01/2018"));
                         eCabecera.AppendChild(eFech_Crea);
             //Creamos la Tercera Etiqueta Hija
             XmlElement eEmpleado = XmlDoc.CreateElement("Empleado");
                        eEmpleado.AppendChild(XmlDoc.CreateTextNode("MARCOS TUESTA"));
                        eCabecera.AppendChild(eEmpleado);
             //Creamos la Tercera Etiqueta Hija
             XmlElement eTipo_act = XmlDoc.CreateElement("TipoActualizacion");
                        eTipo_act.AppendChild(XmlDoc.CreateTextNode("ACTUALIZACION DE EJECUTABLE"));
                        eCabecera.AppendChild(eTipo_act);
             //Creamos la Tercera Etiqueta Hija
             XmlElement eTitulo = XmlDoc.CreateElement("Titulo");
                        eTitulo.AppendChild(XmlDoc.CreateTextNode("MODIFICACION DEL EJECUTABLE X ERROR"));
                        eCabecera.AppendChild(eTitulo);
             //Creamos la Tercera Etiqueta Hija
             string wDetalle = @"jama podre olvidar la noche que te vese 
                                    Yo no se si esto es importante porque vamos a estudiar con la Fabi
                                    Empezemos otra vez el repazo ";
             XmlElement eDetalle = XmlDoc.CreateElement("Detalle");
                        eDetalle.AppendChild(XmlDoc.CreateTextNode(wDetalle));
                        eCabecera.AppendChild(eDetalle);
            //Creamos la Segunda Familiar
            XmlElement eAdjuntos = XmlDoc.CreateElement("ArchivosAdjuntos");
            raiz.AppendChild(eAdjuntos);
            //Creamos la Primera Etiqueta Hija
              XmlElement eArch_Zip = XmlDoc.CreateElement("Archivo_Zip");
                         eArch_Zip.AppendChild(XmlDoc.CreateTextNode("sadsql.zip"));
                         eAdjuntos.AppendChild(eArch_Zip);

            ////Creamos la Primera Familia
            //XmlElement libro1 = XmlDoc.CreateElement("libro");
            //raiz.AppendChild(libro1);
            ////Creamos la Primera Etiqueta Hija
            //XmlElement Titulo1 = XmlDoc.CreateElement("Titulo");
            //Titulo1.AppendChild(XmlDoc.CreateTextNode("El Señor de los Anillos"));
            //libro1.AppendChild(Titulo1);
            ////Creamos la Segunda Etiqueta Hija
            //XmlElement precio1 = XmlDoc.CreateElement("Precio");
            //precio1.AppendChild(XmlDoc.CreateTextNode("55.01"));
            //libro1.AppendChild(precio1);
            ////Creamos la Tercera Etiqueta Hija
            //XmlElement Cantidad1 = XmlDoc.CreateElement("Cantidad");
            //Cantidad1.AppendChild(XmlDoc.CreateTextNode("958"));
            //libro1.AppendChild(Cantidad1);
            var ArchivoCrear = DateTime.Now.ToString("yyyymmdd");
            XmlDoc.Save("C:/estctr/ACT"+ ArchivoCrear+".xml");
        }
    }
}