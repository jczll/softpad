﻿using Control.AccesoDatos;
using Control.Entidades;
using Control.Interfaz;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ControlWeb
{
    public partial class FrmActualizacion : PaginaBase
    {
        public FrmActualizacion()
        {
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            base.IsAutenticate();
            if (!Page.IsPostBack)
            {
                OcultaElementos(0);
                ConsultarActualizacion(DateTime.Now.ToString("yyyy"), Convert.ToInt32(DateTime.Now.Month.ToString()));
            }
        }
        protected void BtnConsultar_Click(object sender, EventArgs e)
        {
            ConsultarActualizacion(CmbAño.Text, Convert.ToInt32(CmbMes.Text));
        }
        protected void CmbCriterio_SelectedIndexChanged(object sender, EventArgs e)
        {
            OcultaElementos(CmbCriterio.SelectedIndex);
        }
        protected void BtnNuevo_Click(object sender, EventArgs e)
        {
            {
                Response.Redirect("FrmEditaActualizacion.aspx");
            }
        }
        private void OcultaElementos(int IElemento)
        {
            switch (IElemento)
            {
                case 0:
                    lblAño.Visible = true;
                    CmbAño.Visible = true;
                    LblMes.Visible = true;
                    CmbMes.Visible = true;
                    LblTipo_act.Visible = false;
                    CmbTipo_act.Visible = false;
                    LblBuscar.Visible = false;
                    TxtBuscar.Visible = false;
                    break;
                case 1:
                    lblAño.Visible = false;
                    CmbAño.Visible = false;
                    LblMes.Visible = false;
                    CmbMes.Visible = false;
                    LblTipo_act.Visible = true;
                    CmbTipo_act.Visible = true;
                    LblBuscar.Visible = false;
                    TxtBuscar.Visible = false;
                    break;
                case 2:
                    lblAño.Visible = false;
                    CmbAño.Visible = false;
                    LblMes.Visible = false;
                    CmbMes.Visible = false;
                    LblTipo_act.Visible = false;
                    CmbTipo_act.Visible = false;
                    LblBuscar.Visible = true;
                    TxtBuscar.Visible = true;
                    break;
            }
        }
        private void ConsultarActualizacion(string sAño, int iMes)
        {
            List<ActualizacionR> data;
            switch (CmbCriterio.SelectedIndex)
            {
                case 1:
                    data = unidadDeTrabajo.RepositorioActualizacion.ConsultaActualizacionXTipo_Act(CmbTipo_act.Text);
                    break;
                case 2:
                    data = unidadDeTrabajo.RepositorioActualizacion.ConsultaActualizacionXId(Convert.ToInt32(TxtBuscar.Text));
                    break;
                default:
                    var sNumeroMes = "";
                    if (iMes < 10)
                        sNumeroMes = $"0{Convert.ToString(iMes)}";
                    else
                        sNumeroMes = Convert.ToString(iMes);
                    data = unidadDeTrabajo.RepositorioActualizacion.ConsultaActualizacionXFecha(sAño, sNumeroMes);
                    break;
            }
            foreach (var item in data)
            {
                item.detalle = CreaCadenaArchivos(item.Id);
            }
            GrdTablas.DataSource = data;
            GrdTablas.DataBind();
        }
        private string CreaCadenaArchivos(int iId)
        {
            string sCadenaArchivos = "";
            var lista = unidadDeTrabajo.RepositorioActualizacion_zip.ConsultaActualizacion_zipXActId(iId);
            foreach (var item in lista)
            {
                sCadenaArchivos = sCadenaArchivos + Path.GetFileName(item.arch_zip) + ",";
            }
            return sCadenaArchivos;
        }

        protected void GrdTablas_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            GrdTablas.PageIndex = e.NewPageIndex;
            ConsultarActualizacion(CmbAño.Text, Convert.ToInt32(CmbMes.Text));
        }
        protected void GrdTablas_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void GrdTablas_SelectedIndexChanging1(object sender, GridViewSelectEventArgs e)
        {
            GridViewRow gr = GrdTablas.SelectedRow;
            var iId = gr.Cells[1].Text;
        }
    }
}