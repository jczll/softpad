﻿using Control.AccesoDatos;
using Control.Entidades;
using Control.Interfaz;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ControlWeb
{
    public partial class FrmActualizacion : PaginaBase
    {
        public FrmActualizacion()
        {
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            base.IsAutenticate();
            if (!Page.IsPostBack)
            {
                LlenaDropDownList();
                HaibilitaCtriterios(1);
                ConsultarActualizacion(DateTime.Now.ToString("yyyy"), Convert.ToInt32(DateTime.Now.Month.ToString()));
            }
        }
        private void LlenaDropDownList()
        {
            //Año de Actualizacion
            DrpAño.DataSource = unidadDeTrabajo.actualizacion.ConsultaDatos("select distinct year(fech_crea) as Expr1 from actualizacion order by 1 desc");
            DrpAño.DataTextField = "Expr1";
            DrpAño.DataValueField = "Expr1";
            DrpAño.DataBind();
            //Mes de Actualizacion:
            DrpMes.DataSource = unidadDeTrabajo.actualizacion.ConsultaDatos("select distinct ta44.mes, ta44.id from actualizacion left outer join bdSoftpad_ctr_tablas.TA44 AS ta44 ON ta44.id = month(actualizacion.fech_crea) order by ta44.id desc");
            DrpMes.DataTextField = "mes";
            DrpMes.DataValueField = "id";
            DrpMes.SelectedValue = DateTime.Now.Month.ToString();
            DrpMes.DataBind();
            //Tipo de Actualizacion:
            DrpTipo_act.DataSource = unidadDeTrabajo.actualizacion.ConsultaDatos("select codigo,descripcio from bdSoftpad_ctr_tablas.ta43 order by descripcio");
            DrpTipo_act.DataTextField = "descripcio";
            DrpTipo_act.DataValueField = "codigo";
            DrpTipo_act.DataBind();
        }
        protected void BtnConsultar_Click(object sender, EventArgs e)
        {
            ConsultarActualizacion(DrpAño.Text, Convert.ToInt32(DrpMes.Text));
        }
        protected void BtnNuevo_Click(object sender, EventArgs e)
        {
            {
                Response.Redirect("FrmEditaActualizacion.aspx");
            }
        }
        private void ConsultarActualizacion(string sAño, int iMes)
        {
            List<ActualizacionR> data;
            if (ChkTipo_act.Checked)
                data = unidadDeTrabajo.RepositorioActualizacion.ConsultaActualizacionXTipo_Act(DrpTipo_act.Text);
            else
            {
                if (ChkNro_actualizacion.Checked)
                    data = unidadDeTrabajo.RepositorioActualizacion.ConsultaActualizacionXId(Convert.ToInt32(TxtBuscar.Text));
                else
                {
                    var sNumeroMes = "";
                    if (iMes < 10)
                        sNumeroMes = $"0{Convert.ToString(iMes)}";
                    else
                        sNumeroMes = Convert.ToString(iMes);
                    data = unidadDeTrabajo.RepositorioActualizacion.ConsultaActualizacionXFecha(sAño, sNumeroMes);
                }
            }
            foreach (var item in data)
            {
                item.detalle = CreaCadenaArchivos(item.Id);
            }
            GrdTablas.DataSource = data;
            GrdTablas.DataBind();
        }
        private string CreaCadenaArchivos(int iId)
        {
            string sCadenaArchivos = "";
            var lista = unidadDeTrabajo.RepositorioActualizacion_zip.ConsultaActualizacion_zipXActId(iId);
            foreach (var item in lista)
            {
                sCadenaArchivos = sCadenaArchivos + Path.GetFileName(item.arch_zip) + ",";
            }
            return sCadenaArchivos;
        }

        protected void GrdTablas_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            GrdTablas.PageIndex = e.NewPageIndex;
            ConsultarActualizacion(DrpAño.Text, Convert.ToInt32(DrpMes.Text));
        }
        protected void GrdTablas_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void GrdTablas_SelectedIndexChanging1(object sender, GridViewSelectEventArgs e)
        {
            GridViewRow gr = GrdTablas.SelectedRow;
            var iId = gr.Cells[1].Text;
        }

        protected void ChkAño_CheckedChanged(object sender, EventArgs e)
        {
            if (ChkAño.Checked)
               HaibilitaCtriterios(1);
            else
               HaibilitaCtriterios(2);
        }

        protected void ChkTipo_act_CheckedChanged(object sender, EventArgs e)
        {
            if (ChkTipo_act.Checked)
               HaibilitaCtriterios(2);
            else
               HaibilitaCtriterios(1);
        }
        protected void ChkNro_actualizacion_CheckedChanged(object sender, EventArgs e)
        {
            if (ChkNro_actualizacion.Checked)
               HaibilitaCtriterios(3);
            else
               HaibilitaCtriterios(1);
        }
        private void HaibilitaCtriterios(int IElemento)
        {
            switch (IElemento)
            {
                case 1:
                    ChkAño.Checked = true;
                    DrpAño.Enabled = true;
                    DrpMes.Enabled = true;
                    ChkTipo_act.Checked = false;
                    DrpTipo_act.Enabled = false;
                    ChkNro_actualizacion.Checked = false;
                    TxtBuscar.Enabled = false;
                    break;
                case 2:
                    ChkAño.Checked = false;
                    DrpAño.Enabled = false;
                    DrpMes.Enabled = false;
                    ChkTipo_act.Checked = true;
                    DrpTipo_act.Enabled = true;
                    ChkNro_actualizacion.Checked = false;
                    TxtBuscar.Enabled = false;
                    break;
                case 3:
                    ChkAño.Checked = false;
                    DrpAño.Enabled = false;
                    DrpMes.Enabled = false;
                    ChkTipo_act.Checked = false;
                    DrpTipo_act.Enabled = false;
                    ChkNro_actualizacion.Checked = true;
                    TxtBuscar.Enabled = true;
                    break;
            }
        }
        //protected void CmbCriterio_SelectedIndexChanged(object sender, EventArgs e)
        //{
        //    OcultaElementos(CmbCriterio.SelectedIndex);
        //}
    }
}