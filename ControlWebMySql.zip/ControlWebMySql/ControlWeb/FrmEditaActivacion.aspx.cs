﻿using Control.Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ControlWeb
{
    public partial class FrmEditaActivacion : PaginaBase
    {
        public FrmEditaActivacion()
        {
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                base.IsAutenticate();
                Session["Historico"] = null;
                ObtenerDetalleActivacion();
            }
        }
        private void ObtenerDetalleActivacion()
        {
            if (!String.IsNullOrWhiteSpace(Request.QueryString["cod_cli"]))
            {
                var sCod_cli = Request.QueryString["cod_cli"];
                //Obteniendo la informacion Completa del Alumno
                var cliente_activacion = unidadDeTrabajo.RepositorioCliente_activacion.ConsultaAcitvacionPendienteDetallada(sCod_cli);
                TxtCod_cli.Text = "(" + cliente_activacion.cod_cli + ") " + cliente_activacion.raz_soc_cli;
                TxtCod_sistema.Text = "(" + cliente_activacion.cod_sistema + ") " + cliente_activacion.des_sistema;
                Txtcod_agte.Text = cliente_activacion.cod_agte;
                TxtServidor.Text = cliente_activacion.servidor;
                TxtUsuario_pc.Text = cliente_activacion.usuario_pc;
                TxtFech_activa.Text = cliente_activacion.fech_activa.ToString();
                ObtenerHistoricoServidores(sCod_cli);
            }
        }
        private void ObtenerHistoricoServidores(string sCod_cli)
        {
            List<Cliente_contrato_Servidores> data;
            data = unidadDeTrabajo.RepositorioCliente_activacion.ConsultaServidoresxCliente(sCod_cli);
            GrdServidores.DataSource = data;
            GrdServidores.DataBind();
        }
        protected void BtnActivar_Click(object sender, EventArgs e)
        {
            if(ActivarCliente(Request.QueryString["cod_cli"]))
               Response.Write("<script>alert('Activacion Realizada en forma Existosa ')</script>");
            else
               Response.Write("<script>alert('No se puede activar este Servidor')</script>");
        }

        protected void BtnRetornar_Click(object sender, EventArgs e)
        {
           Response.Redirect("FrmActivacion");
        }
        private bool ActivarCliente(string sCod_cli)
        {
            bool bActivar = true;
            int iIdServdorAnt = 0;
            var cliente_contrato = unidadDeTrabajo.RepositorioCliente_activacion.ConsultaContratoVigente(sCod_cli);
            if(!String.IsNullOrWhiteSpace(cliente_contrato.cod_cli))
            {
                List<Cliente_contrato_Servidores> data;
                data = unidadDeTrabajo.RepositorioCliente_activacion.ConsultaServidoresxCliente(sCod_cli);
                foreach (var item in data)
                {
                    if(item.activo)
                    {
                        if(item.servidor!=TxtServidor.Text)
                        {
                            iIdServdorAnt = Convert.ToInt32(item.id);
                        }
                        else
                        {
                            Response.Write("<script>alert('El Servidor ya tiene ese numero de Servidor Activo')</script>");
                            bActivar = false;
                        }
                    }
                }
                if (bActivar)
                {
                    if (cliente_contrato.cod_agte != Txtcod_agte.Text)
                    {
                        Response.Write("<script>alert('El Codigo de Agente no corresponde al Cliente Asignado')</script>");
                    }
                    else
                    {
                        String[] ASistemas = new String[2];
                        switch (cliente_contrato.cod_sistema)
                        {
                            case "SD1":
                                ASistemas[0] = "SAD";
                                ASistemas[1] = "VTA";
                                break;
                            case "SD2":
                            case "SD3":
                            case "SD4":
                                ASistemas[0] = "SAD";
                                ASistemas[1] = "CTE";
                                break;
                            default:
                                ASistemas[0] = cliente_contrato.cod_sistema;
                                break;
                        }
                        var sSistema = "";
                        var sSistema1 = "";
                        bActivar = false;
                        foreach (var item in ASistemas)
                        {
                            sSistema = item.ToString().Trim();
                            sSistema1 = TxtCod_sistema.Text.Substring(1, 3);
                            if (sSistema == sSistema1)
                            {
                                bActivar = true;
                            }
                        }
                        if (bActivar)
                        {
                            if (DesactivaServidorAnt(iIdServdorAnt))
                            {
                                ActivaServidorNuevo(cliente_contrato.contrato_correl);
                            }
                        }
                        else
                        {
                            Response.Write("<script>alert('El Sistema a Activar no corresponde al Servicio Contratado ')</script>");
                        }
                    }
                }
            }
            else
            {
                Response.Write("<script>alert('Cliente no tiene Contrato Vigente')</script>");
                bActivar = false;
            }
            return bActivar;
        }
        private bool ActivaServidorNuevo(string sContrato_correl)
        {
            bool bSalida = false;
            var servidor = new Cliente_contrato_Servidores()
            {
                cod_cli = Request.QueryString["cod_cli"],
                contrato_correl = sContrato_correl,
                servidor = TxtServidor.Text,
                activo = true
            };
            var NuevoId = unidadDeTrabajo.cliente_contrato_Servidores.Insert(servidor);
            if (NuevoId > 0)
            {
                ObtenerHistoricoServidores(Request.QueryString["cod_cli"]);
                unidadDeTrabajo.RepositorioCliente_activacion.ActualizaEstadoActivacionCliente(Request.QueryString["cod_cli"], TxtServidor.Text, "A");
                BtnActivar.Enabled = false;
                bSalida = true;
            }
            return bSalida;
        }
        private bool DesactivaServidorAnt(int iServidorAnt)
        {
            bool bSalida = true;
            if (iServidorAnt > 0)
            {
                var ServidorAnt = unidadDeTrabajo.cliente_contrato_Servidores.Get(iServidorAnt);
                ServidorAnt.activo = false;
                var resultado = unidadDeTrabajo.cliente_contrato_Servidores.Update(ServidorAnt);
                if (!resultado)
                    bSalida = false;
            }
            return bSalida;
        }
    }
}