﻿using Control.AccesoDatos;
using Control.Interfaz;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Optimization;
using System.Web.Routing;
using System.Web.Security;
using System.Web.SessionState;

namespace ControlWeb
{
    public class Global : HttpApplication
    {
        void Application_Start(object sender, EventArgs e)
        {
            // Código que se ejecuta al iniciar la aplicación
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            BundleConfig.RegisterBundles(BundleTable.Bundles);
        }
        void Session_Start(object sender, EventArgs e)
        {
            Session["Sistema"] = "SAD";
            Session["Año"] = DateTime.Now.ToString("yyyy");
            Session["Mes"] = DateTime.Now.Month.ToString().PadLeft(2, '0');
            //Si el Usuario esta ya autenticado que tome el codigo para buscar su nombre de usuario       
            if (HttpContext.Current.User.Identity.IsAuthenticated)
            {
                BuscaUsuarioIngresado(HttpContext.Current.User.Identity.Name);
                //Variables para el Cargo de Mantenimiento
            }
        }

        private void BuscaUsuarioIngresado(string sCodigo)
        {
            IUnidadDeTrabajo unidadDeTrabajo = new UnidadDeTrabajo(ConfigurationManager.ConnectionStrings["ControlConexion"].ConnectionString);
            var usuario = unidadDeTrabajo.RepositorioUsuarios.ObtenerUsuarioPorCodigo(sCodigo);
            if (usuario.Count > 0)
            {
                foreach (var item in usuario)
                {
                    Application["Usuario_cod"] = item.cod_usuario;
                    Application["Usuario_Nombre"] = item.nombres.Trim() + " " + item.apellidos.Trim();
                }
            }
        }
        //private void BuscaUsuarioIngresado()
        //{
        //    if (File.Exists("c:/inetpub/wwwroot/Usertext.txt"))
        //    {
        //        using (StreamReader LeerUsuario = new StreamReader(@"c:/inetpub/wwwroot/Usertext.txt"))
        //        {
        //            var nLinea = 0;
        //            while (!LeerUsuario.EndOfStream)
        //            {
        //                nLinea++;
        //                string x = LeerUsuario.ReadLine();
        //                if (nLinea == 1)
        //                    Application["Usuario_cod"] = x;
        //                else
        //                    Application["Usuario_Nombre"] = x;
        //            }
        //        }
        //    }
        //}
    }
}