﻿using Control.AccesoDatos;
using Control.Entidades;
using Control.Interfaz;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ControlWeb
{
    public partial class FrmEditaActualizacion : PaginaBase
    {
        public FrmEditaActualizacion()
        {
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                base.IsAutenticate();
                ValidaEditaActualizacion();
                ObtenerActualizacion();
            }
        }
        protected void BtnGuardar_Click(object sender, EventArgs e)
        {
            if (Guardar() > 0)
            {

                ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('Registro Guardado en Forma Satisfactoria');", true);
                Response.Redirect("FrmActualizacion");
                //Response.Write("<script>alert('Registro Guardado en Forma Satisfactoria')</script>");
                //MessageBox.Show("Registro Guardado en forma Satisfactoria", "SOFTPAD", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
                Response.Write("<script>alert('No se pudo guardar el Registro')</script>");
            // MessageBox.Show("No se pudo guardar el Registro ", "SOFTPAD", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        protected void BtnAdjuntar_Click(object sender, EventArgs e)
        {
            if (FileUpload1.PostedFile.FileName != "")
            {
                var id = Convert.ToInt32(Request.QueryString["id"]);
                var archivo = Path.GetFileName(FileUpload1.PostedFile.FileName);
                //var archivo = FileUpload1.PostedFile.FileName;
                //var archivo = FileUpload1.FileName.ToString();
                //var ruta = Path.GetDirectoryName(FileUpload1.PostedFile.FileName);
                //archivo = ruta + "\\" + archivo;
                //Buscamos si el archivo ya existe
                Response.Write("<script>alert(`No se ha seleccionado el objeto a borrar ${archivo}`)</script>");
                bool bExisteArchivo = false;
                foreach (var item in LstArchivos.Items)
                {
                    if (archivo == item.ToString().Trim())
                        bExisteArchivo = true;
                }
                if (!bExisteArchivo)
                {
                    LstArchivos.Items.Add(archivo);
                    SubirArchivo();
                }
            }
        }
        private void ObtenerActualizacion()
        {
            if (String.IsNullOrWhiteSpace(Request.QueryString["id"]))
            {
                TxtFech_crea.Text = DateTime.Now.ToString();
                TxtCod_emp.Text = Application["Usuario_cod"].ToString();
                return;
            }
            else
            {
                var id = Convert.ToInt32(Request.QueryString["id"]);
                //Obteniendo la informacion Completa del Alumno
                var actualizacion = unidadDeTrabajo.actualizacion.Get(id);
                TxtId.Text = actualizacion.Id.ToString();
                TxtFech_crea.Text = actualizacion.fech_crea.ToString();
                TxtCod_emp.Text = actualizacion.cod_usuario;
                CmbTipo_act.Text = actualizacion.tipo_act;
                CmbVers_act.Text = actualizacion.vers_act;
                TxtTitulo.Text = actualizacion.titulo;
                HFId.Value = actualizacion.Id.ToString();
                TxtDetalle.Text = actualizacion.detalle;
                //Convert.ToBase64String(actualizacion.detalle, 0, actualizacion.detalle.Length);
                var lista = unidadDeTrabajo.RepositorioActualizacion_zip.ConsultaActualizacion_zipXActId(id);
                foreach (var item in lista)
                {
                    LstArchivos.Items.Add(item.arch_zip);
                }
            }
        }
        private long Guardar()
        {
            //var servicio = new MantenimientoService.MantenimientoService1Client();
            if (ValidaTipoActualizacion())
            {
                if (string.IsNullOrWhiteSpace(HFId.Value))  //Nuevo
                {
                    var actualizacion = new Actualizacion()
                    {
                        fech_crea = Convert.ToDateTime(TxtFech_crea.Text),
                        cod_usuario = TxtCod_emp.Text,
                        tipo_act = CmbTipo_act.Text,
                        vers_act = CmbVers_act.Text,
                        titulo = TxtTitulo.Text,
                        detalle = TxtDetalle.Text,
                        enviado1 = false
                    };
                    var NuevoId = unidadDeTrabajo.actualizacion.Insert(actualizacion);
                    if (NuevoId > 0)
                        GuardarAdjuntos(Convert.ToInt32(NuevoId));
                    return NuevoId;
                }
                else //Edicion
                {
                    //Obtener el Objeto de base de datos a Actualizar
                    long nRegistro = Convert.ToInt32(HFId.Value);
                    var actualizacion = unidadDeTrabajo.actualizacion.Get(nRegistro);
                    //Hacemos los cambios en los campos que queremos 
                    actualizacion.cod_usuario = TxtCod_emp.Text;
                    actualizacion.tipo_act = CmbTipo_act.Text;
                    actualizacion.vers_act = CmbVers_act.Text;
                    actualizacion.titulo = TxtTitulo.Text;
                    actualizacion.detalle = TxtDetalle.Text;
                    //Obtener el objeto de BD nuevamente 
                    var resultado = unidadDeTrabajo.actualizacion.Update(actualizacion);
                    if (!resultado)
                        nRegistro = 0;
                    else
                        GuardarAdjuntos(Convert.ToInt32(nRegistro));
                    return nRegistro;
                }
            }
            else
            {
                return 0;
            }
        }
        private bool ValidaTipoActualizacion()
        {
            var bSalida = true;
            String[] Arch_zips = new String[5];
            switch (CmbTipo_act.Text)
            {
                case "2":
                    Arch_zips[0] = "tamex.zip";
                    break;
                case "3":
                    Arch_zips[0] = "factor.zip";
                    break;
                case "4":
                    Arch_zips[0] = "especif.zip";
                    break;
                default:
                    Arch_zips[0] = "sadsql5.zip";
                    Arch_zips[1] = "tabnue.zip";
                    Arch_zips[2] = "sistema.zip";
                    Arch_zips[3] = "mem.zip";
                    Arch_zips[4] = "aduanas.zip";
                    break;
            }
            var ArchEnList = "";
            foreach (var item in LstArchivos.Items)
            {
                ArchEnList=item.ToString().Trim();
                if (!ValidaArchivoAdjunto(Arch_zips, ArchEnList))
                {
                    Response.Write("<script>alert('El Archivo no corresponde al Tipo de Actualizacion especificada ')</script>");
                    bSalida = false;
                }
            }
            return bSalida;
        }
        private bool ValidaArchivoAdjunto(String[] aArch_zips, string sArchEnList)
        {
            int i;
            string Arch_zip;
            var bSalida = false;
            for (i = 0; i < aArch_zips.Count(); i++)
            {
                Arch_zip = aArch_zips[i];
                if (Arch_zip == sArchEnList)
                {
                    bSalida = true;
                    break;
                }
            }
            return bSalida;
        }
        private void GuardarAdjuntos(int iId)
        {
            foreach (var item in LstArchivos.Items)
            {
                //Buscamos si el archivo ya existe
                var resultado = unidadDeTrabajo.RepositorioActualizacion_zip.ConsultaActualizacion_zipXArchivo(iId, item.ToString());
                if (resultado.Count == 0)
                {
                    //Si no existe lo agregamos
                    Actualizacion_zip actualizacion_zip = new Actualizacion_zip() { ActId = iId, arch_zip = item.ToString() };
                    var NuevoId = unidadDeTrabajo.actualizacion_zip.Insert(actualizacion_zip);
                }
            }
        }
        private void EliminarAdjunto()
        {
            if (LstArchivos.SelectedItem != null)
            {
                //Buscamos si el Registro ya fue grabado en la Base de Datos
                if(String.IsNullOrWhiteSpace(TxtId.Text))
                {
                    TxtId.Text = "0";
                }
                var resultado = unidadDeTrabajo.RepositorioActualizacion_zip.ConsultaActualizacion_zipXArchivo(Convert.ToInt32(TxtId.Text), LstArchivos.SelectedItem.ToString());

                if (resultado.Count > 0)
                {
                    //Si ya esta Grabado procedemos a Buscarlo para poder borrarlo
                    foreach (var item in resultado)
                    {
                        var actualizacion_zip = unidadDeTrabajo.actualizacion_zip.Get(item.Id);
                        //Borramos el Registro
                        var ResultadoEliminar = unidadDeTrabajo.actualizacion_zip.Delete(actualizacion_zip);
                        if (ResultadoEliminar)
                        {
                            LstArchivos.Items.RemoveAt(Convert.ToInt32(LstArchivos.SelectedIndex));
                        }
                    }
                }
                else
                {
                    //Si no ha sido grabado solo lo borramos del ListBox
                    LstArchivos.Items.RemoveAt(Convert.ToInt32(LstArchivos.SelectedIndex));
                }
            }
            else
            {
                Response.Write("<script>alert('No se ha seleccionado el objeto a borrar ')</script>");
                //MessageBox.Show("No se ha seleccionado el objeto a borrar ", "SOFTPAD", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        protected void BtnEliminaAdjunto_Click(object sender, EventArgs e)
        {
            EliminarAdjunto();
        }

        protected void BtnCancelar_Click(object sender, EventArgs e)
        {
            Response.Redirect("FrmActualizacion");
        }
        private bool ValidaEditaActualizacion()
        {
            var id = Convert.ToInt32(Request.QueryString["id"]);
            if (unidadDeTrabajo.RepositorioActualizacion.EvaluaActualizacionEnviada(id))
            {
                //Response.Write("<script>alert('La actualizacion ya ha sido enviada ')</script>");
                ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('La actualizacion ya ha sido enviada');", true);
                //MessageBox.Show("La actualizacion ya ha sido enviada ", "SOFTPAD", MessageBoxButtons.OK,MessageBoxIcon.Error);
                Response.Redirect("FrmActualizacion");
            }
            return true;
        }
        private void SubirArchivo()
        {
            //Primero verificamos que se haya seleccionado el Archivo 
            if (FileUpload1.HasFile)
            {
                //Obtenemos la extension y el tamaño del archivo para delimitar si fuera necesario                     
                string ext = System.IO.Path.GetExtension(FileUpload1.FileName);
                ext = ext.ToLower();
                //Ojo el tamaño esta en Bytes
                int tamaño = FileUpload1.PostedFile.ContentLength;

                Response.Write(ext + "," + tamaño);
                //Procederemos llevar a cabo la verificacion de la extensio y el tamaño
                if (ext == ".zip" && tamaño <= 11485700)
                {
                    if (CmbTipo_act.Text == "2" || CmbTipo_act.Text == "3" || CmbTipo_act.Text == "4")
                        FileUpload1.SaveAs(Server.MapPath("~/Subidos/util_sql/" + FileUpload1.FileName));
                    else
                        if (CmbVers_act.Text == "1")
                           FileUpload1.SaveAs(Server.MapPath("~/Subidos/0SQLABR200603/" + FileUpload1.FileName));
                        else
                           FileUpload1.SaveAs(Server.MapPath("~/Subidos/0SQLMAR200503/" + FileUpload1.FileName));
                    Response.Write("Se subio el archivo");
                }
            }
            else
            {
                Response.Write("No se ha subido ningun Archivo");
            }
        }
    }
}