﻿using Control.Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ControlWeb
{
    public partial class FrmEditaVisita : PaginaBase
    {
        public FrmEditaVisita()
        {
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            base.IsAutenticate();
            if (!Page.IsPostBack)
            {
                LlenaDropDownList();
                ObtenerDetalleVisita();
            }           
        }
        private void LlenaDropDownList()
        {
            //TIPO_DESTINO
            DrpTipo_destino.DataSource = unidadDeTrabajo.visitas.ConsultaDatos("SELECT descripcio, codigo FROM bdsoftpad_ctr_tablas.ta19");
            DrpTipo_destino.DataTextField = "Descripcio";
            DrpTipo_destino.DataValueField = "codigo";
            DrpTipo_destino.DataBind();
            //COD_CLI":
            DrpCod_cli.DataSource = unidadDeTrabajo.visitas.ConsultaDatos(Application["SqlCliente"].ToString());
            DrpCod_cli.DataTextField = "raz_soc_cli";
            DrpCod_cli.DataValueField = "cod_cli";
            DrpCod_cli.DataBind();
            //COD_SISTEMA":
            DrpCod_sistema.DataSource = unidadDeTrabajo.visitas.ConsultaDatos("Select des_sistema, cod_sistema from sistema");
            DrpCod_sistema.DataTextField = "des_sistema";
            DrpCod_sistema.DataValueField = "cod_sistema";
            DrpCod_sistema.DataBind();
            //TIPO_VISITA":
            DrpTipo_visita.DataSource = unidadDeTrabajo.visitas.ConsultaDatos("SELECT descripcio, codigo from bdsoftpad_ctr_tablas.ta20 where codigo<>'MNT'");
            DrpTipo_visita.DataTextField = "Descripcio";
            DrpTipo_visita.DataValueField = "codigo";
            DrpTipo_visita.DataBind();
            //COD_EMP":
            var sSql = Application["SqlEmpleado"].ToString() + " and EmpN.cod_tip_emp='C'";
            DrpCod_emp.DataSource = unidadDeTrabajo.visitas.ConsultaDatos(sSql);
            DrpCod_emp.DataTextField = "des_empleado";
            DrpCod_emp.DataValueField = "cod_emp";
            DrpCod_emp.DataBind();
            //SERVICIO MENSUAL
            DrpServ_mensual.DataSource = unidadDeTrabajo.visitas.ConsultaDatos("select descripcio, codigo FROM bdsoftpad_ctr_tablas.ta22");
            DrpServ_mensual.DataTextField = "Descripcio";
            DrpServ_mensual.DataValueField = "codigo";
            DrpServ_mensual.DataBind();
        }
        private void ObtenerDetalleVisita()
        {
            if (String.IsNullOrWhiteSpace(Request.QueryString["id"]))
            {                
                TxtNro_visita.Text= unidadDeTrabajo.visitas.ActualizaCorrelativo("vnro_visita","",7);
                DrpTipo_destino.Text = "C";
                DrpCod_emp.Text = "";
                DrpCod_cli.Text = "";
                TxtContrato_correl.Text = "";
                TxtNro_requerimiento.Text = "";
                DrpCod_sistema.Text = "SAD";
                TxtObservac.Text = "";
                DrpTipo_visita.Text = "";
                DrpServ_mensual.Text = "";
                TxtNro_cotizacion.Text = "";
                TxtFech_visita.Text = DateTime.Now.ToString();
                return;
            }
            else
            {
                var id = Convert.ToInt32(Request.QueryString["id"]);
                //Obteniendo la informacion Completa del Alumno
                var visitas = unidadDeTrabajo.visitas.Get(id);
                DrpTipo_destino.Text = visitas.tipo_destino;
                DrpCod_emp.Text = visitas.cod_emp;
                DrpCod_cli.Text = visitas.cod_cli;
                TxtContrato_correl.Text = visitas.contrato_correl;
                TxtNro_requerimiento.Text = visitas.nro_requerimiento;
                DrpCod_sistema.Text = visitas.cod_sistema;
                TxtObservac.Text = visitas.observac;
                DrpTipo_visita.Text = visitas.tipo_visita;
                DrpServ_mensual.Text = visitas.serv_mensual;
                TxtNro_cotizacion.Text = visitas.nro_cotizacion;
                TxtFech_visita.Text = unidadDeTrabajo.RepositorioVisitas.DatoIncidenciaVisita(id);
                HFId.Value = visitas.Id.ToString();
            }
        }
        private long Guardar()
        {
            if (ValidaGrabarCargo())
            {
                if (string.IsNullOrWhiteSpace(HFId.Value))  //Nuevo
                {
                    var visitas = new Visitas()
                    {
                        nro_visita        = TxtNro_visita.Text,
                        tipo_destino      = DrpTipo_destino.Text,
                        cod_emp           = DrpCod_emp.Text,
                        cod_cli           = DrpCod_cli.Text,
                        contrato_correl   = TxtContrato_correl.Text,
                        nro_requerimiento = TxtNro_requerimiento.Text,
                        cod_sistema       = DrpCod_sistema.Text,
                        observac          = TxtObservac.Text,
                        tipo_visita       = DrpTipo_visita.Text,
                        serv_mensual      = DrpServ_mensual.Text,
                        nro_cotizacion    = TxtNro_cotizacion.Text
                    };
                    var NuevoId = unidadDeTrabajo.visitas.Insert(visitas);
                    return NuevoId;
                }
                else //Edicion
                {
                    //Obtener el Objeto de base de datos a Actualizar
                    long nRegistro = Convert.ToInt32(HFId.Value);
                    var visitas = unidadDeTrabajo.visitas.Get(nRegistro);
                    //Hacemos los cambios en los campos que queremos 
                    visitas.tipo_destino = DrpTipo_destino.Text;
                    visitas.cod_emp = DrpCod_emp.Text;
                    visitas.cod_cli = DrpCod_cli.Text;
                    visitas.contrato_correl = TxtContrato_correl.Text;
                    visitas.nro_requerimiento = TxtNro_requerimiento.Text;
                    visitas.cod_sistema = DrpCod_sistema.Text;
                    visitas.observac = TxtObservac.Text;
                    visitas.tipo_visita = DrpTipo_visita.Text;
                    visitas.serv_mensual = DrpServ_mensual.Text;
                    visitas.nro_cotizacion = TxtNro_cotizacion.Text;
                    //Obtener el objeto de BD nuevamente 
                    var resultado = unidadDeTrabajo.visitas.Update(visitas);
                    if (!resultado)
                        nRegistro = 0;
                    return nRegistro;
                }
            }
            else
            {
                return 0;
            }
        }
        private bool ValidaGrabarCargo()
        {
            var bSalida = true;
            if (string.IsNullOrWhiteSpace(TxtNro_visita.Text) || string.IsNullOrWhiteSpace(DrpCod_cli.Text) || string.IsNullOrWhiteSpace(DrpCod_emp.Text) || string.IsNullOrWhiteSpace(DrpServ_mensual.Text) || string.IsNullOrWhiteSpace(TxtFech_visita.Text))
            {
                bSalida = false;
                Response.Write("<script>alert('No se ha llenado campos que son obligatorios')</script>");
            }
            return bSalida;
        }
        protected void BtnCancelar_Click(object sender, EventArgs e)
        {
            Response.Redirect("FrmVisitas.aspx");
        }

        protected void BtnGuardar_Click(object sender, EventArgs e)
        {

        }

        protected void DrpCod_cli_SelectedIndexChanged(object sender, EventArgs e)
        {
            var sCod_cli = DrpCod_cli.SelectedValue;
            TxtContrato_correl.Text = "001";
            DrpCod_sistema.Text = "DSI";
         }
    }
}