﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ControlWeb
{
    public partial class FrmEditaVisita : PaginaBase
    {
        public FrmEditaVisita()
        {
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            base.IsAutenticate();
            if (!Page.IsPostBack)
            {
                LlenaDropDownList();
                ObtenerDetalleVisita();
            }           
        }
        private void LlenaDropDownList()
        {
            //TIPO_DESTINO
            DrpTipo_destino.DataSource = unidadDeTrabajo.RepositorioVisitas.ConsultaDatos("SELECT descripcio, codigo FROM bdsoftpad_ctr_tablas.ta19");
            DrpTipo_destino.DataTextField = "Descripcio";
            DrpTipo_destino.DataValueField = "codigo";
            DrpTipo_destino.DataBind();
            //COD_CLI":
            DrpCod_cli.DataSource = unidadDeTrabajo.RepositorioVisitas.ConsultaDatos(Application["SqlCliente"].ToString());
            DrpCod_cli.DataTextField = "raz_soc_cli";
            DrpCod_cli.DataValueField = "cod_cli";
            DrpCod_cli.DataBind();
            //COD_SISTEMA":
            DrpCod_sistema.DataSource = unidadDeTrabajo.RepositorioVisitas.ConsultaDatos("Select des_sistema, cod_sistema from sistema");
            DrpCod_sistema.DataTextField = "des_sistema";
            DrpCod_sistema.DataValueField = "cod_sistema";
            DrpCod_sistema.DataBind();
            //TIPO_VISITA":
            DrpTipo_visita.DataSource = unidadDeTrabajo.RepositorioVisitas.ConsultaDatos("SELECT descripcio, codigo from bdsoftpad_ctr_tablas.ta20 where codigo<>'MNT'");
            DrpTipo_visita.DataTextField = "Descripcio";
            DrpTipo_visita.DataValueField = "codigo";
            DrpTipo_visita.DataBind();
            //COD_EMP":
            DrpCod_emp.DataSource = unidadDeTrabajo.RepositorioVisitas.ConsultaDatos(Application["SqlEmpleado"].ToString());
            DrpCod_emp.DataTextField = "des_empleado";
            DrpCod_emp.DataValueField = "cod_emp";
            DrpCod_emp.DataBind();
            //SERVICIO MENSUAL
            DrpServ_mensual.DataSource = unidadDeTrabajo.RepositorioVisitas.ConsultaDatos("select descripcio, codigo FROM bdsoftpad_ctr_tablas.ta22");
            DrpServ_mensual.DataTextField = "Descripcio";
            DrpServ_mensual.DataValueField = "codigo";
            DrpServ_mensual.DataBind();
        }
        private void ObtenerDetalleVisita()
        {
            if (String.IsNullOrWhiteSpace(Request.QueryString["id"]))
            {
                DrpTipo_destino.Text = "C";
                DrpCod_cli.Text = "";
                DrpCod_sistema.Text = "SAD";
                DrpTipo_visita.Text = "";
                DrpCod_emp.Text = "";
                TxtContrato_correl.Text = "";
                TxtNro_cotizacion.Text = "";
                TxtNro_requerimiento.Text = "";
                DrpServ_mensual.Text = "";
                TxtFech_visita.Text = "";
                TxtObservac.Text = "";
                return;
            }
            else
            {
                var id = Convert.ToInt32(Request.QueryString["id"]);
                //Obteniendo la informacion Completa del Alumno
                var visitas = unidadDeTrabajo.visitas.Get(id);
                DrpTipo_destino.Text = visitas.tipo_destino;
                DrpCod_cli.Text = visitas.cod_cli;
                DrpCod_sistema.Text = visitas.cod_sistema;
                DrpTipo_visita.Text = visitas.tipo_visita;
                DrpCod_emp.Text = visitas.cod_emp;
                TxtContrato_correl.Text = visitas.contrato_correl;
                TxtNro_cotizacion.Text = visitas.nro_cotizacion;
                TxtNro_requerimiento.Text = visitas.nro_requerimiento;
                DrpServ_mensual.Text = visitas.serv_mensual;
                //TxtFech_visita.Text = visitas.;
                TxtObservac.Text = visitas.observac;
                HFId.Value = visitas.Id.ToString();
            }
        }

        protected void BtnCancelar_Click(object sender, EventArgs e)
        {
            Response.Redirect("FrmVisitas.aspx");
        }
    }
}