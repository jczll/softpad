﻿using Control.Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ControlWeb
{
    public partial class FrmEditaVisita : PaginaBase
    {
        public FrmEditaVisita()
        {
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            base.IsAutenticate();
            if (!Page.IsPostBack)
            {
                LlenaDropDownList();
                ObtenerDetalleVisita();
            }           
        }
        private void LlenaDropDownList()
        {
            //TIPO_DESTINO
            DrpTipo_destino.DataSource = unidadDeTrabajo.visitas.ConsultaDatos("SELECT descripcio, codigo FROM bdsoftpad_ctr_tablas.ta19");
            DrpTipo_destino.DataTextField = "Descripcio";
            DrpTipo_destino.DataValueField = "codigo";
            DrpTipo_destino.DataBind();
            //COD_CLI":
            LlenaDropDownListCliente("C");
            //COD_EMP":
            var sSql = Application["SqlEmpleado"].ToString() + " and EmpN.cod_tip_emp='C'";
            DrpCod_emp.DataSource = unidadDeTrabajo.visitas.ConsultaDatos(sSql);
            DrpCod_emp.DataTextField = "des_empleado";
            DrpCod_emp.DataValueField = "cod_emp";
            DrpCod_emp.DataBind();
        }
        private void ObtenerDetalleVisita()
        {
            if (String.IsNullOrWhiteSpace(Request.QueryString["id"]))
            {                
                TxtNro_visita.Text= unidadDeTrabajo.visitas.ActualizaCorrelativo("vnro_visita","",7);
                DrpTipo_destino.Text = "C";
                TxtContrato_correl.Text = "";
                DrpNro_requerimiento.Text = null;
                DrpCod_sistema.Text = "SAD";
                TxtObservac.Text = "";
                DrpTipo_visita.Text = "";
                DrpServ_mensual.Text = "";
                DrpCod_emp.Text = Session["Usuario_cod"].ToString();
                TxtNro_cotizacion.Text = null;
                TxtFech_visita.Text = DateTime.Now.ToString();
                BuscaContratoSistemaCliente(DrpCod_cli.Text, DrpTipo_destino.Text);
                return;
            }
            else
            {
                var id = Convert.ToInt32(Request.QueryString["id"]);
                //Obteniendo la informacion Completa del Alumno
                var visitas = unidadDeTrabajo.visitas.Get(id);
                TxtNro_visita.Text = visitas.nro_visita;
                DrpTipo_destino.Text = visitas.tipo_destino;
                DrpCod_emp.Text = visitas.cod_emp;
                DrpCod_cli.Text = visitas.cod_cli;
                TxtContrato_correl.Text = visitas.contrato_correl;
                DrpNro_requerimiento.Text = visitas.nro_requerimiento;
                DrpCod_sistema.Text = visitas.cod_sistema;
                TxtObservac.Text = visitas.observac;
                DrpTipo_visita.Text = visitas.tipo_visita;
                DrpServ_mensual.Text = visitas.serv_mensual;
                TxtNro_cotizacion.Text = visitas.nro_cotizacion;
                DrpCod_emp.Text= unidadDeTrabajo.RepositorioVisitas.DatoIncidenciaVisita(id, "cod_emp");
                TxtFech_visita.Text = unidadDeTrabajo.RepositorioVisitas.DatoIncidenciaVisita(id,"Fech_visita");
                HFId.Value = visitas.Id.ToString();
                //COD_SISTEMA":
                BuscaContratoSistemaCliente(visitas.cod_cli, visitas.tipo_destino);
                if(!string.IsNullOrWhiteSpace(visitas.serv_mensual))
                   LlenaDroDownListServ_Mensual(visitas.serv_mensual);
                DeshabilitaCampos(visitas.tipo_visita);
            }
        }
        private long Guardar()
        {
            if (ValidaGrabarVisita())
            {
                //Greando y Guardando variable con campos que no son constantes
                var sNro_cotizacion = ""; var sNro_requerimiento = ""; var sCod_cli = ""; var sCod_referido = ""; var sServ_mensual = "";
                if (String.IsNullOrWhiteSpace(TxtNro_cotizacion.Text))
                    sNro_cotizacion = null;
                else
                    sNro_cotizacion = TxtNro_cotizacion.Text;
                if (String.IsNullOrWhiteSpace(DrpNro_requerimiento.Text))
                    sNro_requerimiento = null;
                else
                    sNro_requerimiento = DrpNro_requerimiento.Text;
                if (String.IsNullOrWhiteSpace(DrpServ_mensual.Text))
                    sServ_mensual = null;
                else
                    sServ_mensual = DrpServ_mensual.Text;

                if (DrpTipo_destino.Text == "C")
                {
                    sCod_cli = DrpCod_cli.Text; sCod_referido = null;
                }
                else
                {
                    sCod_cli = null; sCod_referido = DrpCod_cli.Text;
                }
                if (string.IsNullOrWhiteSpace(HFId.Value))  //Nuevo
                {
                    long NuevoId = 0;
                    var visitas = new Visitas()
                    {
                        nro_visita      = TxtNro_visita.Text,
                        tipo_destino    = DrpTipo_destino.Text,
                        cod_emp         = Session["Usuario_cod"].ToString(),
                        cod_cli         = sCod_cli,
                        cod_referido    = sCod_referido,
                        contrato_correl = TxtContrato_correl.Text,
                        cod_sistema     = DrpCod_sistema.Text,
                        observac        = TxtObservac.Text,
                        tipo_visita     = DrpTipo_visita.Text,
                        serv_mensual    = sServ_mensual,
                        nro_cotizacion  = sNro_cotizacion,
                        nro_requerimiento= sNro_requerimiento
                    };
                    NuevoId = unidadDeTrabajo.visitas.Insert(visitas);
                    if (NuevoId>0)
                    {
                        unidadDeTrabajo.visitas.Grabacorrelativos("vnro_visita", TxtNro_visita.Text);
                        unidadDeTrabajo.RepositorioVisitas.AgregaIncidencia_Visita(NuevoId, "01",DrpCod_emp.Text,TxtFech_visita.Text);
                    }
                    return NuevoId;
                }
                else //Edicion
                {
                    //Obtener el Objeto de base de datos a Actualizar
                    long nRegistro = Convert.ToInt32(HFId.Value);
                    var visitas = unidadDeTrabajo.visitas.Get(nRegistro);
                    //Hacemos los cambios en los campos que queremos 
                    visitas.tipo_destino      = DrpTipo_destino.Text;
                    visitas.cod_cli           = sCod_cli;
                    visitas.cod_referido      = sCod_referido;
                    visitas.contrato_correl   = TxtContrato_correl.Text;
                    visitas.nro_requerimiento = sNro_requerimiento;
                    visitas.cod_sistema       = DrpCod_sistema.Text;
                    visitas.observac          = TxtObservac.Text;
                    visitas.tipo_visita       = DrpTipo_visita.Text;
                    visitas.serv_mensual      = sServ_mensual;
                    visitas.nro_cotizacion    = sNro_cotizacion;
                    //Obtener el objeto de BD nuevamente 
                    var resultado = unidadDeTrabajo.visitas.Update(visitas);
                    if (resultado)
                    {
                        unidadDeTrabajo.visitas.Grabacorrelativos("vnro_visita", TxtNro_visita.Text);
                        unidadDeTrabajo.RepositorioVisitas.AgregaIncidencia_Visita(nRegistro, "02", DrpCod_emp.Text, TxtFech_visita.Text);
                    }
                    else
                    {
                      nRegistro = 0;
                    }
                    return nRegistro;
                }
            }
            else
            {
                return 0;
            }
        }
        private bool ValidaGrabarVisita()
        {
            var bSalida = true;
            if (string.IsNullOrWhiteSpace(TxtNro_visita.Text) || string.IsNullOrWhiteSpace(DrpCod_cli.Text) || string.IsNullOrWhiteSpace(DrpCod_emp.Text) || string.IsNullOrWhiteSpace(TxtFech_visita.Text))
            {
                bSalida = false;
                Response.Write("<script>alert('No se ha llenado campos que son obligatorios')</script>");
            }
            return bSalida;
        }
        protected void BtnCancelar_Click(object sender, EventArgs e)
        {
            Response.Redirect("FrmVisitas.aspx");
        }

        protected void BtnGuardar_Click(object sender, EventArgs e)
        {
            if (Guardar() > 0)
            {
                ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('Registro Guardado en Forma Satisfactoria');", true);
                Response.Redirect("FrmVisitas.aspx");
            }
            else
                Response.Write("<script>alert('No se pudo guardar el Registro')</script>");
        }

        protected void DrpCod_cli_SelectedIndexChanged(object sender, EventArgs e)
        {
            var sCod_cli = DrpCod_cli.SelectedValue;
            BuscaContratoSistemaCliente(sCod_cli,DrpTipo_destino.Text);
        }
        private void BuscaContratoSistemaCliente(string sCod_cli, string sTipo_destino)
        {
            var sSql = "";
            var sCod_sistema = "";
            if (sTipo_destino == "C")
            {
                var cliente_contrato = unidadDeTrabajo.RepositorioCliente.ConsultaContratoVigente(sCod_cli);
                TxtContrato_correl.Text = cliente_contrato.contrato_correl;
                switch (cliente_contrato.cod_sistema)
                {
                    case "SD1":
                        sSql = "Select des_sistema, cod_sistema from sistema where cod_sistema in('SAD','VTA')";
                        sCod_sistema= "SAD";
                        break;
                    case "SD2":
                        sSql = "Select des_sistema, cod_sistema from sistema where cod_sistema in('SAD','CTE')";
                        sCod_sistema = "SAD";
                        break;
                    case "SD3":
                        sSql = "Select des_sistema, cod_sistema from sistema where cod_sistema in('SAD','CTE','BCO')";
                        sCod_sistema = "SAD";
                        break;
                    case "SD4":
                        sSql = "Select des_sistema, cod_sistema from sistema where cod_sistema in('SAD', 'CTE', 'BCO', 'CTB')";
                        sCod_sistema = "SAD";
                        break;
                    default:
                        sSql = "Select des_sistema, cod_sistema from sistema where cod_sistema='" + cliente_contrato.cod_sistema + "'";
                        sCod_sistema = "";
                        break;
                }
            }
            else
            {
                sSql = "Select des_sistema, cod_sistema from sistema where cod_sistema in('SAD','DSI','DMA','RMF','CTE','CTB')";
                sCod_sistema = "SAD";
            }
            DrpCod_sistema.DataSource = unidadDeTrabajo.visitas.ConsultaDatos(sSql);
            DrpCod_sistema.DataTextField = "des_sistema";
            DrpCod_sistema.DataValueField = "cod_sistema";
            if(sCod_sistema!="")
              DrpCod_sistema.SelectedValue = sCod_sistema;
            DrpCod_sistema.DataBind();
        }

        protected void DrpTipo_visita_SelectedIndexChanged(object sender, EventArgs e)
        {
            var sTipo_visita = DrpTipo_visita.SelectedValue;
            DeshabilitaCampos(sTipo_visita);
        }
        private void DeshabilitaCampos(string sTipo_visita)
        {
            //TxtNro_visita.Text = unidadDeTrabajo.visitas.ActualizaCorrelativo("vnro_visita", "", 7);
            switch (sTipo_visita)
            {
                case "EVR":
                    TxtNro_cotizacion.Enabled = false;
                    DrpNro_requerimiento.Enabled = true;
                    DrpCod_sistema.Enabled = false;
                    DrpServ_mensual.Enabled = false;
                    TxtNro_cotizacion.Text = null;
                    DrpServ_mensual.Text =null;
                    DrpCod_sistema.Text = null;
                    LlenaDropDownListRequerimiento(DrpCod_cli.Text);
                    break;
                case "ENR":
                    TxtNro_cotizacion.Enabled = true;
                    DrpNro_requerimiento.Enabled = true;
                    DrpCod_sistema.Enabled = false;
                    DrpServ_mensual.Enabled = false;
                    DrpServ_mensual.Text = null;
                    DrpCod_sistema.Text = null;
                    LlenaDropDownListRequerimiento(DrpCod_cli.Text);
                    break;
                case "MNT":
                    TxtNro_cotizacion.Enabled = false;
                    DrpNro_requerimiento.Enabled = false;
                    DrpCod_sistema.Enabled = true;
                    DrpServ_mensual.Enabled = true;
                    TxtNro_cotizacion.Text = null;
                    DrpNro_requerimiento.Text = null;
                    LlenaDroDownListServ_Mensual(DrpServ_mensual.Text);
                    TxtNro_visita.Text = DateTime.Now.ToString("yy") + DateTime.Now.Month.ToString().PadLeft(2, '0') + DrpCod_cli.Text;
                    break;
                case "PRO":
                case "REA":
                    TxtNro_cotizacion.Enabled = false;
                    DrpNro_requerimiento.Enabled = true;
                    DrpCod_sistema.Enabled = false;
                    DrpServ_mensual.Enabled = false;
                    TxtNro_cotizacion.Text = "";
                    DrpServ_mensual.Text = null;
                    LlenaDropDownListRequerimiento(DrpCod_cli.Text);
                    break;
                case "DEM":
                case "EST":
                case "CAP":
                case "RNS":
                case "INT":
                case "CUA":
                case "INF":
                    TxtNro_cotizacion.Enabled = true;
                    DrpCod_sistema.Enabled = false;
                    DrpServ_mensual.Enabled = false;
                    DrpServ_mensual.Text = null;
                    break;
            }
        }

        protected void DrpTipo_destino_SelectedIndexChanged(object sender, EventArgs e)
        {
            var sTipo_Destino = DrpTipo_destino.SelectedValue;
            LlenaDropDownListCliente(sTipo_Destino);
        }
        private void LlenaDropDownListCliente(string sTipo_destino)
        {
            if (sTipo_destino == "R")
            {
                LblCliente.Text = "Referido Visitado : ";
                DrpCod_cli.DataSource = unidadDeTrabajo.visitas.ConsultaDatos("Select raz_soc_refer,cod_referido  from referido group by raz_soc_refer,cod_referido");
                DrpCod_cli.DataTextField = "raz_soc_refer";
                DrpCod_cli.DataValueField = "cod_referido";
                DrpTipo_visita.DataSource = unidadDeTrabajo.visitas.ConsultaDatos("SELECT descripcio, codigo from bdsoftpad_ctr_tablas.ta20 where codigo in ('DEM','REA')");
            }
            else
            {
                LblCliente.Text = "cliente Visitado : ";
                DrpCod_cli.DataSource = unidadDeTrabajo.visitas.ConsultaDatos(Application["SqlCliente"].ToString());
                DrpCod_cli.DataTextField = "raz_soc_cli";
                DrpCod_cli.DataValueField = "cod_cli";
                DrpTipo_visita.DataSource = unidadDeTrabajo.visitas.ConsultaDatos("SELECT descripcio, codigo from bdsoftpad_ctr_tablas.ta20 where codigo not in ('M55','MIC','MIG')");
            }
            DrpCod_cli.DataBind();
            //TIPO_VISITA":
            DrpTipo_visita.DataTextField = "Descripcio";
            DrpTipo_visita.DataValueField = "codigo";
            DrpTipo_visita.DataBind();
            BuscaContratoSistemaCliente(DrpCod_cli.Text, sTipo_destino);
        }
        //private bool AgregaIncidencia_Visita(long iId_visitas, string sEstado, string sCod_emp, string sFech_visita)
        //{
        //    long NuevoId = 0;
        //    var visitas_incidencia = new Visitas_incidencia()
        //    {
        //        Id_visitas = Convert.ToInt32(iId_visitas),
        //        fech_visita = Convert.ToDateTime(sFech_visita),
        //        cod_emp = sCod_emp,
        //        estado = sEstado
        //    };
        //    NuevoId = unidadDeTrabajo.visitas_incidencia.Insert(visitas_incidencia);
        //    if (NuevoId > 0)
        //        return true;
        //    else
        //        return false;
        //}
        private void LlenaDropDownListRequerimiento(string sCod_cli)
        {
            if(!string.IsNullOrWhiteSpace(sCod_cli))
            {
                //REQUERIMIENTO
                var sSql = "select titulo_req,nro_requerimiento,fech_Crea from requerimiento";
                sSql = sSql + " where cod_cli = '" + sCod_cli + "' and ";
                sSql = sSql + "(Select estado from requerimiento_incidencia where nro_requerimiento = requerimiento.nro_requerimiento order by fech_incidencia desc limit 1) not in('08', '09', '10', '11')";
                DrpNro_requerimiento.DataSource = unidadDeTrabajo.visitas.ConsultaDatos(sSql);
                DrpNro_requerimiento.DataTextField = "titulo_req";
                DrpNro_requerimiento.DataValueField = "nro_requerimiento";
                DrpNro_requerimiento.DataBind();
            }
        }
        private void LlenaDroDownListServ_Mensual(string sServ_mensual)
        {
            if (string.IsNullOrWhiteSpace(sServ_mensual))
            {
                sServ_mensual= DateTime.Now.Month.ToString().PadLeft(2, '0');
            }
            //SERVICIO MENSUAL
            DrpServ_mensual.DataSource = unidadDeTrabajo.visitas.ConsultaDatos("select descripcio, codigo FROM bdsoftpad_ctr_tablas.ta22");
            DrpServ_mensual.DataTextField = "Descripcio";
            DrpServ_mensual.DataValueField = "codigo";
            DrpServ_mensual.SelectedValue = sServ_mensual;
            DrpServ_mensual.DataBind();
        }
    }
}