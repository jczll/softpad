﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Control.Entidades
{
    public class Documento
    {
        public string tipo_doc { get; set; }
        public string nro_documento { get; set; }
        public DateTime? fech_crea { get; set; }
    }
    public class Documento_Saldo
    {
        public string tipo_doc { get; set; }
        public string nro_documento { get; set; }
        public decimal saldo { get; set; }
    }
}
