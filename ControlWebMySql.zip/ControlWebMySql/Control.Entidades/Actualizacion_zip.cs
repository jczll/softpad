﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Control.Entidades
{
    public class Actualizacion_zip
    {
        public int Id { get; set; }
        public int ActId { get; set; }
        public string arch_zip { get; set; }
    }
}
