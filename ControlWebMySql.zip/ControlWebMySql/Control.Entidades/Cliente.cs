﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Control.Entidades
{
    public class Cliente_contrato
    {
        public string cod_cli { get; set; }
        public string contrato_correl { get; set; }
        public string cod_sistema { get; set; }
        public string cod_agte { get; set; }
        public string period_contrato { get; set; }
        public string tipo_servicio { get; set; }
        public string moneda { get; set; }
    }
    public class Cliente_contrato_Servidores
    {
        public string id { get; set; }
        public string cod_cli { get; set; }
        public string contrato_correl { get; set; }
        public string servidor { get; set; }
        public DateTime? fech_activa { get; set; }
        public bool activo { get; set; }
    }
    public class Cliente_activacion
    {
        public string cod_cli { get; set; }
        public string raz_soc_cli { get; set; }
        public string cod_agte { get; set; }
        public string cod_sistema { get; set; }
        public string des_sistema { get; set; }
        public string servidor { get; set; }
        public string usuario_pc { get; set; }
        public DateTime? fech_activa { get; set; }
        public string estado { get; set; }
    }
    public class Cliente_contrato_estacion
    {
        public string cod_cli { get; set; }
        public string estacion { get; set; }
        public string cod_sistema { get; set; }
        public DateTime? fch_ult_ingre { get; set; }
    }
    public class Servidores_detalle
    {
        public string cod_cli { get; set; }
        public string des_cliente { get; set; }
        public DateTime? fech_activa { get; set; }
        public string servidor { get; set; }
        public int cant_est { get; set; }
        public string cod_sistema { get; set; }
        public int actuales { get; set; }
    }
}
