﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Control.Entidades
{
    public class Visitas
    {
        public int Id { get; set; }
        public string nro_visita { get; set; }
        public DateTime? fech_crea { get; set; }
        public string cod_emp { get; set; }
        public string cod_cli { get; set; }
        public string contrato_correl { get; set; }
        public string nro_requerimiento { get; set; }
        public string cod_sistema { get; set; }
        public string observac { get; set; }
        public string tipo_visita { get; set; }
        public string serv_mensual { get; set; }
        public string cod_referido { get; set; }
        public string tipo_destino { get; set; }
        public string nro_cotizacion { get; set; }
    }
    public class Visitas_incidencia
    {
        public int Id { get; set; }
        public int Id_visitas { get; set; }
        public DateTime? fech_incidencia { get; set; }
        public string estado { get; set; }
        public string observac { get; set; }
        public string cod_emp { get; set; }
        public DateTime? fech_visita { get; set; }
    }
}
