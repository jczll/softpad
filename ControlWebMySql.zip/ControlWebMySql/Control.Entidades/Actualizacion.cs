﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Control.Entidades
{
    public class Actualizacion
    {
        public int Id { get; set; }
        public DateTime ? fech_crea { get; set; }
        public string cod_usuario { get; set; }
        public string tipo_act { get; set; } 
        public string vers_act { get; set; }
        public string titulo { get; set; }
        public string detalle { get; set; }
        public bool ? enviado1 { get; set; }
    }
    public class ActualizacionR
    {
        public int Id { get; set; }
        public DateTime? fech_crea { get; set; }
        public string nombres { get; set; }
        public string desc_act { get; set; }
        public string desc_ver { get; set; }
        public string titulo { get; set; }
        public string detalle { get; set; }
        public bool? enviado1 { get; set; }
    }
}
