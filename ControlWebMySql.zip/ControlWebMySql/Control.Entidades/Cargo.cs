﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Control.Entidades
{
    public class Cargo
    {
        public int Id { get; set; }
        public string tipo_id { get; set; }
        public string anio { get; set; }
        public string mes { get; set; }
        public string descripcio { get; set; }
        public string sad { get; set; }
        public string dsi { get; set; }
        public string dma { get; set; }
        public string rmf { get; set; }
        public string dva { get; set; }
        public bool? cerrado { get; set; }
    }
}
