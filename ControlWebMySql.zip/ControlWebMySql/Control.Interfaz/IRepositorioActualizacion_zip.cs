﻿using Control.Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Control.Interfaz
{
    public interface IRepositorioActualizacion_zip : IRepositorio<Actualizacion_zip>
    {
        List<Actualizacion_zip> ConsultaActualizacion_zipXArchivo(int iActId, string sArchivo);
        List<Actualizacion_zip> ConsultaActualizacion_zipXActId(int iActId);
    }
}
