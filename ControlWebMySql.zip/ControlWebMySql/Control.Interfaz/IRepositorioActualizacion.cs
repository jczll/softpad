﻿using Control.Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Control.Interfaz
{
    public interface IRepositorioActualizacion :IRepositorio<Actualizacion>
    {        
        List<ActualizacionR> ConsultaActualizacionXId(int iId);
        List<ActualizacionR> ConsultaActualizacionXTipo_Act(string sTipo_act);
        List<ActualizacionR> ConsultaActualizacionXFecha(string sAño, string sMes);
        //string BuscarNumeroDeMes(string sMes);
        string BuscaDescripcioTipoActualizacion(string sTipo_act);
        string BuscaDescripcioVersionoActualizacion(string sVers_act);
        string BuscaNombreEmpleado(string sCod_emp);
        bool EvaluaActualizacionEnviada(int iId);
        List<Actualizacion> BuscaUltimaActualizacionXTipo(string sTipo_act, int iId);
    }
}
