﻿using Control.Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Control.Interfaz
{
    public interface IRepositorioCliente_activacion : IRepositorio<Cliente_activacion>
    {
        List<Cliente_activacion> ConsultaAcitvacionPendiente();
        Cliente_activacion ConsultaAcitvacionPendienteDetallada(string sCod_cli);
        List<Cliente_contrato_Servidores> ConsultaServidoresxCliente(string sCod_cli);
        Cliente_contrato ConsultaContratoVigente(string sCod_cli);
        int ActualizaEstadoActivacionCliente(string sCod_cli, string sServidor, string sEstado);
        List<Servidores_detalle> ConsultaServidoresDetalle(string sDes_cliente);
        List<Cliente_contrato_estacion> ConsultaEstacionesxCliente(string sCod_cli);
        string BuscaNombreCliente(string sCod_cli);
        bool EliminarActivacionPendiente(string sCod_cli, string sServidor);
    }
}
