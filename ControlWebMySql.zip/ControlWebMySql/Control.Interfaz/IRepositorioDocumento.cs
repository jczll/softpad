﻿using Control.Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Control.Interfaz
{
    public interface IRepositorioDocumento : IRepositorio<Documento>
    {
        Documento ValidaGeneraMantenMensual(string sCod_cli, string sPeriod_Contrato, string sContrato_correl, string sMes, string sAño);
        Documento_Saldo GeneraConsultaSaldo(string sCod_cli, string sMoneda, string sTipo_doc, string sNro_documento);
    }
}
