﻿using Control.Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Control.Interfaz
{
    public interface IRepositorioCargo : IRepositorio<Cargo>
    {
        List<Cargo> ConsultaCargoXMesAño(string sAño, string sMes, string sSistema);
        string BuscaCorrelativo(string sAño, string sMes);
        int CerrarCargoMantenimiento(string sAño, string sMes);
        bool ValidaCerroCargoMantenimiento(string sAño, string sMes);
    }
}
