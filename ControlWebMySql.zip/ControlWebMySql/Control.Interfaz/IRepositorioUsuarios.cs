﻿using Control.Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Control.Interfaz
{
    public interface IRepositorioUsuarios : IRepositorio<Usuarios>
    {
        List<Usuarios> ObtenerUsuarioPorLogin(string sCorreo, string sClave);
        List<Usuarios> ObtenerUsuarioPorCodigo(string sCodigo);
    }
}
