﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Control.Interfaz
{
    public interface IRepositorio<Entidad> where Entidad :class
    {
        Entidad Get(long id);
        List<Entidad> GetList();
        long Insert(Entidad entity);
        bool Update(Entidad entity);
        bool Delete(Entidad entity);
        DataSet ConsultaDatos(string sConsulta);
        string ActualizaCorrelativo(string sNombre_correl, string sNro_correl, int iTamaño);
        int Grabacorrelativos(string sNombre_correl, string sNro_correl);
    }
}
