﻿using Control.Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Control.Interfaz
{
    public interface IUnidadDeTrabajo
    {
        /*Interfaces de Repositorios de Actualizacion de Datos*/
        IRepositorio<Actualizacion> actualizacion{ get; }
        IRepositorio<Actualizacion_zip> actualizacion_zip { get; }
        IRepositorio<Usuarios> usuarios { get; }
        IRepositorio<Cargo> cargo { get; }
        IRepositorio<Cliente_contrato_Servidores> cliente_contrato_Servidores { get; }
        IRepositorio<Visitas> visitas { get; }
        IRepositorio<Visitas_incidencia> visitas_incidencia { get; }
        /*Interfaces de Repositorios de Funciones*/
        IRepositorioActualizacion RepositorioActualizacion { get; }
        IRepositorioActualizacion_zip RepositorioActualizacion_zip { get; }
        IRepositorioUsuarios RepositorioUsuarios { get; }
        IRepositorioCargo RepositorioCargo { get; }
        IRepositorioCliente RepositorioCliente { get; }
        IRepositorioVisitas RepositorioVisitas { get; }
        IRepositorioDocumento RepositorioDocumento { get; }
    }
}
