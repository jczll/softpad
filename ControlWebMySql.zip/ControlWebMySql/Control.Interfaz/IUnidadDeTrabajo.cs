﻿using Control.Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Control.Interfaz
{
    public interface IUnidadDeTrabajo
    {
        IRepositorio<Actualizacion> actualizacion{ get; }
        IRepositorio<Actualizacion_zip> actualizacion_zip { get; }
        IRepositorio<Cargo> cargo { get; }
        IRepositorio<Cliente_contrato_Servidores> cliente_contrato_Servidores { get; }
        IRepositorio<Visitas> visitas { get; }
        IRepositorioActualizacion RepositorioActualizacion { get; }
        IRepositorioActualizacion_zip RepositorioActualizacion_zip { get; }
        IRepositorioUsuarios RepositorioUsuarios { get; }
        IRepositorioCargo RepositorioCargo { get; }
        IRepositorioCliente_activacion RepositorioCliente_activacion { get; }
        IRepositorioVisitas RepositorioVisitas { get; }
    }
}
