﻿using Control.Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Control.Interfaz
{
    public interface IRepositorioVisitas : IRepositorio<Visitas>
    {
        List<Consulta_Visitas> ConsultaVisitasPendientes(string sNro_visita, string sCod_cli, string sFech_visita);
        bool EliminaIncidencia_Visitas(int id_visitas);
        bool AgregaIncidencia_Visita(long iId_visitas, string sEstado, string sCod_emp, string sFech_visita);
        string DatoIncidenciaVisita(int iId, string sCampo_Resultado);
    }
}
