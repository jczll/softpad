﻿using Control.Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Control.Interfaz
{
    public interface IRepositorioVisitas : IRepositorio<Visitas>
    {
        List<Consulta_Visitas> ConsultaVisitasPendientes(string sNro_visita, string sCod_cli, string sFech_visita);
        bool EliminarIncidencias(int id_visitas);
        string DatoIncidenciaVisita(int iId);
    }
}
