﻿using Control.Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Control.Interfaz
{
    public interface IRepositorioVisitas : IRepositorio<Visitas>
    {
        List<Visitas> ConsultaVisitasPendientes(string sNro_visita, string sCod_cli, DateTime dFech_visita);
    }
}
