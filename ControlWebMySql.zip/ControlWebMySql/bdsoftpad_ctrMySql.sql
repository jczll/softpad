/******************************************************************************************/
/* NUEVAS TABLAS PARA EL CONTROL WEB EN MYSQL                                             */

create table if not exists usuarios(
   cod_usuario	char(3)  not null,	/*C  2  0*/
   correo   	varchar(50) not null,	/*C 30  0*/
   clave     	char(10) default '',     /*C  5  0*/
   nombres 	varchar(90) DEFAULT '',     /*C  3  0*/
   apellidos 	varchar(90) DEFAULT '',    /*C  1  0*/
   roles 	char(15) DEFAULT '',    /*C  50  0*/
   primary key(cod_usuario),	
   constraint uq_usuarios_1 unique(correo),
   constraint uq_usuarios_2 unique(clave));
create index usuarios ON usuarios(cod_usuario);
insert into usuarios(cod_usuario,correo,clave) VALUES('JCZ','jczll@softpad.pe','70729');
insert into usuarios(cod_usuario,correo,clave) VALUES('MTM','mtuesta@softpad.pe','707293');

create table if not exists actualizacion(
   id    	int  auto_increment,
   fech_crea    TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
   cod_usuario  char(3) default '',
   tipo_act     char(1) default '',
   titulo       varchar(60) default '',
   detalle      varchar(500) default '',
   enviado1     bool,     
   vers_act     char(1) default '1',  
   primary key(id),	
   constraint fk_actualizacion_usuarios foreign key(cod_usuario) references usuarios(cod_usuario));
create index actualizacion ON actualizacion(id);

create table if not exists actualizacion_zip(
   id    	int  not null auto_increment,	/*C  2  0*/
   ActId        int NOT NULL,
   arch_zip     char(15) default '',
   primary key(id),	
   constraint fk_actualizacion_zip_actualizacion foreign key(actid) references actualizacion(id));
create index actualizacion_zip ON actualizacion_zip(id);

/******************************************************************************************/
/* USU(USUARIOS DEL SISTEMA */

CREATE TABLE IF NOT EXISTS empleado(
   cod_emp    	 CHAR(3) NOT NULL,	/*C  2  0*/
   nomb_emp   	 VARCHAR(30) DEFAULT 'PONGA AQUI SU NOMBRE',	/*C 30  0*/
   ape_emp     	 CHAR(5) DEFAULT '',     /*C  5  0*/
   dire_emp 	 CHAR(3) DEFAULT '',     /*C  3  0*/
   fch_ingre_emp CHAR(1) DEFAULT 'S',    /*C  1  0*/
   fch_nac_emp 	 CHAR(1) DEFAULT 'S',    /*C  1  0*/
   dni_emp 	 VARCHAR(50) DEFAULT '',    /*C  50  0*/
   cod_distrito	 VARCHAR(10) DEFAULT '',    /*C  10  0*/
   ecivil_emp    CHAR(1) DEFAULT 'E',    /*C  1  0*/
   vigente       VARCHAR(5) DEFAULT '',    /*CAMPOS SOLO PARA HANSA ADUANAS*/
   contratado    VARCHAR(10) DEFAULT '',   /*CAMPOS SOLO PARA HANASA ADUANAS*/
   cod_afp       
   afp_cups     
   nro_segsocial
   esaludv
   fech_ingre_pla
   fech_cese 
   PRIMARY KEY(CODIGO),	
   CONSTRAINT UQ_USU_1 UNIQUE(USUARIO),
   CONSTRAINT UQ_USU_2 UNIQUE(CLAVE));
CREATE INDEX USU ON USU(CODIGO);
INSERT INTO USU(CODIGO,USUARIO,INICIALES) VALUES('001','SUPERVISOR','SUP');

select CONVERT(fech_crea, char(7)),substring(CONVERT(fech_crea, char(7)),6,2) from actualizacion where CONVERT(fech_crea, char(4)) ="2019" and substring(CONVERT(fech_crea, char(7)),6,2) ="08"