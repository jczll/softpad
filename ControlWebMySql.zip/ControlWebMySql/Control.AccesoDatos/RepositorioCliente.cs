﻿using Control.Entidades;
using Control.Interfaz;
using Dapper;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Control.AccesoDatos
{
    public class RepositorioCliente : Repositorio<Cliente_activacion>, IRepositorioCliente
    {
        private string sSqlContratoVigente = @"
                select CliN.cod_cli,CliN.contrato_correl,CliN.cod_sistema,CliN.period_contrato,CliN.tipo_servicio,CliN.moneda,CliN_Ope.cod_operador as cod_agte 
                   from cliente_contrato CliN 
                        left join cliente_contrato_operador CliN_Ope on CliN_ope.cod_cli=CliN.cod_cli and CliN_ope.contrato_correl=CliN.contrato_correl 
                   where
                       left(CliN.contrato_correl, 1) not in('F', 'T') and
                       (CliN.fech_ini <= adddate(curdate(), interval 15 day) and CliN.fech_venc >= curdate()) and
                       (Select estado from cliente_contrato_incidencia where cod_cli = CliN.cod_cli and contrato_correl = CliN.contrato_correl order by fech_incidencia desc limit 1) not in('07')";

        public RepositorioCliente(string connectionString) : base(connectionString)
        {
        }
        public Cliente_contrato ConsultaContratoVigente(string sCod_cli)
        {
            var sComandoSql = sSqlContratoVigente+" and CliN.cod_cli = @FiltroByCod_cli and";
            using (var connection = new MySqlConnection(_connectionString))
            {
                var resultado = connection.QuerySingle<Cliente_contrato>(sComandoSql, new { FiltroByCod_cli = sCod_cli });
                return resultado;
            }
        }
        public List<Cliente_contrato> ConsultaContratosVigentes()
        {
            var sComandoSql = sSqlContratoVigente;
            using (var connection = new MySqlConnection(_connectionString))
            {
                return connection.Query<Cliente_contrato>(sSqlContratoVigente).ToList();
            }
        }
        public List<Cliente_activacion> ConsultaAcitvacionPendiente()
        {
            using (var connection = new MySqlConnection(_connectionString))
            {
                return connection.Query<Cliente_activacion>("Select * from cliente_activacion where estado='P'").ToList();
            }
        }
        public Cliente_activacion ConsultaAcitvacionPendienteDetallada(string sCod_cli)
        {
            var sComandoSql = @"
            select act.cod_cli,cli.raz_soc_cli,act.cod_agte,act.cod_sistema,sis.des_sistema,act.servidor,act.usuario_pc,act.fech_activa
                 from cliente_activacion act
                      left join cliente cli on cli.cod_cli = act.cod_cli
                      left join sistema sis on sis.cod_sistema = act.cod_sistema
                 where act.cod_cli = @FiltroByCod_cli";

            using (var connection = new MySqlConnection(_connectionString))
            {
                var resultado = connection.QuerySingle<Cliente_activacion>(sComandoSql, new { FiltroByCod_cli = sCod_cli });
                return resultado;
            }
        }
        public List<Cliente_contrato_Servidores> ConsultaServidoresxCliente(string sCod_cli)
        {
        var sComandoSql = "Select id,cod_cli,concat(cod_cli,'-',left(contrato_correl,1),'-',right(contrato_correl,2)) as contrato_correl,servidor,fech_activa,activo from cliente_contrato_servidores where cod_cli = @FiltroByCod_cli";

            using (var connection = new MySqlConnection(_connectionString))
            {
                return connection.Query<Cliente_contrato_Servidores>(sComandoSql, new { FiltroByCod_cli = sCod_cli }).ToList();
            }
        }
        public int ActualizaEstadoActivacionCliente(string sCod_cli, string sServidor, string sEstado)
        {
            int ResultUpdate = 0;
            var sSqlUpdate = "";
            if (String.IsNullOrWhiteSpace(sServidor))
               sSqlUpdate = "update cliente_activacion set estado='" + sEstado + "' where cod_cli='" + sCod_cli + "' and estado='P'";
            else
               sSqlUpdate = "update cliente_activacion set estado='" + sEstado + "' where cod_cli='" + sCod_cli + "' and servidor='" + sServidor+"' and estado='P'";

            using (var connection = new MySqlConnection(_connectionString))
            {
                ResultUpdate = connection.Execute(sSqlUpdate);
                return ResultUpdate;
            }
        }
        public List<Servidores_detalle> ConsultaServidoresDetalle(string sDes_cliente)
        {
            var sComandoSql = @"
                select CliN_Svd.cod_cli,CliN_Svd.fech_activa,CliN_Svd.servidor,CliN.cant_Est,CliN.cod_sistema,fech_ini,fech_venc,
                       (Select raz_soc_cli from cliente where cod_cli=CliN_Svd.cod_cli) as des_cliente,
                       (Select count(estacion) from cliente_contrato_estacion where cod_cli=CliN_Svd.cod_cli) as actuales 
                  from cliente_contrato_servidores CliN_Svd 
                       left join cliente_contrato CliN on CliN.cod_cli=CliN_Svd.cod_cli 
                  where CliN_Svd.activo=1 and (CliN.fech_ini<=adddate(curdate(),interval 15 day) and CliN.fech_venc>=curdate()) 
                       and left(CliN.contrato_correl,1) not in('F','T') 
                       and (Select estado from cliente_contrato_incidencia where cod_cli=CliN.cod_cli and contrato_correl=CliN.contrato_correl order by fech_incidencia desc limit 1) not in('07') ";
            if(!String.IsNullOrWhiteSpace(sDes_cliente))
            {
                sComandoSql = sComandoSql + "and (Select raz_soc_cli from cliente where cod_cli = CliN_Svd.cod_cli) like '" + sDes_cliente + "% '";
            }
            sComandoSql = sComandoSql + " order by des_cliente";

            using (var connection = new MySqlConnection(_connectionString))
            {
                var resultado = connection.Query<Servidores_detalle>(sComandoSql).ToList();
                return resultado;
            }
        }
        public List<Cliente_contrato_estacion> ConsultaEstacionesxCliente(string sCod_cli)
        {
            var sComandoSql = "Select cod_cli,estacion,cod_sistema,fch_ult_ingre from cliente_contrato_estaciones where cod_cli = @FiltroByCod_cli order by fch_ult_ingre desc";

            using (var connection = new MySqlConnection(_connectionString))
            {
                return connection.Query<Cliente_contrato_estacion>(sComandoSql, new { FiltroByCod_cli = sCod_cli }).ToList();
            }
        }
        public string BuscaNombreCliente(string sCod_cli)
        {
            var sSql = "Select raz_soc_cli from cliente where cod_cli = @FiltroCod_cli";

            using (var connection = new MySqlConnection(_connectionString))
            {
                var resultado = connection.QueryFirst(sSql, new { FiltroCod_cli = sCod_cli });
                return resultado.raz_soc_cli;
            } 
        }
        public bool EliminarActivacionPendiente(string sCod_cli, string sServidor)
        {
            var sSqlSelect = "select * from cliente_activacion where cod_cli=@FiltroCod_cli and servidor = @FiltroServidor";
            var sSqlDelete = "delete from cliente_activacion where cod_cli=@FiltroCod_cli and servidor = @FiltroServidor";

            using (var connection = new MySqlConnection(_connectionString))
            {
                var ResultDelete = connection.Execute(sSqlDelete, new { FiltroCod_cli = sCod_cli, FiltroServidor = sServidor });
                var ResultSelect = connection.Query<Cliente_activacion>(sSqlSelect, new { FiltroCod_cli = sCod_cli, FiltroServidor = sServidor }).ToList();
                if (ResultSelect.Count > 0)
                    return false;
                else
                    return true; 
            }
        }
    }
}
