﻿using Control.Entidades;
using Control.Interfaz;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Control.AccesoDatos
{
    public class UnidadDeTrabajo : IUnidadDeTrabajo
    {
        public IRepositorio<Actualizacion> actualizacion { get; private set; }
        public IRepositorio<Actualizacion_zip> actualizacion_zip { get; private set; }
        public IRepositorio<Usuarios> usuarios { get; private set; }
        public IRepositorio<Cargo> cargo { get; private set; }
        public IRepositorio<Cliente_contrato_Servidores> cliente_contrato_Servidores { get; private set; }
        public IRepositorio<Visitas> visitas { get; private set; }
        public IRepositorio<Visitas_incidencia> visitas_incidencia { get; private set; }

        public IRepositorioActualizacion RepositorioActualizacion { get; private set; }
        public IRepositorioActualizacion_zip RepositorioActualizacion_zip { get; private set; }
        public IRepositorioUsuarios RepositorioUsuarios { get; private set; }
        public IRepositorioCargo RepositorioCargo { get; private set; }
        public IRepositorioCliente RepositorioCliente { get; private set; }
        public IRepositorioVisitas RepositorioVisitas { get; private set; }

        public UnidadDeTrabajo(string connectionString)
        {
            actualizacion = new Repositorio<Actualizacion>(connectionString);
            actualizacion_zip = new Repositorio<Actualizacion_zip>(connectionString);
            usuarios = new Repositorio<Usuarios>(connectionString);
            cargo = new Repositorio<Cargo>(connectionString);
            cliente_contrato_Servidores = new Repositorio<Cliente_contrato_Servidores>(connectionString);
            visitas = new Repositorio<Visitas>(connectionString);
            visitas_incidencia = new Repositorio<Visitas_incidencia>(connectionString);

            RepositorioActualizacion = new RepositorioActualizacion(connectionString);
            RepositorioActualizacion_zip = new RepositorioActualizacion_zip(connectionString);
            RepositorioUsuarios = new RepositorioUsuarios(connectionString);
            RepositorioCargo = new RepositorioCargo(connectionString);
            RepositorioCliente = new RepositorioCliente(connectionString);
            RepositorioVisitas = new RepositorioVisitas(connectionString);
        }
    }
}
