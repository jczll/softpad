﻿using Control.Entidades;
using Control.Interfaz;
using Dapper;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Control.AccesoDatos
{
    public class RepositorioCargo : Repositorio<Cargo>, IRepositorioCargo
    {
        public RepositorioCargo(string connectionString) : base(connectionString)
        {
        }

        List<Cargo> IRepositorioCargo.ConsultaCargoXMesAño(string sAño, string sMes, string sSistema)
        {
            var sComandoSql = "select * from cargo where anio = @FiltroByAño and mes = @FiltroByMes and "+sSistema+"<>'00' order by "+ sSistema;

            using (var connection = new MySqlConnection(_connectionString))
            {
                return connection.Query<Cargo>(sComandoSql, new { FiltroByAño = sAño, FiltroByMes = sMes }).ToList();
            }
        }
        public string BuscaCorrelativo(string sAño, string sMes)
        {
            var sSql = "Select max(sad) as correl from cargo where anio = @FiltroByAño and mes = @FiltroByMes";

            using (var connection = new MySqlConnection(_connectionString))
            {
                var resultado = connection.QueryFirst(sSql, new { FiltroByAño = sAño, FiltroByMes = sMes });
                return resultado.correl;
            }
        }
        public int CerrarCargoMantenimiento(string sAño, string sMes)
        {
            var sSqlSelect = "select * from cargo where anio = @FiltroByAño and mes = @FiltroByMes limit 1";
            var sSqlUpdate = "update cargo set cerrado=1 where anio = @FiltroByAño and mes = @FiltroByMes";
            var ResultUpdate = 0;

            using (var connection = new MySqlConnection(_connectionString))
            {
                var ResultSelect = connection.Query<Cargo>(sSqlSelect, new { FiltroByAño = sAño, FiltroByMes = sMes }).ToList();
                if (ResultSelect.Count > 0)
                {
                    ResultUpdate = connection.Execute(sSqlUpdate, new { FiltroByAño = sAño, FiltroByMes = sMes });
                }
                return ResultUpdate;
            }
        }
        public bool ValidaCerroCargoMantenimiento(string sAño, string sMes)
        {
            var sSql = "select * from cargo where anio = @FiltroByAño and mes = @FiltroByMes and cerrado=1 limit 1";

            using (var connection = new MySqlConnection(_connectionString))
            {
                var resultado = connection.Query<Cargo>(sSql, new { FiltroByAño = sAño, FiltroByMes = sMes }).ToList();
                if (resultado.Count > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }                 
            }
        }
    }
}
