﻿using Control.Entidades;
using Control.Interfaz;
using Dapper;
using System;
using System.Collections.Generic;
using MySql.Data.MySqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Control.AccesoDatos
{
    public class RepositorioActualizacion : Repositorio<Actualizacion>, IRepositorioActualizacion
    {
        private string sComandoSql = @"
        select id, fech_crea, concat(rtrim(nombres),' ',rtrim(apellidos)) as nombres, Titulo, enviado1,ta43.descripcio as desc_act,ta45.descripcio as desc_ver 
        from actualizacion
        left join usuarios on usuarios.cod_usuario=actualizacion.cod_usuario 
        left join bdSoftpad_ctr_tablas.ta43 ta43 on ta43.codigo= actualizacion.tipo_act 
        left join bdSoftpad_ctr_tablas.ta45 ta45 on ta45.codigo= actualizacion.vers_act";
        private string sOrderBy = "order by fech_crea desc";
        public RepositorioActualizacion(string connectionString) : base(connectionString)
        {
        }
        public List<ActualizacionR> ConsultaActualizacionXId(int iId)
        {
            var sWhere = "where id = @FiltroById ";
            using (var connection = new MySqlConnection(_connectionString))
            {
                return connection.Query<ActualizacionR>(sComandoSql+" "+sWhere+" "+sOrderBy, new { FiltroById = iId }).ToList();
            }
        }
        public List<ActualizacionR> ConsultaActualizacionXTipo_Act(string sTipo_act)
        {
            var sWhere = "where tipo_act = @FiltroByAct ";
            using (var connection = new MySqlConnection(_connectionString))
            {
                return connection.Query<ActualizacionR>(sComandoSql + " " + sWhere + " " + sOrderBy, new { FiltroByAct = sTipo_act }).ToList();
            }
        }
        public List<ActualizacionR> ConsultaActualizacionXFecha(string sAño, string sMes)
        {
            //var sWhere = "where CONVERT(fech_crea, char(6)) = @FiltroByAñoMes ";
            var sWhere = "where CONVERT(fech_crea, char(4)) = @FiltroByAño and substring(CONVERT(fech_crea, char(7)),6,2) = @FiltroByMes";

            using (var connection = new MySqlConnection(_connectionString))
            {
                return connection.Query<ActualizacionR>(sComandoSql + " " + sWhere + " " + sOrderBy, new { FiltroByAño = sAño, FiltroByMes= sMes }).ToList();
                //return connection.Query<ActualizacionR>(sComandoSql + " " + sWhere + " " + sOrderBy, new { FiltroByAñoMes = sAñoMes }).ToList();
            }
        }

        //public string BuscarNumeroDeMes(string sMes)
        //{
        //    var sSql = "Select id from bdSoftpad_ctr_tablas.dbo.TA44 where mes=@FiltroMes ";
        //    string sNumeroMes = "";
        //    using (var connection = new SqlConnection(_connectionString))
        //    {
        //        var result = connection.QueryFirst(sSql, new { FiltroMes = sMes });
        //        if (result.id < 10)
        //            sNumeroMes = $"0{Convert.ToString(result.id)}";
        //        else
        //            sNumeroMes = Convert.ToString(result.id);

        //        return sNumeroMes;
        //    }
        //}
        public string BuscaDescripcioTipoActualizacion(string stipo_act)
        {
            var sSql = "Select descripcio from bdSoftpad_ctr_tablas.TA43 where codigo=@FiltroTipo_act ";
            using (var connection = new MySqlConnection(_connectionString))
            {
                var resultado = connection.QueryFirst(sSql, new { FiltroTipo_act = stipo_act });
                return resultado.descripcio;
            }
        }
        public string BuscaDescripcioVersionoActualizacion(string svers_act)
        {
            var sSql = "Select descripcio from bdSoftpad_ctr_tablas.TA45 where codigo=@FiltroVers_act ";
            using (var connection = new MySqlConnection(_connectionString))
            {
                var resultado = connection.QueryFirst(sSql, new { FiltroVers_act = svers_act });
                return resultado.descripcio;
            }
        }
        public string BuscaNombreEmpleado(string scod_usuario)
        {
            var sSql = "Select concat(rtrim(nombres),' ',rtrim(apellidos)) as nombres from usuarios where cod_usuario=@FiltroCod_usuario ";
            using (var connection = new MySqlConnection(_connectionString))
            {
                var resultado = connection.QueryFirst(sSql, new { FiltroCod_usuario = scod_usuario });
                return resultado.nombres;
            }
        }

        public bool EvaluaActualizacionEnviada(int iId)
        {
            if (iId > 0)
            {
                var sSql = "Select enviado1 from Actualizacion where Id=@FiltroId ";
                using (var connection = new MySqlConnection(_connectionString))
                {
                    var resultado = connection.QueryFirst(sSql, new { FiltroId = iId });
                    return resultado.enviado1;
                }
            }
            else
                return false;
        }

        public List<Actualizacion> BuscaUltimaActualizacionXTipo(string sTipo_act, int iId)
        {
            var sSql = "select * from actualizacion where tipo_act=@FiltroTipo_act and id<>@FiltroId order by fech_crea desc limit 1";
            using (var connection = new MySqlConnection(_connectionString))
            {
                return connection.Query<Actualizacion>(sSql, new { FiltroTipo_act = sTipo_act, FiltroId= iId }).ToList();
            }
        }
    }
}
