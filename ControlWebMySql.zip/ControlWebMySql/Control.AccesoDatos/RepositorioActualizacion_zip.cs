﻿using Control.Entidades;
using Control.Interfaz;
using Dapper;
using System;
using System.Collections.Generic;
using MySql.Data.MySqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Control.AccesoDatos
{
    public class RepositorioActualizacion_zip : Repositorio<Actualizacion_zip>,IRepositorioActualizacion_zip
    {
        public RepositorioActualizacion_zip(string connectionString) : base(connectionString)
        {
        }

        public List<Actualizacion_zip> ConsultaActualizacion_zipXActId(int iActId)
        {
            var sComandoSql = "select id, ActId, arch_zip from actualizacion_zip where ActId=@FiltroByActId";
            using (var connection = new MySqlConnection(_connectionString))
            {
                return connection.Query<Actualizacion_zip>(sComandoSql, new { FiltroByActId = iActId }).ToList();
            }
        }

        public List<Actualizacion_zip> ConsultaActualizacion_zipXArchivo(int iActID, string sArchivo)
        {
            var sComandoSql = "select id, ActId, arch_zip from actualizacion_zip where ActId=@FiltroByActId and arch_zip=@FiltroByArch_zip";
            using (var connection = new MySqlConnection(_connectionString))
            {
                return connection.Query<Actualizacion_zip>(sComandoSql, new { FiltroByActId = iActID, FiltroByArch_zip = sArchivo }).ToList();
            }
        }
    }
}
