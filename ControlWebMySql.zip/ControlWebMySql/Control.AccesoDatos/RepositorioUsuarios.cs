﻿using Control.Entidades;
using Control.Interfaz;
using Dapper;
using Dapper.Contrib.Extensions;
using System;
using System.Collections.Generic;
using MySql.Data.MySqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Control.AccesoDatos
{
    public class RepositorioUsuarios : Repositorio<Usuarios>, IRepositorioUsuarios
    {
        public RepositorioUsuarios(string connectionString) : base(connectionString)
        {
        }

        public List<Usuarios> ObtenerUsuarioPorCodigo(string sCodigo)
        {
            var sSql = "Select cod_usuario,correo,clave,nombres,apellidos,roles from usuarios where cod_usuario=@FiltroCodigo ";
            using (var connection = new MySqlConnection(_connectionString))
            {
                var result = connection.Query<Usuarios>(sSql, new { FiltroCodigo = sCodigo }).ToList();
                return result;
            }
        }

        public List<Usuarios> ObtenerUsuarioPorLogin(string login, string password)
        {
            var sSql = "Select cod_usuario,correo,clave,nombres,apellidos,roles from usuarios where cod_usuario=@FiltroLogin and clave=@FiltroPassword ";
            using (var connection = new MySqlConnection(_connectionString))
            {
                //var parameters = new { FirstName = "Maria", LastName = "Apellido" };
                var result = connection.Query<Usuarios>(sSql, new { FiltroLogin = login, FiltroPassword = password }).ToList();
                return result;
            }
        }
    }
}
