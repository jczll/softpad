﻿using Control.Entidades;
using Control.Interfaz;
using Dapper;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Control.AccesoDatos
{
    public class RepositorioVisitas : Repositorio<Visitas>, IRepositorioVisitas
    {
        public RepositorioVisitas(string connectionString) : base(connectionString)
        {
        }
        public List<Consulta_Visitas> ConsultaVisitasPendientes(string sNro_visita, string sCod_cli) /*, DateTime dFech_visita)*/
        {
            var sSql = "Select vis.nro_visita,vis.fech_crea,vis.cod_emp as ingresadox,vis.tipo_visita,tipo_destino,vis.serv_mensual,";
                sSql = sSql + "(Select estado from visita_incidencia where id_visitas = vis.id and estado<>'00' order by fech_incidencia desc limit 1) as estado,";
                sSql = sSql + "(Select cod_emp from visita_incidencia where id_visitas = vis.id and estado<>'00' order by fech_incidencia desc limit 1) as asignadoa,";
                sSql = sSql + "(Select observac from visita_incidencia where id_visitas = vis.id and estado<>'00' order by fech_incidencia desc limit 1) as observac,";
                sSql = sSql + "(Select fech_visita from visita_incidencia where id_visitas = vis.id and estado<>'00' order by fech_incidencia desc limit 1) as fech_visita,";
                sSql = sSql + "cli.raz_soc_cli as des_cliente,ref.raz_soc_refer as des_referido";
                sSql = sSql + "from visita ";
                sSql = sSql + "left join cliente cli on cli.cod_cli = vis.cod_cli";
                sSql = sSql + "left join referido ref on ref.cod_referido = vis.cod_referido";
            var sWhere = "where (Select estado from visita_incidencia where id_visitas = vis.id order by fech_incidencia desc limit 1) not in('05','04')";
            if (!string.IsNullOrWhiteSpace(sNro_visita))
                sWhere = sWhere + "and vis.Nro_visita='" + sNro_visita.Trim() + "'";
            if (!string.IsNullOrWhiteSpace(sCod_cli))
                sWhere = sWhere + " and vis.Cod_cli like '%" + sCod_cli.Trim() + "%'";
            //if (!string.IsNullOrWhiteSpace(Convert.ToString(dFech_visita)))
            //    sWhere = "(Select year(fech_visita) from visita_incidencia where nro_visita=vis.nro_visita order by fech_incidencia desc limit 1)=" + subs(Convert.ToString(dFech_visita), 7, 4);
            //    sWhere = sWhere + " and (Select month(fech_visita) from visita_incidencia where nro_visita=vis.nro_visita order by fech_incidencia desc limit 1)=" + alltrim(str(val(subs(Convert.ToString(dFech_visita), 4, 2))));
            //    sWhere = sWhere + " and (Select day(fech_visita) from visita_incidencia where nro_visita=vis.nro_visita order by fech_incidencia desc limit 1)=" + alltrim(str(val(left(Convert.ToString(dFech_visita), 2))));
            sSql = sSql + sWhere + " order by fech_crea desc";

            using (var connection = new MySqlConnection(_connectionString))
            {
                var result = connection.Query<Consulta_Visitas>(sSql).ToList();
                return result;
            }
        }
    }
}
