﻿using Control.Entidades;
using Control.Interfaz;
using Dapper;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Control.AccesoDatos
{
    public class RepositorioVisitas : Repositorio<Visitas>, IRepositorioVisitas
    {
        public RepositorioVisitas(string connectionString) : base(connectionString)
        {
        }
        public List<Consulta_Visitas> ConsultaVisitasPendientes(string sNro_visita, string sCod_cli, string sFech_visita)
        {
            var sSql = "Select vis.id,vis.nro_visita,vis.fech_crea,vis.cod_emp as ingresadox,";
                sSql = sSql + "(Select descripcio from bdsoftpad_ctr_tablas.ta20 where codigo = vis.tipo_visita) as des_visita,";
                sSql = sSql + "(Select(Select descripcio from bdsoftpad_ctr_tablas.ta21 where codigo = visI.estado) as des_visita from visitas_incidencia visI where id_visitas = vis.id and estado<>'00' order by fech_incidencia desc limit 1) as detalle_estado,";
                sSql = sSql + "(Select estado from visitas_incidencia where id_visitas = vis.id and estado<>'00' order by fech_incidencia desc limit 1) as estado,";
                sSql = sSql + "(Select cod_emp from visitas_incidencia where id_visitas = vis.id and estado<>'00' order by fech_incidencia desc limit 1) as asignadoa,";
                sSql = sSql + "(Select observac from visitas_incidencia where id_visitas = vis.id and estado<>'00' order by fech_incidencia desc limit 1) as observac,";
                sSql = sSql + "(Select fech_visita from visitas_incidencia where id_visitas = vis.id and estado<>'00' order by fech_incidencia desc limit 1) as fech_visita,";
                sSql = sSql + "cli.raz_soc_cli as des_cliente,ref.raz_soc_refer as des_referido ";
                sSql = sSql + "from visitas vis ";
                sSql = sSql + "left join cliente cli on cli.cod_cli = vis.cod_cli ";
                sSql = sSql + "left join referido ref on ref.cod_referido = vis.cod_referido ";
            var sWhere = "where (Select estado from visitas_incidencia where id_visitas = vis.id order by fech_incidencia desc limit 1) not in('05','04')";
            if (!string.IsNullOrWhiteSpace(sNro_visita))
                sWhere = "where vis.Nro_visita='" + sNro_visita.Trim() + "'";
            if (!string.IsNullOrWhiteSpace(sCod_cli))
                sWhere = "where vis.Cod_cli like '%" + sCod_cli.Trim() + "%'";
            if (!string.IsNullOrWhiteSpace(sFech_visita))
            {
                sWhere = "where (Select left(fech_visita, 10) from visitas_incidencia where id_visitas = vis.id order by fech_incidencia desc limit 1)= '" + sFech_visita + "'";
                sSql = sSql + sWhere + " order by 8 desc";
            }
            else
               sSql = sSql + sWhere + " order by fech_crea desc";

            using (var connection = new MySqlConnection(_connectionString))
            {
                var result = connection.Query<Consulta_Visitas>(sSql).ToList();
                return result;
            }
        }
        public bool EliminarIncidencias(int id_visitas)
        {
            var sSqlSelect = "select * from visitas_incidencia where id_visitas=@FiltroId_visitas";
            var sSqlDelete = "delete from visitas_incidencia where id_visitas=@FiltroId_visitas";

            using (var connection = new MySqlConnection(_connectionString))
            {
                var ResultDelete = connection.Execute(sSqlDelete, new { FiltroId_visitas = id_visitas });
                var ResultSelect = connection.Query<Visitas_incidencia>(sSqlSelect, new { FiltroId_visitas = id_visitas }).ToList();
                if (ResultSelect.Count > 0)
                    return false;
                else
                    return true;
            }
        }
        //public string DatoIncidenciaVisita(int id, string sDatoIncidencia)
        //{
        //    var sSql = "Select correl, fech_visita from visita_incidencia where id_visita = "0006146"  order by fech_incidencia desc limit 1"

        //}
    }
}
