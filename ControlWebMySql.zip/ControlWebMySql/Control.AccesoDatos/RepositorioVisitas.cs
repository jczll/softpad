﻿using Control.Entidades;
using Control.Interfaz;
using Dapper;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Control.AccesoDatos
{
    public class RepositorioVisitas : Repositorio<Visitas>, IRepositorioVisitas
    {
        public RepositorioVisitas(string connectionString) : base(connectionString)
        {
        }
        public List<Consulta_Visitas> ConsultaVisitasPendientes(string sNro_visita, string sCod_cli, string sFech_visita)
        {
            var sWhere = "";
            var sSql = "Select vis.id,vis.nro_visita,vis.fech_crea,vis.cod_emp as ingresadox,";
                sSql = sSql + "concat((Select rtrim(descripcio) from bdsoftpad_ctr_tablas.ta20 where codigo = vis.tipo_visita),' ',(select rtrim(descripcio) from bdsoftpad_ctr_tablas.ta22 where codigo = vis.serv_mensual),' DEL 20',left(vis.nro_visita, 2)) as des_visita,";
                sSql = sSql + "(Select (Select descripcio from bdsoftpad_ctr_tablas.ta21 where codigo = visI.estado) as des_visita from visitas_incidencia visI where id_visitas = vis.id and estado<>'00' order by fech_incidencia desc limit 1) as detalle_estado,";
                sSql = sSql + "(Select estado from visitas_incidencia where id_visitas = vis.id and estado<>'00' order by fech_incidencia desc limit 1) as estado,";
                sSql = sSql + "(Select cod_emp from visitas_incidencia where id_visitas = vis.id and estado<>'00' order by fech_incidencia desc limit 1) as asignadoa,";
                sSql = sSql + "(Select observac from visitas_incidencia where id_visitas = vis.id and estado<>'00' order by fech_incidencia desc limit 1) as observac,";
                sSql = sSql + "(Select fech_visita from visitas_incidencia where id_visitas = vis.id and estado<>'00' order by fech_incidencia desc limit 1) as fech_visita,";
                sSql = sSql + "cli.raz_soc_cli as des_cliente,ref.raz_soc_refer as des_referido ";
                sSql = sSql + "from visitas vis ";
                sSql = sSql + "left join cliente cli on cli.cod_cli = vis.cod_cli ";
                sSql = sSql + "left join referido ref on ref.cod_referido = vis.cod_referido ";
            if (!string.IsNullOrWhiteSpace(sNro_visita))
                sWhere = "where vis.Nro_visita='" + sNro_visita.Trim() + "'";
            else
            {
                if (!string.IsNullOrWhiteSpace(sCod_cli))
                    sWhere = "where vis.Cod_cli like '%" + sCod_cli.Trim() + "%'";
                else
                {
                    if (!string.IsNullOrWhiteSpace(sFech_visita))
                    {
                        sWhere = "where (Select left(fech_visita, 10) from visitas_incidencia where id_visitas = vis.id order by fech_incidencia desc limit 1)= '" + sFech_visita + "'";
                    }
                    else
                    {
                        sWhere = "where (Select estado from visitas_incidencia where id_visitas = vis.id order by fech_incidencia desc limit 1) not in('05','04')";
                    }
                }
            }
            if (!string.IsNullOrWhiteSpace(sFech_visita))
               sSql = sSql + sWhere + " order by 8 desc";
            else
               sSql = sSql + sWhere + " order by fech_crea desc";
            using (var connection = new MySqlConnection(_connectionString))
            {
                var result = connection.Query<Consulta_Visitas>(sSql).ToList();
                return result;
            }
        }
        public bool EliminaIncidencia_Visitas(int id_visitas)
        {
            var sSqlSelect = "select * from visitas_incidencia where id_visitas=@FiltroId_visitas";
            var sSqlDelete = "delete from visitas_incidencia where id_visitas=@FiltroId_visitas";

            using (var connection = new MySqlConnection(_connectionString))
            {
                var ResultDelete = connection.Execute(sSqlDelete, new { FiltroId_visitas = id_visitas });
                var ResultSelect = connection.Query<Visitas_incidencia>(sSqlSelect, new { FiltroId_visitas = id_visitas }).ToList();
                if (ResultSelect.Count > 0)
                    return false;
                else
                    return true;
            }
        }
        public bool AgregaIncidencia_Visita(long iId_visitas, string sEstado, string sCod_emp, string sFech_visita)
        {
            sFech_visita = sFech_visita.Substring(6, 4) + "-" + sFech_visita.Substring(3, 2) + "-" + sFech_visita.Substring(0, 2) + " " + sFech_visita.Substring(11, 8);                
            var sSqlInsert = @"insert into visitas_incidencia(id_visitas,fech_visita,cod_emp,estado,observac) 
                            values(@ValorId_visitas,@ValorFech_visita,@ValorCod_emp,@ValorEstado,@ValorObservac)";          
            using (var connection = new MySqlConnection(_connectionString))
            {
                var resultado = connection.QueryFirst("select descripcio from bdsoftpad_ctr_tablas.ta21 where codigo=@FiltroEstado", new { FiltroEstado = sEstado });
                if (!string.IsNullOrWhiteSpace(resultado.descripcio))
                {
                    var NuevoId = connection.Execute(sSqlInsert, new { ValorId_visitas = iId_visitas, ValorFech_visita = sFech_visita, ValorCod_emp = sCod_emp, ValorEstado = sEstado, ValorObservac=resultado.descripcio });
                    if (NuevoId > 0)
                        return true;
                    else
                        return false;
                }
                else
                    return false;
            }
        }
        public string DatoIncidenciaVisita(int iId, string sCampo_Resultado)
        {
            var sSql = "Select " + sCampo_Resultado + " as campo_resultado from visitas_incidencia where id_visitas = @FiltroId order by fech_incidencia desc limit 1";
            using (var connection = new MySqlConnection(_connectionString))
            {
                var resultado = connection.QueryFirst(sSql, new { FiltroId = iId });
                return Convert.ToString(resultado.campo_resultado);
            }
        }
    }
}
