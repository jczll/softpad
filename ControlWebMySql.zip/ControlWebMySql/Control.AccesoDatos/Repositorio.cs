﻿using Control.Interfaz;
using Dapper.Contrib.Extensions;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Control.AccesoDatos
{
    public class Repositorio<Entidad> :IRepositorio<Entidad> where Entidad : class
    {
        protected readonly string _connectionString;

        public Repositorio(string connectionString)
        {
            _connectionString = connectionString;
            SqlMapperExtensions.TableNameMapper = (type) => { return $"{type.Name}"; };
        }

        public bool Delete(Entidad entidad)
        {
            using (var connection = new MySqlConnection(_connectionString))
            {
                return connection.Delete(entidad);
            }
        }

        public Entidad Get(long id)
        {
            using (var connection = new MySqlConnection(_connectionString))
            {
                return connection.Get<Entidad>(id);
            }
        }

        public List<Entidad> GetList()
        {
            using (var connection = new MySqlConnection(_connectionString))
            {
                return connection.GetAll<Entidad>().ToList();
            }
        }

        public long Insert(Entidad entidad)
        {
            using (var connection = new MySqlConnection(_connectionString))
            {
                return connection.Insert(entidad);
            }
        }

        public bool Update(Entidad entidad)
        {
            using (var connection = new MySqlConnection(_connectionString))
            {
                return connection.Update(entidad);
            }
        }
        public DataSet ConsultaDatos(string sConsulta)
        {
            using (var cn = new MySqlConnection(_connectionString))
            {
                cn.Open();
                using (var cmd = new MySqlCommand(sConsulta, cn))
                {
                    MySqlDataAdapter dataAdapter = new MySqlDataAdapter(cmd);
                    DataSet dataSet = new DataSet();
                    dataAdapter.Fill(dataSet);
                    return dataSet;
                }
            }
        }
    }
}
