﻿using Control.Entidades;
using Control.Interfaz;
using Dapper;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Control.AccesoDatos
{
    public class RepositorioDocumento : Repositorio<Documento>, IRepositorioDocumento
    {
        public RepositorioDocumento(string connectionString) : base(connectionString)
        {

        }
        public Documento ValidaGeneraMantenMensual(string sCod_cli, string sPeriod_Contrato, string sContrato_correl, string sMes, string sAño)
        {
            var sComandoSql = "";
            if (sPeriod_Contrato == "M")
            {
                sComandoSql = @"
                Select tipo_doc, nro_documento from documento_detalle docd 
                    where cod_cli= @FiltroByCod_cli and año_serv= @FiltroByAño and mes_serv= @FiltroByMes 
                          and (Select estado from documento_incidencia where tipo_doc=docd.tipo_doc and nro_documento=docd.nro_documento order by fech_incidencia desc limit 1) not in('07','01')
                          and not exists(select nro_doc_asoc from documento where tipo_doc='07' and nro_doc_asoc=docd.nro_documento and stot_docum=docd.simporte)";
            }
            else
            {
                sComandoSql = @"
                Select tipo_doc,nro_documento from documento_detalle docd 
                   where cod_cli= @FiltroByCod_cli and contrato_correl= @FiltroByContrato_correl 
                         and (Select estado from documento_incidencia where tipo_doc=docd.tipo_doc and nro_documento=docd.nro_documento order by fech_incidencia desc limit 1) not in('07','01')
                         and not exists(select nro_doc_asoc from documento where tipo_doc='07' and nro_doc_asoc=docd.nro_documento and stot_docum=docd.simporte)";
            }
            using (var connection = new MySqlConnection(_connectionString))
            {
                var resultado = connection.QueryFirst<Documento>(sComandoSql, new { FiltroByCod_cli = sCod_cli, FiltroByContrato_correl = sContrato_correl, FiltroByMes = sMes, FiltroByAño = sAño });
                return resultado;
            }
        }
        public Documento_Saldo GeneraConsultaSaldo(string sCod_cli, string sMoneda, string sTipo_doc, string sNro_documento)
        {
            var sComandoSql = "Select nro_documento,tipo_doc,sum(saldo) as saldo ";
            sComandoSql = sComandoSql + "from (";
            // Primera Consulta(Facturas)
            sComandoSql = sComandoSql + "select nro_documento,tipo_doc," + sMoneda + "tot_docum" + " as saldo ";
            sComandoSql = sComandoSql + "from documento doc ";
            if (!string.IsNullOrEmpty(sTipo_doc))
            {
                sComandoSql = sComandoSql + "where tipo_doc=@FiltroByTipo_doc and nro_documento=@FiltroByNro_documento ";
                sComandoSql = sComandoSql + "and (Select estado from documento_incidencia where tipo_doc=doc.tipo_doc and nro_documento=doc.nro_documento order by fech_incidencia desc limit 1) in('04','05','06','08','09') ";
            }
            else
            {
                sComandoSql = sComandoSql + "where cod_cli=@FiltroByCod_cli and moneda=?pMoneda and doc.tipo_doc<>'07' ";
                sComandoSql = sComandoSql + "and (Select estado from documento_incidencia where tipo_doc=doc.tipo_doc and nro_documento=doc.nro_documento order by fech_incidencia desc limit 1) in('04','05','08','09') ";
            }
            // Clausula de Union con la segunda consulta
            sComandoSql = sComandoSql + "union all ";
            // Segunda Consulta(Notas de Credito)
            sComandoSql = sComandoSql + "select doc.nro_doc_asoc as nro_documento,'01' as tipo_doc,(doc." + sMoneda + "tot_docum*-1) as saldo ";
            sComandoSql = sComandoSql + "from documento doc ";
            if (!string.IsNullOrEmpty(sTipo_doc))
            {
                sComandoSql = sComandoSql + "where doc.tipo_doc='07' and doc.nro_doc_asoc=@FiltroByNro_documento ";
                sComandoSql = sComandoSql + "and (Select estado from documento_incidencia where tipo_doc='01' and nro_documento=doc.nro_doc_asoc order by fech_incidencia desc limit 1) in('04','05','06','08','09') ";
            }
            else
            {
                sComandoSql = sComandoSql + "where doc.cod_cli=@FiltroByCod_cli and doc.moneda=@FiltroByMoneda and doc.tipo_doc='07' ";
                sComandoSql = sComandoSql + "and (Select estado from documento_incidencia where tipo_doc='01' and nro_documento=doc.nro_doc_asoc order by fech_incidencia desc limit 1) in('04','05','08','09') ";
            }
            // Clausula de Union con la tercera consulta
            sComandoSql = sComandoSql + "union all ";
            //Tercera Consulta(Vouchers de Ingreso)
            sComandoSql = sComandoSql + "Select voud.nro_documento,voud.tipo_doc,(voud." + sMoneda + "importe*-1) as saldo ";
            sComandoSql = sComandoSql + "from voucher_detalle voud ";
            sComandoSql = sComandoSql + "left join voucher vou on vou.tipo_voucher=voud.tipo_voucher and vou.nro_voucher=voud.nro_voucher ";
            if (!string.IsNullOrEmpty(sTipo_doc))
            {
                sComandoSql = sComandoSql + "where voud.tipo_doc=@FiltroByTipo_doc and voud.nro_documento=@FiltroByNro_documento ";
                sComandoSql = sComandoSql + "and (Select estado from documento_incidencia where tipo_doc=voud.tipo_doc and nro_documento=voud.nro_documento order by fech_incidencia desc limit 1) in('04','05','06','08','09') ";
            }
            else
            {
                sComandoSql = sComandoSql + "where voud.cod_cli=@FiltroByCod_cli and vou.moneda=@FiltroByMoneda ";
                sComandoSql = sComandoSql + "and (Select estado from documento_incidencia where tipo_doc=voud.tipo_doc and nro_documento=voud.nro_documento order by fech_incidencia desc limit 1) in('04','05','08','09') ";
            }
            // Final del Archivo Principal Generado por las Dos Consultas
            sComandoSql = sComandoSql + "     ) as A group by nro_documento,tipo_doc";
            using (var connection = new MySqlConnection(_connectionString))
            {
                var resultado = connection.QuerySingle<Documento_Saldo>(sComandoSql, new { FiltroByCod_cli = sCod_cli, FiltroByMoneda = sMoneda, FiltroByTipo_doc = sTipo_doc, FiltroByNro_documento = sNro_documento });
                return resultado;
            }
        }
    }
}
